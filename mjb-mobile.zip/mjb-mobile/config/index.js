// see http://vuejs-templates.github.io/webpack for documentation.
var path = require('path')
var fs = require('fs')
var chalk = require('chalk')
var cmd = require('./parse-pack-cmd')(process.argv)

function getPackageCfg(envConfig, cmd) {
  var publish = envConfig.defaultCfg.packageCfg.publish;
  var currentEnvName = cmd.env || envConfig.currentEnv;
  var currentEnv = envConfig[currentEnvName] || {};
  var packageCfg = {};
  var defaultPublish = { "packageName": "美捷报2.0", "version": "1.0.1", "build": 1 };
  packageCfg.hybridAppPlatform = currentEnv.hybridAppPlatform || envConfig.defaultCfg.hybridAppPlatform;
  packageCfg.identifier = currentEnv.identifier || envConfig.defaultCfg.meixin.identifier;
  packageCfg.currentEnvName = currentEnvName;
  packageCfg.envName = cmd.envName;
  var curEnvPkgCfg = currentEnv.packageCfg || {};
  packageCfg.theme = cmd.theme || curEnvPkgCfg.theme || 'defaultTheme';
  packageCfg.releaseNote = curEnvPkgCfg.releaseNote || 'MSD';
  packageCfg.isDebug = curEnvPkgCfg.isDebug || 1;
  packageCfg.publish = curEnvPkgCfg.publish;
  packageCfg.name = (publish[curEnvPkgCfg.publish] || defaultPublish).packageName;
  packageCfg.version = (publish[curEnvPkgCfg.publish] || defaultPublish).version;
  packageCfg.build = (publish[curEnvPkgCfg.publish] || defaultPublish).build;
  return packageCfg;
}

function updateEnvConfig() {
  return new Promise((resolve, reject) => {
    fs.readFile(path.resolve(__dirname, '../EnvConfig.json'), function(err, data) {
      if (err) reject(err);
      var envConfig = data.toString();
      envConfig = JSON.parse(envConfig);
      var packageCfg = getPackageCfg(envConfig, cmd);
      var version = packageCfg.version;
      var build = packageCfg.build;
      var publish = envConfig.defaultCfg.packageCfg.publish[packageCfg.publish];
      if (cmd.increase) {
        var increaseArr = cmd.increase.map(i => parseInt(i));
        publish.version = version.split('.').map((item, index) => parseInt(item) + increaseArr[index]).join('.');
        publish.build = parseInt(build) + 1;
      } else if (cmd.decrease) {
        var decreaseArr = cmd.decrease.map(i => parseInt(i));
        publish.version = version.split('.').map((item, index) => parseInt(item) - decreaseArr[index] > 0 ? parseInt(item) - decreaseArr[index] : 0).join('.');
        publish.build = parseInt(build) - 1 > 0 ? parseInt(build) - 1 : 0;
      }
      envConfig = JSON.stringify(envConfig, null, 2);
      fs.writeFile(path.resolve(__dirname, '../EnvConfig.json'), envConfig, function(err){
        if (err) reject(err);
        console.log(chalk.green('\n EnvConfig.json has been updated... \n'));
        resolve();
      })
    })
  })
}

function getZipName() {
  var packageCfg = getPackageCfg(require('../EnvConfig.json'), cmd);
  var checkTime = i => i < 10 ? `0${i}` : i;
  var d = new Date();
  var year = d.getFullYear();
  var month = checkTime(d.getMonth() + 1);
  var day = checkTime(d.getDate());
  var hour = checkTime(d.getHours());
  var minute = checkTime(d.getMinutes());
  return `${packageCfg.name}-${packageCfg.version}-${packageCfg.envName}-${year}${month}${day}${hour}${minute}.zip`;
}

function createCubeModule(envConfig) {
  var packageCfg = getPackageCfg(envConfig, cmd);
  return {
    dependencies: {},
    hidden: false,
    autoDownload: true,
    relatesTo: [],
    dependsOn: [],
    dependsTo: [],
    releaseNote: packageCfg.releaseNote,
    build: packageCfg.build,
    name: packageCfg.name,
    identifier: packageCfg.identifier,
    action: '',
    index: 'index.html',
    isPcTest: 0,
    isDebug: packageCfg.isDebug,
    version: packageCfg.version,
    testVersion: packageCfg.version
  }
}

function getPackageCfgWrap(envConfig) {
  return getPackageCfg(envConfig, cmd);
}

module.exports = {
  build: {
    env: require('./prod.env'),
    index: path.resolve(__dirname, '../dist/index.html'),
    assetsRoot: path.resolve(__dirname, '../dist'),
    assetsSubDirectory: 'static',
    assetsPublicPath: './',
    productionSourceMap: false,
    // Gzip off by default as many popular static hosts such as
    // Surge or Netlify already gzip all static assets for you.
    // Before setting to `true`, make sure to:
    // npm install --save-dev compression-webpack-plugin
    productionGzip: false,
    productionGzipExtensions: ['js', 'css'],
    // Run the build command with an extra argument to
    // View the bundle analyzer report after build finishes:
    // `npm run build --report`
    // Set to `true` or `false` to always turn it on or off
    bundleAnalyzerReport: process.env.npm_config_report,
    updateEnvConfig,
    getZipName,
    createCubeModule,
    getPackageCfgWrap,
    cmd
  },
  dev: {
    env: require('./dev.env'),
    port: 8080,
    autoOpenBrowser: false,
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    proxyTable: {},
    // CSS Sourcemaps off by default because relative paths are "buggy"
    // with this option, according to the CSS-Loader README
    // (https://github.com/webpack/css-loader#sourcemaps)
    // In our experience, they generally work as expected,
    // just be aware of this issue when enabling this option.
    cssSourceMap: false
  }
}
