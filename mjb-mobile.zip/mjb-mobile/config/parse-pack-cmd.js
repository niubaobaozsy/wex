var program = require('commander');

function list(val) {
  return val.split('.');
}

module.exports = function (argv) {
  program
    .option('-e, --env [type]', 'Pick a specified type of environment configuration in EnvConfig.json', '')
    .option('-n, --env-name [type]', 'Set the name of current environment', 'sit')
    .option('-t, --theme [type]', 'Pick a specified kind of theme', '')
    .option('-i, --increase <items>','Increase version',list)
    .option('-d, --decrease <items>','Decrease version',list)
    .option('-l, --less', 'Generate less message for EnvConfig.json')
    .option('--no-envconfig', 'No generate EnvConfig.json')
    .option('--no-cubemodule', 'No generate CubeModule.json')
    .parse(argv);
  if (program.env) console.log(' Set current environment : %s', program.env);
  if (program.envName) console.log(' Set current environment name : %s', program.envName);
  if (program.theme) console.log(' Set app theme : %s', program.theme);
  if (program.increase) console.log(' Increase the version with %j', program.increase);
  if (program.decrease) console.log(' Decrease the version with %j', program.decrease);
  if (program.less) {
    console.log(' Generate less message for EnvConfig.json');
  } else {
    console.log(' Generate full message for EnvConfig.json');
  }
  if (program.envconfig) {
    console.log(' Generate EnvConfig.json');
  } else {
    console.log(' No generate EnvConfig.json');
  }
  if (program.cubemodule) {
    console.log(' Generate CubeModule.json');
  } else {
    console.log(' No generate CubeModule.json');
  }
  return program;
}
