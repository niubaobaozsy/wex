module.exports = {
  configureWebpack: config => {
    if (process.env.NODE_ENV === 'production') {
    	config.plugins.push([
      new MyAwesomeWebpackPlugin()
    ])
      // mutate config for production...
    } else {
      // mutate for development...
    }
  }
}