# 美捷报移动端前端工程文档

日期|版本|作者|修改内容|评审号|变更控制号|发布日期
:-:|:-:|:-:|:-:|:-:|:-:|:-:
2018-06-30|1.0|庄裕浩|初稿|--|--|--

## 工程结构
美捷报移动端采用vue-cli进行构建，项目的工程结构如下所示，主要包括打包构建的配置脚本以及项目的源码，其中工程源码放置于```src```文件夹内，根据不同功能分别放在components/router/store等目录下，每个目录又根据业务模块进行划分，分别对应APP上每一个比较独立的业务模块。
``` bash
tree -I 'node_modules|dist|*.zip|.git|.DS_Store|.gitkeep' -a -L 3 --dirsfirst -o ./dirTree

.
├── build ------------------------------------------- 和打包构建相关的文件
│   ├── build.js ------------------------------------ 用于构建的脚本
│   ├── dev-client.js ------------------------------- 开发环境客户端脚本
│   ├── dev-server.js ------------------------------- 开发环境服务器脚本
│   ├── utils.js ------------------------------------ 用于构建项目的通用脚本
│   ├── vue-loader.conf.js -------------------------- vue-loader配置
│   ├── webpack.base.conf.js ------------------------ webpack公共配置
│   ├── webpack.dev.conf.js ------------------------- webpack开发环境配置
│   ├── webpack.prod.conf.js ------------------------ webpack生产环境配置
│   └── webpack.test.conf.js ------------------------ webpack测试环境配置
├── config ------------------------------------------ 和打包构建相关的文件
│   ├── dev.env.js ---------------------------------- webpack开发环境配置
│   ├── index.js ------------------------------------ webpack打包配置文件
│   ├── parse-pack-cmd.js --------------------------- 打包命令解析
│   ├── prod.env.js --------------------------------- webpack开发环境配置
│   └── test.env.js --------------------------------- webpack测试环境配置
├── datetime ---------------------------------------- fix VUX datetime组件的缺陷
├── src --------------------------------------------- 工程源码的主要目录
│   ├── assets -------------------------------------- 资源文件夹
│   │   ├── css ------------------------------------- 项目的CSS资源
│   │   ├── fonts ----------------------------------- 字体文件
│   │   └── images ---------------------------------- 图片资源
│   ├── components ---------------------------------- vue组件
│   │   ├── activity -------------------------------- 我的足迹页面组件
│   │   ├── common ---------------------------------- 公共组件
│   │   ├── fee ------------------------------------- 费用页面组件
│   │   ├── login ----------------------------------- 登录模块组件
│   │   ├── mine ------------------------------------ 「我的」页面组件
│   │   ├── report ---------------------------------- 报表页面组件
│   │   └── travel ---------------------------------- 商旅页面组件
│   ├── js ------------------------------------------ 项目公共js
│   │   └── util.js --------------------------------- 提供通用的js函数
│   ├── platform ------------------------------------ 平台适配
│   │   ├── index.js -------------------------------- 用于导入在不同平台上使用的底座文件
│   │   ├── meixin-api.js --------------------------- 美信底座接口
│   │   └── wechat-sdk.js  -------------------------- 微信底座接口
│   ├── router -------------------------------------- vue router
│   │   ├── activity.js ----------------------------- 我的足迹router配置
│   │   ├── fee.js ---------------------------------- 费用router配置
│   │   ├── index.js -------------------------------- router配置文件
│   │   ├── mine.js --------------------------------- 「我的」router配置
│   │   ├── report.js  ------------------------------ 报表router配置
│   │   └── travel.js ------------------------------- 商旅router配置
│   ├── store --------------------------------------- vuex store
│   │   ├── activity -------------------------------- 我的足迹模块store
│   │   ├── approve --------------------------------- 审批模块store
│   │   ├── common ---------------------------------- 公共模块store
│   │   ├── login ----------------------------------- 登录模块store
│   │   ├── mine ------------------------------------ 「我的」模块store
│   │   ├── myApply --------------------------------- 申请模块store
│   │   ├── myInvoice ------------------------------- 发票模块store
│   │   ├── myReimburse ----------------------------- 报销模块store
│   │   ├── report ---------------------------------- 报表模块store
│   │   ├── travel ---------------------------------- 商旅模块store
│   │   ├── http.js --------------------------------- 封装axios，用于http(s)请求
│   │   ├── index.js -------------------------------- store配置文件
│   │   └── mutations.js ---------------------------- mutations配置文件
│   ├── App.vue ------------------------------------- APP入口组件
│   └── main.js ------------------------------------- vue入口文件
├── static ------------------------------------------ 工程静态文件
│   ├── menuConfig ---------------------------------- 个性菜单配置文件
│   │   ├── defaultMenu.json ------------------------ 默认菜单配置
│   │   ├── devMenu.json ---------------------------- 开发环境菜单配置
│   │   ├── inforeMenu.json ------------------------- infore环境菜单配置
│   │   └── ofilmMenu.json -------------------------- 欧菲环境菜单配置
│   ├── bgm.mp3 ------------------------------------- 一些静态资源
│   ├── city.json ----------------------------------- 一些静态资源
│   └── ringtone.mp3 -------------------------------- 一些静态资源
├── test -------------------------------------------- 自动测试脚本
├── .babelrc ---------------------------------------- Babel配置文件
├── .editorconfig ----------------------------------- 编辑器配置文件
├── .eslintignore ----------------------------------- eslint配置文件
├── .eslintrc.js ------------------------------------ eslint配置文件
├── .gitignore -------------------------------------- 不解释
├── .postcssrc.js ----------------------------------- postcss load配置文件
├── EnvConfig.json ---------------------------------- 环境配置文件
├── README.md --------------------------------------- 不解释
├── debuggap.js ------------------------------------- debuggap调试脚本
├── index.html -------------------------------------- 单页应用挂载页面
├── package-lock.json ------------------------------- 不解释
├── package.json ------------------------------------ 不解释
└── vue.config.js ----------------------------------- vue load配置文件

39 directories, 70 files

```
## 环境安装
确保已经安装nodejs，如果版本太低请安装最新版本node。针对国内环境使用```npm```速度太慢的问题，可以使用```cnpm```替代。开发工具建议使用 Visual Studio Code，并安装 EditorConfig for VS Code 和 Vetur 插件。
``` bash
# 安装项目依赖
npm install

# 启动开发服务器，支持hot reload，通过localhost:8080访问和调试
npm run dev

# 使用默认配置进行打包
npm run build

# 使用默认配置进行打包并查看打包分析报告
npm run build --report

# 运行单元测试
npm run unit

# 运行单元测试 e2e 测试
npm run e2e

# 运行所有测试
npm test
```
## 全局配置
工程的全局配置文件为```EnvConfig.json```,通过该文件可以配置项目的服务器环境，打包构建方式，发布平台以及定制化方案等。以下为该文件内各个配置项的说明。
``` json
{
  "currentEnv": "meixinMyzsProEnv", // 当前使用的环境
  "defaultCfg": { // 默认的环境配置，其他的环境配置将覆盖默认中的配置
    "appName": "美捷报", // 应用名称
    "isHybridApp": true, // 是否混合开发
    "hybridAppPlatform": "", // 混合开发的平台，可选项有美信(meixin),美信空底座(meixinBase),微信(wechat),阳光城小Y(yango)等
    "menuConfig": "defaultMenu", // 选择的菜单配置
    "tenantId": "156914750821761024", // 报销应用的tenantId
    "smartBuyTenantId": "143616744011111111", // 消费应用的tenantId，消费和报销双登录时启用
    "baseUrl": "https://172.16.7.193:9080/", // 后端接口API路径默认配置
    "baseUrlCdp": "https://172.16.7.193:9080/", // cdp接口API路径
    "smartBuyCdp": "https://jtest.midea.com:9040/", // 消费cdp接口API路径
    "baseUrlExpense": "https://172.16.7.193:9080/", // 报销接口API路径
    "baseUrlDocker": "https://172.16.7.193:9080/", // jiebao-docker接口API路径
    "baseUrlSdatt": "https://172.16.7.193:9080/", // 账柜接口API路径
    "invUrl": "https://jver.midea.com/", // 发票查验接口API路径
    "baseUrlReport": "https://172.16.7.193:9080/", // 报表接口API路径
    "baseUrlCar": "http://10.16.90.69:7004", // 消费-用车接口API路径
    "baseUrlPlane": "http://10.16.90.70:7005", // 消费-机票接口API路径
    "baseUrlActive": "https://172.16.7.193:9080/", // 我的足迹接口API路径
    "extModuleNameList": ["didi", "flight", "htHotel"], // 支持调起的外部应用
    "extModulePathList": ["com.midea.msd.businessCar", "com.midea.msd.newReimbursingTicket", "com.midea.msd.businessHotel"], // 支持调起的外部应用路径配置
    "multiLogin": ["vehicle-dd-web", "smart-buy-center-web"], // 需要走二次登录的应用API路径
    "suppliers": ["didi", "ht-hotel", "ctrip-hotel", "clyh-hotel", "meiya-flight", "yqf-flight", "clyh-flight"], // 应用支持的供应商配置
    "meixin": { // 美信平台的配置，发布到美信平台时启用
      "passMAS": true, // 请求是否经过美信MAS转发
      "ssoTokenName": "mideatest_sso_token", // 美信MAS校验token
      "masUrl": "https://newimtest.midea.com/", // 美信MAS url
      "identifier": "com.midea.msd.meijiebao" // 应用在美信平台上的标识
    },
    "wechat": { // 微信平台的配置，发布到微信平台时启用
      "appid": "wx1deaa225db7d8ad5", // 应用发布到的企业号ID
      "wechatScope": "snsapi_userinfo", // 配置登录需要返回的用户信息，详情参考微信企业号文档
      "wechatAgentid": "1000004", // 应用在企业号上的ID
      "wechatState": "jiebao" // 登录返回校验，详情参考微信企业号文档
    },
    "packageCfg": { // 打包配置
      "theme": "defaultTheme", // 应用的主题配置
      "releaseNote": "MSD", // 发布说明
      "isDebug": 1, // 是否支持调试，发布美信平台启用
      "publish": { // 发布平台配置
        "meixin": { // 美信平台配置
          "packageName": "美捷报2.0", // 应用打包后的包名
          "version": "1.0.14", // 版本号
          "build": 14 // 构建流水号
        }
      }
    }
  },
  "meixinMyzsProEnv": { // 环境配置，启用时将覆盖默认配置
    "hybridAppPlatform": "meixin",
    "baseUrl": "http://emsnewuat.midea.com:9080/",
    "baseUrlCdp": "https://mapnew.midea.com/mas-api/restful/myzsmjbLogin/",
    "smartBuyCdp": "https://mapnew.midea.com/mas-api/restful/mjbLogin/",
    "baseUrlExpense": "https://mapnew.midea.com/mas-api/restful/myzsmjbExpense/",
    "baseUrlDocker": "https://mapnew.midea.com/mas-api/restful/myzsmjbJbdocker/",
    "baseUrlSdatt": "https://mapnew.midea.com/mas-api/restful/myzsmjbSdatt/",
    "baseUrlActive": "https://mapnew.midea.com/mas-api/restful/myzsactive/",
    "baseUrlCar": "https://mapnew.midea.com/mas-api/restful/bizCar/",
    "baseUrlPlane": "https://mapnew.midea.com/mas-api/restful/bizticket/",
    "baseUrlReport": "https://mapnew.midea.com/mas-api/restful/myzsreport/",
    "invUrl": "https://mapnew.midea.com/mas-api/restful/invVrf/",
    "masUrl": "https://mapnew.midea.com/",
    "passMAS": true,
    "ssoTokenName": "midea_sso_token",
    "extModuleNameList": ["didi", "flight", "htHotel"],
    "extModulePathList": ["com.midea.msd.businessCar", "com.midea.msd.newReimbursingTicket", "com.midea.msd.businessHotel"],
    "multiLogin": ["bizCar", "bizticket", "myzsactive"],
    "tenantId": "156914750821761024",
    "smartBuyTenantId": "73564705712504832",
    "packageCfg": { // 打包配置
      "publish": "meixin" //选择发布平台
    }
  }
}
```
## 打包发版
### 应用打包
``` bash
npm run build
```
以上命令将根据```EnvConfig.json```中```currentEnv```的配置进行打包，当该命令无法满足项目的打包需求时，可以在该打包命令后带上可选参数来完成更多复杂的打包需求。命令支持的可选参数可通过以下方式查看：
``` bash
node build/build.js -h

  Usage: build [options]

  Options:

    -e, --env [type]        Pick a specified type of environment configuration in EnvConfig.json (default: )
    -n, --env-name [type]   Set the name of current environment (default: sit)
    -t, --theme [type]      Pick a specified kind of theme (default: )
    -i, --increase <items>  Increase version
    -d, --decrease <items>  Decrease version
    -l, --less              Generate less message for EnvConfig.json
    --no-envconfig          No generate EnvConfig.json
    --no-cubemodule         No generate CubeModule.json
    -h, --help              output usage information

```
对于常用的打包命令可以配置到```package.json```的```scripts```中，如下所示：
``` json
{
  "scripts": {
    "bmytest": "node build/build.js -e meixinSitEnv -n test -i 0.0.1",
    "bmypro": "node build/build.js -e meixinMyzsProEnv -n product -t defaultTheme -i 0.0.1 -l",
    "byftest": "node build/build.js -e fengbaoTestEnv -n test -i 0.0.1",
    "boftest": "node build/build.js -e meixinBaseSitEnv -n test -i 0.0.1",
    "bofpro": "node build/build.js -e ofilmProEnv -n product -t defaultTheme -i 0.0.1 -l",
    "bofiospro": "node build/build.js -e ofilmProEnvForIOS -n product -t defaultTheme -i 0.0.1 -l"
  }
}
```
之后可以通过```npm run```某个脚本别名来执行该打包命令。
### 应用发版
#### 发布到微信及普通web平台
* 将打包后的生成的压缩包如(./美捷报2.0-2.0.24-test-201806281840.zip)通过ftp工具上传服务器，放置到对应的前端tomcat服务器下，修改文件夹名称为```mobile```。
* 进入nginx安装目录的conf，打开该目录下的location.conf，确保该文件中有以下配置：
``` bash
location /mobile {
  proxy_pass scheme://ip:port;  // 上一步骤中tomcat服务器对应的IP和端口号
}
```
* 重载nginx配置：./nginx –s reload  (sbin目录下)
* 之后就可以通过```scheme://ip[:port]/mobile/#/```进行访问。

#### 发布到美信及美信空底座
todo...
