import $method from '@/js/method';
import 'babel-polyfill';
import Vue from 'vue';
import Raven from 'raven-js';
import RavenVue from 'raven-js/plugins/vue';
// import FastClick from 'fastclick';
import VueRouter from 'vue-router';
import sha256 from 'crypto-js/sha256';
import Base64 from 'crypto-js/enc-base64';
import infiniteScroll from 'vue-infinite-scroll';
// import vuescroll from 'vue-scroll'; // 不兼容ios9，webpack打的包在iOS9上直接报错
// import { ToastPlugin, AlertPlugin, LoadingPlugin, ConfirmPlugin, DatetimePlugin } from 'vux';
import { XButton, Cell, CellBox, Group, ToastPlugin, LoadingPlugin,  AlertPlugin, DatetimePlugin, ConfirmPlugin, XInput, TransferDom, Popup } from 'vux'
import QRCode from 'qrcode';
import VueClipboards from 'vue-clipboards';
import { getUrlQueryParam, createCounter, createTimerObj, decorator, isIOSEnviron } from '@/js/util';
import App from './App';
import store from './store';
import routes from './router';
import { platform, setPlatform } from './platform';

Vue.directive('transfer-dom', TransferDom)

const components = {
  'x-button': XButton,
  'x-input': XInput,
  cell: Cell,
  group: Group,
  'cell-box': CellBox,
  popup: Popup
};

const keys = Object.keys(components)
keys.forEach(key => {
  Vue.component(key, components[key])
})
// for (let [key, value] of Object.entries(components)) {
//   Vue.component(key, value)
// }
Vue.prototype.$method = $method


if (process.env.NODE_ENV !== 'development') {
  Raven
  .config('https://833c0a42f52d49eab94c78149309b398@sentry.io/1186420')
  .addPlugin(RavenVue, Vue)
  .install();
}
function ravenCbRegister() {
  const cbList = {};
  return {
    register: (id, cb) => {
      if (typeof(cb) === 'function') {
        cbList[id] = cb;
      }
      return cbList;
    },
    getCb: (id) => {
      return cbList[id] || (() => {});
    },
    executeCb: (id) => {
      if (cbList[id]) {
        cbList[id]();
        delete cbList[id];
      }
    },
    getCbList: () => {
      return cbList;
    },
  }
}
const ravenSuccessCb = ravenCbRegister();
const ravenFailureCb = ravenCbRegister();
Vue.prototype.ravenCaptureMessage = (msg, opt = {}) => {
  opt.level = opt.level || 'info';
  return new Promise((resolve, reject) => {
    Raven.captureMessage(msg, opt);
    const eventId = Raven.lastEventId();
    if (process.env.NODE_ENV !== 'development') {
      ravenSuccessCb.register(eventId, resolve);
      ravenFailureCb.register(eventId, reject);
    } else {
      resolve();
    }
  });
};
Vue.prototype.ravenSetUserContext = (id, email) => {
  Raven.setUserContext({
    id: id || '',
    email: email || 'yuhao.zhuang@meicloud.com',
  });
};
document.addEventListener('ravenSuccess', (e) => {
  if (e && e.data && e.data.event_id) {
    const cbbbb = ravenSuccessCb.getCb(e.data.event_id);
    ravenSuccessCb.executeCb(e.data.event_id);
  }
});
document.addEventListener('ravenFailure', (e) => {
  if (e && e.data && e.data.event_id) {
    ravenFailureCb.executeCb(e.data.event_id);
  }
});

Vue.use(VueRouter);
Vue.use(ToastPlugin);
Vue.use(AlertPlugin);
Vue.use(LoadingPlugin);
Vue.use(ConfirmPlugin);
Vue.use(infiniteScroll);
Vue.use(DatetimePlugin);
// Vue.use(vuescroll);
Vue.use(QRCode);
Vue.use(VueClipboards);

const router = new VueRouter({
  routes,
});

const setInnerNavigateFlag = (flag) => {
  router.isInnerNavigate = flag;
};
Vue.prototype.setInnerNavigateFlag = setInnerNavigateFlag;
VueRouter.prototype.push = decorator(VueRouter.prototype.push, setInnerNavigateFlag);
VueRouter.prototype.replace = decorator(VueRouter.prototype.replace, setInnerNavigateFlag);
VueRouter.prototype.go = decorator(VueRouter.prototype.go, setInnerNavigateFlag);
router.beforeEach((to, from, next) => {
  if (router.isInnerNavigate) {
    // router.isInnerNavigate = '';
    next();
  } else {
    if (from.fullPath === '/travel') {
      platform.exit();
      next(false);
    } else if (['/fee', '/report', '/mine'].indexOf(from.fullPath) > -1) {
      setInnerNavigateFlag('/travel');
      next('/travel');
    } else {
      next();
    }
  }
});
router.afterEach((to, from) => {
  router.isInnerNavigate = '';
});
/**
 * 监听用户是否编辑表单
 */
const MO = {
  observer: (cb) => {
    return new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        const oldVal = mutation.oldValue;
        const newVal = mutation.target.dataset ? mutation.target.dataset.edit || '' : '';
        console.log(`mutation:you has been edited! oldVal:${oldVal}, newVal:${newVal}`);
        if (cb && typeof cb === 'function') cb();
      });
    })
  },
  config: { attributes: true, attributeOldValue: true, attributeFilter: ['data-edit'] },
  inputNode: ['INPUT', 'TEXTAREA', 'RADIO', 'CHECKBOX', 'SELECT', 'BUTTON'],
};

/**
 * 监听编辑的回调函数
 * @param {Object} type 监听编辑的类型
 */
const handleEdit = (type) => {
  return () => {
    store.commit('APPLY_CREATE', { isSave: false });
    store.commit('REIMBURSE_CREATE', { isSave: false });
    console.log('***handle edit with default type***');
    if (type.feeStdExp) {
      store.commit('FEE_STD_EXP', false);
      store.commit('REIM_FEE_STD_EXP', false);
      console.log('***handle edit with feeStdExp type***');
    }
    if (type.overStd) {
      store.commit('OVER_STD_EXP', false);
      store.commit('REIM_OVER_STD_EXP', false);
      // todo: handle the tyoe of overStd
      console.log('***handle edit with overStd type***');
    }
    if(type.createAirBdt){
      store.commit('APPLY_CREATE', { isCreateAirBudget: true });
       console.log('***handle edit with createAirBdt type***');
    }
  };
};

// FastClick.attach(document.body);

Vue.config.productionTip = false;

Vue.directive('focus', {
  inserted: el => el.focus(),
});

/**
 * Vue指令，标识需要监听的表单
 */
Vue.directive('edit', {
  inserted: (el, binding) => {
    const type = binding.modifiers;
    if (MO.inputNode.indexOf(el.nodeName) === -1 || typeof (el.dataset.edit) === 'string') {
      if (MO.inputNode.indexOf(el.nodeName) === -1) el.setAttribute('tabindex', -1);
      el.addEventListener('focus', () => {
        console.log('focus');
        MO.observer(handleEdit(type)).observe(el, MO.config);
      });
    } else {
      el.addEventListener('input', () => {
        console.log('oninput:you has been edited!');
        handleEdit(type)();
      });
    }
  },
});

Vue.prototype.showToast = (obj) => {
  Vue.$vux.toast.show({
    type: 'text',
    text: obj.msg,
    time: obj.time || 2000,
    width: obj.width || '12em',
    position: obj.position || 'default',
    isShowMask: obj.isShowMask || false,
  });
};

Vue.prototype.showLoading = (text) => {
  Vue.$vux.loading.show({
    text: text || '加载中…',
  });
  return true;
};

Vue.prototype.hideLoading = () => {
  Vue.$vux.loading.hide();
  return false;
}

Vue.prototype.alert = obj => Vue.$vux.alert.show(obj);

Vue.prototype.showPopup = (obj) => {
  store.commit('SHOW_POPUP', { show: true, msg: obj.msg });
};

/**
 * 浮层滚动时阻止window窗体跟随滚动
 * @param {Element} container 需要滚动容器的祖先容器
 * @param {Element} selectorScrollable 需要滚动的容器
 */
Vue.prototype.smartScroll = (container, selectorScrollable) => {
  // 如果没有滚动容器选择器，或者已经绑定了滚动，忽略
  if (!selectorScrollable || container.dataset.isBindScroll) return;
  selectorScrollable.className = `${selectorScrollable.className} fix-IOS-scroll`;
  const data = {
    posY: 0,
    maxscroll: 0,
  };
  const contains  = (root, el) => {
    if (root.compareDocumentPosition) return root === el || !!(root.compareDocumentPosition(el) & 16);  // eslint-disable-line
    if (root.contains && el.nodeType === 1) return root.contains(el) && root !== el;
    while (el = el.parentNode) {  // eslint-disable-line
      if (el === root) return true;
    }
    return false;
  };
  // 事件处理
  container.addEventListener('touchstart', (event) => {
      const events = event.touches[0] || event;
      // 先求得是不是滚动元素或者滚动元素的子元素
      let elTarget = event.target;
      if (!elTarget) return;
      let elScroll;
      // 获取标记的滚动元素，自身或子元素皆可
      if (elTarget === selectorScrollable || contains(selectorScrollable, elTarget)) {
        elScroll = selectorScrollable;
      }
      if (!elScroll) return;
      // 当前滚动元素标记
      data.elScroll = elScroll;
      // 垂直位置标记
      data.posY = events.pageY;
      data.scrollY = elScroll.scrollTop;
      // 是否可以滚动
      data.maxscroll = elScroll.scrollHeight - elScroll.clientHeight;
  });
  container.addEventListener('touchmove', () => {
      // 如果不足于滚动，则禁止触发整个窗体元素的滚动
      if (data.maxscroll <= 0) {
          // 禁止滚动
          event.preventDefault();
      }
      // 滚动元素
      const elScroll = data.elScroll;
      // 当前的滚动高度
      const scrollTop = elScroll.scrollTop;
      // 现在移动的垂直位置，用来判断是往上移动还是往下
      const events = event.touches[0] || event;
      // 移动距离
      const distanceY = events.pageY - data.posY;
      // 上下边缘检测
      if (distanceY > 0 && scrollTop === 0) {
          // 往上滑，并且到头,禁止滚动的默认行为
          event.preventDefault();
          return;
      }
      // 下边缘检测
      if (distanceY < 0 && (scrollTop + 1 >= data.maxscroll)) {
          // 往下滑，并且到头,禁止滚动的默认行为
          event.preventDefault();
      }
  });
  container.addEventListener('touchend', () => {
    data.maxscroll = 0;
  });
  // 防止多次重复绑定
  container.dataset.isBindScroll = true;
};

/**
 * 播放提示音
 */
const playRingtone = () => {
  const audios = document.createElement('audio');
  audios.src = './static/ringtone.mp3';
  audios.play();
};

const unablePushMsg = () => {
  if (store.state.baseConfig.unablePushMsg) {
    const unablePushMsgArr = store.state.baseConfig.unablePushMsg.map(item => item.toLowerCase());
    if (unablePushMsgArr.indexOf('ios') > -1 && isIOSEnviron()) {
      return true;
    } else if (unablePushMsgArr.indexOf('android') > -1 && !isIOSEnviron()) {
      return true;
    }
  }
  return false;
};
/**
 * 美信底座提供的推送服务注册接口
 * @param {String} userId
 */
Vue.prototype.registerPushService = (userId) => {
  return new Promise((resolve, reject) => {
    if (store.state.baseConfig.platform === 'meixinBase' && !unablePushMsg()) {
      platform.registerPushService(userId).then(() => {
        resolve();
      }).catch((err) => {
        Vue.prototype.showToast({ msg: `注册推送服务失败:${JSON.stringify(err)}` });
        reject(err);
      });
    } else {
      resolve();
    }
  });
};
/**
 * 美信底座提供的推送服务解绑接口
 * @param {String} userId
 */
Vue.prototype.untiePushService = (userId) => {
  return new Promise((resolve, reject) => {
    if (store.state.baseConfig.platform === 'meixinBase' && !unablePushMsg()) {
      platform.untiePushService(userId).then(() => {
        resolve();
      }).catch((err) => {
        reject(err);
      });
    } else {
      resolve();
    }
  });
};
/**
 * 美信底座提供的获取推送服务内容的接口
 */
Vue.prototype.getPush = () => {
  return new Promise((resolve, reject) => {
    if (store.state.baseConfig.platform === 'meixinBase' && !unablePushMsg()) {
      platform.getPush().then((res) => { // 订阅推送
        if (isIOSEnviron() && res && !res.isBackground) {
          playRingtone();
        } else {
          Vue.prototype.getExtra(); // 读取推送内容
        }
        resolve(res);
        Vue.prototype.getPush();  // 递归订阅推送
      }).catch((err) => {
        reject(err);
      });
    } else {
      resolve();
    }
  });
};
/**
 * 美信底座读取额外启动参数
 */
Vue.prototype.getExtra = () => {
  return new Promise((resolve, reject) => {
    platform.getExtra([store.state.baseConfig.identifier]).then((msg) => {
      if (msg && msg.extra) {
        let info = msg.extra;
        if (msg.extra.pushMsg) {
          router.replace({ path: '/fee/approve/approveHome/unApproved' });
        } else {
          store.commit('EXTCALL', true);
          if (msg.extra.showWidgetKey) {
            try {
              info = JSON.parse(msg.extra.showWidgetKey);
            } catch (error) {
              info = msg.extra.showWidgetKey;
            }
          }
          if (info.subModuleName) { // 调起应用子模块
            if (info.subModuleName === 'footprint') {
              router.push({ path: '/activity/footprint' });
            }
          } else if (info.docUrl || (info.type && info.fdId)) { // 调起待办
            const docUrlHash = info.docUrl ? info.docUrl.split('#')[1] : '';
            const type = docUrlHash && docUrlHash.split('/')[4] ? docUrlHash.split('/')[4] : '';
            const fdId = docUrlHash && docUrlHash.split('/')[5] ? docUrlHash.split('/')[5] : '';
            info.type = info.type || type;
            info.fdId = info.fdId || fdId;
            const query = {
              id: info.fdId,
              type: info.type,
            };
            if (info.type === 'EA') {
              router.replace({ path: '/fee/approve/travelReim', query });
            } else if (info.type === 'EC') {
              router.replace({ path: '/fee/approve/approvalReimburse', query });
            } else if (info.type === 'LM') {
              router.replace({ path: '/fee/approve/approveLoan', query });
            } else if (info.type === 'BM') {
              router.replace({ path: '/fee/approve/budgetChange', query });
            } else if (info.type === 'PA') {
              router.replace({ path: '/fee/approve/feeReim', query });
            } else if (info.type === 'CA') {
              router.replace({ path: '/fee/approve/adjustAccount', query });
            } else if (info.type === 'BA') {
              Vue.prototype.alert({
                title: '提示',
                content: '移动端不支持该类型单据审批，请移步PC端操作',
                onHide() {
                  platform.exit();
                },
              });
            } else {
              Vue.prototype.alert({
                title: '提示',
                content: '单据类型错误',
                onHide() {
                  platform.exit();
                },
              });
            }
          }
        }
      }
      resolve(msg);
    }).catch((err) => { reject(err) });
  });
};
/**
 * debuggap调试工具
 */
function createDebugger() {
  const startDebugger = () => {
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = './debuggap.js';
    document.getElementsByTagName('head')[0].appendChild(script);
    script.onload = () => {
      startDebuggap();
    };
  };
  if (localStorage.getItem('debuggap')) startDebugger();
  return {
    debuggerOn: () => {
      if (!localStorage.getItem('debuggap')) {
        Vue.$vux.confirm.show({
          showInput: true,
          title: '即将进入调试模式，开发或运维人员可输入调试token进行调试，否则请点击「取消」退出该模式',
          placeholder: '请输入调试token',
          closeOnConfirm: false,
          onConfirm(token) {
            if (!token) {
              Vue.prototype.showToast({ msg: '输入调试token或点击「取消」' });
            } else if (Base64.stringify(sha256(Base64.stringify(sha256(token)))) === 'x/WMiXMHIrK9rdZeUfGKlZUcl+DjjG1UMpXyoH9/f/4=') {
              startDebugger();
              localStorage.setItem('debuggap', true);
              Vue.prototype.showToast({ msg: 'token验证通过,已进入调试模式' });
              Vue.$vux.confirm.hide();
            } else {
              Vue.prototype.showToast({ msg: 'token验证失败，请重试' });
            }
          },
        });
      } else {
        Vue.$vux.confirm.show({
          content: '当前处于调试模式，退出该模式？',
          onConfirm() {
            localStorage.removeItem('debuggap');
            location.reload();
          },
        });
      }
    },
    startDebugger,
  };
}

const debuggerOn = createDebugger().debuggerOn;
Vue.directive('debug', {
  bind: (el, binding) => {
    if (binding.value) {
      const timerObj = createTimerObj(() => { debuggerOn() }, 5000);
      el.addEventListener('contextmenu', (e) => {
        e.preventDefault();
      });
      el.addEventListener('touchstart', () => {
        if (timerObj.getTimer()) {
          timerObj.clearTimeout();
        }
        timerObj.setTimeout();
      });
      el.addEventListener('touchend', () => {
        timerObj.clearTimeout();
      });
    }
  },
});

const hybridAppInit = () => {
  return new Promise((resolve, reject) => {
    if (store.state.baseConfig.isHybridApp) {
      document.addEventListener('deviceready', () => {
        platform.changeColor([72, 71, 89, 1]);
        document.addEventListener('offline', () => {
          Vue.prototype.showToast({ msg: '网络连接异常' });
        }, false);
        document.addEventListener('online', () => {
          // Vue.prototype.showToast({ msg: '网络已连接' });
        }, false);
        const initPromise = [Vue.prototype.getExtra()];
        const employeeNumber = store.state.userInfo && store.state.userInfo.employeeNumber ? store.state.userInfo.employeeNumber : '';
        if (employeeNumber) initPromise.push(Vue.prototype.registerPushService(employeeNumber));
        Promise.all(initPromise)
        .then((res) =>{
          Vue.prototype.getPush();
          // alert(`success:${JSON.stringify(res[1])}`);
          resolve(res);
        })
        .catch((err) => {
          // alert(`err:${JSON.stringify(err)}`);
          reject(err);
        });
      });
    } else {
      resolve();
    }
  });
};

store.dispatch('getBaseConfig').then(() => {
  if (Object.keys(store.state.baseConfig).length) {
    console.log('GET_BASECONF');
    setPlatform(store.state.baseConfig.platform);
    if (store.state.baseConfig.platform !== 'meixin') {
      const token = localStorage.getItem('token');
      const userInfo = localStorage.getItem('userInfo');
      const smartBuyToken = localStorage.getItem('smartBuyToken');
      const smartBuyUserInfo = localStorage.getItem('smartBuyUserInfo');
      if (token && userInfo) {
        store.commit('ROOT_LOGIN', token);
        store.commit('USERINFO', JSON.parse(userInfo));
        Vue.prototype.ravenSetUserContext(JSON.parse(userInfo).user.userName);
        console.log('Get Login Info Finish');
      }
      if (smartBuyToken && smartBuyUserInfo) {
        store.commit('SMART_BUY_LOGIN', smartBuyToken);
        store.commit('SMART_BUY_USERINFO', JSON.parse(smartBuyUserInfo));
        console.log('Get Multi Login Info Finish');
      }
    }
    if (getUrlQueryParam('extCall')) {
      store.commit('EXTCALL', true);
    }
    store.dispatch('getMenuConfig', store.state.baseConfig.menuConfig || 'defaultMenu').then(() => {
      if (store.state.menuConfig) {
        hybridAppInit().finally(() => {
          new Vue({
            router,
            store,
            render: h => h(App),
          }).$mount('#app-box');
        });
      } else {
        console.log('无法读取菜单配置信息,请稍后再试！');
      }
    });
  } else {
    console.log('无法读取配置文件,请稍后再试！');
  }
});

export default Vue;
