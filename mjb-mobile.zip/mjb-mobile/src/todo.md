## 美捷报美信平台拉起的如参类型
``` javascript
var msg = {
  "extra":{
    "docSubject":"请审批陈俊英提交的流程:EC180724097090/陈俊英/员工日常报销/33.00/人民币/狗狗号",
    "fdFlowId":"297822292837138432",
    "fdId":"297822292837138432_EC",
    "type":"EC",
    "action":"detail"
  },
  "widgetId":"com.midea.msd.meijiebao",
  "result":true
}
var msg1 = {
  "extra":{
    "showWidgetKey":"{\"fdId\":\"276133053917560832\",\"type\":\"BM\"}"
  },
  "widgetId":"com.midea.msd.meijiebao",
  "result":true
}
var msg2 = {
  "extra":{
    "showWidgetKey":{subModuleName:'footprint'}
  },
  "widgetId":"com.midea.msd.meijiebao",
  "result":true
}
var msg3 = {
  "extra":{
    "pushMsg":"{}"
  },
  "widgetId":"com.midea.msd.meijiebao",
  "result":true
}
function praseMsg(msg) {
  if (msg && msg.extra) {
    let info = msg.extra;
    if (msg.extra.pushMsg) {
      console.log({ path: '/fee/approve/approveHome/unApproved' });
    } else {
      if (msg.extra.showWidgetKey) {
        try {
          info = JSON.parse(msg.extra.showWidgetKey);
        } catch (error) {
          info = msg.extra.showWidgetKey;
        }
      }
      if (info.subModuleName) { // 调起应用子模块
        if (info.subModuleName === 'footprint') {
          console.log({ path: '/activity/footprint' });
        }
      } else if (info.docUrl || (info.type && info.fdId)) { // 调起待办
        const docUrlHash = info.docUrl ? info.docUrl.split('#')[1] : '';
        const type = docUrlHash && docUrlHash.split('/')[4] ? docUrlHash.split('/')[4] : '';
        const fdId = docUrlHash && docUrlHash.split('/')[5] ? docUrlHash.split('/')[5] : '';
        info.type = info.type || type;
        info.fdId = info.fdId || fdId;
        const query = {
          id: info.fdId,
          type: info.type,
        };
        if (info.type === 'EA') {
          console.log({ path: '/fee/approve/travelReim', query });
        } else if (info.type === 'EC') {
          console.log({ path: '/fee/approve/approvalReimburse', query });
        } else if (info.type === 'LM') {
          console.log({ path: '/fee/approve/approveLoan', query });
        } else if (info.type === 'BM') {
          console.log({ path: '/fee/approve/budgetChange', query });
        } else if (info.type === 'PA') {
          console.log({ path: '/fee/approve/feeReim', query });
        } else if (info.type === 'CA') {
          console.log({ path: '/fee/approve/adjustAccount', query });
        } else if (info.type === 'BA') {
          console.log('移动端不支持该类型单据审批，请移步PC端操作');
        } else {
          console.log('单据类型错误');
        }
      }
    }
  }
}

function fn() {
  if (msg && msg.extra) {
    let info = msg.extra;
    if (msg.extra.pushMsg) {
      router.replace({ path: '/fee/approve/approveHome/unApproved' });
    } else {
      store.commit('EXTCALL', true);
      if (msg.extra.showWidgetKey) {
        try {
          info = JSON.parse(msg.extra.showWidgetKey);
        } catch (error) {
          info = msg.extra.showWidgetKey;
        }
      }
      if (info.subModuleName) { // 调起应用子模块
        if (info.subModuleName === 'footprint') {
          router.push({ path: '/activity/footprint' });
        }
      } else if (info.docUrl || (info.type && info.fdId)) { // 调起待办
        const docUrlHash = info.docUrl ? info.docUrl.split('#')[1] : '';
        const type = docUrlHash && docUrlHash.split('/')[4] ? docUrlHash.split('/')[4] : '';
        const fdId = docUrlHash && docUrlHash.split('/')[5] ? docUrlHash.split('/')[5] : '';
        info.type = info.type || type;
        info.fdId = info.fdId || fdId;
        const query = {
          id: info.fdId,
          type: info.type,
        };
        if (info.type === 'EA') {
          router.replace({ path: '/fee/approve/travelReim', query });
        } else if (info.type === 'EC') {
          router.replace({ path: '/fee/approve/approvalReimburse', query });
        } else if (info.type === 'LM') {
          router.replace({ path: '/fee/approve/approveLoan', query });
        } else if (info.type === 'BM') {
          router.replace({ path: '/fee/approve/budgetChange', query });
        } else if (info.type === 'PA') {
          router.replace({ path: '/fee/approve/feeReim', query });
        } else if (info.type === 'CA') {
          router.replace({ path: '/fee/approve/adjustAccount', query });
        } else if (info.type === 'BA') {
          Vue.prototype.alert({
            title: '提示',
            content: '移动端不支持该类型单据审批，请移步PC端操作',
            onHide() {
              platform.exit();
            },
          });
        } else {
          Vue.prototype.alert({
            title: '提示',
            content: '单据类型错误',
            onHide() {
              platform.exit();
            },
          });
        }
      }
    }
  }
}
```
