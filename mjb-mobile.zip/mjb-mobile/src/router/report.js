import report from '@/components/report';
import reportIndex from '@/components/report/reportIndex';
import orgContrast from '@/components/report/budgetReport/orgContrast';
import trendAnalysis from '@/components/report/budgetReport/trendAnalysis';
import OccupAnalysis from '@/components/report/budgetReport/OccupAnalysis';
import ExcutedAnalysis from '@/components/report/budgetReport/ExcutedAnalysis';

const reportConfig = {
  path: '/report',
  component: report,
  children: [
    {
      path: '',
      component: reportIndex,
    },
    {
      path: 'OccupAnalysis',
      component: OccupAnalysis,
      children: [
        {
          path: '',
          redirect: 'trendAnalysis',
        },
        {
          path: 'trendAnalysis',
          component: trendAnalysis,
        },
        {
          path: 'orgContrast',
          component: orgContrast,
        },
      ],
    },
    {
      path: 'ExcutedAnalysis',
      component: ExcutedAnalysis,
      children: [
        {
          path: '',
          redirect: 'trendAnalysis',
        },
        {
          path: 'trendAnalysis',
          component: trendAnalysis,
        },
        {
          path: 'orgContrast',
          component: orgContrast,
        },
      ],
    },
  ],
};

export default reportConfig;
