import travelAll from '@/components/travel/travelCheckAll/travelAll';
import travelIndex from '@/components/travel/travel';
import travel from '@/components/travel';
import didiIndex from '@/components/travel/didi';
import didi from '@/components/travel/didi/didi';
import myTrip from '@/components/travel/didi/myTrip';
import commonAddress from '@/components/travel/didi/commonAddress';
import planeIndex from '@/components/travel/plane';
import ticketSearch from '@/components/travel/plane/ticketSearch';
import ticketList from '@/components/travel/plane/ticketList';
import orderIndex from '@/components/travel/plane/orderIndex';
import ticketOrder from '@/components/travel/plane/ticketOrder';
import allOrders from '@/components/travel/plane/allOrders';
import changeApply from '@/components/travel/plane/changeApply';
import refundApply from '@/components/travel/plane/refundApply';
import orderDetail from '@/components/travel/plane/orderDetail';
import bookingDetails from '@/components/travel/plane/bookingDetails';
import travelTitle from '@/components/travel/plane/travelTitle'; // 旅客信息
import travelMsg from '@/components/travel/plane/travelMsg'; // 旅客信息
import travelPlane from '@/components/travel/travelCheckAll/travelPlane';
import travelDidi from '@/components/travel/travelCheckAll/travelDidi';
import travelHotel from '@/components/travel/travelCheckAll/travelHotel';
import customService from '@/components/travel/plane/customService'; // 旅客信息

import hotelIndex from '@/components/travel/hotel/';

const travelConfig = {
  path: '/travel',
  component: travel,
  children: [
    {
      path: '',
      component: travelIndex,
    },
    {
      path: 'bizOrder',
      component: travelAll,
      children: [
        {
          path: '',
          redirect: 'plane',
        },
        {
          path: 'plane',
          component: travelPlane,
        },
        {
          path: 'didi',
          component: travelDidi,
        },
        {
          path: 'hotel',
          component: travelHotel,
        },
      ],
    },
    {
      path: 'didi',
      component: didiIndex,
      children: [
        {
          path: '',
          component: didi,
        },
        {
          path: 'myTrip',
          component: myTrip,
        },
        {
          path: 'commonAddress',
          component: commonAddress,
        },
      ],
    },
    {
      path: 'plane',
      component: planeIndex,
      children: [
        {
          path: '',
          component: ticketSearch,
        },
        {
          path: 'customService',
          component: customService,
        },
        {
          path: 'ticketList',
          component: ticketList,
        },
        {
          path: 'bookingDetails',
          component: bookingDetails,
        },
        {
          path: 'ticketOrder',
          component: ticketOrder,
        },
        {
          path: 'changeApply',
          component: changeApply,
        },
        {
          path: 'refundApply',
          component: refundApply,
        },
        {
          path: 'travelTitle',
          component: travelTitle,
        },
        {
          path: 'travelMsg',
          component: travelMsg,
        },
        {
          path: 'orderIndex',
          component: orderIndex,
          children: [
            {
              path: '',
              redirect: 'allOrders',
            },
            {
              path: ':orderType',  // allOrders: 全部订单, outTicketOrders: 已出票订单, waitTicketOrders: 待出票订单, refundTicketOrders: 退改单
              component: allOrders,
            },
            // {
            //   path: 'allOrders',
            //   component: allOrders,   // 全部订单
            // },
            // {
            //   path: 'outTicketOrders',
            //   component: outTicketOrders,    // 已出票订单
            // },
            // {
            //   path: 'waitTicketOrders',
            //   component: waitTicketOrders,   // 待出票订单
            // },
            // {
            //   path: 'refundTicketOrders',
            //   component: refundTicketOrders,   // 退改单
            // },
          ],
        },
        {
          path: 'orderDetail',
          component: orderDetail,
        },
      ],
    },
    {
      path: 'hotel',
      component: hotelIndex,
    },
  ],
};

export default travelConfig;
