import activity from '@/components/activity';
import footprint from '@/components/activity/footprint';
import flight from '@/components/activity/footprint/flight';
import car from '@/components/activity/footprint/car';
import cost from '@/components/activity/footprint/cost';
import fiveMedal from '@/components/activity/footprint/fiveMedal';
import end from '@/components/activity/footprint/end';

const activityConfig = {
  path: '/activity',
  component: activity,
  children: [
    {
      path: '',
      redirect: 'footprint',
    },
    {
      path: 'footprint',
      component: footprint,
      children: [
        {
          path: '',
          redirect: 'flight',
        },
        {
          path: 'flight',
          component: flight,
        },
        {
          path: 'car',
          component: car,
        },
        {
          path: 'cost',
          component: cost,
        },
        {
          path: 'fiveMedal',
          component: fiveMedal,
        },
        {
          path: 'end',
          component: end,
        },
      ],
    },
  ],
};

export default activityConfig;
