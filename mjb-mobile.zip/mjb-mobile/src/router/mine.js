import mine from '@/components/mine';
import mineIndex from '@/components/mine/mineIndex';
import collectionTitle from '@/components/mine/collectionProfile/collectionTitle'; // 收款信息
import invoiceTitle from '@/components/mine/invoiceProfile/invoiceTitle'; // 发票抬头
import reimburseTitle from '@/components/mine/reimburseProfile/reimburseTitle'; // 报销基本信息
import travelTitle from '@/components/mine/travelProfile/travelTitle'; // 旅客信息
import executeMsg from '@/components/mine/collectionProfile/executeMsg'; // 添加或编辑
import travelMsg from '@/components/mine/travelProfile/travelMsg'; // 旅客信息
import mineBackInfo from '@/components/common/mineBackInfo'; // 挑选银行城市网点
import addInvoice from '@/components/mine/invoiceProfile/addInvoice'; // 添加发票
import invoiceMsg from '@/components/mine/invoiceProfile/invoiceMsg'; // 发票详情

const mineConfig = {
  path: '/mine',
  component: mine,
  children: [
    {
      path: '',
      component: mineIndex,
    },
    {
      path: 'collectionTitle',
      component: collectionTitle,
    },
    {
      path: 'executeMsg',
      component: executeMsg,
    },
    {
      path: 'mineBackInfo',
      component: mineBackInfo,
    },
    {
      path: 'addInvoice',
      component: addInvoice,
    },
    {
      path: 'invoiceMsg',
      component: invoiceMsg,
    },
    {
      path: 'reimburseTitle',
      component: reimburseTitle,
    },
    {
      path: 'travelTitle',
      component: travelTitle,
    },
    {
      path: 'travelMsg',
      component: travelMsg,
    },
    {
      path: 'invoiceTitle',
      component: invoiceTitle,
    },
  ],
};

export default mineConfig;
