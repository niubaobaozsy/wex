import Hello from '@/components/HelloFromVux';
import login from '@/components/login/login';
import advancedSetting from '@/components/mine/advancedSetting'; // 高级设置
import fee from './fee';
import report from './report';
import travel from './travel';
import mine from './mine';
import activity from './activity';

const routes = [
  {
    path: '/',
    name: 'login',
    component: login,
  },
  {
    path: '/index',
    redirect: '/travel',
  },
  {
    path: '/hello',
    name: 'Hello',
    component: Hello,
  },
  {
    path: '/advancedSetting',
    name: 'advancedSetting',
    component: advancedSetting,
  },
  // {
  //   path: '/login',
  //   name: 'login',
  //   component: login,
  // },
  fee,
  report,
  travel,
  mine,
  activity,
];

export default routes;
