import fee from '@/components/fee';
import feeIndex from '@/components/fee/feeIndex';
import myReimburse from '@/components/fee/myReimburse';
import myApply from '@/components/fee/myApply';
import details from '@/components/fee/myApply/details';
import loanDetail from '@/components/fee/myApply/loanDetail';
import expenseEstimateIndex from '@/components/fee/myApply/expenseEstimateIndex';
import expenseEstimate from '@/components/fee/myApply/expenseEstimate';
import addBudget from '@/components/fee/myApply/addBudget';
import addAirTickerBudget from '@/components/fee/myApply/addAirTickerBudget';
import addTravelRoute from '@/components/fee/myApply/addTravelRoute';
import myInvoice from '@/components/fee/invoice';
import invoiceDetail from '@/components/fee/invoice/invoiceDetail';
import invoiceManually from '@/components/fee/invoice/invoiceManually';
import invoiceFail from '@/components/fee/invoice/invoiceFail';
import addInvoice from '@/components/fee/invoice/addInvoice';
import invoiceHome from '@/components/fee/invoice/invoiceHome';
import invoiceHomeNotUsed from '@/components/fee/invoice/invoiceHome_notUsed';
import invoiceHomeUsed from '@/components/fee/invoice/invoiceHome_Used';
import myApprove from '@/components/fee/approve';
import applyHome from '@/components/fee/myApply/applyHome';
import applyDraft from '@/components/fee/myApply/applyDraft';
import applyBeingApproved from '@/components/fee/myApply/applyBeingApproved';
import applyApproved from '@/components/fee/myApply/applyApproved';
import addTravelApply from '@/components/fee/myApply/addTravelApply';
import reimburseHome from '@/components/fee/myReimburse/reimburseHome';
import reimburseDraft from '@/components/fee/myReimburse/reimburseDraft';
import reimburseBeingApproved from '@/components/fee/myReimburse/reimburseBeingApproved';
import reimburseApproved from '@/components/fee/myReimburse/reimburseApproved';
import consumeRecord from '@/components/fee/myReimburse/consumeRecord';
import feeBudget from '@/components/fee/myReimburse/feeBudget';
import travelSysUsed from '@/components/fee/myReimburse/travelSysUsed';
import invoiceBudget from '@/components/fee/myReimburse/invoiceBudget';
import addInvoiceReim from '@/components/fee/myReimburse/addInvoice';
import selectInvoice from '@/components/fee/myReimburse/selectInvoice';
import addBudgetReim from '@/components/fee/myReimburse/addBudget';
import addLoan from '@/components/fee/myReimburse/addLoan';
import determinationProcess from '@/components/fee/myApply/determinationProcess';
import attachment from '@/components/fee/myReimburse/attachment';
import addReimburseAttachment from '@/components/fee/myReimburse/addReimburseAttachment';
import basicInformation from '@/components/fee/myReimburse/basicInformation';
import confirmApplyCompensate from '@/components/fee/myReimburse/confirmApplyCompensate';
import applyCreate from '@/components/fee/myApply/create';
import reimburseCreate from '@/components/fee/myReimburse/create';
// import addTravelRouteNew from '@/components/fee/myApply/addTravelRouteNew';
import applyAttachment from '@/components/fee/myApply/addApplyAttachment';
import checkReimburse from '@/components/fee/myReimburse/checkReimburse';
import invoiceManuallyDetail from '@/components/fee/myReimburse/invoiceManuallyDetail';
import feeReim from '@/components/fee/approve/feeReim';
import approveHome from '@/components/fee/approve/approveHome';
import myApproved from '@/components/fee/approve/approved';
import myUnApproved from '@/components/fee/approve/unApproved';
import travelReim from '@/components/fee/approve/travelReim';
import invoiceListApprove from '@/components/fee/approve/enclosureList';
import invoiceListApply from '@/components/fee/myApply/enclosureList';
import invoiceListReim from '@/components/fee/myReimburse/enclosureList';
import approveLoan from '@/components/fee/approve/approveLoan';
import adjustAccount from '@/components/fee/approve/adjustAccount';
import budgetChange from '@/components/fee/approve/budgetChange';
import approvalReimburse from '@/components/fee/approve/approvalReimburse';
import reimburseAddInvoice from '@/components/fee/myReimburse/invoiceManually';
import collectionTitle from '@/components/mine/collectionProfile/collectionTitle'; // 收款信息
import executeMsg from '@/components/mine/collectionProfile/executeMsg'; // 添加或编辑
import mineBackInfo from '@/components/common/mineBackInfo'; // 挑选银行城市网点
import testAttachment from '@/components/common/attachment'; // 测试附件

const feeConfig = {
  path: '/fee',
  component: fee,
  children: [
    {
      path: '',
      component: feeIndex,
    },
    {
      path: 'details',
      component: details,
    },
    {
      path: 'invoiceList',
      component: invoiceListApprove,
    },
    {
      path: 'reimburseAddInvoice',
      component: reimburseAddInvoice,  // 测试报销手工录入
    },
    // 我的报销
    {
      path: 'myReimburse',
      component: myReimburse,
      children: [
        {
          path: '',
          redirect: 'reimburseHome',
        },
        {
          path: 'checkReimburse',
          component: checkReimburse,
        },
        {
          path: 'invoiceManuallyDetail',
          component: invoiceManuallyDetail,
        },

        {
          path: 'invoiceList',
          component: invoiceListReim,
        },
        {
          path: 'reimburseHome',
          component: reimburseHome,
          children: [
            {
              path: '',
              redirect: 'draft',
            },
            {
              path: 'draft',
              component: reimburseDraft,
            },
            {
              path: 'beingApproved',
              component: reimburseBeingApproved,
            },
            {
              path: 'approved',
              component: reimburseApproved,
            },
          ],
        },
        {
          path: 'attachment',
          component: attachment,
        },
        {
          path: 'feeBudget',
          component: feeBudget,
        },
        {
          path: 'travelSysUsed',
          component: travelSysUsed,
        },
        {
          path: 'addInvoice',
          component: addInvoiceReim,
        },
        {
          path: 'selectInvoice',
          component: selectInvoice,
        },
        {
          path: 'addBudget',
          component: addBudgetReim,
        },
        {
          path: 'addLoan',
          component: addLoan,
        },
        {
          path: 'create',
          component: reimburseCreate,
          children: [
            {
              path: '',
              redirect: 'basicInformation',
            }, {
              path: 'basicInformation',
              component: basicInformation,
            }, {
              path: 'consumeRecord',
              component: consumeRecord,
            }, {
              path: 'invoiceBudget',
              component: invoiceBudget,
            }, {
              path: 'addReimburseAttachment',
              component: addReimburseAttachment,
            }, {
              path: 'confirmApplyCompensate',
              component: confirmApplyCompensate,
            }, {
              path: 'viewApplyDetail',
              component: details,
            }, {
              path: 'collectionTitle',
              component: collectionTitle,
            }, {
              path: 'executeMsg',
              component: executeMsg,
            }, {
              path: 'mineBackInfo',
              component: mineBackInfo,
            },
          ],
        },
      ],
    },
    // 申请
    {
      path: 'myApply',
      component: myApply,
      children: [
        {
          path: '',
          redirect: 'applyHome',
        },
        {
          path: 'loanDetail',
          component: loanDetail,
        },
        {
          path: 'invoiceList',
          component: invoiceListApply,
        },
        {
          path: 'applyHome',
          component: applyHome,
          children: [
            {
              path: '',
              redirect: 'draft',
            },
            {
              path: 'draft',
              component: applyDraft,
            },
            {
              path: 'beingApproved',
              component: applyBeingApproved,
            },
            {
              path: 'approved',
              component: applyApproved,
            },
          ],
        },
        {
          path: 'expenseEstimateIndex',
          component: expenseEstimateIndex,
        },
        {
          path: 'addTravelApply',
          component: addTravelApply,
        },
        {
          path: 'determinationProcess',
          component: determinationProcess,
        },
        {
          path: 'expenseEstimate',
          component: expenseEstimate,
        },
        {
          path: 'addBudget',
          component: addBudget,
        },
        {
              path: 'addAirTickerBudget',
              component: addAirTickerBudget,
        },
        {
          path: 'create',
          component: applyCreate,
          children: [
            {
              path: '',
              redirect: 'addTravelApply',
            },
            {
              path: 'addTravelApply',
              component: addTravelApply,
            },
            {
              path: 'addTravelRoute',
              component: addTravelRoute,
            },
            {
              path: 'expenseEstimateIndex',
              component: expenseEstimateIndex,
            }, {
              path: 'addBudget',
              component: addBudget,
            },
            {
              path: 'addAirTickerBudget',
              component: addAirTickerBudget,
            },
            {
              path: 'applyAttachment', // 附件
              component: applyAttachment,
            },
            {
              path: 'determinationProcess',
              component: determinationProcess,
            },
            {
              path: 'viewApplyDetail',
              component: details,
            },
          ],
        },
      ],
    },
    // 我的发票
    {
      path: 'myInvoice',
      component: myInvoice,
      children: [
        {
          path: '',
          redirect: 'invoiceHome',
        },
        {
          path: 'invoiceHome',
          component: invoiceHome,
          children: [
            {
              path: '',
              redirect: 'notUsed',
            },
            {
              path: 'notUsed',
              component: invoiceHomeNotUsed,
            },
            {
              path: 'used',
              component: invoiceHomeUsed,
            },
          ],
        },
        {
          path: 'invoiceDetail',
          component: invoiceDetail,
        },
        {
          path: 'invoiceManually',
          component: invoiceManually,
        },
        {
          path: 'invoiceFail',
          component: invoiceFail,
        },
        {
          path: 'addInvoice',
          component: addInvoice,
        },
      ],
    },
    {
      path: 'approve',
      component: myApprove,
      children: [
        {
          path: '',
          redirect: 'approveHome',
        },
        {
          path: 'budgetChange',
          component: budgetChange,
        },
        {
          path: 'approvalReimburse',
          component: approvalReimburse,
        },
        {
          path: 'approveLoan',
          component: approveLoan,
        },
        {
          path: 'adjustAccount',
          component: adjustAccount,
        },
        {
          path: 'approveHome',
          component: approveHome,
          children: [
            {
              path: '',
              redirect: 'unApproved',
            },
            {
              path: 'unApproved',
              component: myUnApproved,
            },
            {
              path: 'approved',
              component: myApproved,
            },
          ],
        },
        {
          path: 'travelReim',
          component: travelReim,
        },
        {
          path: 'feeReim',
          component: feeReim,
        },
      ],
    },
    // {
    //   path: 'myRequisitionSubmit',
    //   component: requisitionSubmit,
    // },
    {
      path: 'testPDF',
      component: testAttachment,
    },
  ],
};

export default feeConfig;
