import style2insert from './style2insert.js';

export { style2insert };
export default { style2insert };
