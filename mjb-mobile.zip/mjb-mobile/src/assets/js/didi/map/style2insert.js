export default {
  waitingOrder: [
    ['.amap-overlay-text-container:before', ['content', '等待：'],['color', '#979797'], ['line-height', '1'], ['display', 'inline-block'], ['padding', '0 0 0 .5em']], 
    ['.amap-overlay-text-container:after', ['content', '正在呼叫'], ['color', '#979797'], ['display', 'inline-block'], ['line-height', '1'], ['margin-left', '0.5em'], ['border-left', '1px solid #979797'], ['padding', '0 .5em']]
  ],
  waitingDriver: [
    ['.amap-overlay-text-container:before', ['content', '等待：'],['color', '#979797'], ['line-height', '1'], ['display', 'inline-block'], ['padding', '0 0 0 .5em']], 
    ['.amap-overlay-text-container:after', ['content', '等待司机到达'], ['color', '#979797'], ['display', 'inline-block'], ['line-height', '1'], ['margin-left', '0.5em'], ['border-left', '1px solid #979797'], ['padding', '0 .5em']]
  ],
  going: [
    ['.amap-overlay-text-container:before', ['content', '距离终点'],['color', '#000'], ['line-height', '1'], ['display', 'inline-block'], ['padding', '0 0 0 .5em']], 
    ['.amap-overlay-text-container:after', ['content', '公里'], ['color', '#000'], ['display', 'inline-block'], ['line-height', '1'],  ['padding', '0 .5em 0 0']]
  ],
  styleEl: null
};

