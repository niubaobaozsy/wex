export default {
  canCall: '滴滴出行',
  nonCall: '滴滴出行',
  toCall: '用车',
  calling: '用车',
  waitOrder: '用车',
  cancelling: '用车',
  takeOrder: '等待接驾',
  waitCar: '等待接驾',
  takeCar: '等待接驾',
  onTheWay: '行程中',
  endTrip: '行程结束',
  paying: '行程结束',
  payFail: '行程结束',
  paid: '行程结束',
  cancelled: '行程结束',
  detail: '订单详情'
}
