<template>
  <div id="app">
    <!-- <keep-alive include="addTravelApply"> -->
      <router-view></router-view>
    <!-- </keep-alive> -->
    <div @touchstart="onTouchstart" @touchend="onTouchend">
      <popup v-model="popupCfg.show" position="top" :show-mask="false" :popup-style="popupStyle">
        <p class="popup-content">{{popupCfg.msg}}</p>
      </popup>
    </div>
  </div>
</template>

<script>
import { platform } from '@/platform';
import { Popup } from 'vux';

export default {
  name: 'app',
  components: {
    Popup,
  },
  data() {
    return {
      popupStyle: {
        backgroundColor: 'rgba(0,0,0,0.6)',
        color: '#fff',
        padding: '14px 10px',
        fontSize: '12px',
        boxSizing: 'border-box',
      },
      touch: {
        start: 0,
        end: 0,
      },
    };
  },
  mounted() {
    this.init();
    this.listenVisibilityChange();
    console.log(process.env.NODE_ENV)
  },
  computed: {
    baseConfig() {
      return this.$store.state.baseConfig;
    },
    token() {
      return this.$store.state.token;
    },
    userInfo() {
      return this.$store.state.userInfo;
    },
    popupCfg: {
      get() {
        return this.$store.state.popupCfg;
      },
      set(val) {
        this.$store.commit('SHOW_POPUP', Object.assign({}, this.popupCfg, { show: val }));
      },
    },
  },
  methods: {
    init() {
      const path = location.hash.split('?')[0];
      if (path !== '#/') {
        this.getLoginInfo();// 获取登录信息
      }
    },
    WX_JS_SDK_INIT() {
      this.$store.dispatch('getWxSign', {
        corpid: this.baseConfig.appid,
        url: location.origin + location.pathname,
      }).then((res) => {
        if (res && res.code === '0000') {
          platform.wxconfig(this.baseConfig.appid, res.data.nonceStr, res.data.signature, res.data.timestamp);
        }
      });
      platform.wxready(() => {
        console.log('WX_JS_SDK_INIT_SUCCESS');
      });
      platform.wxerror(() => {
        console.log('WX_JS_SDK_INIT_ERROR');
      });
    },
    // 本地缓存中获取Token和userInfo
    getLoginInfo() {
      const _this = this;
      const isInWeChat = this.baseConfig.platform === 'wechat'; // 判断是否在微信浏览器
      if (isInWeChat) this.WX_JS_SDK_INIT();
      if (!this.token || !this.userInfo) {
        this.$store.commit('ROOT_LOGOUT');
        const redirectUrl = location.hash;
        if (redirectUrl !== '#/') {
          localStorage.setItem('redirectUrl', redirectUrl);
        }
        if (isInWeChat) {
          window.location.href = this.baseConfig.wechatOAuthUrl;
        } else {
          this.$router.push({ path: '/' });// 页面跳转
        }
      }
    },
    onTouchstart(e) {
      this.touch.end = 0;
      this.touch.start = e.touches[0] ? e.touches[0].clientY : 0;
    },
    onTouchend(e) {
      this.touch.end = e.touches[0] ? e.touches[0].clientY : 0;
      if (this.touch.start - this.touch.end > 0) {
        this.$store.commit('SHOW_POPUP', Object.assign({}, this.popupCfg, { show: false }));
      }
    },
    listenVisibilityChange() {
      const hiddenProperty = 'hidden' in document ? 'hidden' : 'webkitHidden' in document ? 'webkitHidden' : 'mozHidden' in document ? 'mozHidden' : null; // eslint-disable-line
      const visibilityChangeEvent = hiddenProperty.replace(/hidden/i, 'visibilitychange');
      const onVisibilityChange = () => {
        if (!document[hiddenProperty]) {
          this.$store.commit('APP_VISIBILITY', true);
          console.log('页面激活');
        }else{
          this.$store.commit('APP_VISIBILITY', false);
          console.log('页面非激活');
        }
      }
    document.addEventListener(visibilityChangeEvent, onVisibilityChange);
    },
  },
};
</script>

<style>
@import "./assets/css/grid.css";
@import "./assets/css/animate.css";
@import "~minirefresh/dist/debug/minirefresh.css";
</style>
<style lang="less">
@import '~vux/src/styles/reset.less';
@import "./assets/css/base.less";
</style>
