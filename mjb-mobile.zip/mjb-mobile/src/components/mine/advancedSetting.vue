<template>
  <div class="advanced-setting">
    <my-header title="高级配置" @previous="goBack" ></my-header>
    <div class="has-header env">
      <div v-if="showTip">
        <group>
          <x-icon type="ios-information" size="20" class="x-icon-red"></x-icon>
          <span class="tip">本次修改配置需要重载页面才能生效</span>
        </group>
      </div>
      <group title="环境配置">
        <popup-picker title="后端环境" :data="envList" v-model="envName" placeholder="请选择" @on-change="onChangeEnv"></popup-picker>
        <x-textarea v-model="envDetail" readonly :autosize="autosize"></x-textarea>
        <div class="more" @click="more">{{autosizeTip}}</div>
      </group>
    </div>
    <group title="高级设置">
      <popup-picker title="设置登录类型" :data="loginTypeList" v-model="loginType" placeholder="请选择" @on-change="onChangeLoginType"></popup-picker>
      <popup-picker title="选择菜单配置" :data="menuConfigList" v-model="menuConfig" placeholder="请选择" @on-change="onChangeMenuConfig"></popup-picker>
    </group>
    <group title="发票查验">
      <x-switch title="强制使用验证码模式" v-model="forceFree" @on-change="onInvQueryModeChange"></x-switch>
    </group>
    <group title="访问特定页面">
      <cell title="进入demo页" link="/hello"></cell>
      <popup-picker title="进入页面:" :data="toPageList" v-model="toPageUrl" placeholder="请选择" @on-change="selectToPage"></popup-picker>
      <x-input title="url:" v-model="toUrl">
        <x-button slot="right" type="primary" mini @click.native="navigateTo">前往</x-button>
      </x-input>
    </group>
    <group class="group reload">
      <x-button type="primary" plain @click.native="reset">恢复默认</x-button>
      <x-button type="primary" plain @click.native="clearStorage">清除localStorage</x-button>
      <x-button type="primary" @click.native="reload">重载页面</x-button>
    </group>
  </div>
</template>

<script>
import { PopupPicker, Group, XTextarea, XButton, Cell, XSwitch, XInput } from 'vux';
import MyHeader from '@/components/common/header';

export default {
  components: {
    PopupPicker,
    Group,
    XTextarea,
    XButton,
    Cell,
    XSwitch,
    XInput,
    MyHeader,
  },
  data() {
    return {
      envList: [],
      envName: [],
      envDetail: '',
      autosize: false,
      autosizeTip: '展开',
      showTip: false,
      loginTypeList: [['localLogin', 'customLogin']],
      loginType: [],
      menuConfigList: [['devMenu', 'defaultMenu', 'ofilmMenu']],
      menuConfig: [],
      advancedSetting: {},
      forceFree: false,
      toPageList: [['费用', '商旅', '我的', '报表', '报销', '申请', '发票', '审批']],
      toPageUrlList: ['/fee', '/travel', '/mine', '/report', '/fee/myReimburse', '/fee/myApply', '/fee/myInvoice/', '/fee/approve'],
      toPageUrl: ['费用'],
      toUrl: '/fee',
    };
  },
  computed: {
    currentEnvName() {
      return this.$store.state.baseConfig.envName;
    },
    currentMenuConfig() {
      return this.$store.state.baseConfig.menuConfig;
    },
    envConfig() {
      return this.$store.state.baseConfig.envConfig;
    },
  },
  watch: {
    envName(nval) {
      if (nval[0] !== this.currentEnvName) {
        this.showTip = true;
      } else {
        this.showTip = false;
      }
    },
    menuConfig(nval) {
      if (nval[0] !== this.currentMenuConfig) {
        this.showTip = true;
      } else {
        this.showTip = false;
      }
    },
    advancedSetting(nVal) {
      if (nVal) {
        localStorage.advancedSetting = JSON.stringify(nVal);
      }
    },
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    onChangeEnv(val) {
      this.advancedSetting = Object.assign({}, this.advancedSetting, {env: val[0]});
      this.envDetail = JSON.stringify(this.envConfig[this.envName[0]]);
    },
    more() {
      this.autosize = !this.autosize;
      this.autosizeTip = this.autosize ? '收起' : '展开';
    },
    reload() {
      window.location.reload();
    },
    reset() {
      localStorage.removeItem('advancedSetting');
      this.advancedSetting = {};
      this.envList = [];
      this.envName = [];
      this.loginType = [];
      this.menuConfig = [];
      this.forceFree = false;
      this.init();
    },
    clearStorage() {
      localStorage.clear();
    },
    onChangeLoginType(val) {
      this.advancedSetting = Object.assign({}, this.advancedSetting, {loginType: val[0]});
    },
    onChangeMenuConfig(val) {
      this.advancedSetting = Object.assign({}, this.advancedSetting, {menuConfig: val[0]});
    },
    selectToPage(val) {
      const toUrl = this.toPageUrlList[this.toPageList[0].indexOf(val[0])];
      this.$router.push(toUrl);
    },
    navigateTo() {
      this.$router.push(this.toUrl);
    },
    onInvQueryModeChange(cVal) {
      if (cVal) {
        this.advancedSetting = Object.assign({}, this.advancedSetting, {invQueryMode: 'forceFree'});
      } else {
        this.advancedSetting = Object.assign({}, this.advancedSetting, {invQueryMode: 'normal'});
      }
    },
    init() {
      this.advancedSetting = JSON.parse(localStorage.getItem('advancedSetting') || '{}');
      const envName = this.advancedSetting.env || this.envConfig.currentEnv;
      const loginType = this.advancedSetting.loginType || 'customLogin';
      const menuConfig = this.advancedSetting.menuConfig || this.envConfig[envName].menuConfig || 'defaultMenu';
      this.envList.push(Object.keys(this.envConfig).filter(v => v !== 'defaultCfg' && v !== 'currentEnv').sort());
      this.envName.push(envName);
      this.envDetail = JSON.stringify(this.envConfig[envName]);
      this.loginType.push(loginType);
      this.menuConfig.push(menuConfig);
      this.forceFree = this.advancedSetting.invQueryMode === 'forceFree';
    },
  },
  mounted() {
    this.init();
  },
}
</script>

<style lang="less" scoped>
.advanced-setting {
  .env {
    .tip {
      display: inline-block;
      line-height: 20px;
      color: #999999;
      font-size: 12px;
    }
    .more {
      padding: 0 20px 5px 0;
      text-align: right;
      color: red;
      font-size: 14px;
    }
  }
  .reload {
    margin: 0 10px;
  }
}
.x-icon-red {
  fill: red;
}
.group {
  margin-bottom: 20px;
}
</style>
