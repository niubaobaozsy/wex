 <!--
  describe：个人基本信息
  created by：周積坤
  date：2017-11-29
-->
<template>
  <div class="basicBg" v-if="show">
    <my-header :title="top.title" :headerClass="top.headerTop" @previous="goBack" ></my-header>
    <div class="basic-content">
      <div class="basic-top border-bottom">
        <div class="user-img"><img :src="userInfo.user.avatar || defaultAvatar"></div>
        <div class="user-msg">
          <div class="f-name">
            <p>{{userInfoList.user_full_name}}</p>
            <img v-if="userInfoList.gender" :src="userInfoList.gender === '1' ? sexMan : sexWoman ">
          </div>
          <span class="fn">{{userInfoList.nick_name}}</span>
        </div>
      </div>
      <ul class="user-list">
        <li class="border-bottom">
          <span>账号</span>
          <p>{{userInfoList.mip_account}}</p>
        </li>
        <li class="border-bottom">
          <span>职工号</span>
          <p>{{userInfoList.employee_number}}</p>
        </li>
        <li class="border-bottom">
          <span>职位</span>
          <p>{{userInfoList.position_name || '未维护职位信息'}}</p>
        </li>
        <li>
          <span>部门</span>
          <p>{{userInfoList.org_name}}</p>
        </li>
      </ul>
    </div>
    <div class="wrap-hide"></div>
    <ul class="second-list">
        <li class="border-bottom">
          <div>
            <span class="fn">电子邮箱</span>
            <p>{{userInfoList.user_email}}</p>
          </div>
          <img :src="emaliIcon">
        </li>
        <li>
          <div>
            <span class="fn">电话号码</span>
            <p>{{userInfoList.telephone_number}}</p>
          </div>
          <img :src="callPhone">
        </li>
      </ul>
  </div>
</template>
<script type="text/ecmascript-6">
  import { platform } from '@/platform';
  import myHeader from '../../common/header';
  import sexM from '../../../assets/images/mine/sexM.png';
  import sexW from '../../../assets/images/mine/sexW.png';
  import call from '../../../assets/images/mine/call.png';
  import email from '../../../assets/images/mine/email.png';
  import defaultAvatar from '../../../assets/images/common/defaultAvatar.png';

  export default {
    components: {
      myHeader,
    },
    props: {
      show: Boolean,
      list: Object,
    },
    computed: {
      userInfoList() {
        return this.$store.state.mine.userMsg;
      },
      userInfo() {
        return this.$store.state.userInfo;
      },
    },
    data() {
      return {
        sexMan: sexM,
        sexWoman: sexW,
        callPhone: call,
        emaliIcon: email,
        defaultAvatar,
        top: {
          title: '基础信息',
        },
      };
    },
    methods: {
      goBack() { // 返回
        this.$emit('on-hide');
      },
    },
    created() {
      if (platform === 'wechat') {
        this.userInfo.wechatAvatar = this.$store.state.userInfo.user.avatar;
      }
    },
  };
</script>
<style lang="less">
@grey:        #858585;
@border-grey: #DEDFE0;
@black:       #000000;
@white:       #FFFFFF;
@white-gray:  #f2f2f2;

.flex(@style:center) {
  display: flex;
  align-items: @style;
}
.basicBg {
  background: @white-gray;
  position: fixed;
  top:46px;
  left:0;
  bottom: 0;
  right:0;
  z-index: 9;
  font-family: PingFangSC-Regular;
  .basic-content {
    padding-left:15px;
    background: @white;
    p {
      font-size: 16px;
      color: @black;
    }
    span {
      font-size: 16px;
      color:@grey;
    }
    .fn {
      font-size:12px;
    }
    .basic-top {
      padding:14px 0 14px 8px;
      .flex(center);
    .user-img {
      width:62px;
      height:62px;
      box-sizing: border-box;
      margin-right: 15px;
      border-radius: 50%;
      overflow: hidden;
      background-color: #484759;
      img {
        width:100%;
        height:100%;
        }
      }
      .f-name {
        .flex(center);
        img {
          margin-left:9px;
          width:20px;
          height:20px;
        }
      }
    }
    .user-list {
      li {
        height: 50px;
        padding-right:15px;
        .flex(center);
        justify-content: space-between;
        p {
          width:266px;
          text-align: right;
        }
      }
      .list-margin{
        height:10px;
      }
      li:nth-child(4) {
        height: 72px;
        border-bottom: 0;
      }
    }
  }
  .wrap-hide {
      height: 10px;
    }
  .second-list {
    padding-left:15px;
    background: #ffffff;
      li {
        height:67px;
        list-style: none;
        padding-right:15px;
        .flex(center);
        justify-content: space-between;
        p {
          text-align: left;
          color:@black;
          font-size:16px;
          line-height:22px;
        }
        span {
          color:grey;
          font-size:12px;
          line-height:17px;
        }
        img {
          width:22px;
          height:22px;
        }
      }
    }
}

</style>
