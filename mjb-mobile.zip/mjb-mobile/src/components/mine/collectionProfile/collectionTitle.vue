 <!--
  describe：收款信息
  created by：周積坤
  date：2017-11-29
-->
<style lang="less" scoped>
@import '../../../assets/css/mine/mineTitle.less';
</style>

<template>
  <div>
    <my-header :title="top.title" :headerClass="top.headerTop" @previous="goBack" ></my-header>
    <div class="has-header collect-c">
      <swipeout>
      <swipeout-item v-for="(items, index) in dataMsg" :key="index" ref="swip">
        <div slot="right-menu">
          <swipeout-button @click.native="showPlugin(items.id, index)" style="font-size:17px;background:#FC4B4B;width: 66px;height:87px;border-top:0.5px solid #DEDFE0;border-bottom:1px solid #DEDFE0;">删除</swipeout-button>
        </div>
        <div slot="content" class="title-cont " @click="checkMsg(items, items.id)">
          <div class="collect-box">
            <div class="invoiceLeft">
              <div class="invoiceSecondCol">
                <div class="invoiceRow">
                <span>{{items.receiver}}</span>
                <section v-if=" items.is_default == 'Y' ">默认</section>
                </div>
                <p>{{items.bank_account}}</p>
                <p>{{items.bank_name}}</p>
              </div>
            </div>
          </div>
        </div>
      </swipeout-item>
      </swipeout>
        <div class="addMsg" @click="add()">
          <img :src="addMsg">
          <span>{{top.addTitle}}</span>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import { platform } from '@/platform';
  import { Swipeout, SwipeoutItem, SwipeoutButton, Confirm, TransferDomDirective as TransferDom } from 'vux';
  import myHeader from '../../common/header';
  import add from '../../../assets/images/mine/add.png';

  export default {
    components: {
      myHeader,
      platform,
      Swipeout,
      Confirm,
      SwipeoutItem,
      SwipeoutButton,
      TransferDom,
    },
    computed: {
      companyId() {
        return this.$store.state.mine.companyId;
      },
      collectTions() {
        return this.$store.state.mine.collectMsg;
      },
    },
    data() {
      return {
        addMsg: add,
        id: '',
        costFirst: [],
        top: {
          title: '收款信息',
          addTitle: '添加收款信息',
        },
        dataMsg: [],
        bankAdress: '',
      };
    },
    methods: {
      getCompanyId() { // 获取默认入账单位id
        if (!this.companyId) {
          this.$store.dispatch('getDefaultConfig').then((res) => {
            if (res.code === '0000') {
              console.log(res.data);
              this.id = res.data.companys[0].company_id;
              this.$store.commit('COMPANYID', this.id);
              this.getData(this.id);
            } else if (res && res.code) {
              this.showToast({ msg: `请求异常[${res.code}]:${res.msg}` });
            }
          });
        } else {
          this.getData(this.companyId);
        }
      },
      getData(id) {
        const params = {
          company_id: id,
          type: 'EMP',
          page_number: 1,
          page_size: 100000,
        };
        const self = this;
        this.showLoading();
        this.$store.dispatch('getReceiver', params).then((res) => {
          this.hideLoading();
          if (res && res.code === '0000') {
            if (res.data) {
              this.dataMsg = res.data.dataList;
              let dataFirst = '';
              for (let i = 0; i < this.dataMsg.length; i++) {
                if (this.dataMsg[i].is_default === 'Y') {
                  dataFirst = this.dataMsg.splice(i, 1);
                  break;
                }
              }
              if (dataFirst.length > 0) {
                this.dataMsg.unshift(dataFirst[0]);
              }
              this.$nextTick(() => {
                self.vuxChangeWidth();
              });
            }
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      },
      goBack() {
        if (this.$route.query.redict) {
          this.$router.push(this.$route.query.redict);
        } else {
          this.$router.push('/mine');
        }
      },
      add() {
        this.$store.commit('COLLECT_MSG', {});
        this.$router.push({ path: './executeMsg' });
      },
      checkMsg(obj, collectId) {
        return new Promise((resolve) => {
          this.getbankAddress(obj).then(() => {
            setTimeout(() => {
              this.$router.push({
                path: './executeMsg', query: { id: collectId },
              });
              this.$store.commit('COLLECT_MSG', Object.assign({}, obj, { bank_address: this.bankAdress }));
            }, 800);
            resolve();
          });
        });
      },
      getbankAddress(obj) {
        const params = {
          page_number: 1,
          page_size: 100,
          bank_name: obj.bank_name,
        };
        return new Promise((resolve) => {
          this.$store.dispatch('mineGetBankAdress', params).then((res) => {
            if (res && res.code === '0000') {
              if (res.data.info) {
                this.bankAdress = res.data.info[0].bank_address;
                resolve();
              }
            } else if (res && res.code) {
              this.showToast({ msg: `请求异常${res.code}` });
            }
          });
        });
      },
      vuxChangeWidth() {
      // 修改vux-swiper-item距离content的宽
        if (this.$refs.swip) {
          this.$refs.swip.forEach((swip) => {
            const list = swip.$slots['right-menu'][0].children.filter(one => one.tag);
            list.forEach((one) => {
              one.componentOptions.propsData.width = 66;
            });
          });
        }
      },
      // 删除弹框
      showPlugin(collectId, index) {
        const self = this;
        this.$vux.confirm.show({
          title: '删除',
          content: '删除该收款信息？',
          onConfirm() {
            self.deleteCollect(collectId, index);
          },
        });
      },
      // 确认删除
      deleteCollect(collectId, index) {
        this.$store.dispatch('deleteCollect', { id: collectId }).then((res) => {
          if (res.code === '0000') {
            this.dataMsg.splice(index, 1);
            // setTimeout(() => {
            //   this.$router.replace('/mine/collectionTitle');
            // }, 800);
            this.$store.commit('COLLECT_FLAG', 'delOk');
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      },
    },
    mounted() {
      this.getCompanyId();
    },
    activated() {
      this.getCompanyId();
    },
};
</script>
<style lang="less" scoped>

.collect-c {
  .vux-swipeout {
    .vux-swipeout-item {
      margin-top:10px;
      .collect-box {
        border-bottom: 1px solid #DEDFE0;
        background-color: #ffffff;
        height:87px;
        display: flex;
        box-sizing: border-box;
        padding: 0 15px;
        justify-content: space-between;
        .invoiceRow {
          display: flex;
          margin-top:12px;
          span {
            color:#000000;
            font-size:16px;
            line-height:22px;
          }
          section {
            font-size: 12px;
            background: #6CC60A;
            border-radius: 23px;
            width:40px;
            height: 19px;
            text-align: center;
            color:#FFFFFF;
            line-height: 19px;
            margin-left:10px;
          }
        }
        p {
          font-size: 14px;
          color:#9B9B9B;
          line-height:20px;
          }
      }
    }
  }
  .addMsg {
    height: 50px;
    margin-top:10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #FFFFFF;
    img {
      width:12px;
      height:12px;
      margin-right: 5px;
    }
    span {
      font-size: 16px;
      color: #000000;
    }
  }
}
</style>
