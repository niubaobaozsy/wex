<style lang="less" scoped>
@import '../../../assets/css/mine/mineMsg.less';
</style>

<template>
  <div>
    <my-header :title="top.title" :headerClass="top.headerTop" rightItem="保存" @previous="goBack" @on-click="savaCollect"></my-header>
    <div class="has-header">
      <ul>
        <li class="border-bottom">
          <span>收款方</span>
          <input type="text" placeholder="请填写" v-model="collectTions.receiver">
        </li>
        <li class="border-bottom" @click="selectType('0')">
          <span>开户行</span>
          <div class="arrow">
            <p :class="['choice', {'randomly':  collectTions.bank_name }]">{{ collectTions.bank_name || '请输入关键词'}}</p>
            <img :src="r_arrow" class="rt-arrow">
          </div>
        </li>
        <li class="border-bottom">
          <span>账号</span>
          <input type="text" placeholder="请填写" v-model="collectTions.bank_account" maxlength="19">
        </li>
        <!-- <li class="border-bottom" @click="selectType('1')">
          <span>开户城市</span>
          <div class="arrow">
            <p :class="['choice', {'randomly':  collectTions.city }]">{{ collectTions.city || '请选择'}}</p>
            <img :src="r_arrow" class="rt-arrow">
          </div>
        </li>
        <li @click="selectType('2')">
          <span>开户网点</span>
          <div class="arrow">
            <p :class="['choice', {'randomly':  collectTions.bank_name }]">{{ collectTions.bank_name || '请选择'}}</p>
            <img :src="r_arrow" class="rt-arrow">
          </div>
        </li> -->
        <li class="border-bottom">
          <span>开户行地址</span>
          <!-- <textarea type="text" placeholder="请输入开户行地址" v-model="collectTions.bank_address" class="address"></textarea> -->
          <input type="text" placeholder="请输入开户行地址" v-model="collectTions.bank_address" class="address">
        </li>
      </ul>
      <group style="margin-top:-10px;">
        <x-switch :title="top.isTrue" v-model="isFlag" @on-change="isDefault"></x-switch>
      </group>
      <div class="deleted" v-if="deleteShow" @click="del()">删除信息</div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
import { Group, XSwitch } from 'vux';
import MyHeader from '../../common/header';
import rArrow from '../../../assets/rt-arrow.png';

export default {
  components: {
    MyHeader,
    Group,
    XSwitch,
  },
  data() {
    return {
      r_arrow: rArrow,
      isFlag: false,
      deleteShow: '',
      type: '',
      city: '',
      verifyMsg: '',
      top: {
        title: '收款信息',
        isTrue: '设为默认',
      },
      addressParams: {
        page_number: 1,
        page_size: 100,
        bank_name: '',
      },
    };
  },
  computed: {
    collectTions() {
      return this.$store.state.mine.collectMsg;
    },
  },
  methods: {
    init() {
      this.deleteShow = this.$route.query.id;
      if (this.deleteShow) {
        this.isFlag = this.collectTions.is_default === 'Y';
        this.top.title = '编辑收款信息';
      }
    },
    goBack() {
      this.$router.go(-1);
    },
    isDefault(val) {
      this.collectTions.is_default = val ? 'Y' : 'N';
    },
    // 保存前校验
    verify() {
      const regUser = /[\u3400-\u9FFFa-zA-Z]{2,}/;
      // const regCarNumber = /[0-9]{16}/; // 银行卡账号校验
      if (!regUser.test(this.collectTions.receiver)) {
        this.verifyMsg = '用户名不正确';
        return false;
      } else if (!this.collectTions.bank_account) {
        this.verifyMsg = '请输入银行卡号';
        return false;
      } else if (!this.collectTions.bank_name) {
        this.verifyMsg = '请选择开户行';
        return false;
      } else if (!this.collectTions.bank_address) {
        this.verifyMsg = '请选择开户地址';
        return false;
      }
      return true;
    },
    savaCollect() {
      const params = {
        cmEmsEmpReceiver: {
          id: this.collectTions.id || null,
          receiver: this.collectTions.receiver,
          receiver_en: this.collectTions.receiver_en,
          bank_name: this.collectTions.bank_name,
          bank_category_name: this.collectTions.bank_category_name,
          bank_account: this.collectTions.bank_account,
          bank_code: this.collectTions.bank_code,
          bank_adress: this.collectTions.bank_adress,
          province: this.collectTions.province,
          card_type: this.collectTions.card_type,
          is_default: this.collectTions.is_default,
          swiftcode: this.collectTions.swiftcode || this.collectTions.attribute1,
          attribute1: this.collectTions.attribute1 || this.collectTions.swiftcode,
          city: this.collectTions.city,
          type: 'EMP',
        },
      };
      if (this.verify()) {
        this.$store.dispatch('mineSaveCollect', params).then((res) => {
          if (res && res.code === '0000') {
            console.log(res);
            this.showToast({ msg: '保存成功' });
            setTimeout(() => {
              this.$router.go(-1);
              // this.$router.push({
              //   path: '/mine/collectionTitle',
              // });
            }, 800);
          } else if (res && res.code) {
            this.showToast({ msg: '已保存' });
          }
        });
      } else {
        // let msg = this.verify;
        this.hideLoading();
        this.showToast({ msg: this.verifyMsg });
      }
    },
    // 挑选类型
    selectType(num) {
      if (num === '0') {
        this.$router.push({ path: './mineBackInfo', query: { type: num } });
        this.getbankAddress();
      } else if (num === '1') {
        this.$router.push({ path: './mineBackInfo', query: { type: num } });
      } else if (num === '2') {
        if (this.collectTions.bank_category_name && this.collectTions.city) {
          this.$router.push({ path: './mineBackInfo', query: { type: num } });
        } else {
          this.showToast({ msg: '请先选择开户行和开户城市', width: '14em', time: 800 });
        }
      }
    },
    getbankAddress() {
      this.addressParams.bank_name = this.collectTions.bank_category_name;
      this.$store.dispatch('mineGetBankAdress', this.addressParams).then((res) => {
        console.log(res);
      });
    },
    del() {
      const self = this;
      self.$vux.confirm.show({
        title: '删除该信息？',
        onConfirm() {
          self.$store.dispatch('deleteCollect', { id: self.deleteShow }).then((res) => {
            console.log(this.deleteShow);
            console.log(res);
            if (res.code === '0000') {
              setTimeout(() => {
                self.$router.replace('/mine/collectionTitle');
              }, 800);
              self.$store.commit('COLLECT_FLAG', 'delOk');
              self.showToast({ msg: '删除成功', width: '14em', time: 800 });
            }
          });
        },
      });
    },
  },
  mounted() {
    this.init();
  },
  activated() {
    this.init();
  },
};
</script>

<style>
.deleted {
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: #FC4B4C;
  background: #FFFFFF;
  margin-top:10px;
}
.weui-switch, .weui-switch-cp__box{
  width:46.1px;
  height:28px;
}
.weui-switch:after, .weui-switch-cp__box:after{
  width:25.3px;
  height:25.3px;
}
.address {
  resize: none;
    outline: none;
    border: none;
    font-size: 16px;
    line-height: 22px;
    width: 230px;
    color: #858585;
}
</style>
