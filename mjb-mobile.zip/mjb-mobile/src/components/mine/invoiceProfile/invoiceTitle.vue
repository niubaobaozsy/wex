 <!--
  describe：发票抬头
  created by：周積坤
  date：2017-11-29
-->

<template>
  <div>
    <my-header :title="top.title" :headerClass="top.headerTop" @previous="goBack"></my-header>
    <div class="has-header">
      <swipeout>
        <swipeout-item v-for="(items, index) in dataMsg" :key="index" ref="swip">
          <div slot="right-menu">
            <swipeout-button @click.native="showPlugin(items.config_id, index)" style="font-size:17px;background:#FC4B4B;width: 66px;height:100%;box-sizing:border-box;border-top:0.5px solid #DEDFE0;border-bottom:1px solid #DEDFE0;">删除</swipeout-button>
          </div>
          <div slot="content" @click="checkMsg(items, index)">
            <div class="invoice-box">
              <div class="invoiceSecondCol">
                <div class="invoiceRow">
                  <span>{{items.company_name}}</span>
                  <section v-if=" items.is_default == 'Y' ">默认</section>
                </div>
                <p>税号：{{items.tax_num}}</p>
              </div>
            </div>
          </div>
        </swipeout-item>
      </swipeout>
      <div class="addMsg" @click="add()">
        <img :src="addMsg">
        <span>{{top.addTitle}}</span>
      </div>
    </div>
    <co :show.sync="showCo" :defCo="defaultConfig.companys" @confirm="onSelectCo" />
  </div>
</template>
<script type="text/ecmascript-6">
import { platform } from '@/platform';
import { Swipeout, SwipeoutItem, SwipeoutButton, Confirm, TransferDomDirective as TransferDom } from 'vux';
import myHeader from '../../common/header';
import co from '../../common/company';
import add from '../../../assets/images/mine/add.png';

export default {
  components: {
    myHeader,
    platform,
    Swipeout,
    Confirm,
    SwipeoutItem,
    SwipeoutButton,
    TransferDom,
    co,
  },
  data() {
    return {
      addMsg: add,
      companys: '',
      defaultConfig: {},
      showCo: false,
      costFirst: [],
      top: {
        title: '发票抬头',
        addTitle: '添加发票抬头',
      },
      dataMsg: [],
    };
  },
  methods: {
    init() {
      this.showLoading();
      const self = this;
      this.$store.dispatch('getDefaultConfig').then((res) => {
        if (res && res.code === '0000') {
          this.hideLoading();
          if (res.data) {
            this.dataMsg = res.data.companys;
            // console.log(this.dataMsg);
            this.$nextTick(() => {
              self.vuxChangeWidth();
            });
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    // 入账单位
    onSelectCo(selCo) {
      const invoiceMsg = Object.assign({}, selCo);
      this.$store.commit('INVOICEMSG', invoiceMsg);
      this.$router.push({ path: '/mine/addInvoice' });
    },
    goBack() {
      this.$router.push('/mine');
    },
    add() {
      // this.$router.push({ path: '/mine/addInvoice' });
      this.showCo = true;
    },
    checkMsg(obj, index) {
      console.log(index);
      console.log(1213);
      this.$store.commit('INVOICEMSG', obj);
      setTimeout(() => {
        this.$router.push({
          path: '/mine/invoiceMsg', query: { id: obj.config_id },
        });
      }, 800);
    },
    vuxChangeWidth() {
      // 修改vux-swiper-item距离content的宽
      if (this.$refs.swip) {
        this.$refs.swip.forEach((swip) => {
          const list = swip.$slots['right-menu'][0].children.filter(one => one.tag);
          list.forEach((one) => {
            one.componentOptions.propsData.width = 66;
          });
        });
      }
    },
    // 删除弹框
    showPlugin(collectId, index) {
      console.log(collectId);
      const self = this;
      this.$vux.confirm.show({
        title: '删除',
        content: '删除该收款信息？',
        onConfirm() {
          self.deletInvoice(collectId, index);
        },
      });
    },
    // 确认删除
    deletInvoice(collectId, index) {
      console.log(222);
      console.log(collectId);
      console.log(index);
      this.$store.dispatch('deletInvoice', collectId).then((res) => {
        if (res.code === '0000') {
          console.log(res);
          console.log(this.dataMsg);
          this.dataMsg.splice(index, 1);
          setTimeout(() => {
            this.$router.replace('/mine/invoiceTitle');
          }, 800);
          this.$store.commit('COLLECT_FLAG', 'delOk');
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
  },
  mounted() {
    this.init();
  },
};
</script>
<style lang="less" scoped>
.has-header {
  .vux-swipeout {
    .vux-swipeout-item {
      margin-top: 10px;
      .invoice-box {
        display: flex;
        padding: 12px 15px;
        .invoiceSecondCol {
          flex: 1;
          .invoiceRow {
            display: flex;
            line-height: 20px;
            span {
              color: #000000;
              font-size: 16px;
            }
            section {
              font-size: 12px;
              background: #6CC60A;
              border-radius: 23px;
              width: 40px;
              height: 19px;
              text-align: center;
              color: #FFFFFF;
              line-height: 19px;
              margin-left: 15px;
            }
          }
          p {
            font-size: 14px;
            color: #9B9B9B;
            margin-top: 1px;
          }
        }
      }
    }
  }
  .addMsg {
    height: 50px;
    margin-top: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #FFFFFF;
    img {
      width: 12px;
      height: 12px;
      margin-right: 5px;
    }
    span {
      font-size: 16px;
      color: #000000;
    }
  }
}
</style>
