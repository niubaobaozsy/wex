
<template>
  <div>
    <my-header :title="top.title" :headerClass="top.headerTop" :rightItem="'分享'" @previous="goBack" @on-click="share" ></my-header>
    <div class="has-header">
      <div class="has-main-c">
      <div class="inv-content">
        <div class="inv-top">
          <div class="inv-two">
            <img :src='qrcodeImg'>
          </div>
          <span>开票时出示</span>
        </div>
        <div class="inv-bottom">
          <ul>
            <li>
              <span>名称</span>
              <p>{{invoiceMassge.invoice_head}}</p>
            </li>
            <li>
              <span>税号</span>
              <p>{{invoiceMassge.tax_num}}</p>
            </li>
            <li>
              <span>公司地址</span>
              <p>{{invoiceMassge.address}}</p>
            </li>
            <li>
              <span>公司电话</span>
              <p>{{invoiceMassge.telephone}}</p>
            </li>
            <li>
              <span>开户银行</span>
              <p>{{invoiceMassge.bank_name}}</p>
            </li>
            <li>
              <span>银行账户</span>
              <p>{{invoiceMassge.bank_account}}</p>
            </li>
          </ul>
        </div>
      </div>
      <div class="sections">点击右上角分享,可生成文字信息发送给朋友或同事</div>
      <div class="inv-footer">
      <div @click="del()">删除</div>
      <div @click="compile()">编辑</div>
    </div>
    </div>
    </div>
     <!-- 这是绑定将被复制到剪贴板的内容的按钮,通过点击分享按钮触发此按钮的点击事件从而复制内容到剪贴板 -->
    <button style="display:hidden" ref="copyButton" v-clipboard='cordInfo' @success="copySuccess" @error="copyError"></button>
  </div>
</template>
<script type="text/ecmascript-6">
import QRCode from 'qrcode';
import { Confirm } from 'vux';
import MyHeader from '../../common/header';

export default {
  components: {
    MyHeader,
    Confirm,
  },
  data() {
    return {
      qrcodeImg: '',
      top: {
        title: '发票详情',
      },
      dataMsg: [],
      cordInfo: '',
    };
  },
  computed: {
    invoiceMassge() { // 发票抬头信息
      return this.$store.state.mine.invoiceMsg;
    },
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    compile() {
      this.$router.push({ path: '/mine/addInvoice', query: { id: this.invoiceMassge.config_id } });
    },
    del() {
      const self = this;
      self.$vux.confirm.show({
        title: '删除该信息？',
        onConfirm() {
          self.$store.dispatch('deletInvoice', self.invoiceMassge.config_id).then((res) => {
            console.log(res);
            console.log(self.invoiceMassge.config_id);
            if (res.code === '0000') {
              setTimeout(() => {
                self.$router.replace('/mine/invoiceTitle');
              }, 800);
              self.$store.commit('COLLECT_FLAG', 'delOk');
              self.showToast({ msg: '删除成功', width: '14em', time: 800 });
            }
          });
        },
      });
    },

    // 生成二维码
    useqrcode() {
      this.cordInfo = `名称：${this.invoiceMassge.company_name}
                       税号：${this.invoiceMassge.tax_num}
                       公司地址：${this.invoiceMassge.address}
                       公司电话：${this.invoiceMassge.telephone}
                       开户银行：${this.invoiceMassge.bank_name}
                       银行账户：${this.invoiceMassge.bank_account}`;
      QRCode.toDataURL(this.cordInfo, (err, url) => {
        // console.log(url);
        // console.log(this.cordInfo);
        this.qrcodeImg = url;
      });
    },
    // 分享事件
    share() {
      this.$refs.copyButton.click();
      this.doCopy();
    },
    doCopy() {

    },
    // 成功复制到剪贴板
    copySuccess(val) {
      const self = this;
      self.$vux.confirm.show({
        title: '发票抬头信息已复制成功',
        content: '可以文字信息发送给您的朋友',
        onConfirm() {
          console.log(val);
        },
      });
    },
    // 复制到剪贴板失败
    copyError(error) {
      console.log(error);
    },
  },
  mounted() {
    this.useqrcode();
  },
};
</script>

<style lang="less" scoped>
body {
  background: #F4F4F4;
}
.has-main-c {
  padding: 15px 15px 0 15px;
  margin-bottom:23px;
  overflow: hidden;
  .inv-content {
    background: #FFFFFF;
    box-shadow: 0 0 4px 0 rgba(0,0,0,0.20);
    border-radius: 4px;
    padding:40px 14px 20px 16px;
    .inv-top {
      width:100%;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      border-bottom: 1px solid  #C1C1C1;
      .inv-two {
        border:1px solid #C1C1C1;
        height:154px;
        img {
          width:152px;
          height:152px;
        }
      }
      span {
        display: inline-block;
        margin: 20px 0;
        font-size: 12px;
        color: #858585;
      }
    }
    .inv-bottom {
      padding-top: 9px;
      ul {
        padding-left:4px;
        li {
          margin-top:11px;
          overflow: hidden;
          list-style: none;
          display: flex;
          span {
            font-size: 14px;
            color: #858585;
            width:56px;
          }
          p {
            overflow: hidden;
            font-size: 14px;
            color: #000000;
            margin-left:24px;
            line-height:20px;
          }
        }
      }
    }
  }
  .sections {
    font-size: 12px;
    color: #858585;
    text-align: center;
    margin-top:15px;
    margin-bottom:23px;
  }
}
.inv-footer {
  height:50px;
  position: fixed;
  width:100%;
  left: 0;
  right: 0;
  bottom:0;
  div {
    width:50%;
    height: 50px;
    line-height: 50px;
    text-align: center;
    font-size: 18px;float: left;

  }
  div:nth-child(1) {
    color:666666px;
    background: #ffffff;
  }
  div:nth-child(2) {
    color: #FFFFFF;
    background: #3DA5FE;
  }
}
</style>
