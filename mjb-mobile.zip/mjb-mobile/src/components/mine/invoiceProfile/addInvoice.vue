
<template>
  <div>
    <my-header :title="top.title" :headerClass="top.headerTop" rightItem="保存" @on-click="save"  @previous="goBack" ></my-header>
      <div class="has-header">
        <div class="z-companys" @click="cor()">
          <div class="border-bottom row">
            <p>入账单位</p>
            <div class="cloumns">
              <span>{{invoiceMassge.company_name}}</span>
              <img :src="r_arrow">
            </div>
            </div>
          </div>
        <ul>
          <li class="border-bottom">
            <span>名称</span>
            <p>{{invoiceMassge.invoice_head}}</p>
          </li>
          <li class="border-bottom">
            <span>税号</span>
            <p>{{invoiceMassge.tax_num}}</p>
          </li>
          <li class="border-bottom">
            <span>公司地址</span>
            <p>{{invoiceMassge.address}}</p>
          </li>
          <li class="border-bottom">
            <span>公司电话</span>
            <p>{{invoiceMassge.telephone}}</p>
          </li>
          <li class="border-bottom">
            <span>开户银行</span>
            <p>{{invoiceMassge.bank_name}}</p>
          </li>
          <li>
            <span>银行账户</span>
            <p>{{invoiceMassge.bank_account}}</p>
          </li>
        </ul>
        <group style="margin-top:-10px;">
        <x-switch :title="top.isTrue" v-model="isFlag" @on-change="isDefault"></x-switch>
      </group>
      <div class="deleted" v-if="deleteShow" @click="del()">删除信息</div>
      </div>
      <co :show.sync="showCo" :defCo="defaultConfig.companys" @confirm="onSelectCo" />
  </div>
</template>
<script type="text/ecmascript-6">
import { Group, XSwitch } from 'vux';
import MyHeader from '../../common/header';
import co from '../../common/company';
import rArrow from '../../../assets/rt-arrow.png';

export default {
  components: {
    MyHeader,
    Group,
    XSwitch,
    co,
  },
  data() {
    return {
      showCo: false,
      r_arrow: rArrow,
      isFlag: false,
      deleteShow: false,
      companys: '',
      num: 1,
      top: {
        title: '',
        isTrue: '设为默认',

      },
      data: [],
      defaultConfig: {},
    };
  },
  computed: {
    invoiceMassge() { // 发票抬头信息
      return this.$store.state.mine.invoiceMsg;
    },
  },
  methods: {
    init() {
      this.delHide();
      this.isFlag = this.invoiceMassge.is_default === 'N' ? this.isFlag : !this.isFlag;
    },
    goBack() {
      this.$router.push('/mine/invoiceTitle');
    },
    delHide() {
      if (this.invoiceMassge.config_id) {
        this.top.title = '编辑发票抬头';
        this.deleteShow = true;
      } else {
        this.top.title = '添加发票抬头';
        this.deleteShow = false;
      }
    },
    cor() {
      this.showCo = true;
    },
    save() {
      this.setDefault();
    },
    // 默认Value绑定
    isDefault(val) {
      console.log(val);
      this.invoiceMassge.is_default = val ? 'Y' : 'N';
    },
    // 设置默认
    setDefault() {
      const params = [
        {
          company: {
            company_id: this.invoiceMassge.company_id,
            company_name: this.invoiceMassge.company_name,
            invoice_head: this.invoiceMassge.invoice_head,
            config_id: this.invoiceMassge.config_id,
            is_default: this.invoiceMassge.is_default,
            config_type: 'company',
            ou_id: this.invoiceMassge.ou_id,
          },
        },
      ];
      this.savaDefualtList(params);
    },
    savaDefualtList(params) {
      console.log(999);
      console.log(params);
      this.$store.dispatch('saveDefalutInvoice', params).then((res) => {
        if (res && res.code === '0000') {
          console.log(res);
          this.showToast({ msg: '保存成功' });
          this.data = res.data.companys;
          for (let i = 0; i < this.data.length; i++) {
            if (this.invoiceMassge.company_name === this.data[i].company_name) {
              this.$store.commit('INVOICEMSG', this.data[i]);
              break;
            }
          }
          console.log(88);
          console.log(this.data);
          // this.$store.commit('INVOICEMSG', invoiceMsg);
          console.log(res);
          setTimeout(() => {
            this.$router.push({
              path: '/mine/invoiceMsg',
            });
          }, 800);
        } else if (res && res.code) {
          this.showToast({ msg: res.msg });
        }
      });
    },
    // 入账单位
    onSelectCo(selCo) {
      console.log(selCo);
      console.log(222);
      const invoiceMsg = Object.assign({}, selCo);
      this.$store.commit('INVOICEMSG', invoiceMsg);
    },
    del() {
      const self = this;
      const params = this.$route.query.id;
      self.$vux.confirm.show({
        title: '删除该信息？',
        onConfirm() {
          self.$store.dispatch('deletInvoice', params).then((res) => {
            console.log(res);
            if (res.code === '0000') {
              setTimeout(() => {
                self.$router.replace('/mine/invoiceTitle');
              }, 800);
              self.$store.commit('COLLECT_FLAG', 'delOk');
              self.showToast({ msg: '删除成功', width: '14em', time: 800 });
            }
          });
        },
      });
    },
  },
  mounted() {
    this.init();
  },
};
</script>

<style lang="less" scoped>
@black:       #000000;
@grey:        #858585;
@border-grey: #DEDFE0;
body {
  background: #F4F4F4;
}
.cloumns {
  display: flex;
  align-items: center;
}
.has-header {
  font-size: 16px;
  margin-top:56px;
  .z-companys {
    padding-left:15px;
    background: #ffffff;
    margin-bottom:10px;
    .row {
        padding:14px 14px 9px 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        span {
          text-align: right;
          display: inline-block;
          width:232px;
          color:#858585;
          line-height: 22px;
        }
        p {
          width:64px;
        }
        img {
          margin-left:12px;
          width:7.5px;
          height:13px;
        }
    }
  }
    ul {
      padding-left:15px;
      overflow: hidden;
      background: #ffffff;
      li {
        padding:14px 14px 14px 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        p {
          color:@black;
          width: 240px;
          text-align: right;
          line-height: 22px;
          font-size: 16px;
        }
        span {
          color:@grey;

        }
      }
    }
    .deleted {
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: #FC4B4C;
  background: #FFFFFF;
  margin-top:10px;
}
}


</style>
