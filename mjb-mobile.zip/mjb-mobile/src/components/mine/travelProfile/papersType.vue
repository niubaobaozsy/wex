<template>
  <div v-if="show" class="papers-type">
    <my-header title="选择证件类型" @previous="goBack" ></my-header>
    <ul class="has-header">
      <li class="border-bottom" v-for="(item,index) in listType" :key="index" @click="addValue(item)">{{item.name}}</li>
    </ul>
  </div>
</template>
<script>
  import myHeader from '../../common/header';

  export default {
    components: {
      myHeader,
    },
    props: {
      show: Boolean,
    },
    data() {
      return {
        listType: [
          {
            name: '身份证',
            type: 1,
          },
          {
            name: '护照',
            type: 2,
          },
          {
            name: '护照',
            type: 3,
          },
          {
            name: '回乡证',
            type: 4,
          },
          {
            name: '港澳通行证',
            type: 5,
          },
          {
            name: '军人证',
            type: 6,
          },
          {
            name: '台胞证',
            type: 7,
          },
          {
            name: '台胞证',
            type: 8,
          },
          {
            name: '外国人居住证',
            type: 9,
          },
          {
            name: '外国人出入境证',
            type: 10,
          },
        ],
      };
    },
    methods: {
      goBack() { // 返回
        this.$emit('on-hide');
      },
      addValue(item) {
        this.$emit('ievent', item);
        this.$emit('on-hide');
      },
    },
  };
</script>

<style lang="less" scoped>
.papers-type {
  position: fixed;
  z-index: 99;
  top: 0;
  left: 0;
  width: 100%;
  background-color: #f2f2f2;
  ul {
    li {
      line-height:50px;
      padding-left:15px;
      height:50px;
      color:#858585;
      background: #FFFFFF;
      transform-origin: 0 0;
      margin-bottom: 1px;
}
  }
}
</style>
