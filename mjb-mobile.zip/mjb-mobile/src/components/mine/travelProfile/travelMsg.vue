<template>
  <div>
    <my-header :title="top.title" :headerClass="top.headerTop" :rightItem="'保存'" @on-click="save" @previous="goBack" ></my-header>
    <div class="has-header">
      <div class="travelMsg-c">
      <div class="travel-m">
        <div :class="['travel-list', {'changeBg' : trick1 && !travelMsg.cnName}]">
          <div class="active border-bottom">
            <span>姓名</span>
            <input type="text" placeholder="请填写" :class="{'changeBg' : trick1 && !travelMsg.cnName}" v-model="travelMsg.cnName" required>
          </div>
        </div>
        <div :class="['travel-list', {'changeBg' : trick2 && !travelMsg.mobile}]">
          <div class="active border-bottom">
            <span>移动电话</span>
            <input type="text" placeholder="请填写" :class="{'changeBg' : trick2 && !travelMsg.mobile}" v-model="travelMsg.mobile" maxlength="11" required>
          </div>
        </div>
        <div @click="getSex" class="travel-list">
          <div class="active">
            <span>性别</span>
            <div class="arrow">
            <p :class="['choice', {'randomly': travelMsg.gender }]">{{travelMsg.gender || '请选择'}}</p>
              <img :src="r_arrow" >
            </div>
          </div>
        </div>
        <div class="hideBg"></div>
        <div class="travel-list" @click="show = true">
          <div class="active border-bottom">
            <span>证件类型</span>
            <div class="arrow">
              <p :class="['choice', {'randomly':  travelMsg.name }]">{{ travelMsg.name || '请选择'}}</p>
              <img :src="r_arrow" >
            </div>
          </div>
        </div>
        <div :class="['travel-list', {'changeBg' : trick3 && !travelMsg.certNumber}]">
          <div class="active">
            <span>证件号</span>
            <input type="text" placeholder="请填写" :class="{'changeBg' : trick3 && !travelMsg.certNumber}" v-model="travelMsg.certNumber" required>
          </div>
        </div>
      </div>
      <div class="deleted" v-if="deleteShow" @click="del()">删除信息</div>
      </div>
    </div>
    <papers-type :show="show" @on-select="selectArea"  @on-hide="hideArea" @ievent = "ievent"></papers-type>
    <actionsheet v-model="showAction" :menus="menus" :show-cancel="showCancel" @on-click-menu="addtxt">
    </actionsheet>
  </div>
</template>
<script type="text/ecmascript-6">
import { Actionsheet } from 'vux';
import myHeader from '../../common/header';
import papersType from './papersType';
import rArrow from '../../../assets/rt-arrow.png';

export default {
  components: {
    myHeader,
    Actionsheet,
    papersType,
  },
  data() {
    return {
      r_arrow: rArrow,
      showAction: false, // 是否显示弹出差旅单类型选择组件
      showCancel: true, // 是否显示取消按钮
      show: false,
      deleteShow: false,
      trick1: false,
      trick2: false,
      trick3: false,
      trick4: false,
      trick5: false,
      cnName: '',
      sex: '',
      papers: '',
      types: '',
      top: {
        title: '旅客信息',
      },
      dataMsg: [],
      menus: {
        menu0: '<span style="color: #666666;">男</span>',
        menu1: '<span style="color: #666666;">女</span>',
      },
    };
  },
  computed: {
    travelMsg: { // 发票抬头信息
      get() {
        return this.$store.state.mine.travelMsg;
      },
      set(val) {
        this.$store.state.mine.travelMsg = val;
      },
    },
  },
  methods: {
    init() {
      // if (this.travelMsg.gender) {  如果gender 有值 将不可点击;

      // }
      this.delHide();
    },
    goBack() {
      // this.$router.go(-1);
      this.$router.push({ path: '/mine/travelTitle' });
    },
    save() { // 保存添加旅客信息
      const params = {
        certNumber: this.travelMsg.certNumber,
        certType: this.travelMsg.certType,
        cnName: this.travelMsg.cnName,
        commPassengerId: this.travelMsg.commPassengerId,
        mobile: this.travelMsg.mobile,
        gender: this.travelMsg.gender,
      };
      if (this.verify()) {
        this.$store.dispatch('addTravelMsg', params).then((res) => {
          if (res && res.code === '1') {
            this.showToast({ msg: '保存成功' });
            this.trick1 = false;
            this.trick2 = false;
            this.trick3 = false;
            const travelObj = Object.assign(this.travelMsg, {}, params);
            this.$store.commit('TRAVELMSG', travelObj);
            this.deleteShow = true;
            setTimeout(() => {
              this.$router.push({
                path: '/mine/travelTitle',
              });
            }, 800);
          } else if (res.code === '0') {
            this.showToast({ msg: res.resultMsg });
          }
        });
      } else {
        // let msg = this.verify;
        this.hideLoading();
        this.showToast({ msg: this.verifyMsg });
        console.log(params);
      }
    },
    // 保存前校验
    verify() {
      const regUser = /^[\u4e00-\u9fa5]+$/;
      // const regCarNumber = /[0-9]{16}/;
      if (!regUser.test(this.travelMsg.cnName)) {
        this.verifyMsg = '用户名不正确';
        this.trick1 = true;
        return false;
      } else if (!this.travelMsg.mobile) {
        this.verifyMsg = '请填写：移动电话';
        this.trick2 = true;
        return false;
      } else if (!this.travelMsg.gender) {
        this.verifyMsg = '请选择性别';
        return false;
      } else if (!this.travelMsg.name) {
        this.verifyMsg = '请选择证件类型';
        return false;
      } else if (!this.travelMsg.certNumber) {
        this.verifyMsg = '请填写证件号';
        this.trick3 = true;
        return false;
      }
      return true;
    },
    delHide() {
      if (this.travelMsg.commPassengerId) {
        this.top.title = '编辑旅客信息';
        this.deleteShow = true;
      } else {
        this.top.title = '添加旅客信息';
        this.deleteShow = false;
      }
    },
    getSex() {
      this.showAction = true;
    },
    selectArea() {
      this.show = true;
    },
    hideArea() {
      this.show = false;
    },
    addtxt(ket, item) { // 点击弹出差旅单类型选择组件
      if (item) {
        let str = '';
        str = item.split('>');
        str = str[1].split('<')[0];
        this.travelMsg.gender = str;
      }
    },
    del() {
      const self = this;
      self.$vux.confirm.show({
        title: '删除该信息？',
        onConfirm() {
          self.$store.dispatch('deleteTravel', { commPassengerId: self.travelMsg.commPassengerId }).then((res) => {
            console.log(res);
            if (res.code === '1') {
              setTimeout(() => {
                self.$router.replace('/mine/travelTitle');
              }, 800);
              self.showToast({ msg: '删除成功', width: '14em', time: 800 });
            }
          });
        },
      });
    },
    ievent(item) {
      this.papers = item;
      this.travelMsg.certType = this.papers.type;
      const params = {
        name: this.papers.name,
      };
      const papersObj = Object.assign(this.travelMsg, {}, params);
      this.$store.commit('TRAVELMSG', papersObj);
    },
  },
  mounted() {
    this.init();
    console.log(this.travelMsg);
  },
};
</script>
<style lang="less" scoped>
@black:       #000000;
@grey:        #C3C3C3;
@border-grey: #DEDFE0;
body {
  background: #F4F4F4;
}

.travelMsg-c {
  font-size: 16px;
  .travel-m {
    background: #ffffff;
    .travel-list {
      background: #FFFFFF;
      box-sizing: border-box;
      padding:0 13px 0 15px;
      &.changeBg{
      background: rgba(255,127,127,0.2);
      }
      .active {
        height:50px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        input {
          height:22px;
          border:none;
          text-align: right;
          color:#858585;
          outline: medium;
          font-size: 16px;
          &::-webkit-input-placeholder {
            color: @grey;
          }
          &.changeBg {
            background: rgba(255,127,127,0);
          }
        }
        .choice {
          color:@grey;
        }
        .randomly {
          color: #858585;
          line-height: 20px;
        }
        span {
          color:@black;
          line-height: 22px;
        }
        .arrow {
          display: flex;
          align-items: center;
          img {
            width:7.5px;
            height:16px;
            margin-left:11.5px;
          }
        }
      }
    }
    .hideBg{
      height:10px;
      background: #F4F4F4;
    }
  }
}
</style>

