 <!--
  describe：报销基本信息
  created by：周積坤
  date：2017-11-29
-->
<style lang="less" scoped>
@import '../../../assets/css/mine/mineMsg.less';
</style>
<template>
  <div>
    <my-header title="报销基本信息" @previous="goBack" ></my-header>
    <div class="has-header container">
      <ul>
        <li class="border-bottom" @click="onCellEClick()">
          <span>预算部门</span>
          <div class="arrow">
            <p :class="['choice', {'randomly':  defCfg.busi_org_name}]">{{ defCfg.busi_org_name || '请选择'}}</p>
            <img :src="r_arrow" class="rt-arrow">
          </div>
        </li>
        <li class="border-bottom">
          <span>预算主体</span>
          <div class="arrow">
            <p class ='randomly'>{{ defCfg.parent_org_name || '' }}</p>
            <!-- <img :src="r_arrow" class="rt-arrow"> -->
          </div>
        </li>
      </ul>
      <ul>
        <li @click="cor()">
          <span>入账单位</span>
          <div class="arrow">
            <p :class="['choice', {'randomly':  defCfg.company_name}]">{{ defCfg.company_name || '请选择'}}</p>
            <img :src="r_arrow" class="rt-arrow">
          </div>
        </li>
      </ul>
    </div>
    <co :show.sync="showCo" :defCo="defCfg.companys" @confirm="onSelectCo" />
    <bugdet-org @confirm="onSelectBug" :show.sync="showBdOrg" :defBdOrg="defCfg.busiOrgs" />
  </div>
</template>
<script type="text/ecmascript-6">
  import myHeader from '../../common/header';
  import co from '../../common/company';
  import bugdetOrg from '../../common/bugdetOrg';
  import rArrow from '../../../assets/rt-arrow.png';

  export default {
    components: {
      myHeader,
      co,
      bugdetOrg,
    },
    data() {
      return {
        r_arrow: rArrow,
        showCo: false,
        showBdOrg: false,
        defCfg: {
          busi_org_name: '',
          parent_org_name: '',
          company_name: '',
          companys: [],
          busiOrgs: [],
        },
      };
    },
    methods: {
      goBack() { // 返回
        this.$router.push(this.$route.query.redirect || '/mine');
      },
      cor() {
        this.showCo = true;
      },
      onCellEClick() {
        this.showBdOrg = true;
      },
      // 入账单位
      onSelectCo(selCo) {
        let configId = '';
        if (this.defCfg.companys) {
          this.defCfg.companys.forEach((item) => {
            if (selCo.company_name === item.company_name) {
              configId = item.config_id;
            }
          });
        }
        const params = [{
          company: {
            company_id: selCo.company_id,
            config_type: 'company',
            ou_id: selCo.ou_id,
            is_default: 'Y',
            invoice_head: selCo.invoice_head,
            company_name: selCo.company_name,
          },
        }];
        if (configId) params[0].company.config_id = configId;
        this.savaDefault(params);
      },
      // 预算部门
      onSelectBug(buget) {
        let configId = '';
        if (this.defCfg.busiOrgs) {
          this.defCfg.busiOrgs.forEach((item) => {
            if (buget.busi_org_name === item.busi_org_name) {
              configId = item.config_id;
            }
          });
        }
        const params = [{
          busiOrg: {
            busi_org_code: buget.busi_org_code,
            busi_org_name: buget.busi_org_name,
            busi_org_id: buget.busi_org_id,
            is_default: 'Y',
            config_type: 'busiOrg',
          },
        }];
        if (configId) params[0].busiOrg.config_id = configId;
        this.savaDefault(params);
      },
      getData() {
        this.showLoading();
        this.$store.dispatch('getDefaultConfig').then((res) => {
          this.hideLoading();
          if (res.code === '0000') {
            this.defCfg = {
              busi_org_name: res.data.busiOrg ? res.data.busiOrg.busi_org_name : null,
              parent_org_name: res.data.busiOrg ? res.data.busiOrg.busi_main_org_name : null,
              company_name: res.data.company ? res.data.company.company_name : null,
              companys: res.data.companys,
              busiOrgs: res.data.busiOrgs,
            };
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常[${res.code}]:${res.msg}` });
          }
        });
      },
      savaDefault(params) {
        this.$store.dispatch('savaDefaultConfig', params).then((res) => {
          if (res.code === '0000') {
            this.getData();
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常[${res.code}]:${res.msg}` });
          }
        });
      },
    },
    mounted() {
      this.getData();
    },
  };
</script>
 <style lang="less" scoped>
 .container {
    padding-top: 16px;
    ul {
      margin-top: 16px;
      &:first-child {
        margin-top: 0;
      }
    }
    .randomly {
      width:205px!important;
      word-wrap: break-word;
    }
 }
 </style>
