<!--
  describe："我的"页面 默认子组件
  created by：Yim Lee
  date：2017-10-17
-->
<style lang="less" scoped>
@import '../../assets/css/mine/mineIndex.less';
</style>
<template>
  <div class="mine-wrap">
    <!-- "我的"页面内容 -->
    <div class="mine-content">
      <!-- 用户信息部分 -->
      <div class="mine-banner">
        <div class="mine-userInfo columns is-mobile is-gapless" @click="showMsg = true">
          <div class="user-img"><img :src="user.avatar || defaultAvatar"></div>
          <div class="user-name column">
            <span class="u-name">{{user.userName}}</span>
            <span class="u-name" v-if="user.org_name">{{user.org_name[0]}}</span>
          </div>
          <!-- 右箭头 -->
          <img :src="icons.rArrow" class="rt-arrow">
        </div>
      </div>
      <!-- 功能列表部分 -->
      <div v-for="(menus,menusIndex) in mineList" :key="menusIndex" class="margin-bottom">
        <div v-for="(item, index) in menus" :key="index" :class="['mine-function', { 'invisible': item.invisible }]" @click="onMenuClick(item)" v-debug="item.invisible" v-if="!item.hidden">
          <ul class="columns is-mobile function is-gapless">
            <img :src="icons[item.icon]" class="func-icon">
            <li :class="['name','column', {'border-bottom': index !== menus.length-1}]">
              <span class="f-name">{{ item.name }}</span>
              <!-- 右箭头 -->
              <img :src="icons.rArrow" class="func-arrow" v-if="!item.hideArrow">
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- 固定footer组件（复用） -->
    <footerBar :index="4" :tabName="'mine'"></footerBar>
    <!-- 个人基础信息组件 -->
    <basicMsg :list="user" :show="showMsg" @on-select="selectArea"  @on-hide="hideArea"></basicMsg>
    <actionsheet v-model="showActionsheet" :menus="menus" show-cancel @on-click-menu="onActionsheetClick">
      <p slot="header" class="logout-tip">
        <span>退出后不会删除任何历史数据，下次登录依然可以使用本账号。</span>
      </p>
    </actionsheet>
  </div>
</template>
<script>
import { platform } from '@/platform';
import { Actionsheet } from 'vux';
import footerBar from '../common/footerBar';
import basicMsg from './collectionProfile/basicMsg';
import back from '../../assets/images/common/nav_back.png';
import gatheringInfo from '../../assets/images/mine/gatheringInfo.png';
import invoiceInfo from '../../assets/images/mine/invoiceInfo.png';
import touristInfo from '../../assets/images/mine/touristInfo.png';
import reimbursement from '../../assets/images/mine/reimbursement.png';
import setting from '../../assets/images/mine/setting.png';
import logout from '../../assets/images/mine/logout.png';
// import addFunction from '../../assets/images/mine/addFunction.png';
// import helpCenter from '../../assets/images/mine/helpCenter.png';
// import onlineCalling from '../../assets/images/mine/onlineCalling.png';
import rArrow from '../../assets/rt-arrow.png';
import defaultAvatar from '../../assets/images/common/defaultAvatar.png';

export default {
  components: {
    Actionsheet,
    footerBar,
    basicMsg,
  },
  data() {
    return {
      icons: {
        gatheringInfo,
        invoiceInfo,
        touristInfo,
        reimbursement,
        logout,
        setting,
        rArrow,
      },
      showMsg: false,
      showActionsheet: false,
      top: {
        img: back,
        title: '费用预算占用分析',
      },
      mineList: [ // 功能列表
        // [
        //   {
        //     icon: 'gatheringInfo',
        //     name: '收款信息',
        //     alias: '/mine/collectionTitle', // 这里是要跳转的路由路径
        //   },
        //   {
        //     icon: 'invoiceInfo',
        //     name: '发票抬头',
        //     alias: '/mine/invoiceTitle', // 这里是要跳转的路由路径
        //   },
        //   {
        //     icon: 'touristInfo',
        //     name: '旅客信息',
        //     alias: '/mine/travelTitle', // 这里是要跳转的路由路径
        //   },
        //   {
        //     icon: 'reimbursement',
        //     name: '报销基本信息',
        //     alias: '/mine/reimburseTitle', // 这里是要跳转的路由路径
        //   },
        // ], [
        //   {
        //     icon: 'logout',
        //     name: '退出登录',
        //     hdlFnName: 'showLogout',
        //     hideArrow: true,
        //   },
        //   // {
        //   //   icon: setting,
        //   //   name: '关于美捷报',
        //   //   alias: '', // 这里是要跳转的路由路径
        //   // },
        //   // {
        //   //   icon: setting,
        //   //   name: '设置',
        //   //   alias: '/', // 这里是要跳转的路由路径
        //   // },
        //   // {
        //   //   icon: addFunction,
        //   //   name: '增值功能',
        //   //   alias: '/', // 这里是要跳转的路由路径
        //   // },
        //   // {
        //   //   icon: helpCenter,
        //   //   name: '帮助中心',
        //   //   alias: '/', // 这里是要跳转的路由路径
        //   // },
        //   // {
        //   //   icon: onlineCalling,
        //   //   name: '在线客服',
        //   //   alias: '/', // 这里是要跳转的路由路径
        //   // },
        // ], [
        //   {
        //     icon: 'setting',
        //     name: '关于美捷报',
        //     alias: '', // 这里是要跳转的路由路径
        //     invisible: true,
        //   },
        // ],
      ],
      defaultAvatar,
      menus: [
        {
          label: '退出登录',
          type: 'warn',
        }
      ],
    };
  },
  computed: {
    userInfoImage() {
      return this.$store.state.mine.uploadImg;
    },
    userInfo() {
      return this.$store.state.userInfo;
    },
    user() {
      return this.$store.state.userInfo.user;
    },
    userMsg() {
      return this.$store.state.mine.userMsg;
    },
    baseConfig() {
      return this.$store.state.baseConfig;
    },
    mineMenuCfg() {
      return this.$store.state.menuConfig.mine.children;
    },
  },
  methods: {
    // 路由跳转（这里只接受路由路径path的参数，不接受路由名称name的参数）
    onMenuClick(item) {
      if (item.alias) {
        this.$router.push({ path: item.alias });
      } else if (item.hdlFnName) {
        this[item.hdlFnName]();
      }
    },
    // 个人基础信息显示
    selectArea() {
      this.showMsg = true;
    },
    hideArea() {
      this.showMsg = false;
    },
    showLogout() {
      this.showActionsheet = true;
    },
    logout() {
      this.$store.commit('ROOT_LOGOUT');
      this.$router.push('/');
    },
    onActionsheetClick() {
      this.untiePushService(this.userInfo.employeeNumber).then(() => {
        this.logout();
      }).catch((err) => {
        const _this = this;
        this.$vux.confirm.show({
          title: '登出失败',
          content: `解除信息推送服务失败(${JSON.stringify(err)})，继续退出登录仍能接收消息推送`,
          confirmText: '继续退出',
          cancelText: '稍后重试',
          onConfirm() {
            _this.logout();
          },
        });
      });
    },
    getUserMsg() {
      this.$store.dispatch('getUserInfo', { id: this.user.userId }).then((rep) => {
        if (rep && rep.code === '0000') {
          this.$store.commit('USERMSG', rep.data);
        } else if (rep && rep.code) {
          this.showToast({ msg: `获取用户信息失败[${rep.code}]` });
        }
      });
    },
  },
  mounted() {
    this.getUserMsg();
  },
  created() {
    Object.keys(this.mineMenuCfg).forEach((item, index) => {
      if (!this.mineList[this.mineMenuCfg[item].group]) {
        this.mineList[this.mineMenuCfg[item].group] = [];
      }
      this.mineList[this.mineMenuCfg[item].group].push(this.mineMenuCfg[item]);
    });
    if (this.user.org) {
      this.user.org_name = Object.values(this.user.org);
    }
  },
};
</script>
