<!--
  describe：预算明细
  created by：张绍武
  date：2017-11-11
-->
<template>
  <div class="subject" v-if="show">
    <my-header :title="top.type" @previous="goBack"></my-header>
    <ul class="main" v-if="isCompnayPayAir">
      <!-- 含有对公飞机票的预算行展示  -->
        <li v-for="(item,index) in budgets" :key="index">
          <div class="border-bottom border-top"  @click="showDetail(index)">
            <img :src="top.showbottom" v-show="!item.showDetail" class="img-show">
            <img :src="top.hidetop" v-show="item.showDetail" class="img-show">
            <section class="main-top" >预算明细{{index+1}}</section>
          </div>
          <template v-if="item.showDetail">
            <div>
              <span>申请金额</span>
              <section v-if="item.approve_reim_amount">￥{{ item.approve_reim_amount.toFixed(2) }}</section>
              <section v-if="item.approve_amount">￥{{ item.approve_amount.toFixed(2) }}</section>
            </div>
            <div>
              <span>预算部门</span>
              <section>{{item.busi_org_name}}</section>
            </div>
            <div>
              <span>经济事项</span>
              <section>{{item.fee_type_name}}</section>
            </div>
            <div>
              <span>预算来源</span>
              <section>{{item.budget_node_desc}}</section>
            </div>

             <div>
              <span>出行人</span>
              <section>{{item.attribute3}}</section>
            </div>

             <div>
              <span>地点</span>
              <section>{{item.attribute7}} - {{item.attribute10}}</section>
            </div>

            <div>
              <span>日期</span>
              <section>{{ (item.attribute4 && item.attribute12) ? `${formatDate(item.attribute4)} - ${formatDate(item.attribute12)}` : '' }}</section>
            </div>

            <div>
              <span>业务描述</span>
              <section>{{item.attribute5}}</section>
            </div>

          </template>
        </li>
    </ul>

    <ul class="main" v-else>
        <!-- 不含有对公飞机票的预算行展示  -->
        <li v-for="(item,index) in budgets" :key="index">
          <div class="border-bottom border-top"  @click="showDetail(index)">
            <img :src="top.showbottom" v-show="!item.showDetail" class="img-show">
            <img :src="top.hidetop" v-show="item.showDetail" class="img-show">
            <section class="main-top" >预算明细{{index+1}}</section>
          </div>
          <template v-if="item.showDetail">
            <div>
              <span>申请金额</span>
              <section v-if="item.approve_reim_amount">￥{{ item.approve_reim_amount.toFixed(2) }}</section>
              <section v-if="item.approve_amount">￥{{ item.approve_amount.toFixed(2) }}</section>
            </div>
            <div>
              <span>预算部门</span>
              <section>{{item.busi_org_name}}</section>
            </div>
            <div>
              <span>经济事项</span>
              <section>{{item.fee_type_name}}</section>
            </div>
            <div>
              <span>预算来源</span>
              <section>{{item.budget_node_desc}}</section>
            </div>
            <div>
              <span>业务描述</span>
              <section>{{item.sensitive_info}}</section>
            </div>
          </template>
        </li>
    </ul>

    <div class="cnt">金额合计：<span>￥{{budgetFee.toFixed(2)}}</span></div>
  </div>
</template>

<script>
import MyHeader from './header';
import rtarrow from '../../assets/rt-arrow.png';
import hideTravel from '../../assets/images/fee/approve/hideTravel.png';
import showTravel from '../../assets/images/fee/approve/showTravel.png';

export default {
  components: {
    MyHeader,
  },
  props: {
    title: {
      type: Array,
      default: () => [],
    },
    show: Boolean,
  },
  data() {
    return {
      top: {
        type: '预算来源',
        arrow: rtarrow,
        hidetop: hideTravel,
        showbottom: showTravel,
      },
      budgets: [],
      isCompnayPayAir: false,
    };
  },
  watch: {
    show() {
      const copy = Object.assign([], this.title);
      copy.forEach(item => {
        if (item.showDetail === undefined) item.showDetail = true;
      });
      this.budgets = copy;
    }
  },
  computed: {
    budgetFee() {
      let amountFee = 0;
      this.isCompnayPayAir = false;
      this.title.forEach((items) => {
        if(items.attribute1 === 'COMPANY' && items.attribute13 === 'AIRPLANE'){
          this.isCompnayPayAir = true;
        }
        if (items.approve_reim_amount) {
          amountFee += items.approve_reim_amount ? items.approve_reim_amount : 0;
        } else {
          amountFee += items.approve_amount ? items.approve_amount : 0;
        }
      });
      return parseFloat(amountFee);
    },
  },
  methods: {
      // 将日期格式化成年月日的形式
    formatDate(date) {
      const formatDate = new Date(date.split(' ')[0]);
      const year = formatDate.getFullYear();
      const month = formatDate.getMonth() + 1;
      const day = formatDate.getDate();
      return `${year}年${month}月${day}日`;
    },

    goBack() {
      this.$emit('on-hide');
    },
    // 点击收起
    showDetail(index) {
      this.budgets[index].showDetail = !this.budgets[index].showDetail;
      this.budgets = Object.assign([], this.budgets);
    },
  },
};
</script>

<style lang='less' scoped>
  .subject{
    width:100%;
    height:130%;
    position: fixed;
    top:0;
    left:0;
    bottom: 0;
    right:0;
    background:#f2f2f2;
    z-index: 99999;
  }
  .main{
    font-size: 16px;
    margin-top: 56px;
    color: #000000;
    list-style: none;
    img{
      width:7px;
      height:6px;
      padding-right:8px;
    }
    p{
      width: 0;
      height: 0;
      border-left: 6px solid transparent;
      border-right: 6px solid transparent;
      border-top: 7px solid #AFAFAF;
      margin-right: 6px;
    }
    li{
      background: #ffffff;
      margin-top: 10px;
      font-size:14px;
      div{
        padding:10px 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 0 0 0 #DEDFE0, 0 0 0 0 #DEDFE0;
        span{
          display: inline-block;
          width:120px;
          color: #858585;
        }
        section{
          display: inline-block;
          text-align: right;
        }
      }
      div:nth-child(1){
        height:50px;
        box-sizing:content-box;
        justify-content: initial;
        margin:0;
        padding:0 15px;
        section{
          font-size:16px;
        }
      }
        div:nth-child(2){
        section{
          font-size:16px;
        }
      }
    }
  }
  .cnt {
    width:100%;
    padding:0 15px;
    box-sizing:border-box;
    height: 50px;
    text-align: right;
    line-height: 50px;
    margin-bottom: 0;
    background: #ffffff;
    box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
    position: fixed;
    bottom: 0;
    span{
      color: #3DA5FE;
    }
  }
</style>
