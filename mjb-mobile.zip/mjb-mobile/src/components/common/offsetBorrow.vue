 <!--
  describe：冲抵借款
  created by：周積坤
  date：2017-11-22
-->
<template>
  <div class="related-container" v-if="show">
    <my-header :title="top.title" :headerClass="top.headerTop" @previous="goBack" ></my-header>
    <div class="wrap">
      <div class="data-content" v-for="(item, index) in showList" :key="index">
          <div class="left">
            <div class="typeColor">借款</div>
          </div>
          <div class='right'>
            <div>
              <div>{{item.sensitive_info}}</div>
              <div class="date">{{item.creation_date}}</div>
            </div>
            ￥{{ item.repay_amount.toFixed(2)}}
          </div>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import myHeader from './header';

  export default {
    components: {
      myHeader,
    },
    data() {
      return {
        top: {
          title: '冲抵借款',
        },
        ids: [],
      };
    },
    props: {
      showList: Array,
      show: Boolean,
    },
    methods: {
      goBack() { // 返回
        this.$emit('on-hide');
      },
    },
  };
</script>
<style lang="less" scoped>
  @white:#ffffff;

  .related-container {
    width: 100%;
    height:100%;
    background-color: #F4F4F4;
    position: fixed;
    top:46px;
    left:0;
    bottom:0;
    z-index: 999999;
    overflow: auto;
    .wrap {
      background: @white;
      .data-content {
        display: flex;
          .left {
            padding:15px;
            .typeColor{
              width: 40px;
              height: 40px;
              border-radius: 50%;
              color: @white;
              font-size: 12px;
              text-align: center;
              align-items: center;
              line-height: 40px;
              flex: none;
              background-color: #FF7F7F;
            }
          }
          .right {
              padding: 12px 15px 12px 0;
              display: flex;
              font-size: 16px;
              justify-content: space-between;
              border-bottom: 0.5px solid #DEDFE0;
              align-items: center;
              flex:1;
              .data {
                color:#9B9B9B;
                font-size:14px;
              }
            }
      }
    }
  }
</style>
