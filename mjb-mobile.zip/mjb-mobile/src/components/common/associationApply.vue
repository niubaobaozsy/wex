<!--
  describe: association apply bill
  created by: zhuangyh
  date: 2017-12-23
-->
<template>
  <div class="container" v-if="show">
    <div class="scrollWrap" ref="scrollWrap">
      <div class="scroll">
        <div v-for="(item, index) in applyList" :key="index" class="item-cell border-bottom" @click="pick(item)">
          <span class="check-box" :class="{checked: item.checked}"></span>
          <div class="type" :class="{'blue': item.order_type !== 'TY', 'grey': type=== 'CL'&&!item.available}">{{item.order_type === 'TY' ? '通用' : '差旅'}}</div>
          <!-- <div class="summary" @click="viewDetail(item, item.fee_apply_id)"> -->
          <div class="summary">
            <p v-if="item.attribute15_name">{{item.attribute15_name}}</p>
            <p>{{item.reason_desc}}</p>
            <span>{{item.apply_date}}</span>
          </div>
          <div class="amount">
            <div>￥{{ parseFloat(item.avail_amount).toFixed(2) }}</div>
            <span>剩余预算</span>
          </div>
        </div>
      </div>
    </div>
    <div v-if="isloading && !applyList.length" class="empty">
      <img src="../../assets/images/common/no_data.png">
      <p>暂无数据</p>
    </div>
    <my-header :title="title" @previous="goBack" rightItem="确定"  @on-click="onConfirm"></my-header>
  </div>
</template>
<script type="text/ecmascript-6">
  import BScroll from 'better-scroll';
  import myHeader from './header';
  import noDataImg from '../../assets/images/common/no_data.png';

  export default {
    components: {
      myHeader,
    },
    data() {
      return {
        noDataImg,
        applyList: [],
        pickedList: [],
        isloading: false,
      };
    },
    props: {
      title: {
        type: String,
        required: false,
        default: '关联申请单',
      },
      show: {
        type: Boolean,
        required: true,
        default: false,
      },
      value: {
        type: Array,
        required: true,
        default:  () => [],
      },
      type: {
        type: String,
        required: false,
        default: 'LM',
      },
      traveltype:{
        type: Object,
        required: false,
        default: () => { },
        // default: { },
      }
    },
    computed: {
      myApplyMenuCfg() {
        return this.$store.state.menuConfig.fee.children.myApply.children;
      }
    },
    methods: {
      goBack() {
        this.$emit('hide', this.pickedList);
        setTimeout(() => {
          this.$emit('update:show', false);
        }, 200);
      },
      getAvaliableFeeApply() {
        const params = {
          query_param: {
            page_size: 100,
            page_number: 1,
//            fee_apply_code: 'EA17',
            order_type: this.type,
          },
        };
        this.showLoading();
        this.$store.dispatch('getAvaliableFeeApply', params)
          .then((rep) => {
            this.hideLoading();
            this.isloading = true;
            if (rep && rep.code === '0000' && rep.data && rep.data.info) {
              rep.data.info.forEach((item) => {
                item.checked = false;
                item.available = this.type !== 'CL';
              });
              this.applyList = rep.data.info;
              this.pickedList = this.value;
              this.applyList.forEach((item) => {
                if (this.type === 'CL' && item.attribute2 === 'Y' && (!this.pickedList.length || item.fee_apply_id === this.pickedList[0].fee_apply_id)) {
                  item.available = true;
                }
                if(this.type ==='CL' && this.myApplyMenuCfg[this.type].hasTravelType && Object.keys(this.traveltype).length>0){
                  item.attribute15 = item.attribute15 || 'NORMAL_TRIP';
                   item.attribute15_name = this.traveltype[item.attribute15];
                }
                this.pickedList.forEach((picked) => {
                  if (item.fee_apply_l_id === picked.fee_apply_l_id) {
                    item.checked = true;
                  }
                });
              });
              this.$nextTick(() => {
                this.scroll = new BScroll(this.$refs.scrollWrap, { click: true });
              });
            } else if (rep && rep.code) {
              this.showToast({ msg: `请求异常(${rep.code})` });
            }
          });
      },
      selectAvaliableFeeApply() {
        const params = {
          page_size: 100,
          page_number: 1,
          query_param: {
            biz_flag: '0',
            fee_apply_code: '',
            sensitive_info: '',
          },
        };
        this.showLoading();
        this.$store.dispatch('selectAvaliableFeeApply', params)
          .then((rep) => {
            this.hideLoading();
            if (rep && rep.code === '0000' && rep.data && rep.data.info) {
              this.isloading = true;
              rep.data.info.forEach((item) => {
                item.checked = false;
              });
              this.applyList = rep.data.info;
              this.pickedList = this.value;
              this.applyList.forEach((item) => {
                this.pickedList.forEach((picked) => {
                  if (item.fee_apply_id === picked.fee_apply_id) {
                    item.checked = true;
                  }
                });
              });
              this.$nextTick(() => {
                this.scroll = new BScroll(this.$refs.scrollWrap, { click: true });
              });
            } else if (rep && rep.code) {
              this.showToast({ msg: `请求异常(${rep.code})` });
            }
          });
      },
      onConfirm() {
        const pickedList = [];
        this.applyList.forEach((item) => {
          if (item.checked) {
            pickedList.push(item);
          }
        });
        this.$emit('input', pickedList);
        this.$emit('confirm', pickedList);
        setTimeout(() => {
          this.$emit('update:show', false);
        }, 200);
      },
      viewDetail(item, id) {
        if (this.type === 'LM') {
          setTimeout(() => {
            this.$router.push({
              path: 'viewApplyDetail', query: { id },
            });
          }, 800);
        } else {
          setTimeout(() => {
            this.$router.push({
              path: 'viewApplyDetail', query: { id },
            });
          }, 800);
        }
      },
      pick(item) {
        if (this.type === 'LM') {
          if (!item.checked) {
            this.applyList.forEach((apply) => {
              apply.checked = false;
            });
            item.checked = true;
            this.pickedList = [item];
            this.onConfirm();
          } else {
            item.checked = false;
            this.pickedList = [];
          }
        } else if (this.type === 'CL' && !item.available) {
          this.showToast({ msg: '移动端暂不支持报销单关联行程不一致申请单，请移步PC端' });
        } else {
          item.checked = !item.checked;
          if (item.checked) {
            this.pickedList.push(item);
          } else {
            this.pickedList = this.pickedList.filter(pickItem => pickItem.fee_apply_l_id !== item.fee_apply_l_id);
          }
        }
        if (this.type === 'CL') {
          if (this.pickedList.length === 1) {
            this.applyList.forEach((apply) => {
              if (apply.fee_apply_id !== this.pickedList[0].fee_apply_id) {
                apply.available = false;
              }
            });
          } else if (this.pickedList.length === 0) {
            this.applyList.forEach((apply) => {
              if (apply.attribute2 === 'Y') {
                apply.available = true;
              }
            });
          }
        }
      },
    },
    watch: {
      show(nVal) {
        if (nVal) {
          if (this.type === 'LM') {
            this.selectAvaliableFeeApply();
          } else {
            this.getAvaliableFeeApply();
          }
        }
      },
    },
  };
</script>
<style lang="less" scoped>
@import "~@/assets/css/theme.less";

.container {
  .scrollWrap {
    position: fixed;
    top: @height-header;
    bottom: 0;
    width: 100%;
    z-index: 99;
    background-color: #fff;
  }
  .scroll {
    .item-cell {
      display: flex;
      flex-flow: row;
      align-items: flex-start;
      padding: 12px 15px 12px 0;
      .check-box {
        flex: none;
        display: block;
        box-sizing: border-box;
        width: 18px;
        height: 18px;
        margin: 13px 20px;
        border-radius: 9px;
        border: 1px #ADADAD solid;
      }
      .checked {
        border: 0px;
        background-image: url(../../assets/images/common/checked.png);
        background-repeat: no-repeat;
        background-position: center;
        background-size: contain;
      }
      .type {
        flex: none;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        color: #fff;
        font-size: 12px;
        text-align: center;
        line-height: 40px;
        margin: 2px 14px 0 0;
        background-color: #6CC60A;
        &.blue {
          background-color: #51AFFF;
        }
        &.grey {
           background-color: #c1c1c1;
        }
      }
      .summary {
        max-width: 50%;
        flex-grow: 1;
        p {
          font-size: 16px;
          line-height: 22px;
          word-break: break-all;
        }
        span {
          font-size: 14px;
          line-height: 20px;
          color: #9B9B9B;
        }
      }
      .amount {
        display: flex;
        flex-direction: column;
        flex-grow: 1;
        justify-content: flex-end;
        align-items:flex-end;
        span:nth-child(1) {
          font-size:16px;
          line-height: 22px;
          text-align: right;
        }
        span:nth-child(2) {
          background-color: #3DA5FE;
          border-radius: 12px;
          font-size: 11px;
          height: 20px;
          line-height: 19px;
          color: #ffffff;
          padding:0 10px;
        }
      }
    }
  }
  .empty{
    text-align: center;
    img {
      display: block;
      margin: 20% auto 10px;
      width: 50%;
    }
    p {
      color: #6e7481;
    }
  }
}
.emptyBox{
  text-align: center;
  .no_data_img {
    display: block;
    margin: 45% auto 10px;
    width: 50%;
  }
  .no_data_text {
    color: #6e7481;
  }
}
</style>

