 <!--
  describe：发票
  created by：周積坤
  date：2017-11-22
-->
 <style lang="less" scoped>
@import '../../assets/css/fee/myInvoice/invoice.less';
</style>

<template>
  <div class="related-container" v-if="show">
    <my-header :title="top.title" :headerClass="top.headerTop" @previous="goBack"></my-header>
    <div class="invoiceBox" v-for="(data,index) in showList" :key='index' @click="editInvoice(index)">
      <div class="invoiceLeft">
        <div :class="['invoiceType',{'blue':tempType[data.invoice_type]=='专票'},{'green':tempType[data.invoice_type]=='普票'},{'pink':1}]">
          专票
        </div>
        <!-- {{ tempType[data.invoice_type] }} -->
      </div>
      <div class="invoiceRight">
        <div class="invoiceSecondCol">
          <!-- <p>发票号码：{{ data.invoice_num }}</p> -->
          <p>{{ data.invoice_maker }}</p>
          <p>{{ formatDate(data.invoice_date) }}</p>
        </div>
        <div class="invoiceThirdCol">
          <p class="invoicePrice">￥{{ data.invoice_amount.toFixed(2) }}</p>
          <!-- <span class="invoiceStatus" >已查验</span> -->
        </div>
      </div>
    </div>
    <!-- <div class="has-footer">
                    <div class='bottom'>金额合计：<span>2312</span></div>
                  </div> -->
    <!-- <invoiceManually :show="showInvoice" v-model="invoice" @on-hide="hideArea"></invoiceManually> -->
  </div>
</template>
<script type="text/ecmascript-6">
import myHeader from './header';

export default {
  components: {
    myHeader,
  },
  data() {
    return {
      invoice: {},
      tempType: {
        1: '专票',
        2: '专票',
        3: '普票',
        4: '普票',
        10: '电子',
        11: '普票',
      },
      top: {
        title: '发票',
      },
    };
  },
  props: {
    showList: Array,
    show: Boolean,
  },
  methods: {
    formatDate(time) {
      let result = '';
      if (time) {
        const num = new Date(time);
        result = `${num.getFullYear()}-${num.getMonth() + 1}-${num.getDate()}`;
      }
      return result;
    },
    editInvoice(index) {
      this.invoice = this.showList[index];
      this.invoice.no_tax_amount = Number((this.invoice.invoice_amount - this.invoice.tax_amount).toFixed(2));
      this.$router.push({ path: '/fee/myReimburse/invoiceManuallyDetail', query: { invoice: this.invoice } });
    },
    goBack() { // 返回
      this.$emit('on-hide');
    },
    mounted() {
      console.log(111, this.showList);
    },
  },
};
</script>

<style lang="less" scoped>
.related-container {
  width: 100%;
  height: 100%;
  position: fixed;
  background: #F4F4F4;
  top: 46px;
  left: 0;
  bottom: 0;
  z-index: 999999;
  overflow: auto;
}

.has-footer {
  .bottom {
    width: 100%;
    height: 50px;
    line-height: 50px;
    margin-bottom: 0;
    background: #ffffff;
    color: #000000;
    box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
    position: fixed;
    bottom: 0;
  }
}
</style>
