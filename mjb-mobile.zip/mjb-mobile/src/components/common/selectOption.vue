<!--
  describe：下拉框
  created by：ouql
  date：2017-10-27
-->
<template>
  <div class="selection">
    <div :class="[isshow?'textup':'textdown']" @click="show">{{selected.text}}</div>
    <div class="list" :class="{'show':isshow}">
      <ul>
        <li v-for="(item,index) in List" :key="index" @click.stop.prevent="choice(item)" :class="{'active':item.text===selected.text}">
          {{item.text}}
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  props:
  {
    List: Array,
  },
  data() {
    return {
      selected: {
        text: '本月',
        value: 'this_month',
      },
      isshow: true,
      // List: [{ text: '上月' }, { text: '本月' }, { text: '本季度' }, { text: '本年' }],
    };
  },
  methods: {
    show() {
      this.isshow = !this.isshow;
    },
    choice(item) {
      this.selected.value = item.value;
      this.selected.text = item.text;
      this.isshow = !this.isshow;
      this.$emit('on-select', item.value);
    },
  },
  mounted() {
  },
};
</script>
<style lang="less" scoped>
.selection {
  height: 20px;
  font-size: 14px;
  letter-spacing: 2px;
  padding: 0px 19px;
  .show {
    display: none;
  }
  .selected{
    line-height: 14px;
  }
  .textdown {
    &::after {
      position: absolute;
      content: ' ';
      height: 0;
      width: 0;
      top: 1px;
      right: 4px;
      margin-left: -10px;
      border: solid transparent;
      border-width: 6px 4.5px;
      border-bottom-color: #595959;
    }
  }
  .textup {
    &::after {
      position: absolute;
      content: ' ';
      height: 0;
      width: 0;
      top: 8px;
      right: 4px;
      margin-left: -10px;
      border: solid transparent;
      border-width: 6px 4.5px;
      border-top-color: #595959;
    }
  }
  .list {
    position: absolute;
    top: 35px;
    right: 0;
    width: 100%;
    height: auto;
    &::after {
      position: absolute;
      content: ' ';
      height: 0;
      width: 0;
      left: 50%;
      top: -15px;
      margin-left: -10px;
      border: solid transparent;
      border-width: 8px;
      border-bottom-color: #fff;
    }
    &::before {
      position: absolute;
      content: ' ';
      height: 0;
      width: 0;
      left: 50%;
      top: -17px;
      margin-left: -10px;
      border: solid transparent;
      border-width: 8px;
      border-bottom-color: rgba(0, 0, 0, 0.05);
      filter: blur(1px);
    }
    ul {
      background: #FFFFFF;
      box-shadow: 0 2px 6px 0 rgba(0, 0, 0, 0.30);
      border-radius: 8px;
      li {
        list-style: none;
        text-align: center;
        height: 44px;
        margin: auto;
        line-height: 44px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .active {
        background: #E3E3E3;
      }
    }
  }
}
</style>

