<!--
  describe："选择城市" 页面
  created by：Yim Lee
  date：2017-11-14
-->
<template>
  <div class="select-city-main">
    <!-- 选择城市 -->
    <!-- 差旅行程————头部和搜索框 -->
    <my-header :title="headTitle" :showBack="true" :showRedDot="true" @previous="hideSearch" v-if="(tempType==='travel'||tempType==='plane') && !toSearch"></my-header>
    <div class="search-box columns is-mobile is-gapless" v-bind:class="{ stick2top: toSearch }"
      v-if="tempType==='travel'||tempType==='plane'">
      <!-- <div class="column"> -->
        <!-- <img :src="searchS" /> -->
        <input type="text"
          v-model="cityName"
          ref="searchInput"
          :class="['inputNomal', 'black-font']"
          v-on:focus="openSearch()"
          :placeholder="'搜索地点'" />
        <div class="hide-search" v-on:click="toggleSearch(false)">取消</div>
      <!-- </div> -->
    </div>
    <!-- 滴滴（选择城市）————搜索框 -->
    <div class="didi-search columns is-mobile is-gapless" v-show="tempType==='didi'">
      <img :src="searchM" class="search-img">
      <div class="column is-4.5 border-right input-wrap">
        <input type="text" class="column searchCity4didi grey-font hasPadding"
          v-model="cityName"
          v-on:focus="openSearch()"
          :placeholder="'搜索城市名'" />
        <!-- <input-box :placeholder="'搜索城市名'" :focus="true" :inputValue="cityName" @get-value="getValue"></input-box> -->
      </div>
      <div class="column is-4 border-right input-wrap">
        <input-box :placeholder="locationText" :isreadOnly="true" @select="hideCity"></input-box>
      </div>
      <span class="didi-hide column is-2" @click="hideSearch">取消</span>
    </div>

    <div class="letterTips" v-show="navigateLetter">{{ navigateLetter }}</div>

    <!-- 右侧字母列表 -->
    <div ref="letterList" class="letter-list columns is-mobile is-gapless"
      @touchmove="ontouchMove($event)"
      @touchend="ontouchEnd($event)"
      @click="goAnchor($event)">
      <div class="column letterType" v-for="(item, index) in letters" :key="index" :to-city="'goToCity_' + item">{{ item }}</div>
    </div>
    <!-- 可滚动区域  :scrollTop="scrollTop" :style="style" @scroll.native="onScroll" touchmove.stop-->
    <div ref="scrollContent" class="fix-IOS-scroll" :class="['scroll', {'didi-top': tempType==='didi', 'travel-top': tempType==='travel'||tempType==='plane'}]" v-show="!toSearch">
      <div class="search-wrap has-header">
        <!-- 当前城市 -->
        <span id="goToCity_A"></span>
        <div class="current-city">
          <span class="current-city-title">当前城市</span>
          <span :class="['current-city-text', {'current-city-success': locationInfo.area_name || locationInfo.name || locationInfo.text, 'current-city-fail': !locationInfo.area_name && !locationInfo.name && !locationInfo.text}]" @click="selectCity(locationInfo)">{{ locationInfo.area_name || locationInfo.name || locationInfo.text || locationInfo.tip }}</span>
        </div>
        <!-- 热门城市 -->
        <div class="hot-city">
          <span class="hot-city-title">热门城市</span>
          <div class="hot-city-items columns is-mobile is-gapless" @click="delegation_selectPopularCity">
            <span class="hot-city-text column is-3 perCity" v-for="(item, index) in hotCities" :key="index" :data-index="index">{{ item.text }}</span>
          </div>
        </div>
        <!-- didi城市首字母排序列表 -->
        <div v-if="tempType === 'didi'">
          <div class="letter-cities" v-for="(item, index) in cityList" ref="city" :id="index" :key="index" @click="delegation_selectClassifiedCity">
            <span :id="item.name !== 'A' ? 'goToCity_' + item.name : null" class="letter">{{ item.name }}</span>
            <div class="border-bottom cities" v-for="(list, subIndex) in item.cities" :key="subIndex">
              <div class="perCity" :data-sub-index="subIndex" :data-index="index">{{ list.name }}</div>
            </div>
          </div>
        </div>
        <!-- travel城市首字母排序列表 -->
        <div v-if="(tempType==='travel'||tempType==='plane')&&!toSearch">
          <div class="letter-cities" v-for="(item, index) in cityList" ref="city" :id="index" :key="index">
            <span :id="item.letter !== 'A' ? 'goToCity_' + item.letter : null" :name="item.letter !== 'A' ? 'goToCity_' + item.letter : null" class="letter">{{ item.letter }}</span>
            <div class="border-bottom cities" v-for="(list, cIndex) in item.cities" :key="cIndex">
              <div @click="selectCity(list)">{{ list.area_name || list.text }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 搜索结果 -->
    <!-- <div :class="['result-list', {'border': hasResult}, {'whiteBack': hasResult, 'greyBack': !hasResult}]" v-show="showResult">
      <div class="result" v-for="(list, index) in cityResult" :key="index">
        <span :class="[{'border-top': index !== 0}]" @click="selectCity(list)">{{ list.name }}</span>
      </div>
      <div class="no-result" v-if="!hasResult">
        <span>暂无结果，换个关键字试试</span>
      </div>
    </div> -->
    <filtered-cities v-show="toSearch"
      :dataType="tempType"
      :searchText="cityName"
      :showSearch.sync="toSearch"
      @selec-city="selectCity"></filtered-cities>

  </div>
</template>

<script>
import { platform } from '@/platform';
import { isIOSEnviron } from '@/js/util';
import MyHeader from './header';
import searchS from '../../assets/images/common/searchS.png';
import searchM from '../../assets/images/common/searchM.png';
import InputBox from './input.vue';
import airCity from '../travel/plane/airCity.json';
import filteredCities from './filteredCities.vue';

var timeout2hideLetterTips;

export default {
  components: {
    MyHeader,
    InputBox,
    filteredCities,
  },
  props: {
    headTitle: String,
    tempType: String,
    locationText: String,
  },
  data() {
    return {
      searchS,
      searchM,
      toSearch: false, // travel控制是否显示搜索地址的页面
      hasResult: true, // 是否有搜索结果
      showResult: false, // 控制是否显示搜索结果
      hotCities: [ // 热门城市列表area_code修复
        { text: '北京', area_name: '北京市', area_code: '111', name: '北京市', cityid: 1, area_id: '4386' },
        { text: '广州', area_name: '广州市', area_code: '14401', name: '广州市', cityid: 3, area_id: '5135' },
        { text: '上海', area_name: '上海市', area_code: '131', name: '上海市', cityid: 4, area_id: '4479' },
        { text: '深圳', area_name: '深圳市', area_code: '14403', name: '深圳市', cityid: 2, area_id: '4637' },
        { text: '武汉', area_name: '武汉市', area_code: '14201', name: '武汉市', cityid: 6, area_id: '5137' },
        { text: '天津', area_name: '天津市', area_code: '112', name: '天津市', cityid: 7, area_id: '4385' },
        { text: '西安', area_name: '西安市', area_code: '16101', name: '西安市', cityid: 10, area_id: '4740' },
        { text: '杭州', area_name: '杭州市', area_code: '13301', name: '杭州市', cityid: 5, area_id: '4503' },
        { text: '南京', area_name: '南京市', area_code: '13201', name: '南京市', cityid: 11, area_id: '4487' },
        { text: '成都', area_name: '成都市', area_code: '15101', name: '成都市', cityid: 17, area_id: '4686' },
        { text: '重庆', area_name: '重庆市', area_code: '150', name: '重庆市', cityid: 18, area_id: '4669' },
      ],
      letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'W', 'X', 'Y', 'Z', '#'],
      airCity: airCity.citys,
      scrollTop: 0,
      style: '',
      cityName: '',
      cityResult: [],
      locationInfo: {
        text: '',
        area_name: '',
        area_code: '',
        name: '',
        tip: '正在努力定位',
      },
      defaultScroll: '',
      touchStart: null,
      navigateLetter: ''
    };
  },
  watch: {
    cityName(val) {
      if (val) {
        // this.getCityResult();
        this.showResult = true;
      } else {
        this.showResult = false;
        this.hasResult = false;
        this.cityResult = [];
      }
    },
  },
  computed: {
    cityList() {
      return this.$store.state.common.views.cityList;
    },
  },
  methods: {
    ontouchStart(e) {
      this.touchStart = e.targetTouches[0];
    },
    ontouchMove(e) {
      const touch = e.targetTouches[0];
      const elem = document.elementFromPoint(touch.clientX, touch.clientY);
      if (elem.className.indexOf('letterType') >= 0) {
        document.getElementById(elem.getAttribute('to-city')).scrollIntoView();
        this.navigateLetter = elem.getAttribute('to-city').split('_')[1];
      }
      // e.preventDefault();
    },

    ontouchEnd(event) {
      this.navigateLetter = '';
      // event.preventDefault();
    },
    // 显示差旅搜索地址页面
    openSearch() {
      // setTimeout((function () {
      //       this.$refs.searchInput.focus();
      //       }).bind(this), 10)
      this.toSearch = true;
    },
    toggleSearch(action) {
      this.cityName = '';
      this.toSearch = action;
    },
    hideSearch() {
      this.$emit('hide-search');
      this.$emit('update:showCity', false);
      this.$emit('close-panel');
    },
    // 关闭城市页面
    hideCity() {
      this.$emit('update:showCity', false);
    },
    // 获取用户搜索城市时的输入值
    getValue(value) {
      if (value) {
        this.cityName = value;
        this.showResult = true;
      } else {
        this.cityName = '';
      }
    },
    delegation_selectClassifiedCity(event) {
      var clickedCity;
      if (event.target.className === 'perCity') {
        clickedCity = this.cityList[event.target.getAttribute('data-index') * 1].cities[event.target.getAttribute('data-sub-index') * 1];
        this.selectCity(clickedCity)
      }
    },
    delegation_selectPopularCity(event) {
      var clickedCity;
      if (event.target.className.indexOf('perCity') >= 0) {
        clickedCity = this.hotCities[event.target.getAttribute('data-index') * 1];
        this.selectCity(clickedCity)
      }
    },
    // 点击城市名选择城市
    selectCity(city) {
      if (this.tempType === 'travel' || this.tempType === 'plane') {
        this.$emit('select-city', city);
      } else {
        this.locationInfo = city;
        this.$emit('select-city', this.locationInfo);
      }
      this.$emit('close-panel');
    },
    // 字母表适屏
    setLetterHight() {
      const scrollContent = this.$refs.scrollContent;
      const scrollContentHeight = scrollContent ? scrollContent.clientHeight : 0;
      const letterHight = scrollContentHeight - 22;
      if (letterHight > 0) {
        // this.$refs.letterList.style.height = letterHight + "px";
        this.$refs.letterList.style.lineHeight = `${(letterHight / 29).toFixed(2)}px`;
        this.$refs.letterList.style.fontSize = '1em';
        console.log(scrollContentHeight, letterHight);
      }
    },
    // vue的滚动监听事件
    // onScroll(e, position) {
    //   this.scrollTop = position.scrollTop;
    // },

    // 点击字母跳到相应的字母城市列表
    goAnchor(event) {
      if (event.target.className.indexOf('letterType') >= 0) {
        document.getElementById(event.target.getAttribute('to-city')).scrollIntoView();
        clearTimeout(timeout2hideLetterTips);
        this.navigateLetter = event.target.getAttribute('to-city').split('_')[1];
        timeout2hideLetterTips = setTimeout(() => {
          this.navigateLetter = '';
        }, 200);
      }
    },
    // 差旅获取所有城市
    getTravelCities() {
      this.$store.dispatch('searchArea', { page_size: 10000, page_number: 1 })
        .then((rep) => {
          this.hideLoading();
          if (rep && rep.code === '0000') {
            const arr = rep.data.info;
            const cityArr = [];
            arr.forEach((item) => {
              if (item.region_type_code === '3') {
                cityArr.push(item);
              }
            });
            this.sortCity(cityArr);
            this.getLocation();
          } else if (rep) {
            this.showToast({ msg: `请求异常[${rep.code}]: ${rep.msg}` });
          }
        });
    },
    // 城市首字母分类
    sortCity(arr) {
      const allCities = [];
      this.letters.forEach((item) => {
        const obj = {
          letter: '',
          cities: [],
        };
        arr.forEach((city) => {
          if (city.pin_yin) {
            if (city.pin_yin.substr(0, 1) === item.toLowerCase()) {
              obj.letter = item;
              obj.cities.push(city);
            }
          }
        });
        allCities.push(obj);
      });
      this.$store.commit('CITY_LIST', allCities);
    },
    // 滴滴获取所有城市
    getDiDiCities() {
        this.$store.dispatch('getCities', {}).then((rep) => {
          this.hideLoading();
          if (rep && rep.errcode === '00000') {
            const arr = rep.data.data;
            this.$store.commit('CITY_LIST', arr);
            this.getLocation();
          } else if (rep) {
            this.showToast({ msg: `请求异常[${rep.code}]: ${rep.msg}` });
          }
        });
    },
    // 机票获取城市
    getAirCities() {
      this.hotCities = this.airCity.Hot;
      const allCities = [];
      this.letters.forEach((item) => {
        const obj = {
          letter: '',
          cities: [],
        };
        obj.letter = item;
        obj.cities = this.airCity.All[item] || [];
        allCities.push(obj);
      });
      this.$store.commit('CITY_LIST', allCities);
      this.getLocation();
      this.hideLoading();
    },
    // 当前城市
    getCurrentCity(name) {
      if (this.tempType === 'travel' || this.tempType==='plane') {
        this.cityList.forEach((item) => {
          item.cities.forEach((city) => {
            if (city.area_name === name || name.indexOf(city.text) > -1) {
              this.locationInfo = city;
            }
          });
        });
        if (!this.locationInfo.area_code && !this.locationInfo.text) {
          this.locationInfo.tip = '当前定位城市不可用';
        }
      } else {
        this.cityList.forEach((item) => {
          item.cities.forEach((city) => {
            if (city.name === name) {
              this.locationInfo = city;
            }
          });
        });
      }
    },
    // 定位
    getLocation() {
      if (isIOSEnviron()) {
        platform.locationForIOS().then((data) => {
          if (data) {
            this.getCurrentCity(data.city);
          }
        }, () => { this.locationInfo.tip = '定位失败'; });
      } else {
        platform.location().then((data) => {
          if (data) {
            this.getCurrentCity(data.city);
          }
        }, () => { this.locationInfo.tip = '定位失败'; });
      }
    },
    // 获取城市搜索结果
    getCityResult() {
      if (!this.cityName) return;
      const arr = [];
      const keywordType = 'name'; // name字段
      this.cityList.forEach((list) => {
        list.cities.forEach((city) => {
          if (city[keywordType].indexOf(this.cityName) > -1) {
            this.hasResult = true;
            arr.push(city);
          }
        });
      });
      if (arr.length === 0) this.hasResult = false;
      this.cityResult = arr;
    },
  },
  // mounted
  activated() {
    this.$nextTick(() => {
      this.setLetterHight(); // 右边字母表适屏高度
    });
    this.defaultScroll = this.scrollTop;
  },

  mounted() {
    this.showLoading();
      this.$nextTick(() => {
        this.setLetterHight();
      });
      this.setLetterHight(); // 右边字母表适屏高度
      this.scrollTop = this.defaultScroll;
      this.style = `height: ${window.screen.height}px; overflow: auto;`;
      // this.getLocation();
      if (this.tempType === 'didi') {
        this.getDiDiCities();
      } else if (this.tempType === 'plane') {
        this.getAirCities();
      } else {
        this.getTravelCities();
      }
  }
};
</script>
<style lang="less" scoped>

.search-box {
  position: absolute;
  width: 100%;
  top: 46px; // hearder改成46px了
  background: #FFFFFF;
  z-index: 99;
  height: 53px;
  margin-bottom: 0 !important;

  &.stick2top {
    top: 0;
    background-color: #484759;
    // height: 46px;

    .hide-search {
      line-height: 53px;
      text-align: center;
      font-size: 16px;
      width: 4.5em;
      color: #fff;
    }

    .inputNomal {
      margin: ((53px-32px)/2) 0 0 1em;

      &::-webkit-input-placeholder {
        text-align: left;
      }
    }
  }

  .inputNomal {
    border: none;
    background: #F4F4F4;
    outline: none;
    border-radius: 16px;
    width: 100%;
    font-size: 13px;
    height: 32px;
    margin: ((53px-32px)/2) 1em 0 1em;
    padding: 0 1em;

    &::-webkit-input-placeholder {
      text-align: center;
    }
  }

  .hide-search {
    width: 0;
    font-size: 0;
    float: right;
  }

  .column {
    padding: 10px;
    height: 53px;
    border-radius: 23px;
    background: #F7F7F7;
    color: #7F8389;
    font-size: 13px;
    justify-content: center;
    align-items: center;
    img {
      width: 14px;
      height: 14px;
      margin-right: 4px;
    }
  }
}

.travel-top {
  top: 98px;
}

.select-city-main {
  position: fixed;
  top: 0; // bottom: 0;
  left: 0;
  z-index: 99;
  width: 100%;
  background: #F4F4F4;
  .didi-search {
    height: 45px;
    border: 0 solid #ADADAD;
    background: #FFFFFF;
    margin: 0;

    .searchCity4didi {
      border: none;
      background: none;
      outline: none;
      width: 100%;
      font-size: 16px;
      line-height: 22px;
      padding: 0;
      color: #0076FF; // 光标颜色
      -webkit-text-fill-color: transparent; // 模拟让placeholder成镂空状态
      &::-webkit-input-placeholder {
        color: #C3C3C3;
        opacity: 0.5;
      }
    }

    .location-wrap {
      margin: 0 15px;
      .location {
        width: 100%;
        margin: 11px 0;
        text-align: center;
        line-height: 22px;
        span {
          font-size: 16px;
          color: #666666;
        }
        img {
          width: 7px;
          height: 6px;
        }
      }
    }
    .search-img {
      width: 17px;
      height: 18px;
      margin: auto;
      margin-left: 15px;
      margin-right: 8px;
    }
    .input-wrap {
      height: 20px;
      margin: auto 0;
      &:nth-child(3) {
        margin-left: 15px;
      }
      input {
        font-size: 16px;
        text-shadow: 0px 0px 0px #000000; // 字体颜色
        &::-webkit-input-placeholder {
          color: #C3C3C3;
          opacity: 0.32;
        }
      }
    }
    .didi-hide {
      font-size: 16px;
      line-height: 45px;
      color: #666666; // margin: 0px 15px;
      text-align: center;
    }
  }
  .scroll {
    position: fixed;
    width: 100%;
    top: 99px;
    bottom: 0;
    overflow: auto;
    background: #F7F7F7;

    &.didi-top {
      top: 45px;
    }

    .search-wrap {
      padding: 0;
      margin: 0;
      .current-city,
      .hot-city {
        display: flex;
        background: #F7F7F7;
        flex-direction: column;
        padding: 10px 14px;
        .current-city-title,
        .hot-city-title {
          font-size: 16px;
          line-height: 22px;
          color: #9B9B9B;
          margin: 5px 0;
        }
        .current-city-text,
        .hot-city-text {
          display: block;
          margin: 5px 0;
          height: 36px;
          background: #FFFFFF;
          border: 1px solid #D7D7D7;
          box-sizing: border-box;
          border-radius: 2px;
          font-size: 14px;
          text-align: center;
          line-height: 36px;
          color: #000000;
        }
        .current-city-fail {
          width: 92%;
        }
        .current-city-success {
          width: 20.2%;
        }
        .hot-city-title {
          margin: 0 14px;
        }
        .hot-city-items {
          flex-wrap: wrap;
          margin: 5px 9px;
          .hot-city-text {
            display: flex;
            width: 20.2%;
            justify-content: center;
            margin: 5px;
          }
        }
      }
      .hot-city {
        padding: 0;
        margin-bottom: 10px;
      }
      .letter-cities {
        background: #FFFFFF;
        .letter {
          display: block;
          background: #F4F4F4;
          font-size: 16px;
          color: #9B9B9B;
          line-height: 22px;
          padding-left: 14px
        }
        .cities {
          margin-left: 14px;
          line-height: 46px;
          div {
            margin-right: 35px;
            font-size: 16px;
          }
        }
      }
    }
  }
  .letter-list {
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    transform: translate3d(0,0,0);
    position: fixed;
    z-index: 99;
    width: 35px;
    right: 0;
    top: 153px;
    flex-direction: column;
    line-height: 17px;
    font-size: 14px;
    flex-wrap: wrap; // padding-right: 10px;
    div {
      height: auto;

      text-align: center;
      color: #888888;
    }
  }
  .letterTips {
    position: fixed;
    z-index: 199;
    width: 60px;
    height: 60px;
    margin: 0 auto;
    top: 50%;
    left: 0;
    right: 0;
    background: rgba(0,0,0,.6);
    text-align: center;
    color: #FFFFFF;
    line-height: 60px;
    font-size: 28px;
  }
}
</style>
