
<template>
  <div class="org-container" v-if="show">
    <MyHeader title="选择预算主体" :showBack="true" @previous="goBack" v-show="!onSearch"></MyHeader>
    <div class="searchHeader" v-if="onSearch">
      <div class="search">
        <i class="iconfont icon-qietu03"></i>
        <input type="text" placeholder="搜索预算主体" v-model="search" v-focus>
      </div>
      <span class="cancel" @click="searchCancel">取消</span>
    </div>
    <div :class="{'has-header': !onSearch}">
      <div class="search-wrap" @click="handleSearch" v-show="!onSearch">
        <div class="search">
          <i class="iconfont icon-qietu03"></i>
          <input type="text" placeholder="搜索预算主体">
        </div>
      </div>
      <div :style="style" @touchmove.stop>
        <div class="wrap">
          <div v-for="(org, index) in (onSearch?searchRes:defBdOrg)" :key="org.busi_org_id" @click="pickBugdetOrg(org)" class="org border-top">
            {{org.busi_org_name}}
          </div>
          <div class="tipMsg" v-if="onSearch&&!searchRes.length">暂无匹配预算主体</div>
          <div class="tipMsg" v-if="!onSearch&&!defBdOrg.length">无默认预算主体,去维护</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MyHeader from './header';

export default {
  components: {
    MyHeader,
  },
  props: {
    show: {
      type: Boolean,
      required: true,
      default: false,
    },
    value: {
      type: Object,
      required: false,
      default: () => { },
    },
    defBdOrg: {
      type: Array,
      required: true,
      default: () => [],
    },
  },
  data() {
    return {
      search: '',
      onSearch: false,
      searchRes: [],
      style: {
        height: '0px',
        position: 'fixed',
        overflow: 'auto',
        width: '100%',
      },
      timer: null,
    };
  },
  methods: {
    goBack() {
      this.searchCancel();
      this.$emit('goBack');
      this.$emit('update:show', false);
    },
    pickBugdetOrg(org) {
      this.$emit('input', org);
      this.$emit('confirm', org);
      setTimeout(() => {
        this.$emit('update:show', false);
        this.searchCancel();
      }, 200);
    },
    debounce(action, delay) {
      return (() => {
        if (this.timer) clearTimeout(this.timer);
        this.timer = setTimeout(() => {
          action.apply(this);
        }, delay);
      })();
    },
    searchBdOrg() {
      this.showLoading();
      this.$store.dispatch('getSbjuct', {
        busi_org_name: this.search,
        enable_flag: 'Y',
        page_number: 1,
        page_size: 10,
      }).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          console.log(res);
          this.searchRes = res.data.info || [];
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    searchBdOrgDebounce() {
      this.debounce(() => {
        this.searchBdOrg();
      }, 500);
    },
    handleSearch() {
      this.onSearch = true;
      this.style.height = `${window.screen.height - 56}px`;
      this.searchBdOrg();
    },
    searchCancel() {
      this.onSearch = false;
      this.style.height = `${window.screen.height - 109}px`;
      this.search = '';
      this.searchRes = [];
    },
  },
  watch: {
    show(newVal) {
      if (newVal) {
        this.style.height = `${window.screen.height - 156}px`;
      }
    },
    search(newVal) {
      if (newVal) {
        this.searchBdOrgDebounce();
      }
    },
  },
  mounted() {
    this.style.height = `${window.screen.height - 156}px`;
  },
};
</script>
<style lang="less" scoped>
@searchBoxHeight: 32px;

.searchHeader {
  display: flex;
  background-color: #484759;
  .search {
    flex-grow: 1;
    margin: 10px 0 10px 10px;
  }
  .cancel {
    padding: 14px;
    font-size: 16px;
    color: #fff;
  }
}

.org-container {
  position: fixed;
  top: 0;
  z-index: 100;
  width: 100%;
  height: 100%;
  background-color: #F4F4F4;
}

.search {
  position: relative;
  height: @searchBoxHeight;
  color: #7F8389;
  padding: 0 @searchBoxHeight/2 0 40px;
  line-height: @searchBoxHeight;
  border-radius: @searchBoxHeight/2;
  background-color: #F4F4F4;
  i {
    position: absolute;
    top: 0;
    left: 0;
    padding: 3px 15px 0;
  }
  input {
    width: 100%;
    height: @searchBoxHeight - 5px;
    font-size: 13px;
    outline: none;
    border: 0px;
    background-color: #F4F4F4;
  }
}

.search-wrap {
  padding: 10px;
  background-color: #fff;
}

.wrap {
  .org {
    padding: 12px 15px;
    font-size: 16px;
    background-color: #fff;
  }
  .tipMsg {
    margin-top: 65px;
    text-align: center;
    color: #cecece;
  }
}
</style>
