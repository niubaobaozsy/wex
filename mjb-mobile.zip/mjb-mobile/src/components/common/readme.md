# common component

**common component api**

2018/3/7 by DKZ



### header

```
<my-header :title="top.title" :showBack="true" :redDotCount="2" @previous="goBack"></my-header>
```

- title             <String> 标题
- rightItem         <String> 
- showScan          <Boolean> default: false
- showMessage       <Boolean> default: false
- showBack          <Boolean> default: true 返回键显示
- showItem          <Boolean> default: false
- showRedDot        <Boolean> default: false
- redDotCount       <Number> default: 0
- cusStyle          <String> default: ''
- showSet           <Boolean> default: false
- imgSrc            <String> default: ''
- showImgTitle      <Boolean> default: false
- titleImg          <String> default: ''
- rightTitle        <String> default: ''
- leftTitle         <String> default: ''

- @previous
- @on-click
- @scan
- @message
- @showChoice

### footerBar

```
<footerBar :index="3" :tabName="'report'"></footerBar>
```

- index         <String> 序号
- tabName       <String> 名称

### barGraph

```
<barGraph ref="chart" class="echart-container" :cusOpt="cusOpt"></barGraph>
``` 

- cusOpt        <Object> 
```
{
title: '',
xAxis: [],
series: {
  backgroundSeries: {
    name: '预算总额',
    data: [],
  },
  foregroundSeries: {
    name: '',
    data: [],
  },
},
}
```

### lineGraph

```
<lineGraph ref="chart" class="echart-container" :cusOpt="cusOpt"></lineGraph>
```

- cusOpt        <Object> 
```
cusOpt: {
title: '每月预算总额(百万)',
xAxis: [],
series: [],
// xAxis: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
// series: [943, 851, 1020, 785, 960, 888, 980, 910, 750, 830, 230, 900],
},
```
