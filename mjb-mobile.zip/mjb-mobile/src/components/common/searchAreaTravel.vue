<!--
  describe："搜索城市" 页面（差旅）
  created by：Yim Lee
  date：2017-11-14
-->
<template>
    <div :class="['result-list', {'border': hasResult}, {'whiteBack': hasResult, 'greyBack': !hasResult}]" v-if="showSearch">
      <div class="result" v-for="(list, index) in cityResult" :key="index">
        <span :class="[{'border-top': index !== 0}]" @click="selectCity(list)">{{ list.area_name || list.text }}</span>
      </div>
      <div class="no-result" v-if="!hasResult">
        <span>暂无结果，换个关键字试试</span>
      </div>
    </div>
</template>

<script>

export default {
  props: {
    searchText: {
      type: String,
      require: true,
      default: ''
    },
    showSearch: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  data() {
    return {
      hasResult: false, // 是否有搜索结果
      cityName: '',
      cityResult: []
    };
  },
  watch: {
    searchText(val) {
      if (val) {
        this.getCityResult();
      } else {
        this.hasResult = false;
        this.cityResult = [];
      }
    },
  },
  computed: {
    cityList() {
      return this.$store.state.common.views.cityList;
    }
  },
  methods: {
    // 点击城市名选择城市
    selectCity(item) {
      this.$emit('selec-city', item);
      this.$emit('update:showSearch', false);
    },
    // travel获取城市搜索结果
    getCityResult() {
      if (!this.searchText) return;
      let arr = [];
      this.cityList.forEach((collection4cities) => {
        if(collection4cities.cities) {
          collection4cities.cities.forEach((item) => {
            if (item.area_name && item.area_name.indexOf(this.searchText) > -1 && item.region_type_code === '3') {
              arr.push(item);
            } else if (item.text && item.text.indexOf(this.searchText) > -1) {
              arr.push(item);
            }
          });
        }
      });
      this.hasResult = arr.length ? true : false;
      this.cityResult = arr;
    },
  }
};
</script>
<style lang="less" scoped>
.columns {
  margin-bottom: 0 !important;
}

.whiteBack {
  background: #FFFFFF;
}

.greyBack {
  background: #F4F4F4;
}

.main {
  position: fixed;
  top: 0; // bottom: 0;
  z-index: 99;
  width: 100%;
  height: 100%;
  background: #F4F4F4;
  .real-search {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: 100;
    background: #F4F4F4;
    .search-header {
      height: 57px;
      background: #484759;
      margin-bottom: 10px;
      .search-input {
        display: flex;
        background: #F4F4F4;
        margin: auto;
        margin-left: 10px;
        margin-right: 0px;
        border-radius: 23px;
        padding: 0px 9px !important;
        img {
          width: 16px;
          height: 16px;
          margin: auto;
        }
        input {
          font-size: 13px;
          height: 32px;
          margin-left: 4px;
        }
      }
      .hide-search {
        font-size: 16px;
        line-height: 57px;
        color: #FFFFFF;
        margin: 0px 14px;
        text-align: center; // margin: auto;
      }
    }
  }
  .result-list {
    position: fixed;
    top: 53px;
    bottom: 0;
    width: 100%;
    padding-top: 10px;
    overflow: auto;
    z-index: 100;
    background: #F4F4F4;
    .result {
      padding-left: 14px;
      background: #FFFFFF;
      span {
        display: block;
        font-size: 16px;
        line-height: 46px;
      }
    }
    .no-result {
      display: block;
      margin: auto;
      padding-top: 20px;
      font-size: 14px;
      color: #858585;
      text-align: center;
    }
  }
}
</style>
