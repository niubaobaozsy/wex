<!--
  created by：panjm2
  date：2017-10-17
-->
<template>
  <div class="header-wrap">
    <div class="header" :style="cusStyle">
      <div class="back" @click.stop.prevent="back">
        <span v-if="showBack" class="back">
          <img :src="top.iconBack" class="icon">
        </span>
      </div>
      <div class="title"><span>{{title}}</span></div>
      <div class="header-right-item">
        <span v-if="rightItem!=null" @click.stop.prevent="onClick">{{rightItem}}</span>
        <div v-if="showScan"  @click.stop.prevent="scan">
          <img :src="top.iconScan" class="icon" >
        </div>
        <!-- lym：显示设置中心的图标 图片路径通过父组件传参进来 -->
        <div v-if="showSet"  @click.stop.prevent="showChoice">
          <img :src="imgSrc" class="icon" >
        </div>
        <!-- 应用场景：title中间包含图片的情况 -->
        <div v-if="showImgTitle" class="showImgTitle">
          <span v-if="rightTitle" class="rightTitle">{{ rightTitle }}</span>
          <img :src="titleImg" class="icon">
          <span v-if="leftTitle" class="leftTitle">{{ leftTitle }}</span>
        </div>
        <span v-if="showMessage"  @click.stop.prevent="message">
          <img :src="top.iconMessage" class="icon">
          <i class="red-dot" v-if="showRedDot && redDotCount">{{redDotCount}}</i>
        </span>
      </div>
    </div>
  </div>
</template>
<script>
import back from '../../assets/images/common/nav_back.png';
import scan from '../../assets/images/common/nav_scan.png';
import message from '../../assets/images/common/nav_message.png';

export default {
  components: {
  },
  created() {
  },
  props: {
    title: String,
    rightItem: String,
    showScan: {
      type: Boolean,
      default: false,
    },
    showMessage: {
      type: Boolean,
      default: false,
    },
    showBack: {
      type: Boolean,
      default: true,
    },
    showItem: {
      type: Boolean,
      default: false,
    },
    showRedDot: {
      type: Boolean,
      default: false,
    },
    redDotCount: {
      type: Number,
      default: 0,
    },
    cusStyle: {
      type: String,
      default: '',
    },
    showSet: {
      type: Boolean,
      default: false,
    },
    imgSrc: {
      type: String,
      default: '',
    },
    showImgTitle: {
      type: Boolean,
      default: false,
    },
    titleImg: {
      type: String,
      default: '',
    },
    rightTitle: {
      type: String,
      default: '',
    },
    leftTitle: {
      type: String,
      default: '',
    },
  },
  computed: {
    hasStep() {
      return this.stepTotal;
    },
  },
  data() {
    return {
      top: {
        iconBack: back,
        iconScan: scan,
        iconMessage: message,
      },
    };
  },
  methods: {
    back() {
      this.$emit('previous');
    },
    onClick() {
      this.$emit('on-click');
    },
    scan() {
      this.$emit('scan');
    },
    message() {
      this.$emit('message');
    },
    // lym: didi点击打开设置选择
    showChoice() {
      this.$emit('showChoice');
    },
  },
  watch: {
  },
};
</script>

<style lang="less" scoped>
@import "~@/assets/css/theme.less";

.header-wrap {
  // position: absolute;
  position: fixed;
  top: 0;
  z-index: 99;
  width: 100%;
}
.header {
  height: 46px;
  background-color: @color-header-bg;
  display: flex;
  flex-flow: row nowrap;
  justify-content: space-between;
  align-items: center;
  padding: 0 15px;
  box-sizing: border-box;
  color: #ffffff;
  .back{
    height: 100%;
    width: 40%;
    display: flex;
    align-items: center;
  }
  .title {
    height: 100%;
    font-size: 18px;
    line-height: 46px;
    text-align: center;
    white-space: nowrap;
  }
  .icon {
    width: 20px;
    position: relative;
    // top: 2px;
  }
  .header-right-item {
    height: 100%;
    width: 40%;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    div {
      display: flex;
      align-items: center;
      img {
        margin: auto 0;
      }
    }
  }
  .header-right-item span{
    margin-right: 20px;
    white-space: nowrap;
  }
  .header-right-item span:last-child{
    margin-right:0px;
  }
  .red-dot {
    position: absolute;
    right: 3px;
    top: 6px;
    width: 18px;
    height: 18px;
    font-size: 12px;
    line-height: 18px;
    font-style: normal;
    color: #fff;
    text-align: center;
    background-color: #FC4B4C;
    border-radius: 50%;
  }
  .mr-20{
    margin-right: 20px;
  }
  .showImgTitle {
    .rightTitle {
      margin-right: 8px;
      font-size: 18px;
      line-height: 25px;
    }
    .leftTitle {
      margin-left: 8px;
      font-size: 18px;
      line-height: 25px;
    }
  }
}
</style>
