<!--
  describe：Line Graph power by ECharts
  created by：Zhuangyh
  date：2017-10-24
-->
<template>
  <div class="container">
    <div ref="lineGraph" class="line-graph"></div>
  </div>
</template>

<script>
import echarts from 'echarts/lib/echarts';
import symbol from '@/assets/images/common/symbol.png';

require('echarts/lib/chart/line');
require('echarts/lib/component/title');
require('echarts/lib/component/tooltip');

export default {
  components: {},
  data() {
    return {
      lineGraph: {},
      option: {
        textStyle: {
          color: '#4B4B4B',
        },
        title: {
          text: '标题',
          subtext: '',
          textStyle: {
            color: '#666',
            fontSize: 10,
          },
          top: 10,
        },
        grid: {
          show: true,
          top: 50,
          right: '4%',
          bottom: 50,
        },
        tooltip: {},
        xAxis: {
          type: 'category',
          data: [],
          boundaryGap: false,
          axisLine: {
            lineStyle: {
              color: '#DCDCDC',
            },
          },
          axisLabel: {
            interval: 0,
            fontSize: 12,
            color: '#858585',
            lineHeight: 28,
          },
          splitLine: {
            show: true,
            inside: true,
          },
        },
        yAxis: {
          axisLine: {
            lineStyle: {
              color: '#DCDCDC',
            },
            axisLabel: {
              color: '#858585',
              fontSize: 10,
              lineHeight: 10,
            },
          },
        },
        series: [{
          name: '序列名',
          type: 'line',
          symbol: `image://${symbol}`,
          symbolSize: 6,
          data: [],
          smooth: true,
          itemStyle: {
            normal: {
              color: '#3DA5FE',
            },
          },
          tooltip: {
            formatter: '{c}',
            // extraCssText: 'padding: 10px 16px;',
            position: (point, params, dom, rect, size) => {
              dom.setAttribute('class', 'line-graph-top-arrow');
              return {
                left: point[0] - (size.contentSize[0] / 2),
                top: point[1] + 20,
              };
            },
          },
        }],
      },
    };
  },
  props: {
    cusOpt: {},
  },
  methods: {
    drawLineGraph() {
      this.lineGraph = echarts.init(this.$refs.lineGraph);
      this.option.title.text = this.cusOpt.title;
      this.cusOpt.xAxis.forEach((item, index) => {
        this.option.xAxis.data[index] = {
          value: item,
          textStyle: { color: this.option.xAxis.axisLabel.color },
        };
        this.option.series[0].data[index] = {
          value: this.cusOpt.series[index],
          symbolSize: this.option.series[0].symbolSize,
        };
      });
      this.lineGraph.setOption(this.option);
      this.lineGraph.on('click', (params) => {
        this.option.series[0].data.forEach((item, index) => {
          item.symbolSize = this.option.series[0].symbolSize;
          this.option.xAxis.data[index].textStyle.color = this.option.xAxis.axisLabel.color;
          if (index === params.dataIndex) {
            item.symbolSize = 16;
            this.option.xAxis.data[index].textStyle.color = '#3DA5FE';
          }
        });
        this.lineGraph.setOption(this.option);
      });
    },
  },
  mounted() {

  },
};
</script>

<style lang="less" scoped>
.container {
  position: relative; // overflow: hidden;
}

.line-graph {
  // width: 108%;
  height: 100%;
}

.graph-tip {
  position: absolute;
}
</style>
<style lang="less">
.line-graph-top-arrow {
  padding: 10px 16px !important;
  background-color: rgba(35, 65, 90, 0.76) !important;
  &:after {
    position: absolute;
    content: ' ';
    height: 0;
    width: 0;
    left: 50%;
    top: -15px;
    margin-left: -8px;
    border: solid transparent;
    border-width: 8px;
    border-bottom-color: rgba(35, 65, 90, 0.76);
  }
}
</style>
