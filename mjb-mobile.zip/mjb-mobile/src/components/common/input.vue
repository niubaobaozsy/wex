<!--
  describe：“input” 组件（可复用）
  created by：Yim Lee
  date：2017-11-02
-->

<template>
  <input type="text"
  ref="input"
  :class="['column', 'inputNomal', {'black-font': blackFont}, {'grey-font': !blackFont}, {'blue-font': blueFont}, {'hasPadding': !isreadOnly}, {'placeholderCenter': textCenter}]"
  :placeholder="placeholder"
  :maxlength="length"
  :autofocus="autoFocus"
  :value="isreadOnly ? pickValue : inputValue"
  @focus="onfocus" @blur="onblur" @input="getValue"
  @click="select"
  :readonly="isreadOnly"
  v-focus="focus">
</template>

<script>
export default {
  props: {
    placeholder: String,
    length: Number,
    isreadOnly: { // 是否只读
      type: Boolean,
      default: false,
    },
    pickValue: String,    // 选择地点或者时间的值xxxxxxxxx
    inputValue: {
      type: [String, Number],
      default: '',
    },
    textCenter: { // 输入值居中还是靠左（true为居中，false为靠左）
      type: Boolean,
      default: false,
    },
    blackFont: {
      type: Boolean,
      default: false,
    },
    blueFont: {
      type: Boolean,
      default: false,
    },
    isAmount: {           // 输入值是否必须是金额
      type: Boolean,
      default: false,
    },
    autoFocus: {
      type: Boolean,
      default: false,
    },
    focus: {
      type: Boolean,
      default: false,
    },
    oneDecimal: {
      type: Boolean,
      default: false,
    }
  },
  data() {
    return {
    };
  },
  methods: {
    // input失去焦点
    onblur() {
      this.$emit('on-blur', this.$refs.input.value);
      this.$emit('input', this.$refs.input.value);
    },
    // input获得焦点
    onfocus() {
      this.$emit('on-focus');
    },
    // input输入时
    getValue() {
      if (this.isAmount || this.oneDecimal) {
        this.formatAmount(this.$refs.input.value);
      }
      this.$emit('input', this.$refs.input.value);
      this.$emit('get-value', this.$refs.input.value);
    },
    // 选择地点或时间
    select() {
      this.$emit('select');
    },
    // 输入的是金额时校验
    formatAmount(value) {
      const reg = /\d/;
      if (!reg.test(value)) {
        this.$refs.input.value = '';
      }
      // 清除"数字"和"."以外的字符
      value = value.replace(/[^\d.]/g, '');
      // 验证第一个字符是数字而不是
      value = value.replace(/^\./g, '');
      // 只保留第一个. 清除多余的
      value = value.replace(/\.{2,}/g, '.');
      value = value.replace('.', '$#$').replace(/\./g, '').replace('$#$', '.');
      if (!this.oneDecimal) {
        // 只能输入两个小数
        value = value.replace(/^(\\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
      } else {
        // 只能输入一个小数
        value = value.replace(/^(\\-)*(\d+)\.(\d).*$/, '$1$2.$3');
      }
      this.$refs.input.value = value;
    },
  },
  watch: {
    autoFocus(val) {
      console.log('焦点', val);
    },
    // inputValue(val) {
    //   if (val === 0) {
    //     this.inputValue = '';
    //   }
    // },
  },
};
</script>
<style lang="less" scoped>
.hasPadding {
  padding-left: 10px;
}

.placeholderCenter {
  text-align: center;
}

.black-font {
  text-shadow: 0px 0px 0px #000000; // 字体颜色
}

.grey-font {
  text-shadow: 0px 0px 0px #858585; // 字体颜色
}

.blue-font {
  text-shadow: 0px 0px 0px #3DA5FE; // 字体颜色
}

.inputNomal {
  border: none;
  background: none;
  outline: none;
  width: 100%;
  font-size: 16px;
  line-height: 22px;
  padding: 0;
  color: #0076FF; // 光标颜色
  -webkit-text-fill-color: transparent; // 模拟让placeholder成镂空状态
  &::-webkit-input-placeholder {
    color: #C3C3C3;
    opacity: 0.5;
  }
}
/* cartet-color只设置光标的颜色，但有些浏览器可能支持该属性，因此使用@support来检查支持caret-color的浏览器，
*  如果支持的就是用该简便方法设置光标颜色，如果不支持就是用上面-webkit-text-fill-color的方法
*/
@supports (caret-color: #0076FF) {
  input [contenteditable] {
    color: #858585; // 文本颜色
    caret-color: #0076FF; // 光标颜色
  }
}
</style>

