<!--
  describe：Pick receiver
  created by：Zhuangyh
  date：2017-11-20
-->

<template>
  <div class="receiver-container" v-if="show">
    <MyHeader title="选择收款方" :rightItem="hideReceiverMgmt?'':'管理'" @on-click="mgmt" :showBack="true" @previous="goBack" v-show="!onSearch"></MyHeader>
    <div class="searchHeader" v-if="onSearch">
      <div class="search">
        <i class="iconfont icon-qietu03"></i>
        <input type="text" placeholder="搜索收款方" v-model="search" v-focus>
      </div>
      <span class="cancel" @click="searchCancel">取消</span>
    </div>
    <div :class="{'has-header': !onSearch}" class="search-wrap" @click="handleSearch" v-show="!onSearch">
      <div class="search">
        <i class="iconfont icon-qietu03"></i>
        <input type="text" placeholder="搜索收款方">
      </div>
    </div>
    <div class="wrap has-search-box" :class="{'has-header': !onSearch}">
      <div v-for="(receiver, index) in (onSearch?searchRes:defReceiver)" :key="index" class="receiver border-top" @click="pickReceiver(receiver)">
        <span class="check-box" :class="{checked: receiver.checked}"></span>
        <div class="detail">
          <span class="bank-receiver">{{receiver.receiver}}</span>
          <span class="bank-account">{{receiver.bank_account}}</span>
          <span class="bank-name">{{receiver.bank_name}}</span>
        </div>
        <div class="badge">
          <span v-if="receiver.is_default==='Y'">默认</span>
        </div>
      </div>
      <div class="tipMsg" v-if="onSearch&&!searchRes.length">暂无匹配收款方</div>
      <div class="tipMsg" v-if="!onSearch&&!defReceiver.length">无默认收款方</div>
    </div>
  </div>
</template>

<script>
import MyHeader from './header';

export default {
  components: {
    MyHeader,
  },
  props: {
    show: {
      type: Boolean,
      required: true,
      default: false,
    },
    value: {
      type: Object,
      required: false,
      default: () => { },
    },
    coId: {
      type: String,
      required: true,
      default: '',
    },
  },
  data() {
    return {
      search: '',
      onSearch: false,
      searchRes: [],
      timer: null,
      defReceiver: [],
    };
  },
  methods: {
    goBack() {
      this.searchCancel();
      this.$emit('goBack');
      this.$emit('update:show', false);
    },
    pickReceiver(receiver) {
      // receiver.checked = !receiver.checked;
      // this.searchRes.forEach((item) => {
      //   item.checked = true;
      //   // if (item.bank_account === receiver.bank_account) {
      //   //   item.checked = true;
      //   // }
      // });
      this.defReceiver.forEach((item) => {
        item.checked = false;
        if (item.bank_account === receiver.bank_account) {
          item.checked = true;
        }
      });
      if (receiver.checked) {
        this.$emit('input', receiver);
        this.$emit('confirm', receiver);
        setTimeout(() => {
          this.$emit('update:show', false);
          this.searchCancel();
        }, 200);
      } else {
        this.$emit('input', {});
      }
    },
    debounce(action, delay) {
      return (() => {
        if (this.timer) clearTimeout(this.timer);
        this.timer = setTimeout(() => {
          action.apply(this);
        }, delay);
      })();
    },
    searchReceiver() {
      this.showLoading();
      this.$store.dispatch('getReceiver', {
        receiver: this.search,
        company_id: this.coId,
        type: 'EMP',
        isYjzbj: '',
        page_number: 1,
        page_size: 1000,
      }).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          res.data.dataList.forEach((item) => {
            item.checked = false;
            if (item.bank_account === this.value.bank_account) {
              item.checked = true;
            }
          });
          if (this.onSearch) {
            this.searchRes = res.data.dataList || [];
          } else {
            this.defReceiver = res.data.dataList || [];
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    searchReceiverDebounce() {
      this.debounce(() => {
        this.searchReceiver();
      }, 500);
    },
    handleSearch() {
      this.onSearch = true;
      this.searchReceiver();
    },
    searchCancel() {
      this.onSearch = false;
      this.search = '';
      this.searchRes = [];
    },
    mgmt() {
      this.$router.push('');
      this.$router.push({
        path: './collectionTitle', query: { redict: './basicInformation' },
      });
    },
  },
  watch: {
    search(newVal) {
      if (newVal) {
        this.searchReceiverDebounce();
      }
    },
    coId(newVal) {
      if (newVal) {
        this.searchReceiver();
      }
    },
  },
  computed: {
    hideReceiverMgmt() {
      return this.$store.state.menuConfig.mine.children.collectionTitle.hidden;
    },
  },
  activated() {
    if (this.coId) this.searchReceiver();
  },
};
</script>
<style lang="less" scoped>
@searchBoxHeight: 32px;
.has-search-box {
  padding-top: 52px;
}
.searchHeader {
  box-sizing: border-box;
  position: fixed;
  z-index: 99;
  top: 0;
  width: 100%;
  display: flex;
  background-color: #484759;
  .search {
    flex-grow: 1;
    margin: 10px 0 10px 10px;
  }
  .cancel {
    padding: 14px;
    font-size: 16px;
    color: #fff;
  }
}

.receiver-container {
  position: fixed;
  top: 0;
  z-index: 100;
  width: 100%;
  height: 100%;
  background-color: #F4F4F4;
}

.search {
  position: relative;
  height: @searchBoxHeight;
  color: #7F8389;
  padding: 0 @searchBoxHeight/2 0 40px;
  line-height: @searchBoxHeight;
  border-radius: @searchBoxHeight/2;
  background-color: #F4F4F4;
  i {
    position: absolute;
    top: 0;
    left: 0;
    padding: 3px 15px 0;
  }
  input {
    width: 100%;
    height: @searchBoxHeight - 5px;
    font-size: 13px;
    outline: none;
    border: 0px;
    background-color: #F4F4F4;
  }
}

.search-wrap {
  box-sizing: border-box;
  position: fixed;
  z-index: 99;
  top: 0;
  width: 100%;
  padding: 10px;
  background-color: #fff;
}

.wrap {
  position: fixed;
  top: 0;
  bottom: 0;
  overflow: auto;
  width: 100%;
  .receiver {
    display: flex;
    padding: 12px 0;
    font-size: 16px;
    background-color: #fff;
    .check-box {
      display: block;
      box-sizing: border-box;
      width: 18px;
      height: 18px;
      margin: 24px 20px;
      border-radius: 9px;
      border: 1px #ADADAD solid;
    }
    .checked {
      border: 0px;
      background-image: url(../../assets/images/common/checked.png);
      background-repeat: no-repeat;
      background-position: center;
      background-size: contain;
    }
    .detail {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      .bank-account,
      .bank-name {
        font-size: 14px;
        color: #9B9B9B;
      }
    }
    .badge {
      span {
        padding: 3px 14px;
        margin: 0 10px;
        border-radius: 11px;
        font-size: 12px;
        color: #fff;
        word-break: keep-all;
        background-color: #3DA5FE;
      }
    }
  }
  .tipMsg {
    margin-top: 65px;
    text-align: center;
    color: #cecece;
  }
}
</style>
