<!--
  describe：Tip when module unavailale
  created by：Zhuangyh
  date：2017-12-16
-->
<template>
  <div class="has-header has-footer container">
    <div class="content" @click="devTool">
      <img class="part0" src="../../assets/images/common/underDevP0.png" alt="">
      <img class="part1" src="../../assets/images/common/underDevP1.png" alt="">
      <p class="tip">页面开发中，敬请期待...</p>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    devTool() {
      localStorage.removeItem('redirectUrl');
      this.$router.push('/');
    },
  },
};
</script>

<style lang="less" scoped>
@imgSize: 100px;

.container {
  position: fixed;
  width: 100%;
  top: 0;
  bottom: 0;
  background-color: #F4F4F4;
  text-align: center;
  .content {
    position: relative;
    margin: 120px 0;
    .part0 {
      width: @imgSize;
      height: @imgSize;
    }
    .part1 {
      position: absolute;
      left: 50%;
      top: 50%;
      width: @imgSize/2.3;
      height: @imgSize/2.3;
      margin-left: 15px;
      margin-top: -17px;
      animation: circle 4s infinite linear;
    }
  }
  @keyframes circle{
    0% { transform:rotate(0deg); }
    100% { transform:rotate(-360deg); }
  }
  .tip {
    font-size: 12px;
  }
}
</style>
