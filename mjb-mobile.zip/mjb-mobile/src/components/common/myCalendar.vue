<!--
  describe: custom calendar base on vux inline-calendar
  created by: zhuangyh
  date: 2017-11-05
-->
<template>
  <!-- <transition name="calendar-transition" leave-active-class="animated fadeOutRightBig"> -->
  <div class="calendar-container" v-if="show">
    <MyHeader :title="'选择日期'" :showBack="true" @previous="goBack"></MyHeader>
    <div class="has-header">
      <div class="custom-header inline-calendar" @touchmove.prevent>
        <div class="selected-value">
          <div class="tip">{{tip}}</div>
          <div class="value">{{formatDate}}</div>
        </div>
        <div class="weeks border-top">
          <table>
            <thead>
              <tr>
                <th v-for="(week, index) in weeksList" class="week" :class="`is-week-list-${index}`" :key="index">{{ week }}</th>
              </tr>
            </thead>
          </table>
        </div>
      </div>
      <div @scroll="onScroll" :style="style" @touchmove.stop class="fix-IOS-scroll" ref="scrollContainer">
        <div ref="scroll">
          <div v-for="(month, index) in monthList" :key="index">
            <div class="title">
              <p>{{month[0]}}年{{month[1]}}月</p>
            </div>
            <div class="custom-calendar">
              <inline-calendar :show="true" v-model="innerValue" @on-dbclick = "onDbclick" @on-change="onChange" :render-month="month" :highlight-weekend="true" :hide-week-list="true" :hide-header="true" :return-six-rows="false" :show-last-month="false" :show-next-month="false" :replace-text-list="{'TODAY':'今日'}" :render-on-value-change="false" :start-date="innerStartDate" :end-date="innerEndDate" :disable-past="innerDisablePast" :disable-future="innerDisableFuture" :disable-weekend="innerDisableWeekend">
                <template slot-scope="props" slot="each-day">
                  <div :class="buildClass(props.rawDate)">
                    <span class="vux-calendar-each-date" v-show="props.isShow">
                      {{ buildReplaceText(props.rawDate) || props.showDate }}
                    </span>
                  </div>
                </template>
              </inline-calendar>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- </transition> -->
</template>

<script>
// import { InlineCalendar } from 'vux';
import MyHeader from './header';
import InlineCalendar from './inlineCalendar';

export default {
  components: {
    InlineCalendar,
    MyHeader,
  },
  props: {
    show: {
      type: Boolean,
      required: true,
      default: false,
    },
    value: {
      type: [String, Array],
      required: false,
      default: '',
    },
    startDate: {
      type: String,
      required: false,
      default: '',
    },
    endDate: {
      type: String,
      required: false,
      default: '',
    },
    disablePast: {
      type: Boolean,
      required: false,
      default: false,
    },
    disableFuture: {
      type: Boolean,
      required: false,
      default: false,
    },
    disableWeekend: {
      type: Boolean,
      required: false,
      default: false,
    },
  },
  data() {
    return {
      style: '',
      // tip: '选中',
      innerValue: this.value,
      multi: false,
      dirty: false,
      defaultDate: [],
      monthList: [],
      weeksList: ['日', '一', '二', '三', '四', '五', '六'],
      innerStartDate: this.startDate,
      innerEndDate: this.endDate,
      innerDisablePast: this.disablePast,
      innerDisableFuture: this.disableFuture,
      innerDisableWeekend: this.disableWeekend,
    };
  },
  computed: {
    formatDate() {
      if (this.multi) {
        const startDate = this.dateStr(this.innerValue[0]) || '起始日期';
        const endDate = this.dateStr(this.innerValue[1]) || '结束日期';
        return `${startDate} - ${endDate}`;
      }
      return this.dateStr(this.innerValue);
    },
    tip() {
      if (this.multi) {
        if (this.innerValue.length === 0 || !this.innerValue[0]) {
          return '请选择起始日期';
        } else if (this.innerValue.length === 1 || !this.innerValue[1]) {
          return '请选择结束日期';
        }
      }
      return '选中';
    },
  },
  watch: {
    show(newVal) {
      if (newVal) {
        this.init();
      } else {
        this.monthList = [];
        this.scroll = 0;
      }
    },
    innerValue(newVal) {
      if ((this.multi && newVal && (newVal.length === 3 || !this.defaultDate.length || (this.defaultDate.length > newVal.length)) && (newVal.toString() !== this.defaultDate.toString())) || (!this.multi && (newVal !== this.defaultDate))) this.dirty = true;
      console.log(`dirty:${this.dirty}`);
    },
  },
  methods: {
    generateMonthList(step, midDate) {
      step = step || [3, 3];
      const upStep = step[0];
      const downStep = step[1];
      const date = midDate ? new Date(midDate) : new Date(); // eslint-disable no-new
      const midMonth = [date.getFullYear(), date.getMonth() + 1];
      let tempMonList = [];
      if (!this.monthList.length) this.monthList.push(midMonth);
      const mostUpMon = this.monthList[0];
      const mostDownMon = this.monthList[this.monthList.length - 1];
      if (upStep) {
        for (let i = 1; i <= upStep; i++) {
          if (mostUpMon[1] - i > 0) {
            tempMonList.push([mostUpMon[0], mostUpMon[1] - i]);
          } else {
            tempMonList.push([
              mostUpMon[0] - (Math.floor((i - mostUpMon[1]) / 12) + 1),
              12 - ((i - mostUpMon[1]) % 12),
            ]);
          }
        }
        this.monthList = tempMonList.reverse().concat(this.monthList);
        tempMonList = [];
      }
      if (downStep) {
        for (let i = 1; i <= downStep; i++) {
          if (mostDownMon[1] + i <= 12) {
            tempMonList.push([mostDownMon[0], mostDownMon[1] + i]);
          } else if ((mostDownMon[1] + i) % 12) {
            tempMonList.push([
              mostDownMon[0] + Math.floor((mostDownMon[1] + i) / 12),
              (mostDownMon[1] + i) % 12,
            ]);
          } else {
            tempMonList.push([mostDownMon[0] + (((mostDownMon[1] + i) / 12) - 1), 12]);
          }
        }
        this.monthList = this.monthList.concat(tempMonList);
        tempMonList = [];
      }
      // console.log(this.monthList);
    },
    init() {
      console.time('init');
      this.multi = Object.prototype.toString.call(this.value) === '[object Array]';
      if (this.multi) {
        this.defaultDate = this.formatInput(Object.assign([], this.value));
      } else {
        this.defaultDate = this.formatInput(this.value);
      }
      this.innerValue = this.formatInput(this.value);
      this.innerStartDate = this.formatInput(this.startDate);
      this.innerEndDate = this.formatInput(this.endDate);
      this.innerDisablePast = this.disablePast;
      this.innerDisableFuture = this.disableFuture;
      this.innerDisableWeekend = this.disableWeekend;
      const midDate = this.multi ? this.innerValue[0] : this.innerValue;
      this.generateMonthList([3, 3], midDate);
      this.style = `height: ${window.screen.height}px; padding-top: ${this.multi ? 40 : 111}px; overflow: auto;`;
      this.$nextTick(() => {
        const offset = this.multi ? 250 : 250;
        this.$refs.scrollContainer.scrollTop = (this.$refs.scroll.scrollHeight / 2) - offset;
        console.log(this.$refs.scrollContainer.scrollTop);
        console.timeEnd('init');
      });
    },
    goBack() {
      if (this.multi && this.value.length < 2) {
        this.innerValue = this.defaultDate;
        this.$emit('input', this.defaultDate);
        this.dirty = false;
      }
      this.$emit('update:show', false);
      this.$emit('goBack', this.value);
    },
    onScroll(e) {
      this.$refs.scrollContainer.scrollTop = e.target.scrollTop;
      if (!(e.target.scrollHeight - e.target.clientHeight - e.target.scrollTop)) { // down
        this.generateMonthList([0, 20]);
      }
      if (!e.target.scrollTop) { // up
        const oldScrollHeight = e.target.scrollHeight;
        this.generateMonthList([20, 0]);
        this.$nextTick(() => {
          this.$refs.scrollContainer.scrollTop = (this.$refs.scroll.scrollHeight - oldScrollHeight) + 50;
        });
      }
    },
    buildClass(rawDate) {
      if (!this.multi) return '';
      const value = this.innerValue;
      const prd = Date.parse(rawDate);
      const complete = value && value.length === 2;
      const isSame = (complete && value[0] === value[1] && rawDate === value[0]);
      const isBeginPoint = (complete && rawDate === value[0] && !isSame);
      const isEndPoint = (complete && rawDate === value[1] && !isSame);
      const isMidPoint = prd > Date.parse(value[0]) && prd < Date.parse(value[1]) && !isSame;
      const className = {
        beginPoint: isBeginPoint,
        endPoint: isEndPoint,
        midPoint: isMidPoint,
        inSamePoint: isSame,
      };
      return className;
    },
    buildReplaceText(rawDate) {
      if (!this.multi) return '';
      const value = this.innerValue;
      if (value && value.length === 2 && value[0] === value[1] && rawDate === value[1]) {
        return '起/止';
      } else if (value && value.length && rawDate === value[0]) {
        return '起';
      } else if (value && value.length === 2 && rawDate === value[1]) {
        return '止';
      }
      return '';
    },
    formatInput(inputDate) {
      if (typeof (inputDate) === 'string') {
        return inputDate.split(' ')[0].split('-').map(i => (i.length === 1 ? `0${i}` : i)).join('-');
      }
      const result = [];
      inputDate.forEach((item) => {
        item = item || '';
        result.push(item.split(' ')[0].split('-').map(i => (i.length === 1 ? `0${i}` : i)).join('-'));
      });
      return result;
    },
    onChange(val) {
      if (this.multi) {
        const date0 = val[0] ? Date.parse(val[0]) : 0;
        const date1 = val[1] ? Date.parse(val[1]) : 0;
        const rtnVal = [];
        if (val.length < 2) return;
        if (val && val.length === 2 && (date0 > date1)) {
          rtnVal.push(val[1]);
          this.innerValue = rtnVal;
          this.$emit('input', rtnVal);
          return;
        }
        if (val && val.length > 2) {
          rtnVal.push(val[2]);
          this.innerValue = rtnVal;
          this.$emit('input', rtnVal);
          return;
        }
      }
      this.$emit('input', val);
      if (this.dirty && this.value && ((this.multi && this.value.length === 2) || !this.multi)) {
        this.dirty = false;
        setTimeout(() => {
          this.$emit('update:show', false);
          this.$emit('pickDate', this.innerValue);
        }, 500);
      }
    },
    dateStr(str) {
      if (str && typeof (str) === 'string') {
        const strArr = str.split('-');
        return `${strArr[1]}月${strArr[2]}号`;
      }
      return '';
    },
    onDbclick(date) {
      console.log(date);
      console.log(this.innerValue);
      if (this.innerValue.length === 2) {
        this.innerValue = [date];
      } else if (this.innerValue.length === 1) {
        this.dirty = false;
        this.innerValue = [date, date];
        this.$emit('input', [date, date]);
        this.$emit('pickDate', [date, date]);
        setTimeout(() => {
          this.$emit('update:show', false);
        }, 500);
      }
    },
  },
};
</script>

<style lang="less" scoped>
.calendar-container {
  position: fixed;
  top: 0;
  z-index: 100;
  width: 100%;
  height: 100%;
  background-color: #fff;
}

.custom-header {
  position: fixed;
  z-index: 98;
  .selected-value {
    padding: 10px;
    text-align: center;
    .tip {
      font-size: 12px;
      color: #858585;
    }
    .value {
      height: 32px;
      font-size: 20px;
    }
  }
  .weeks {
    padding: 8px 18px;
    box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.15);
  }
}

.title {
  height: 36px;
  color: #9B9B9B;
  padding-left: 14px;
  font-size: 16px;
  line-height: 36px;
  background-color: #F4F4F4;
}

.custom-calendar {
  padding: 10px 18px;
  background-color: #fff;
}

.weeks th {
  font-size: 11px;
  color: #000;
}
</style>
