<!--
  describe：tab
  created by：ouql
  date：2017-10-25
-->
<template>
  <div class="my-tabs border">
    <div class="tabs-bar">
      <div class="tabs-bar-nav">
        <div class="tabs-tab" v-for="(tab,index) in tabList" :key="index" @click="changeTab(tab)">
          <div class="title" :class="{ 'tabs-active': currentLinkTo === tab.linkTo }">
            {{tab.name}}
            <span v-if="tab.unreadNum">({{ tab.unreadNum}})</span>
          </div>
          <span class="dot" v-if="tab.unread"></span>
        </div>
      </div>
    </div>
    <div class="tabs-content">
    </div>
  </div>
</template>
<script>
export default {
  props:
  {
    tabList: Array,
    budgetType: String,
  },
  data() {
    return {
      currentRule: '',
      currentLinkTo: '',
    };
  },
  methods: {
    changeTab(tab) {
      this.hideLoading();
      this.currentLinkTo = tab.linkTo;
      this.$router.push({ path: tab.linkTo, query: { budgetType: this.budgetType } });
      this.$emit('on-select', tab);
    },
  },
  mounted() {
    this.currentLinkTo = this.$route.path.split('/').pop();
  },
};
</script>
<style lang="less" scoped>
@import "../../assets/css/base.less";
.my-tabs {
  position: fixed;
  width: 100%;
  top: 46px;
  z-index: 3;
  .tabs-bar {
    height: 50px;
    line-height: 50px;
    background: #fff;
    font-size: 16px;
    color: #666666;
    .tabs-bar-nav {
      margin: auto;
      height: 100%;
      width: 100%;
      color: #666666;
      display: flex;
      justify-content: center;
      align-items: center;
      .tabs-tab {
        margin: auto;
      }
      .title {
        height: 47px;
        display: -webkit-inline-box;
        position: relative;
      }
      .tabs-active {
        border-bottom: 3px solid @color-main;
      }
      .dot {
        width: 8px;
        height: 8px;
        border-radius: 8px;
        background: #FC4B4C;
        display: inline-block;
        top: -8px;
        right: 3px;
        position: relative;
      }
    }
  }
}
</style>
