<!--
  describe：cell组件
  created by：欧倩伶
  date：2017-10-20
  modify by: zhuangyh @ 2018-06-10
-->
<template>
  <div class="cellList border">
    <div class="row columns is-mobile" v-for="(item, index) in list" :key="index" @click="goRoute(item)">
      <div class="icon flex">
        <img :src="item.icon">
      </div>
      <div class="content column  device">
        <p class="name">{{ item.name }}</p>
        <p class="font14 message">
          <span class="message-count" v-if="item.msgCnt">[{{ item.msgCnt }}]</span>
          {{ item.desc }}
        </p>
      </div>
      <div class="unread  flex  device" v-if="item.unreadCnt">
        <span class="dot">
          <p>{{ item.unreadCnt }}</p>
        </span>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    list: {
      type: Array,
      default: () => ({
        alias: String,
        icon: String,
        name: String,
        msgCnt: Number,
        desc: String,
        unreadCnt: Number,
      }),
    },
  },
  methods: {
    goRoute(item) {
      if (item.underDev) {
        this.alert({
          title: '提示',
          content: '即将上线，敬请期待',
        });
      } else {
        this.$router.push({ path: item.alias });
      }
    },
  },
};
</script>
<style lang="less" scoped>
@import '~@/assets/css/base.less';
.flex {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.cellList {
  margin-bottom: 10px;
  background-color: #fff;
  .columns {
    margin: 0;
  }
  .column {
    padding: 0.75em 0;
    text-align: left;
  }
  .row {
    background-color: white;
    .icon {
      flex: none;
      width: 68px;
      img {
        width: 40px;
        height: 40px;
        margin: auto;
      }
    }
    .content {
      .name {
        color: #000000;
        font-size: 16px;
        line-height: 22px;
        background-color: #fff;
      }

      .message {
        color: #9B9B9B;
        font-size: 14px;
        line-height: 20px;
        background-color: #fff;
        .message-count {
          color: #FCB23C;
        }
      }
    }
    .unread {
      flex: none;
      width: 51px;
      .dot {
        width: 19px;
        height: 19px;
        border-radius: 50%;
        display: inline-block;
        background: #FC4B4C;
        text-align: center;
        margin: auto;
        p {
          font-size: 12px;
          color: white;
        }
      }
    }
  }
}

.borderScale {
  content: "";
  position: absolute;
  left: 0px;
  right: 0px;
  transform: scaleY(.3);
  transform-origin: 0 0;
}
.device,
.row:nth-last-child(1) .content,
.row:nth-last-child(1) .unread {
  position: relative;
}
.device::before {
  .borderScale;
  bottom: 0px;
  border-bottom: 2px solid #CBCFD6;
}
.row:nth-last-child(1) .content::before {
  .borderScale;
  bottom: 0px;
  border-bottom: 0px solid #CBCFD6;
}
.row:nth-last-child(1) .unread::before {
  .borderScale;
  bottom: 0px;
  border-bottom: 0px solid #CBCFD6;
}
</style>
