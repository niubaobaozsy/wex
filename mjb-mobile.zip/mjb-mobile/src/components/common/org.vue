<!--
  describe：Pick users from organizational structure
  created by：Zhuangyh
  date：2017-10-29
-->

<template>
  <div class="org-container" v-if="show">
    <MyHeader :title="'组织架构'" :showBack="true" @previous="goBack" v-show="!onSearch"></MyHeader>
<!--     <div class="searchHeader" v-if="onSearch">
      <div class="search">
        <i class="iconfont icon-qietu03"></i>
        <input type="text" placeholder="搜索申请人" v-model="search" v-focus>
      </div>
      <span class="cancel" @click="searchCancel">取消</span>
    </div> -->
    <div :class="{'has-header': !onSearch}">
      <div :class="{ 'search-wrap': !onSearch, 'searchHeader': onSearch}">
        <div class="search">
          <i class="iconfont icon-qietu03"></i>
          <input type="text" placeholder="搜索申请人" v-model="search" @click="handleSearch">
        </div>
        <span class="cancel" @click="searchCancel">取消</span>
      </div>
      <div class="paths" ref="path" v-show="!onSearch">
        <div v-for="(path, index) in (onSearch?[]:paths)" :key="index" @click="getOrgUsersById(path.id)">
          <span class="org-name" :class="{active: path.active}">{{path.org_name}}</span>
          <span v-if="(index + 1) !== paths.length" class="icon"> > </span>
        </div>
      </div>
      <div :style="style" @touchmove.stop>
        <div class="wrap" :class="{hasUsersList: usersPicked.length}">
          <div v-for="(user, index) in (onSearch?searchRes:users)" :key="user.user_id+user.is_primary" class="user" @click="pickUsers(index)">
            <img :src="user.avatar||defaultAvatar" alt="avatar" class="avatar" />
            <div class=" main border-bottom">
              <div class="detail">
                <span class="user-name">{{user.user_full_name}}</span>
                <span class="position">{{user.position_name || user.fullNameCutback}}</span>
              </div>
              <div>
                <span class="check-box" :class="{checked: user.checked}"></span>
              </div>
            </div>
          </div>
          <div v-for="org in (onSearch?[]:orgs)" :key="org.id" @click="getOrgUsersById(org.id)" class="org border-top">
            <img src="../../assets/images/common/list.png" class="org-icon" />
            <span>{{org.org_name}}</span>
          </div>
          <div class="tipMsg" v-if="onSearch&&!searchRes.length">暂无匹配联系人</div>
        </div>
      </div>
      <!-- <div class="pick-users" v-if="multi && usersPicked.length"> -->
      <div class="pick-users">
        <div class="users-list" ref="usersList">
          <div v-for="(user, index) in usersPicked" :key="index" class="user" @click="delPickUser(index)">
            <img :src="user.avatar||defaultAvatar" alt="avatar" class="avatar">
            <span>{{user.user_full_name}}</span>
            <img src="../../assets/images/common/delete2x.png" class="del">
          </div>
        </div>
        <div class="confirm-btn" @click="onConfirm">完成</div>
      </div>
    </div>
  </div>
</template>

<script>
import MyHeader from './header';
import defaultAvatar from '../../assets/images/common/defaultAvatar.png';

export default {
  components: {
    MyHeader,
  },
  props: {
    show: {
      type: Boolean,
      required: true,
      default: false,
    },
    multi: {
      type: Boolean,
      required: false,
      default: false,
    },
    value: {
      type: Array,
      required: false,
      default: () => [],
    },
    defOrgId: {
      type: String,
      required: false,
      default: '',
    },
  },
  data() {
    return {
      search: '',
      onSearch: false,
      paths: [],
      users: [],
      orgs: [],
      searchRes: [],
      usersPicked: [],
      style: {
        top: '53px',
        position: 'fixed',
        overflow: 'auto',
        width: '100%',
        bottom: '0px',
      },
      defaultAvatar,
      timer: null,
    };
  },
  methods: {
    goBack() {
      this.searchCancel();
      this.$emit('goBack', this.usersPicked);
      this.$emit('update:show', false);
      this.users = [];
    },
    getOrgUsersById(id) {
      this.showLoading();
      this.$store.dispatch('getOrgUsers', { org_id: id, pageSize: 200 })
        .then((res) => {
          this.hideLoading();
          if (res && res.code === '0000') {
            res.data.paths.sort((a, b) => a.full_path.split('/').length - b.full_path.split('/').length);
            res.data.paths.forEach((path) => {
              path.active = false;
              if (path.id === id) path.active = true;
            });
            res.data.users.forEach((user) => {
              user.checked = false;
              if (this.uidInValue.indexOf(user.user_id) !== -1) user.checked = true;
            });
            this.paths = res.data.paths;
            this.users = res.data.users;
            this.orgs = res.data.orgs;
            this.$nextTick(() => {
              if (this.$refs.path) this.$refs.path.scrollLeft = this.$refs.path.scrollWidth;
            });
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
    },
    pickUsers(index) {
      const userList = this.onSearch ? this.searchRes : this.users;
      const currentUser = userList[index];
      currentUser.checked = !currentUser.checked;
      console.log(currentUser, '2222');
      if (currentUser.checked) {
        if (this.multi) {
          this.usersPicked.push(currentUser);
        } else {
          this.searchRes.forEach((user) => {
            if (this.usersPicked[0] && (user.user_id === this.usersPicked[0].user_id)) {
              user.checked = false;
            }
          });
          this.users.forEach((user) => {
            if (this.usersPicked[0] && (user.user_id === this.usersPicked[0].user_id)) {
              user.checked = false;
            }
          });
          this.usersPicked = [currentUser];
          setTimeout(() => {
            this.onConfirm();
          }, 500);
        }
      } else {
        this.usersPicked = this.usersPicked.filter(user => user.user_id !== currentUser.user_id);
      }
      this.$nextTick(() => {
        if (this.$refs.usersList) this.$refs.usersList.scrollLeft = this.$refs.usersList.scrollWidth;
      });
    },
    delPickUser(index) {
      const userList = this.onSearch ? this.searchRes : this.users;
      const currentUser = this.usersPicked[index];
      this.usersPicked.splice(index, 1);
      userList.forEach((user) => {
        if (user.user_id === currentUser.user_id) currentUser.checked = false;
      });
    },
    onConfirm() {
      this.searchCancel();
      this.$emit('input', this.usersPicked);
      this.$emit('confirm', this.usersPicked);
      this.$emit('update:show', false);
      this.users = [];
    },
    debounce(action, delay) {
      return (() => {
        if (this.timer) clearTimeout(this.timer);
        this.timer = setTimeout(() => {
          action.apply(this);
        }, delay);
      })();
    },
    searchUsers() {
      this.debounce(() => {
        this.showLoading();
        this.$store.dispatch('queryUsersByName', { user_name: this.search, page_size: 200 })
          .then((res) => {
            this.hideLoading();
            if (res && res.code === '0000') {
              res.data.list.forEach((user) => {
                user.checked = false;
                if (this.uidInValue.indexOf(user.user_id) !== -1) user.checked = true;
              });
              this.searchRes = res.data.list;
              console.log(11111, this.searchRes)
              this.searchRes.forEach((item) => {
                let fullName = item.full_path_name;
                let fullNameArray = item.full_path_name.split('/');
                let fullNameCutback = ''
                fullNameArray.reverse();
                fullNameArray.forEach((data) => {
                  fullNameCutback += `${data}/`;
                })
                item.fullNameCutback = fullNameCutback;
              });
            } else if (res && res.code) {
              this.showToast({ msg: `请求异常(${res.code})` });
            }
          });
      }, 500);
    },
    handleSearch() {
      this.onSearch = true;
      // this.style.height = `${window.screen.height - 56}px`;
      this.style.top = '53px';
    },
    searchCancel() {
      this.onSearch = false;
      // this.style.height = `${window.screen.height - 156}px`;
      this.style.top = '145px';
      if (this.$refs.usersList) this.$refs.usersList.scrollLeft = this.$refs.usersList.scrollWidth;
      this.search = '';
      this.searchRes = [];
    },
  },
  watch: {
    show(newVal) {
      if (newVal) {
        this.usersPicked = this.value;
        const orgId = Object.keys(this.$store.state.userInfo.user.org)[0];
        this.getOrgUsersById(this.defOrgId || orgId);
        // this.style.height = `${window.screen.height - 156}px`;
        this.style.top = '145px';
      }
    },
    search(newVal) {
      if (newVal) {
        this.searchUsers();
        console.log(this.users, 'testUsersSearch');
      }
    },
  },
  computed: {
    uidInValue() {
      const uid = [];
      this.value.forEach((user) => {
        uid.push(user.user_id);
      });
      return uid;
    },
  },
};
</script>
<style lang="less" scoped>
@searchBoxHeight: 32px;

.searchHeader {
  display: flex;
  background-color: #484759;
  .search {
    flex-grow: 1;
    margin: 10px 0 10px 10px;
  }
  .cancel {
    padding: 14px;
    font-size: 16px;
    color: #fff;
  }
}

.org-container {
  position: fixed;
  top: 0;
  z-index: 100;
  width: 100%;
  height: 100%;
  background-color: #F4F4F4;
}

.search {
  position: relative;
  height: @searchBoxHeight;
  color: #7F8389;
  padding: 0 @searchBoxHeight/2 0 40px;
  line-height: @searchBoxHeight;
  border-radius: @searchBoxHeight/2;
  background-color: #F4F4F4;
  i {
    position: absolute;
    top: 0;
    left: 0;
    padding: 3px 15px 0;
  }
  input {
    width: 100%;
    height: @searchBoxHeight - 5px;
    font-size: 13px;
    outline: none;
    border: 0px;
    background-color: #F4F4F4;
  }
}

.search-wrap {
  padding: 10px;
  background-color: #fff;

  .cancel {
    display: none;
  }
}

.paths {
  width: 100%;
  color: #666;
  font-size: 16px;
  white-space: nowrap;
  overflow-x: scroll;
  border-bottom: 1px solid #BDBDBD;
  background-color: #fff;
  div {
    display: inline;
    .icon {
      margin: 0 !important;
    }
    span {
      margin: 0 10px;
    }
    &:first-child {
      span {
        margin-left: 20px;
      }
    }
    &:last-child {
      span {
        margin-right: 20px;
      }
    }
  }
  .org-name {
    display: inline-block;
    padding: 4px 0 14px 0;
  }
  .active {
    border-bottom: 3px #3DA5FE solid;
  }
  &::-webkit-scrollbar {
    display: none;
  }
}

.hasUsersList {
  margin-bottom: 80px !important;
}

.wrap {
  .user {
    display: flex;
    flex-wrap: nowrap;
    align-items: center;
    background-color: #fff;
    .avatar {
      width: 30px;
      height: 30px;
      margin: 12px 15px;
      border-radius: 15px;
    }
    .main {
      flex-grow: 1;
      display: flex;
      .detail {
        flex-grow: 1;
        justify-content: center;
        display: flex;
        flex-direction: column;
        .user-name {
          font-size: 16px;
        }
        .position {
          font-size: 14px;
          color: #666;
          font-size: 14px;
          color: #666;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          width: 250px;
        }
      }
      .check-box {
        display: block;
        box-sizing: border-box;
        width: 18px;
        height: 18px;
        margin: 18px;
        border-radius: 9px;
        border: 1px #ADADAD solid;
      }
      .checked {
        border: 0px;
        background-image: url(../../assets/images/common/checked.png);
        background-repeat: no-repeat;
        background-position: center;
        background-size: contain;
      }
    }
  }
  .org {
    display: flex;
    align-items: center;
    background-color: #fff;
    img {
      width: 20px;
      height: 20px;
      margin: 13px 20px;
    }
    span {
      display: block;
      flex-grow: 1;
      font-size: 16px;
    }
  }
  .tipMsg {
    margin-top: 65px;
    text-align: center;
    color: #cecece;
  }
}

.pick-users {
  display: flex;
  align-items: center;
  position: fixed;
  bottom: -1px;
  left: 0;
  padding: 5px 0;
  width: 100%;
  background-color: #fff;
  box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.10);
  .users-list {
    flex-grow: 1;
    display: flex;
    overflow-x: scroll;
    &::-webkit-scrollbar {
      display: none;
    }
    .user {
      display: flex;
      position: relative;
      flex-direction: column;
      align-items: center;
      margin: 0 8px;
      img {
        width: 30px;
        height: 30px;
        border-radius: 15px;
      }
      .del {
        width: 14px;
        height: 14px;
        position: absolute;
        top: 0;
        right: -5px;
      }
      span {
        font-size: 10px;
        color: #666;
        white-space: nowrap;
      }
    }
  }
  .confirm-btn {
    flex-shrink: 0;
    box-sizing: border-box;
    width: 71px;
    height: 29px;
    line-height: 29px;
    text-align: center;
    font-size: 16px;
    margin: 10px 20px;
    color: #fff;
    background-color: #3DA5FE;
    border-radius: 14px;
  }
}
</style>
