<template>
  <div>
    <!-- <input ref="input" @input="updateValue($event.target.value)" @blur="formatValue" placeholder="0.00"> -->
    <input ref="input" autofocus v-bind:value="value" @focus="selectAll" @input="updateValue($event.target.value)" @blur="formatValue" placeholder="请输入金额">
  </div>
</template>
<script>
export default {
  props: {
    value: [Number, String],
  },
  mounted() {
    // this.formatValue();
  },
  methods: {
    updateValue(value) {
      const result = this.currencyValidator.parse(value, this.value);
      if (result.warning) {
        this.$refs.input.value = result.value;
      }
      this.$emit('input', result.value);
    },
    formatValue() {
      if ((this.value === '' && this.$refs.input.value === '') || (this.value === undefined)) return;
      // this.$refs.input.value = this.value;
      this.$refs.input.value = this.currencyValidator.format(this.value);
      this.$emit('on-blur');
    },
    selectAll(event) {
      setTimeout(() => {
        event.target.select();
      }, 0);
    },
  },
  data() {
    return {
      currencyValidator: {
        format(number) {
          return `￥${(Math.round(number * 100) / 100).toFixed(2)}`;
        },
        parse(newString, oldNumber) {
          function CleanParse(value) {
            return { value };
          }
          function CurrencyWarning(warning, value) {
            return {
              warning,
              value,
              attempt: newString,
            };
          }
          function NotAValidDollarAmountWarning(value) {
            return new CurrencyWarning(`${newString} is not a valid dollar amount ${value}`);
          }
          function AutomaticConversionWarning(value) {
            return new CurrencyWarning(`${newString} was automatically converted to ${value}`, value);
          }

          const newNumber = Number(newString);
          const indexOfDot = newString.indexOf('.');
          const indexOfE = newString.indexOf('e');

          if (isNaN(newNumber)) {
            if (
              indexOfDot === -1 &&
              indexOfE > 0 &&
              indexOfE === newString.length - 1 &&
              Number(newString.slice(0, indexOfE)) !== 0
            ) {
              return new CleanParse(oldNumber);
            }
            return new NotAValidDollarAmountWarning(oldNumber);
          }

          const newCurrencyString = this.format(newNumber);
          const newCurrencyNumber = Number(newCurrencyString);

          if (newCurrencyNumber === newNumber) {
            if (indexOfE !== -1 && indexOfE === newString.length - 2) {
              return new AutomaticConversionWarning(newNumber);
            }
            return new CleanParse(newNumber);
          }
          const number = newNumber > newCurrencyNumber ? newCurrencyNumber : oldNumber;
          return new NotAValidDollarAmountWarning(number);
        },
      },
    };
  },
  watch: {
    value() {
      this.formatValue();
    },
  },
};
</script>
<style lang="less" scoped>
input {
  font-size: 16px;
  border: 0;
  height: inherit;
  top: 50%;
  text-align: right;
  outline: none;
  transform: translate(0, -50%);
  -webkit-transform: translate(0, -50%);
  -ms-transform: translate(0, -50%);
  -o-transform: translate(0, -50%);
  -moz-transform: translate(0, -50%);
  background-color: transparent;
  vertical-align: -webkit-baseline-middle;
}

.weui-cell {
  padding: 0;
}
</style>
