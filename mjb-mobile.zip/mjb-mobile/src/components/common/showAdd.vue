<!--
  describe："添加" 页面
  created by：Yim Lee
  date：2017-10-31
-->
<style lang="less" scoped>
@import '../../assets/css/common/showAdd.less';
</style>
<template>
  <div>
    <div class="content" :style="{ width: contentWidth + 'px' }">
      <div class="main-module">
        <transition-group name="shortcut-animate" tag="ul" enter-active-class="animated fadeInUpBig" leave-active-class="animated fadeOutDownBig" class="columns is-mobile is-multiline modules">
          <li class="column is-4 module" v-for="(item, index) in modules" :key="index" @click="goRouter(item)">
            <img :src="item.src">
            <span>{{ item.text }}</span>
          </li>
        </transition-group>
      </div>
      <!-- <div class="close" @click="closeAdd">
          <img src="../../assets/images/common/showAdd/add_on.png">
        </div> -->
    </div>
  </div>
</template>
<script>
import addInvoice from '../../assets/images/common/showAdd/add_invoice.png';
// import charge from '../../assets/images/common/showAdd/charge.png';
import feeReimburse from '../../assets/images/common/showAdd/fee_reimburse.png';
import feeApply from '../../assets/images/common/showAdd/fee_apply.png';
// import loanApply from '../../assets/images/common/showAdd/loan_apply.png';
import travelApply from '../../assets/images/common/showAdd/travel_apply.png';
import travelReimburse from '../../assets/images/common/showAdd/travel_reimburse.png';
// import demo from '../../assets/images/common/showAdd/demo.png';

export default {
  props: {
  },
  data() {
    return {
      contentWidth: 0,
      modules: [],
      allModules: [
        {
          src: travelApply,
          text: '差旅申请',
          moduleName: 'travelApply',
          href: '/fee/myApply/create',
          index: 0,
          type: 'CL',
        },
        {
          src: feeApply,
          text: '费用申请',
          moduleName: 'feeApply',
          href: '/fee/myApply/create',
          index: 1,
          type: 'EA',
        },
        // {
        //   src: loanApply,
        //   text: '借款申请',
        //   moduleName: 'loanApply',
        //   href: '/fee/myApply/create',
        //   index: 2,
        //   type: 'LM',
        // }, // 美的版本需要屏蔽
        {
          src: travelReimburse,
          text: '差旅报销',
          moduleName: 'travelReimburse',
          href: '/fee/myReimburse/create',
          index: 3,
          type: 'CL',
        },
        {
          src: feeReimburse,
          text: '费用报销',
          moduleName: 'feeReimburse',
          href: '/fee/myReimburse/create',
          index: 4,
          type: 'TY',
        },
        {
          src: addInvoice,
          text: '添加发票',
          moduleName: 'addInvoice',
          href: '/fee/myInvoice/invoiceHome',
          index: 5,
        },
        // {
        //   src: charge,
        //   text: '记一笔',
        //   moduleName: 'charge',
        //   href: '/',
        //   index: 6,
        // },
        // {
        //   src: demo,
        //   text: 'demo',
        //   moduleName: 'demo',
        //   href: '/hello',
        //   index: 7,
        // },
      ],
    };
  },
  methods: {
    // 关闭“添加”页面
    closeAdd(callBack) {
      this.removeModules(callBack);
    },
    goRouter(item) {
      this.removeModules(() => {
        switch (item.moduleName) {
          case 'travelApply':
            this.$store.commit('APPLY_CREATE', { applyType: 'CL' });
            break;
          case 'feeApply':
            this.$store.commit('APPLY_CREATE', { applyType: 'EA' });
            break;
          case 'loanApply':
            this.$store.commit('APPLY_CREATE', { applyType: 'LM' });
            break;
          case 'travelReimburse':
            this.$store.commit('REIMBURSE_CREATE', { reimburseType: 'CL' });
            break;
          case 'feeReimburse':
            this.$store.commit('REIMBURSE_CREATE', { reimburseType: 'TY' });
            break;
          case 'addInvoice':
            this.$router.push({ path: item.href });
            break;
          default:
            break;
        }
        if (item.moduleName !== 'addInvoice') this.$router.push({ path: item.href, query: { addType: item.type } });
      });
    },
    addModules() {
      this.contentWidth = document.body.clientWidth;
      let count = 0;
      const timer = setInterval(() => {
        if (count < this.allModules.length) {
          this.modules.push(this.allModules[count]);
          count += 1;
        } else {
          clearInterval(timer);
        }
      }, 25);
    },
    removeModules(callBack) {
      this.contentWidth = document.body.clientWidth;
      let count = 0;
      const timer = setInterval(() => {
        if (count < this.allModules.length) {
          this.modules.pop();
          count += 1;
        } else {
          clearInterval(timer);
          if (callBack && (typeof callBack === 'function')) callBack();
          this.$emit('close');
        }
      }, 25);
    },
  },
  watch: {
  },
  mounted() {
    this.addModules();
  },
};
</script>
