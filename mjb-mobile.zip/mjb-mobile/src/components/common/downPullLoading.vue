<!--
  describe：下拉加载组件
  created by：panjm
  date：2018-03-01
  example: <down-pull-loading @loading="refresh">
              <div slot="list"></div>
            </down-pull-loading>
-->
<template>
  <div id="minirefresh" class="minirefresh-wrap" ref="minirefresh">
    <div class="minirefresh-scroll">
      <div class="msg-flow">
        <slot name="list"></slot>
      </div>
    </div>
  </div>
</template>
<script>
import MiniRefreshTools from 'minirefresh';

export default {
  methods: {
    downPull() {
      return new Promise((resolve) => {
        this.$emit('loading');
        resolve();
      });
    },
  },
  mounted() {
    const _this = this;
    const miniRefresh = new MiniRefresh({
      container: '#minirefresh',
      down: {
        callback: () => {
          _this.downPull().then(() => {
            miniRefresh.endDownLoading();
          });
        },
      },
      up: {
        isLock: true,
        toTop: {
            // 是否开启点击回到顶部
            isEnable: false,
        },
        callback: () => {
          // 上拉事件
          // 注意，由于默认情况是开启满屏自动加载的，所以请求失败时，请务必endUpLoading(true)，防止无限请求
          miniRefresh.endUpLoading(true);
        },
        contentnomore: '',
      },
      isUseBodyScroll: true,
      isScrollBar: false,
    });
  },
};
</script>
<style>
.minirefresh-wrap {
  overflow: visible;
  z-index: 0;
}
.minirefresh-theme-default .minirefresh-upwrap {
  display: none;
}
</style>
