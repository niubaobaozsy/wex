<!--
  describe： View attachment
  created by：Zhuangyh
  date：2018-02-28
-->
<template>
  <div>
    <div class="detail" v-if="showDetail">
      <my-header title="附件" :showBack="true" @previous="showDetail=false"></my-header>
      <div class="has-header">
        <div v-for="(item, index) in fileList" :key="index" @click="viewFile(index)">
          <div v-if="item.type==='img'" class="file border-bottom">
            <img :src="item.src" @load="setImgSize(index)" class="icon">
            <div class="file-msg">
              <div class="file-name">{{item.fileName}}</div>
              <div class="file-info">{{item.fileInfo}}</div>
            </div>
          </div>
          <div v-else class="file border-bottom">
            <img :src="item.icon" class="icon">
            <div class="file-msg">
              <div class="file-name">{{item.fileName}}</div>
              <div class="file-info">{{item.fileInfo}}</div>
            </div>
          </div>
        </div>
      </div>
      <pdf-viewer :show.sync="showPdf" :src="pdfSrc"></pdf-viewer>
      <gallery :show="showImg" :index="0" :list="[imgtoShow]" @on-hide="showImg=false" :hasDel="false"></gallery>
    </div>
    <div v-if="!showDetail&&fileList.length" class="menu border" @click="showDetail=true">
      <div class="title">附件</div>
      <div class="cnt">共{{fileList.length}}份
        <img src='../../assets/rt-arrow.png'>
      </div>
    </div>
  </div>
</template>

<script>
import { platform } from '@/platform';
import pdf from '@/assets/images/common/pdf.png';
import doc from '@/assets/images/common/doc.png';
import xls from '@/assets/images/common/xls.png';
import ppt from '@/assets/images/common/ppt.png';
import myHeader from './header';
import gallery from './gallery';
import pdfViewer from './pdf';

export default {
  components: {
    myHeader,
    pdfViewer,
    gallery,
  },
  props: {
    formInstanceId: {
      type: String,
      required: true,
      default: '',
    },
  },
  data() {
    return {
      showDetail: false,
      showPdf: false,
      showImg: false,
      pdfSrc: '',
      fileSrc: '',
      imgtoShow: {},
      fileList: [],
    }
  },
  methods: {
    viewFile(index) {
      const file = this.fileList[index];
      if(this.baseConfig.isHybridApp && file.type !== 'img') {
        document.addEventListener('deviceready', () => {
          platform.showPdf(file.src).then((success) => {
            this.showToast({ msg: success });
          }, (error) => {
            this.showToast({ mag: `Error: + ${JSON.stringify(error)}`});
          });
        }, false);
      } else {
        switch(file.type) {
          case 'pdf':
            this.showPdf = true;
            this.pdfSrc = file.src[0].url;
            break;
          case 'img':
            this.showImg = true;
            this.imgtoShow = file;
            break;
          case 'doc':
          case 'xls':
          case 'ppt':
          default:
            this.showToast({ msg: '暂不支持该类型附件的预览' });
        }
      }
    },
    setImgSize(index) {
      const el = event.srcElement;
      const showImg = this.fileList[index];
      console.log(index, el.naturalWidth, el.naturalHeight);
      if (showImg) {
        showImg.el = el;
        showImg.src = el.src;
        showImg.w = el.naturalWidth;
        showImg.h = el.naturalHeight;
        this.fileList[index] = showImg;
      }
    },
    getFileByOrderMsg() {
      const params = {
        source_system: 'Expense',
        source_order_id: this.formInstanceId.split('_')[0],
        source_order_type: this.formInstanceId.split('_')[1],
      };
      this.$store.dispatch('getFileByOrderMsg', params)
        .then((rep) => {
          if (rep.code === '0000' && rep.data && rep.data.info) {
            rep.data.info.forEach((item, index) => {
              const file = item;
              if (item.mime_type === 'application/vnd.ms-excel') {
                file.type = 'xls';
                file.icon = xls;
              } else if (item.mime_type === 'application/vnd.openxmlformats-officedocument.presentationml.presentation') {
                file.type = 'ppt';
                file.icon = ppt;
              } else if (item.mime_type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
                file.type = 'doc';
                file.icon = doc;
              } else if (item.mime_type === 'application/pdf') {
                file.type = 'pdf';
                file.icon = pdf;
              } else if (item.mime_type.split('/')[0] === 'image') {
                file.type = 'img';
                file.fileId = item.file_id;
                file.src = '';
              }
              if (item.mime_type.split('/')[0] === 'application') {
                file.src = [{ url: `${this.baseConfig.baseUrl}sdatt/file/downloadFile/${item.url_path}?${this.baseConfig.ssoTokenName}=${this.ssoToken}` }];
                // file.src = `${this.baseConfig.masUrl}mas-api/proxy?alias=md.x2pr.file&access_token=${this.ssoToken}&docType=${item.extension}&exParam=${item.url_path}&fdType=MJB&quality=pdf&attachment_stamp=`;
              }
              file.fileName = item.source_filename;
              file.fileInfo = `${item.last_update_date.split(' ')[0].split('_').join('/')}  ${(parseFloat(item.file_size)/1024).toFixed(2)}K`;
              this.fileList.push(file);
            });
            this.fileList.forEach((item, index) => {
              if (item.type === 'img') {
                this.$store.dispatch('getBigImg', item.fileId).then((res) => {
                  if (res && res.code === '0000') {
                    if (res.data) {
                      item.src = `data:image/jpeg;base64,${res.data.content}`;
                    }
                  } else if (res && res.code) {
                    this.showToast({ msg: `请求异常(${res.code})` });
                  }
                });
              } else if (this.baseConfig.isHybridApp && item.type !== 'pdf') {
                this.$store.dispatch('switchToken', {
                  alias: 'md.x2pr.file',
                  access_token: this.ssoToken,
                  docType: item.extension,
                  exParam: item.url_path,
                  fdType: 'MJB',
                  quality: 'pdf',
                  attachment_stamp: '',
                }).then((resp) => {
                  if (resp && !resp.error) {
                    item.src = resp.pages;
                  } else {
                    this.showToast({ msg: resp.msg });
                  }
                }, () => {
                  this.showToast({ msg: `MAS转换${item.extension}失败` });
                });
              }
            });
          }
        });
    },
  },
  computed: {
    baseConfig() {
      return this.$store.state.baseConfig;
    },
    ssoToken() {
      return this.$store.state.ssoToken;
    },
  },
  watch: {
    formInstanceId(nVal) {
      if(nVal) {
        this.getFileByOrderMsg();
      }
    },
  },
}
</script>

<style lang="less" scoped>
.detail {
  position: fixed;
  width: 100%;
  top: 0;
  bottom: 0;
  z-index: 99;
  background-color: #F4F4F4;
}
.file {
  display: flex;
  background-color: #fff;
  padding: 15px;
  .icon {
    width: 40px;
    height: 40px;
  }
  .file-msg {
    flex-grow: 1;
    display: flex;
    flex-direction: column;
    margin-left: 14px;
    .file-name {
      font-size: 16px;
      line-height: 22px;
      width: 86%;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }
    .file-info {
      font-size: 12px;
      line-height: 18px;
      color: #9B9B9B;
    }
  }
}
.border-bottom {
  &:after {
    z-index: 1;
  }
}
.menu {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 16px;
  background-color: #fff;
  padding: 15px 14px 13px;
  margin: 10px 0;
  .title {
    color: #858585;
  }
  .cnt {
    img {
      margin-left: 11px;
      width: 7.5px;
      height: 13px;
    }
  }
}
</style>
