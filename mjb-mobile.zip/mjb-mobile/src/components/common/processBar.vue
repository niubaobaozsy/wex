<!--
  describe：“流程导航条” 组件
  created by：Yim Lee
  date：2017-11-14
  使用说明：
    1. 需要从父组件传回来的参数： process数组（所有流程的文字案）、 currentStep（当前页面流程数，第一个流程则为1，以此类推）
    2. 提供一个点击事件，使用该点击事件可编辑控制流程导航条的路由跳转
    3. 使用方法可参考addTravelRoute.vue
-->
<template>
  <div class="process-wrap">
    <ul class="process columns is-mobile">
      <li v-for="(item, index) in process" :key="index" class="column" @click="goRouter(index)">
        <div :class="['line', {'green-background': index <= currentStep, 'grey-background': index > currentStep}]" v-if="index"></div>
        <img src="../../assets/images/fee/myApply/true.png" v-if="index < currentStep">
        <span :class="['number', {'orange-background': index === currentStep, 'grey-background': index > currentStep }]" v-if="index >= currentStep">{{index+1}}</span>
        <span class="title" :class="[{'black-font': index <= currentStep, 'grey-font': index > currentStep}]">{{item}}</span>
      </li>
    </ul>
  </div>
</template>

<script type="es6">
export default {
  data() {
    return {}
  },
  props: {
    process: Array, // 所有流程导航的文字描述
    currentStep: Number,  // 当前是第几步，第一步为0
  },
  methods: {
    // 点击流程导航跳转相应的路由
    goRouter(index) {
      this.$emit('on-click', index);
    },
  },
};
</script>
<style  lang="less" scoped>
ul,
li {
  list-style: none;
}

.orange-background {
  background: #FCB23C;
}

.grey-background {
  background: #E6E6E6;
}

.green-background {
  background: #6CC60A;
}

.black-font {
  color: #666666;
}

.grey-font {
  color: #C3C3C3;
}

.process-wrap {
  background: #FFFFFF;
  .process {
    margin: 0px auto;
    li {
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      padding: 0 !important;
      margin: 14px 0px;
      .line {
        position: absolute;
        width: 100%;
        height: 2px;
        top: 12px;
        left: -50%;
      }
      .number,
      img {
        width: 24px;
        height: 24px;
        font-size: 12px;
        text-align: center;
        line-height: 24px;
        color: #FFFFFF;
        border-radius: 50%;
        z-index: 1;
      }
      .title {
        line-height: 18px;
        font-size: 12px;
        transform: scale(0.85);
        letter-spacing: 0.5px;
      }
    }
  }
}
</style>
