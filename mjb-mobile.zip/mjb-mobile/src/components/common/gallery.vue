<!--
	Author: zhuangyh
	Create: 2017-09-14
	props:
		show 是否显示该组件
		list 图片数组,
		index 当前点击图片索引,
		on-hide 组件关闭事件
  modified by: Yim Lee
  date: 2017-11-09
-->
<template>
  <!-- Root element of PhotoSwipe. Must have class pswp. -->
  <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
    <!-- Background of PhotoSwipe.
                  It's a separate element as animating opacity is faster than rgba(). -->
    <div class="pswp__bg"></div>
    <!-- Slides wrapper with overflow:hidden. -->
    <div class="pswp__scroll-wrap">
      <!-- Container that holds slides.
                      PhotoSwipe keeps only 3 of them in the DOM to save memory.
                      Don't modify these 3 pswp__item elements, data is added later on. -->
      <div class="pswp__container">
        <div class="pswp__item"></div>
        <div class="pswp__item"></div>
        <div class="pswp__item"></div>
      </div>
      <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
      <div class="pswp__ui pswp__ui--hidden">
        <div class="pswp__top-bar">
          <!--  Controls are self-explanatory. Order can be changed. -->
          <div class="pswp__counter"></div>
          <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>
          <button class="pswp__button pswp__button--share" title="Share"></button>
          <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>
          <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
          <!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
          <!-- element will get class pswp__preloader--active when preloader is running -->
          <div class="pswp__del" v-if="hasDel">
            <button class="pswp__button pswp__button--delete" title="del" @touchend="del"></button>
          </div>
          <div class="pswp__preloader">
            <div class="pswp__preloader__icn">
              <div class="pswp__preloader__cut">
                <div class="pswp__preloader__donut"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
          <div class="pswp__share-tooltip"></div>
        </div>
        <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
        </button>
        <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
        </button>
        <div class="pswp__caption">
          <div class="pswp__caption__center"></div>
        </div>
        <button class="pswp__button pswp__button--download" title="download" @touchend="download"></button>
      </div>
    </div>
  </div>
</template>
<script type="es6">
import PhotoSwipe from 'photoswipe/dist/photoswipe'
import UI from 'photoswipe/dist/photoswipe-ui-default'
import 'photoswipe/dist/photoswipe.css'
import 'photoswipe/dist/default-skin/default-skin.css'
export default {
  data() {
    return {
      gallery: {}
    }
  },
  props: {
    show: {
      type: Boolean,
      default: false
    },
    list: {
      type: Array,
      default: []
    },
    index: {
      type: Number,
      default: 0
    },
    hasDel: {
      type: Boolean,
      default: true
    }
  },
  methods: {
    openPhotoSwipe() {
      const that = this;
      const options = {
        index: this.index,
        galleryUID: 1,
        maxSpreadZoom: 5,
        zoomEl: true,
        shareEl: false,
        fullscreenEl: false,
        getThumbBoundsFn: function(index) {
          console.log('传参格式', that.list);
          var pageYScroll = window.pageYOffset || document.documentElement.scrollTop,
            rect = that.list[index].el.getBoundingClientRect();
          return { x: rect.left, y: rect.top + pageYScroll, w: rect.width };
        }
      };
      this.gallery = new PhotoSwipe(this.$el, UI, this.list, options);

      this.gallery.listen('close', () => {
        this.$emit("on-hide");
      });
      this.gallery.init();
    },
    del() {
      console.log("delete image");
      let curIndex = this.gallery.getCurrentIndex();
      let leftImgNum = this.gallery.items.length - 1;
      this.$emit("on-del", curIndex);
      if (leftImgNum <= 0) {
        this.gallery.close();
      } else {
        // this.nextTick(() => {
          this.gallery.items.splice(curIndex, 1);
          if (curIndex == leftImgNum) {
            this.gallery.goTo(0);
          }
          this.gallery.invalidateCurrItems();
          this.gallery.updateSize(true);
          console.log("当前index：" + curIndex);
        // })
      }
    },
    download() {
      this.$emit('download');
    },
  },
  watch: {
    show(val) {
      console.log("show change");
      if (val) {
        console.log('this.list', this.list);
        this.openPhotoSwipe();
      }
    }
  }
}
</script>

<style lang="less">
    .pswp__top-bar {
      // margin-top: 15px !important;
      margin-top: 0px !important;
    }
    .pswp__button--delete {
      background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAB80lEQVR4Xu2Y4VHDMAyF35sANoANOCYANoAN2ACYgLIBbAATwAaUDRihnaDHBOJUSC+YuMldK9WN5Z9OGluf3pPsEpUPVh4/AkAooHICYYHKBRBFMCwQFqicQFigcgFEFwgLhAUqJxAWqFwA0QXCAt4WEJEpgLPMuh8kzz335K6AqgCIyDWAoySjOnecyfIMwHPybE4ynduaSEwV0JPtoUGY2sIawLpsDwUw21sFDI1wl++ZKkADExHZJECSpns0/XgA+FHAJ4CTtLIn3eELwEGHUrQD5DrGJsJa/dZDAe2Dz7Kii4gedt5bEayd30qkmY+UAuCJ5G0OzL4DeARw8xtEk+lDAItWYA8kJyIyAXDfmn8hqa3UbHgo4E9QTVVPukMOwHLeLHrA/jqcZjUD4Irkm4i01aJxjwLAJYDXJostAO3ucEFy2nF0viOpUMyGhwXSit8VbA7Act4seicL9ALIqELjHgWAtOI3fl8Vx0xdUACnJNUqZsPcAh3H4X8VPwfA+h6ge9sFgMHZHBOArvtAHwjze4CnArQVqufTS1EOwlzft/wjZNWW+9Iw9ucuNaBkiAGg5Ox47C0U4EG55DVCASVnx2NvoQAPyiWvEQooOTseewsFeFAueY1QQMnZ8dhbKMCDcslrhAJKzo7H3qpXwDcrAshBVPaxUQAAAABJRU5ErkJggg==) 0 0 no-repeat !important;
      background-size: contain !important;
      right: 3px;
    }
    .pswp__counter {
      margin-left: 45%;
    }
    .pswp__button--close {
      position: absolute !important;
      background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAiCAYAAAAtZZsLAAAAAXNSR0IArs4c6QAAASBJREFUWAntlsFqwkAQhiP00KO9FITC+hiC5+Kz9CwevfsC+hh6K+Kpj1B8gX0CJb206iV+EQaWIGXJZJsGZuAjs8nOzJ8/e0iWKaIoimeYwVjRJk0pohx4KOMb+mkm1eiKGAceJA4kjzVaNV+CEAceJH5IJs1PqtERIQ48SJi4KB+xy4EHCXPOnItyoO4mDpoDDxJ25qLMxC4HHiTMuc4798C3fOEtPmAIEguSL56N5EYL1wsz9z1E7EheWxAQM/K9FHhk51PM7hb25KXANwavKsM/WZ8q9/56eWbg8jYUkXMIY8vif/yAii0IMpFihupqTqrsC4rNycAMVWpOquwLis3JwAxV2lUn16q3TlF8x8lBijmqnoicQg4bVaNfiq9tW5F/96ckxQAAAABJRU5ErkJggg==) 12px 14px no-repeat !important;
      background-size: 20px 16.8px !important;
      left: 3px;
    }
    .pswp__button--download {
      position: absolute !important;
      background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAABuUlEQVRYR+2Y4U3DMBSE7yYANmAD2KBlAzYAJqBMABvACGWETgDdACagI7DBoZPcyg1JnNhWVVD8s42fv3fxu2eHOPLBI+dDNUBJtwAuSD7UTLom4DuAGclqMZ1otWCSJsCirTMpWCQfgEnBScFMBSYfzBRuN+1vKyhpDmBDcpNSYozNSDoNfXuVituroCQB+AZwRfKjL9hQwAD3BuAyxHUP7xwpwBcA90MghwA24D5JGrJ3JPegpCWAmxRkCrAJB2BO0m+nDNCzh0D2AebCjToPpiC7AEvgRgGmlGwDLIUbDdgH2QSsAZcF2AUZA9aCywZsgwRgS5oBOAOw9bnPodXaVcpJm0mYc2xBtoxzADZ0+1sx3C8FJfnauE55U/x/VN3xz6PhJDkpt9U9b9wpKGkB4HlI+2km0IAcDRe2jNvqiuR1HD8GfALwmAMYFvB8v+LFkA7RkqQB1yR9QNmNaoBjtkXbs+FgMgFmC/mvFLwjaX872JDk4vpKFcnWZmy07grJY36lDHz899qu3leS/s7YWsV+0FAnlRbOCeOrxd4VYK/VhSbvDAx76LFsu5wV9eJDZDABlqr8A1XmQzhVc0kNAAAAAElFTkSuQmCC) 12px 14px no-repeat !important;
      background-size: 20px 19px !important;
      bottom: 16px;
      right: 27px;
    }
</style>
