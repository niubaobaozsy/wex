<!--
  describe： View pdf document
  created by：Zhuangyh
  date：2018-02-28
-->
<template>
<div v-if="show">
  <my-header title="附件预览" :showBack="true" @previous="goBack" cusStyle="background-color: #000;"></my-header>
  <div class="pdf-container" @touchstart.prevent="onTouchstart" @touchend.prevent="onTouchend">
    <div class="pdf">
      <div class="pdf-toolbox" v-if="pageCount">{{currentPage}} / {{pageCount}}</div>
      <pdf
        :src="src"
        :page="parseInt(currentPage)"
        @num-pages="pageCount = $event"
        @page-loaded="onPageLoaded"
      ></pdf>
    </div>
	</div>
</div>
</template>

<script>

import pdf from 'vue-pdf';
import myHeader from './header';

export default {
	components: {
    pdf,
    myHeader,
  },
  props: {
    show: {
      type: Boolean,
      required: true,
      default: false,
    },
    src: {
      type: String,
      required: true,
    }
  },
	data() {
		return {
      currentPage: 1,
      pageCount: 0,
      touch: {
        start: 0,
        end: 0,
      },
    };
  },
  methods: {
    goBack() {
      this.$emit('update:show', false);
      console.log('goBack');
    },
    onTouchstart(e) {
      this.touch.end = 0;
      this.touch.start = e.changedTouches[0] ? e.changedTouches[0].clientX : 0;
      console.log(this.touch.start);
    },
    onTouchend(e) {
      this.touch.end = e.changedTouches[0] ? e.changedTouches[0].clientX : 0;
      console.log(this.touch.end);
      if (this.touch.start - this.touch.end > 50) {
        if (this.currentPage < this.pageCount) {
          this.currentPage ++;
          this.showLoading();
        } else {
          this.showToast({ msg: '已是最后一页' });
        }
      } else if (this.touch.end - this.touch.start > 50) {
        if (this.currentPage > 1) {
          this.currentPage --;
          this.showLoading();
        } else {
          this.showToast({ msg: '已是第一页' });
        }
      }
    },
    onPageLoaded(e) {
      this.currentPage = e;
      this.hideLoading();
    },
  },
  watch: {
    show(nVal) {
      if (nVal) this.showLoading();
    },
  },
};

</script>

<style lang="less" scoped>
.pdf-container {
  position: absolute;
  z-index: 90;
  width: 100%;
  background-color: #000;
  top: 0;
  bottom: 0;
  .pdf {
    position: absolute;
    width: 100%;
    top: 50%;
    transform: translateY(-50%);
    .pdf-toolbox {
      margin-bottom: 10px;
      color: #fff;
      font-size: 14px;
      text-align: center;
    }
  }
}
</style>
