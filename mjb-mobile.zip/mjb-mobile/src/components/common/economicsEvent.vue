<!--
  describe：经济事项组件
  created by：欧倩伶
  date：2017-11-10
-->
<template>
  <div class="economics-event" v-if="show">
    <my-header :title="top.title" :showBack="true" :showRedDot="true" @previous="hide" v-show="!onSearch"></my-header>
    <div class="searchHeader" v-if="onSearch">
      <div class="search">
        <i class="iconfont icon-qietu03"></i>
        <input type="text" placeholder="搜索经济事项" v-model="search" v-focus>
      </div>
      <span class="cancel" @click="searchCancel">取消</span>
    </div>
    <div :class="['list', {'has-header': !onSearch}]">
      <div class="search-wrap" @click="handleSearch" v-show="!onSearch">
        <div class="search">
          <i class="iconfont icon-qietu03"></i>
          <input type="text" placeholder="搜索经济事项" />
        </div>
      </div>
      <div class="content" @touchmove.stop v-if="!onSearch">
        <div v-for="user in eventsList" :key="user.user_id" class="user" @click="onSelected(user)">
          <div class="row border-top">{{user.fee_type_name}}</div>
        </div>
      </div>
      <div class="contentSearch" @touchmove.stop v-if="onSearch">
        <div v-for="user in searchRes" :key="user.user_id" class="user" @click="onSelected(user)">
          <div class="row border-top">{{user.fee_type_name}}</div>
        </div>
        <div class="tipMsg has-header" v-if="searchEnd && !searchRes.length">暂无数据…</div>
      </div>
    </div>
  </div>
</template>
<script>
import MyHeader from './header';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {
      // style: '',
      top: {
        title: '选择经济事项',
      },
      eventsList: [],
      onSearch: false,
      search: '',
      searchRes: [],
      timer: null,
      searchEnd: false,
    };
  },
  props: {
    show: Boolean,
    id: String,
  },
  methods: {
    // 获取费用类型列表
    getFeeTypeList() {
      this.showLoading();
      const params = {
        fee_type_name: '',
        busi_org_id: this.id,
        page_number: 1,
        page_size: 1000,
      };
      this.$store.dispatch('getReimEconomicsEvent', params)
        .then((rep) => {
          this.hideLoading();
          if (rep.code === '0000') {
            this.eventsList = rep.data.info;
            if (!rep.data.info) {
              this.showToast({ msg: '该预算部门下无可用费用类型，请重新选择预算部门!' });
            }
          } else {
            this.showToast({ msg: rep.msg });
          }
        }, () => {
          this.hideLoading();
          this.showToast({ msg: '页面开小差，请重试' });
        });
    },
    hide() {
      this.$emit('on-hide');
    },
    // 选择费用类型
    onSelected(item) {
      this.$emit('on-select', item);
    },
    init() {
      // this.style.height = `${window.screen.height - 50}px`;
      // this.style.overflow = 'auto';
      console.log('jdkjasjdisad');
    },
    debounce(action, delay) {
      return (() => {
        if (this.timer) clearTimeout(this.timer);
        this.timer = setTimeout(() => {
          action.apply(this);
        }, delay);
      })();
    },
    searchEconomicsEvent() {
      this.debounce(() => {
        this.showLoading();
        console.log(this.search, 'search');
        const params = {
          fee_type_name: this.search,
          busi_org_id: this.id,
          page_number: 1,
          page_size: 1000,
        };
        this.$store.dispatch('getReimEconomicsEvent', params)
          .then((res) => {
            this.hideLoading();
            if (res && res.code === '0000') {
              this.searchRes = res.data.info.filter(item => item.fee_type_name.indexOf(this.search) !== -1);
              this.searchEnd = true;
            } else if (res && res.code) {
              this.showToast({ msg: `请求异常(${res.code})` });
            }
          });
      }, 500);
    },
    handleSearch() {
      this.onSearch = true;
      // this.style.height = `${window.screen.height - 56}px`;
    },
    searchCancel() {
      this.onSearch = false;
      // this.style.height = `${window.screen.height - 156}px`;
      if (this.$refs.eventsList) this.$refs.eventsList.scrollLeft = this.$refs.eventsList.scrollWidth;
      this.search = '';
      this.searchRes = [];
    },
  },
  watch: {
    search(newVal) {
      if (newVal) {
        this.searchEconomicsEvent();
        console.log(this.searchRes, 'searchRes');
      }
    },
    show() {
      this.searchEnd = false;
      this.onSearch = false;
      this.search = '';
      this.searchRes = [];
      // this.style.height = `${window.screen.height - 156}px`;
    },
  },
  mounted() {
    this.init();
    console.log('search tttt');
  },
};
</script>
<style lang="less" scoped>
@searchBoxHeight: 32px;

.searchHeader {
  display: flex;
  background-color: #484759;
  .search {
    flex-grow: 1;
    margin: 10px 0 10px 10px;
  }
  .cancel {
    padding: 14px;
    font-size: 16px;
    color: #fff;
  }
}
.search-wrap {
  padding: 10px;
  background-color: #fff;
}
.search {
  position: relative;
  height: @searchBoxHeight;
  color: #7F8389;
  padding: 0 @searchBoxHeight/2 0 40px;
  line-height: @searchBoxHeight;
  border-radius: @searchBoxHeight/2;
  background-color: #F4F4F4;
  i {
    position: absolute;
    top: 0;
    left: 0;
    padding: 3px 15px 0;
  }
  input {
    width: 100%;
    height: @searchBoxHeight - 5px;
    font-size: 13px;
    outline: none;
    border: 0px;
    background-color: #F4F4F4;
  }
}
.economics-event {
  position: fixed;
  top: 0;
  bottom: 0;
  z-index: 100;
  width: 100%;
  // height: 100%;
  background: #F4F4F4;
}
.content {
  position: fixed;
  top: 98px;
  bottom: 0;
  left: 0;
  right: 0;
  overflow: auto;
  // background: #fff;
  .row {
    height: 50px;
    padding: 14px 15px;
    box-sizing: border-box;
    line-height: 22px;
    background: #fff;
  }
}
.contentSearch {
  position: fixed;
  top: 50px;
  bottom: 0;
  left: 0;
  right: 0;
  overflow: auto;
  // background: #fff;
  .row {
    height: 50px;
    padding: 14px 15px;
    box-sizing: border-box;
    line-height: 22px;
    background: #fff;
  }
}
.tipMsg {
  margin-top: 65px;
  text-align: center;
  color: #cecece;
  padding: auto;
}
</style>
