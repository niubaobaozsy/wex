<script>
import back from '../../assets/images/common/nav_back.png';
import scan from '../../assets/images/common/nav_scan.png';
import message from '../../assets/images/common/nav_message.png';

function default4leftPart(createElement) {
  return createElement('img', {
    attrs: {
      src: back
    }
  })
}

function default4rightPart(createElement, imgSrc) {
  return createElement('img', {
    attrs: {
      src: scan
    }
  })
}

export default {
  render (createElement) {
      return createElement('div', {
        class: ['flex-row', this.$style.header]
      }, this.generateChildren(createElement));
  },
  props: {
    titleText: {
      type: String,
      default: ''
    }
  },
  computed: {
    hasStep() {
      return this.stepTotal;
    },
  },
  data() {
    return {
      top: {
        iconBack: back,
        iconScan: scan,
        iconMessage: message,
      },
    };
  },
  methods: {
    back() {
      this.$emit('previous');
    },
    onClick() {
      this.$emit('on-click');
    },
    scan() {
      this.$emit('scan');
    },
    message() {
      this.$emit('message');
    },
    // lym: didi点击打开设置选择
    showChoice() {
      this.$emit('showChoice');
    },
    generateChildren(createElement) {
      return [
        createElement('div', {
          class: [this.$style.left, 'text-left']
        }, [this.$slots.left || default4leftPart]),

        createElement('div', {
          class: ['titleText', 'rest-area', 'text-center']
        }, [this.$slots.title || this.titleText]),

        createElement('div', {
          class: [this.$style.right, 'text-right']
        }, this.$slots.right ? [this.$slots.right] : [])
      ];
    },
  },
};
</script>

<style lang="less" module>
.header {
  width: 100%;
  height: 46px;
  background-color: #484759;
  align-items: center;
  padding: 0 15px;
  box-sizing: border-box;
  color: #ffffff;
  flex-shrink: 0;
  .left, .right{
    width: 100px;
    line-height: 1;
  }
  .title {
    height: 100%;
    font-size: 18px;
    line-height: 46px;
    text-align: center;
    white-space: nowrap;
    line-height: 1;
  }
  .icon {
    width: 20px;
    position: relative;
    // top: 2px;
  }
}
</style>
