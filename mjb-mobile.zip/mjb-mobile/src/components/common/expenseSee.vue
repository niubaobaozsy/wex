<!--
  describe：费用预估
  created by：张绍武
  date：2017-11-11
-->
<template>
  <div class='subject' v-if='show'>
    <my-header :title='top.title' @previous="goBack"></my-header>
    <ul class='main has-header has-footer'>
      <!-- 交通 -->
      <li v-if="order.length" v-for='(item,index) in order[0]' :key="index">
        <div class='border-bottom border-top lidiv' @click="showTravel">
          <div>
            <img v-if="trclose" :src='showConp' class="img-show">
            <img v-if="!trclose" :src='hideConp' class="img-show">
            <section>交通({{item.from_area_name}} → {{item.to_area_name}})</section>
          </div>
          <section>合计: ￥{{travelFee[index].toFixed(2) || 0}}</section>
        </div>
        <div v-if="trclose" v-for='(feeItem,feeIndex) in item.trans' :key="feeIndex">
          <div>
            <span>工具</span>
            <section v-if="feeItem.transport === 'AIRPLANE'"><img :src='aircraft'>飞机</section>
            <section v-if="feeItem.transport === 'TAIX'"><img :src='car'>打的</section>
            <section v-if="feeItem.transport === 'BUS'"><img :src='car'>汽车</section>
            <section v-if="feeItem.transport === 'SHIP'"><img :src='ship'>轮船</section>
            <section v-if="feeItem.transport === 'TRAIN'"><img :src='train'>火车</section>
            <section v-if="feeItem.transport === 'DIDI'"><img :src='car'>滴滴打车</section>
          </div>
          <div class="right border-bottom">
            <span>金额:</span>
            <section>￥{{feeItem.transport_fee.toFixed(2)}}</section>
          </div>
        </div>
      </li>
      <!-- 住宿 -->
      <li>
        <div class='border-bottom border-top' @click="showRent">
          <div>
            <img v-if="rentClose" :src='showConp' class="img-show">
            <img v-if="!rentClose" :src='hideConp' class="img-show">
            <section>住宿</section>
          </div>
          <section>合计: ￥{{hotelFee.toFixed(2) || 0}}</section>
        </div>
        <div v-if="rentClose" v-for='(item,index) in order[2]' :key="index">
          <div>
            <span>住宿人</span>
            <section>{{item.travel_persons_name}}</section>
          </div>
          <div class="right">
            <span>住宿城市</span>
            <section>{{item.to_area_name}}</section>
          </div>
          <div class="data">
            <span>日期</span>
            <section>{{formatDate(item.start_date)}}-{{formatDate(item.end_date)}}</section>
          </div>
          <div class="right border-bottom">
            <span>住宿费用:</span>
            <section>￥{{item.rent_fee.toFixed(2)}}</section>
          </div>
        </div>
      </li>
      <!-- 补助 -->
      <li>
        <div class='border-bottom border-top' @click="showHelp">
          <div>
            <img v-if="heclose" :src='showConp' class="img-show">
            <img v-if="!heclose" :src='hideConp' class="img-show">
            <section>补助</section>
          </div>
          <section>合计: ￥{{subsidyFee.toFixed(2)}}</section>
        </div>
        <div v-if="heclose" v-for='(item,index) in order[3]' :key="index">
          <div>
            <span>补助人</span>
            <section>{{item.assistant_persons_name}}</section>
          </div>
          <div class="right">
            <span>城市</span>
            <section>{{item.to_area_name}}</section>
          </div>
          <div class="data">
            <span>日期</span>
            <section v-if="item.start_date">{{formatDate(item.start_date)}}-{{formatDate(item.end_date)}}</section>
          </div>
          <div v-if="item.standard_type_name" class="right">
            <span>补助类型</span>
            <section>{{ item.standard_type_name }}</section>
          </div>
          <div class="right border-bottom">
            <span>补助费用:</span>
            <section v-if="item.assistant_fee">￥{{item.assistant_fee.toFixed(2) || 0}}</section>
          </div>
        </div>
      </li>
      <!-- 其他 -->
      <li>
        <div class='border-bottom border-top' @click="showOther">
          <div>
            <img v-if="othclose" :src='showConp' class="img-show">
            <img v-if="!othclose" :src='hideConp' class="img-show">
            <section>其他费用</section>
          </div>
          <section>合计: ￥{{otherFee.toFixed(2) || 0}}</section>
        </div>
        <div v-if="othclose && item.other_fee" v-for='(item,index) in order[4]' :key="index">
          <div>
            <span>费用</span>
            <section>￥{{item.other_fee.toFixed(2)}}</section>
          </div>
          <div class="right border-bottom">
            <span>消费事由:</span>
            <section>{{item.sensitive_info}}</section>
          </div>
        </div>
      </li>
    </ul>
    <div class='bottom'>金额合计: <span class="totalSum">￥{{totalSum.toFixed(2)}}</span></div>
  </div>
</template>

<script>
import MyHeader from './header';
import rtarrow from '../../assets/rt-arrow.png';
import aircraft from '../../assets/images/fee/myApply/aircraft2x.png'; // 飞机
import car from '../../assets/images/fee/myApply/car2x.png'; // 汽车
import ship from '../../assets/images/fee/myApply/ship2x.png'; // 轮船
import train from '../../assets/images/fee/myApply/train2x.png'; // 火车
import hideConp from '../../assets/images/fee/approve/hideTravel.png';
import showConp from '../../assets/images/fee/approve/showTravel.png';

export default {
  components: {
    MyHeader,
  },
  props: {
    order: Array,
    show: Boolean,
  },
  data() {
    return {
      aircraft,
      car,
      ship,
      train,
      see: true,
      trclose: false,
      rentClose: false,
      heclose: false,
      othclose: false,
      vehicle: '',
      img: '',
      showConp,
      hideConp,
      rtarrow,
      top: {
        title: '费用预估',
      },
    };
  },
  methods: {
    showTravel() {
      this.trclose = !this.trclose;
    },
    showRent() {
      this.rentClose = !this.rentClose;
    },
    showHelp() {
      this.heclose = !this.heclose;
    },
    showOther() {
      this.othclose = !this.othclose;
    },
    formatDate(time) {
      if (!time) return null;
      const str = time.split(' ');
      const temp1 = str[0].substr(5, 2);
      const temp2 = str[0].substr(8, 2);
      return `${temp1}月${temp2}日`;
    },
    goBack() {
      this.$emit('on-hide');
    },
    arraySum(arr) {
      let sum = 0;
      arr.forEach((item) => {
        sum += parseFloat(item);
      });
      return sum;
    },
  },
  computed: {
    travelFee() {
      const travelSum = [];
      if (this.order[0]) {
        this.order[0].forEach((item) => {
          if (item.trans) { // 交通
            let travelItem = 0;
            item.trans.forEach((feeItem) => {
              travelItem += parseFloat(feeItem.transport_fee) ? parseFloat(feeItem.transport_fee) : 0;
            });
            travelSum.push(travelItem);
          }
        });
      }
      return travelSum;
    },
    hotelFee() { // 住宿
      let hotelSum = 0;
      if (this.order[2]) {
        this.order[2].forEach((item) => {
          hotelSum += parseFloat(item.rent_fee) ? parseFloat(item.rent_fee) : 0;
        });
      }
      return hotelSum;
    },
    subsidyFee() { // 补助
      let subsidySum = 0;
      if (this.order[3]) {
        this.order[3].forEach((item) => {
          subsidySum += parseFloat(item.assistant_fee) ? parseFloat(item.assistant_fee) : 0;
        });
      }
      return subsidySum;
    },
    otherFee() { // 其他
      let otherSum = 0;
      if (this.order[4]) {
        this.order[4].forEach((item) => {
          otherSum += parseFloat(item.other_fee) ? parseFloat(item.other_fee) : 0;
        });
      }
      return otherSum;
    },
    totalSum() {
      return parseFloat(this.arraySum(this.travelFee) + this.hotelFee
        + this.subsidyFee + this.otherFee);
    },
  },
};
</script>

<style lang='less' scoped>
.subject {
  width: 100%;
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  overflow-y:auto;
  background: #f2f2f2;
  z-index: 99999;
}

.main {
  font-size: 16px;
  margin-top: 56px;
  color: #000000;
  list-style: none;
  background: #f2f2f2;
  span{
      color:#858585;
      font-size:14px;
  }
  p {
    width: 0;
    height: 0;
    border-left: 6px solid transparent;
    border-right: 6px solid transparent;
    border-top: 7px solid #AFAFAF;
    margin-right: 6px;
  }
  li {
    margin-top: 10px;
    background: #ffffff;
    &.stop {
      height: 49px;
      overflow: hidden;
    }
    .lidiv{
      section{
        font-size:16px;
      }
    }
  }
  div:nth-child(1) {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 50px;
    padding: 0 15px;
    div {
      padding: 0;
      section{
        font-size:16px;
      }
    }
  }
}

img {
  width: 26px;
  height: 26px;
  margin-right: 12px;
}

.right {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 0 15px;
  height: 50px;
}

.has-footer {
  .bottom {
    width: 100%;
    height: 50px;
    line-height: 50px;
    margin-bottom: 0;
    background: #ffffff;
    color: #000000;
    box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
    position: fixed;
    bottom: 0;
    text-align: right;
    .totalSum {
      color: #3DA5FE;
      margin-right:15px;
    }
  }
}

.img-show {
  width: 7px;
  height: 6px;
}

.data {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 0 15px;
  height: 50px;
}
section{
  display: flex;
  align-items: center;
  font-size:14px;
}
</style>
