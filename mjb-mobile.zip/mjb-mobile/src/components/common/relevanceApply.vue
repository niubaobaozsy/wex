 <!--
  describe：关联申请人
  created by：周積坤
  date：2017-11-22
  data: 2017-12
  修改：黄喆
-->
<template>
  <div class="related-container" v-if="show">
    <my-header :title="top.title" :headerClass="top.headerTop" @previous="goBack" ></my-header>
    <div class="wrap">
      <div v-if="item.fee_apply_id" class="data-content" v-for="(item, index) in newList" :key="index" @click='clic(index)'>
          <div class="left">
            <div :class="['type', logoColor]">{{type}}</div>
          </div>
          <div class='right'>
            <div>
              <div>{{item.sensitive_info}}</div>
              <div class="data">{{item.fee_happened_date}}</div>
            </div>
            ￥{{ item.approve_reim_amount.toFixed(2)}}
          </div>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import myHeader from './header';

  export default {
    components: {
      myHeader,
    },
    created() {
      console.log(this.$route.query.type, 1111111111111111);
      if (this.$route.query.type === 'HW') {
        this.type = '会务';
      } else if (this.$route.query.type === 'CL') {
        this.type = '差旅';
        this.logoColor = 'blue';
      } else if (this.$route.query.type === 'TY') {
        this.type = '通用';
        this.logoColor = 'green';
      } else if (this.$route.query.type === 'CAR') {
        this.type = '用车';
      } else if (this.$route.query.type === 'LM') {
        this.type = '借款';
        this.logoColor = 'pink';
      }
    },
    data() {
      return {
        top: {
          title: '关联申请单',
        },
        type: '',
        logoColor: '',
      };
    },
    props: {
      show: Boolean,
      showList: Array,
    },
    computed: {
      newList() {
        const List = [];
        this.showList.forEach((data) => {
          if (data.fee_apply_id) {
            List.push(data);
          }
        });
        return List;
      },
    },
    methods: {
      goBack() { // 返回
        this.$emit('on-hide');
      },
      clic(index) {
        console.log(1111);
        console.log(this.newList);
        console.log(this.newList[index].fee_apply_id);
        this.$router.push({ path: '/fee/details', query: { id: this.newList[index].fee_apply_id } });
      },
    },
  };
</script>
<style lang="less" scoped>
@white:#ffffff;

  .related-container {
    width: 100%;
    height:100%;
    background-color: #F4F4F4;
    position: fixed;
    top:46px;
    left:0;
    bottom:0;
    z-index: 999999;
    overflow: auto;
    .wrap {
      background: @white;
      .data-content {
        display: flex;
          .left {
            padding:15px;
            .type{
              width: 40px;
              height: 40px;
              border-radius: 50%;
              color: @white;
              font-size: 12px;
              text-align: center;
              align-items: center;
              line-height: 40px;
              flex: none;
          }
          .green {
              background-color: #6CC60A;
            }
            .blue{
              background-color: #51AFFF;
            }
            .pink{
              background-color: #FF7F7F;
            }
        }
        .right {
          padding: 12px 15px 12px 0;
          display: flex;
          font-size: 16px;
          justify-content: space-between;
          border-bottom: 0.5px solid #DEDFE0;
          align-items: center;
          flex:1;
          .data {
            color:#9B9B9B;
            font-size:14px;
          }
        }
    }
  }
}
</style>
