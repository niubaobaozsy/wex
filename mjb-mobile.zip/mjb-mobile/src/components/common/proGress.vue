<!--
  describe：审批进度
  created by：张绍武
  date：2017-11-11
-->
<template>
  <div class="has-main">
    <div class="title unapproved" v-for="(item,index) in logs" :key="index">
      <div class="img three"></div>
      <div class="left">
        <p class="name">{{item.fdFactNodeName}}-{{item.fdHandlerName}}</p>
        <p class="opinion">意见: {{item.fdAuditNote}}</p>
        <p class="opinion">{{item.fdHandleDate}}</p>
      </div>
      <div class="right">
        {{ item.fdActionKey }}
      </div>
    </div>
    <div v-if="newList.length">
      <div class="title" v-for="(item,index) in newList" :key="index" :class="{'approval' : item.current}">
        <div class="img" :class="{'two' : item.current, 'three' : !item.current}">
          <p :class="{'img two_' : item.current}"></p>
        </div>
        <div class="left">
          <p class="name">{{item.fdNodeName}}-{{item.fdNodeHandlerNames}}</p>
        </div>
        <div class="right">{{item.fdProessType}}</div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    title: Array,
    list: Array,
    current:String,
  },
  computed: {
    newList() {
      let List = [];
      this.list.forEach((data, index, arr) => {
        if (data.current) {
          if(data.fdNodeHandlerNames !== this.current){
            data.fdNodeHandlerNames = this.current;
          }
          List = this.list.slice(index, arr.length);
        }
      });
      return List;
    },
    logs() {
      return this.title.filter(log => (log.fdActionKey.indexOf('走分支') === -1 && log.fdActionKey.indexOf('处理人为空') === -1));
    },
  },
  watch: {
    title(val) {
      console.log('1111111', val);
    },
  },
  methods: {
  },
  mounted() {
  },
};
</script>
<style lang='less' scoped>
.has-main {
  font-size: 16px;
  line-height: 16px;
  background: #ffffff;
  margin-top: 0;
  padding-bottom: 20px;
  .title {
    padding-top: 20px;
    color: #C3C3C3;
    display: flex;
    justify-content: space-between;
    margin-left: 18px;
    border-left: 1px solid #cbcfd6;
    &.approval {
      color: #FCB23C!important;
    }
    &.unapproved {
      color: #666666!important;
    }
    .img {
      position: relative;
      width: 12px;
      height: 12px;
      position: absolute;
      left: 11.5px;
      border: 1px solid #9B9B9B;
      margin-top: 3px;
      box-sizing: border-box;
      &.one {
        border-radius: 12px;
        background: #9B9B9B;
      }
      &.two {
        border-radius: 100%;
        border: 1px solid #FCB23C;
      }
      &.three {
        border: 1px solid #C3C3C3;
        border-radius: 12px;
        background: #ffffff;
      }
      &.two_ {
        border: 0;
        background: #FCB23C;
        width: 11px;
        height: 11px;
        border-radius: 100%;
        position: absolute;
        margin-top: -1px;
        left: -1px;
      }
    }
    .left {
      padding-bottom: 0px;
      font-size: 12px;
      flex: 0.7;
      margin-left: 18px;
      .name {
        font-size: 16px;
        line-height: 20px;
      }
      .opinion {
        margin-top: 10px;
        font-size: 12px;
      }
      p {
        margin-top: 0px;
        line-height: 18px;
      }
    }
    .left-second {
      position: absolute;
      left: 18px;
      padding-top: 80px;
      margin-left: 18px;
      font-size: 12px;
      line-height: 12px;
      flex: 0.7;
      p {
        margin-top: 0px;
        margin-bottom: 20px;
        line-height: 22px;
      }
    }
    .right {
      display: flex;
      padding-top: 0px;
      flex: 0.5;
      margin-right: 14px; // text-align: right;
      justify-content: flex-end;
      font-size: 16px;
      line-height: 20px; // span {
      //   // text-align: right;
      //   font-size: 16px;
      //   line-height: 16px;
      // }
    }
  }
  .clear {
    clear: both;
  }
}
</style>

