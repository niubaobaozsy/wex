<!--
  describe：关联申请单组件
  created by：黄喆
  date：2017-11-30
  noClick: 列表是否可以点击
-->
<template>
  <div class="related-container" v-if="show || applyArr.length">
    <my-header :title="top.title" :headerClass="top.headerTop" @previous="goBack" :rightItem="top.rightTitle"  @on-click="saveDraft"></my-header>
    <div v-if="isloading || !datalist" class="emptyBox">
      <img class="no-data-img" src="../../assets/images/common/no_data.png" alt="">
      <p class="no-data-text">暂无数据</p>
    </div>
    <div class="wrap">
      <div class="data-content">
        <div v-for="(item, index) in datalist" :key="index" class="data-list border-bottom" @click="details(item.fee_apply_id)">
          <div class="left">
            <img :src="emsecfeebudgets.indexOf(item.fee_apply_id) !== -1 ? select_active : seselect" alt="" class="nochoices" @click.stop="choice(item.fee_apply_id)">
            <div :class="['type', {'blue': item.order_type !== 'TY'}]">{{item.order_type === 'TY' ? '通用' : '差旅'}}</div>
            <div>
              <div>{{item.sensitive_info}}</div>
              <div class="date">{{item.apply_date}}</div>
            </div>
          </div>
          <div class='right'>
            ￥{{ item.approve_amount.toFixed(2) }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import myHeader from './header';
  import seselect from '../../assets/images/fee/myReimburse/select.png';
  import selectActive from '../../assets/images/fee/myReimburse/select_active.png';

  export default {
    name: 'relatedapply',
    components: {
      myHeader,
    },
    data() {
      return {
        top: {
          title: '差旅申请',
          rightTitle: '确定',
        },
        types: '差旅',
        typesColorLm: false,
        emsecfeebudgets: [],
        datalist: [],
        seselect,
        select_active: selectActive,
        isloading: false,
      };
    },
    watch: {
      show(newVal) {
        if (newVal) {
          this.getAvaliableFeeApply();
          this.emsecfeebudgets = this.emsecfeebudgets.concat(this.list);
          console.log(998179, this.emsecfeebudgets);
        }
      },
    },
    computed: {
      applyArr() {
        return this.$store.state.common.applyArr;
      },
    },
    created() {
    },
    props: {
      show: {
        type: Boolean,
        required: true,
        default: false,
      },
      noClick: {
        type: Boolean,
        default: true,
      },
      list: {
        type: Array,
      },
      only: {
        type: String,
      },
      type: {
        type: String,
        required: false,
        default: 'CL',
      },
    },
    methods: {
      goBack() { // 返回
        this.$emit('on-hide');
        this.emsecfeebudgets = [];
        this.$store.commit('APPLY_ARR', []);
      },
//      获取列表
      getAvaliableFeeApply() {
        const params = {
          query_param: {
            page_size: 100,
            page_number: 1,
            fee_apply_code: 'EA17',
            order_type: this.type,
          },
        };
        this.showLoading();
        this.$store.dispatch('getAvaliableFeeApply', params)
          .then((rep) => {
            this.hideLoading();
            if (rep && rep.code === '0000') {
              this.datalist = rep.data.info;
              this.$emit('getDatalistid', this.datalist);
            } else if (rep && rep.code) {
              this.showToast({ msg: `请求异常(${rep.code})` });
            }
          });
      },
      saveDraft() {
        const emsecfeebudgets = [];
        console.log(emsecfeebudgets);
        if (this.datalist) {
          this.datalist.forEach((item) => {
            this.emsecfeebudgets.forEach((id) => {
              if (item.fee_apply_id === id) {
                emsecfeebudgets.push(item);
              }
            });
          });
        }
        this.$emit('getDatalist', emsecfeebudgets);
        this.$emit('update:show', false);
        this.$emit('count', false);
        this.$store.commit('APPLY_ARR', []);
      },
      details() {
        const applyArr = this.emsecfeebudgets;
        this.$store.commit('APPLY_ARR', applyArr);
      },
      choice(item) {
        if (this.only !== 'only') {
          const newindex = this.emsecfeebudgets.indexOf(item);
          if (newindex === -1) {
            this.emsecfeebudgets.push(item);
          } else {
            this.emsecfeebudgets.splice(newindex, 1);
          }
        } else {
          this.emsecfeebudgets = [];
          this.emsecfeebudgets.push(item);
        }
      },
    },
  };
</script>
<style lang="less" scoped>
  @white:#ffffff;

  .related-container {
    position: fixed;
    top: 0;
    z-index: 100;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: #F4F4F4;
    .wrap {
      margin-top: 57px;
      background: @white;
      .data-content {
        .data-list {
          display: flex;
          justify-content: space-between;
          padding: 11px 15px 11px 11px;
          .left {
            display: flex;
            justify-content: flex-start;
            .nochoices {
              width: 18px;
              height: 18px;
              margin: -14px 0px -14px -15px;
              padding: 26px 20px 23px 24px;
            }
            .type{
              width: 40px;
              height: 40px;
              border-radius: 50%;
              color: @white;
              font-size: 12px;
              text-align: center;
              align-items: center;
              line-height: 40px;
              margin-right: 14px;
              flex: none;
              background-color: #6CC60A;
              &.blue {
               background-color: #51AFFF;
              }
              &.lm {
                background: #FF7F7F;
              }
            }
            .date {
              font-size: 14px;
              line-height: 20px;
              color: #9B9B9B;
            }
          }
          .right {
            font-size: 16px;
            color: #000000;
          }
        }
      }
      .details-content {
        .details-list {
          display: flex;
          justify-content: flex-start;
          padding: 10px 10px;
        }
        .details-left {
          width: 85px;
          color: #9B9B9B;
        }
      }
    }
  }
  .emptyBox{
    text-align: center;
    .no-data-img {
      display: block;
      margin: 20% auto 10px;
      width: 50%;
    }
    .no-data-text {
      color: #6e7481;
    }
    .createOrderBtn{
      display: inline-block;
      margin-top:27px;
      background-color: #3DA5FE;
      color: #ffffff;
      border-radius: 40px;
      padding:10px 35px;
      font-size: 16px;
      line-height: 22px;
    }
  }
</style>

