<!--
  describe："搜索城市" 页面（差旅）
  created by：Yim Lee
  date：2017-11-14
-->
<template>
    <div :class="['result-list', {'border': filteredCities.length}, {'whiteBack': filteredCities.length, 'greyBack': !filteredCities.length}]">
      <div class="result" v-for="(list, index) in filteredCities" :key="index" v-show="filteredCities.length">
        <span :class="[{'border-top': index !== 0}]" @click="selectCity(list)">{{ list.area_name || list.name || list.text }}</span>
      </div>
      <div class="no-result" v-show="!filteredCities.length">
        <span>暂无结果，换个关键字试试</span>
      </div>
    </div>
</template>

<script type="es6">

export default {
  props: {
    dataType: {
      type: String,
      require: true,
      default: 'travel'
    },
    searchText: {
      type: String,
      require: true,
      default: ''
    },
    showSearch: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  data() {
    return {

    };
  },
  computed: {
    filteredCities() {
      if (!this.searchText) return [];
      let arr = [];
      this.$store.state.common.views.cityList.forEach((collection4cities) => {
        if (collection4cities.cities) {
          collection4cities.cities.forEach((item) => {
            if ((item.text && item.text.indexOf(this.searchText) > -1) || (item.name && item.name.indexOf(this.searchText) > -1) || (item.area_name && item.area_name.indexOf(this.searchText) > -1 && item.region_type_code === '3')) {
              arr.push(item);
            }
          });
        }
      });

      return arr;
    }
  },
  methods: {
    // 点击城市名选择城市
    selectCity(item) {
      this.$emit('selec-city', item);
      this.$emit('update:showSearch', false);
    }
  }
};
</script>
<style lang="less" scoped>
.columns {
  margin-bottom: 0 !important;
}

.whiteBack {
  background: #FFFFFF;
}

.greyBack {
  background: #F4F4F4;
}

.result-list {
    position: fixed;
    top: 53px;
    min-height: 100vh;
    bottom: 0;
    width: 100%;
    overflow: auto;
    z-index: 100;
    background: #F4F4F4;
    .result {
      padding-left: 14px;
      background: #FFFFFF;
      span {
        display: block;
        font-size: 16px;
        line-height: 46px;
      }
    }
    .no-result {
      display: block;
      margin: auto;
      padding-top: 20px;
      font-size: 14px;
      color: #858585;
      text-align: center;
    }
  }

</style>
