<!--
  describe：Tip in graph
  created by：Zhuangyh
  date：2017-10-23
-->
<template>
  <div class="tip-container" :class="{leftArrow: leftArrow, rightArrow: !leftArrow, hidden: !show}" :style="style" ref="container">
    <div class="item" v-for="(item, index) in tipContent" :key="index">
      <div class="title">{{item.title}}</div>
      <div class="content">{{item.content}}</div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      show: false,
      style: '',
      leftArrow: false,
      timer: 0,
      tipContent: [],
    };
  },
  props: {},
  watch: {},
  methods: {
    showTip(position, tipContent) {
      this.tipContent = tipContent;
      this.$nextTick(() => {
        const width = this.$refs.container.offsetWidth;
        const height = this.$refs.container.offsetHeight;
        let left = position.x - width - 20;
        if (left < 0) {
          this.leftArrow = true;
          left = position.x + 20;
        } else {
          this.leftArrow = false;
        }
        this.style = `left: ${left}px; top: ${position.y - (height / 2)}px`;
        this.show = true;
      });
      if (this.timer) clearTimeout(this.timer);
      this.timer = setTimeout(() => { this.show = false; }, 1500);
    },
  },
  mounted() {

  },
};
</script>

<style lang="less" scoped>
.tip-container {
  padding: 5px 10px;
  color: #fff;
  background-color: rgba(35, 65, 90, 0.76);
  box-shadow: 0 1px 2px 0;
  border-radius: 4px;
  .item {
    padding: 5px 0;
  }
  .title {
    font-size: 10px;
    color: #C3C3C3;
    line-height: 15px;
  }
  .content {
    font-size: 14px;
    line-height: 19px;
  }
}

.hidden {
  visibility: hidden;
}

.leftArrow:after,
.rightArrow:after {
  position: absolute;
  content: ' ';
  height: 0;
  width: 0;
  top: 50%;
  margin-top: -8px;
  border: solid transparent;
  border-width: 8px;
}

.leftArrow:after {
  left: -15px;
  border-right-color: rgba(35, 65, 90, 0.76);
}

.rightArrow:after {
  left: calc(~"100% - 1px");
  border-left-color: rgba(35, 65, 90, 0.76);
}
</style>
