<!--
  describe：飞机退改签规则
  created by：panjm2
  date：2018-08-02
-->
<template>
  <div class="planeChange" v-if="show">
    <my-header :title="top.title" :showBack="true"  @previous="hide"></my-header>
    <div class="has-header content">
      <div class="info">
        <span>舱位：{{ changeInfo[0].cabin }}</span>
      </div>
      <div class="info">
        <span>票面价：￥{{ changeInfo[0].ticketPrice }}（不含税）</span>
      </div>
      <div class="info">
        <span>规则明细：{{ changeInfo[0].refundChangeInfo }}</span>
      </div>

    </div>
  </div>
</template>
<script>
import { XTextarea } from 'vux';
import MyHeader from './header';

export default {
  components: {
    MyHeader,
    XTextarea,
  },
  props: {
    show: Boolean,
    changeInfo: {
      type: Array,
      required: true,
    }
  },
  data() {
    return {
      reason: '',
      top: {
        title: '退改签规则',
      },
    };
  },
  methods: {
    hide() {
      this.$emit('on-hide');
    },
  },
  computed: {

  },
  mounted() {
    console.log('展示', this.changeInfo);
  },
};
</script>
<style lang="less" scoped>
.planeChange {
  position: fixed;
  top: 0;
  z-index: 100;
  width: 100%;
  height: 100%;
  background: #ffffff;
  overflow:scroll;
  .content {
    margin-top: 70px;
    margin-bottom: 20px
  }
  .info {
    margin: 12px 20px 0 20px;
    font-size: 19px;
  }
}
</style>
