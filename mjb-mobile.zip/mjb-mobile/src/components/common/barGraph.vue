<!--
  describe：Bar Graph power by ECharts
  created by：Zhuangyh
  date：2017-10-21
-->
<template>
  <div class="container">
    <div ref="barGraph" class="bar-graph"></div>
    <graphTip ref="graphTip" class="graph-tip"></graphTip>
  </div>
</template>

<script>
import echarts from 'echarts/lib/echarts';
import graphTip from './graphTip';

require('echarts/lib/chart/bar');
require('echarts/lib/component/title');
require('echarts/lib/component/dataZoom');
require('echarts/lib/component/legend');

export default {
  components: {
    graphTip,
  },
  data() {
    return {
      barGraph: {},             // 当前对象下的一个图表对象
      option: {                 // 图表对象的设置参数
        animation:false,
        textStyle: {
          color: '#4B4B4B',
        },
        title: {
          text: '标题',          // 图表的主标题
          subtext: '',           // 图表的子标题
          textStyle: {           // 图表标题的字体样式
            color: '#666',
            fontSize: 10,
          },
          top: 30,               // 设置标题的位置
        },
        grid: {                  // 为直角坐标系内的绘图网格
          show: true,
          top: 80,
          right: 0,
          bottom: 50,
          borderWidth: 0,        // 不显示网格的边，只显示里面的网格
        },
        legend: {                // 图例，表述数据和图形的关联
          data: [],              // 图例数组，图例可能会有多个，直接放图例的名称
          // left: '42%',
          itemWidth: 10,         // 图例图形宽度
          itemHeight: 10,        // 图例图形高度
          selectedMode: false,   // 是否可勾选
        },
        tooltip: {},             // 气泡提示框，常用于展现更详细的数据
        xAxis: {                 // x轴 ，通常并默认为类目型
          type: 'category',      // x轴表示内容
          data: [],              // 存放x轴所有项的名称
          axisLine: {            // 坐标轴线
            lineStyle: {         // 线条样式
              color: '#DCDCDC',
            },
          },
          // splitLine: {
          //   show: false,
          // },
          axisLabel: {            // 坐标轴文本标签（坐标轴每一项的的名称）
            interval: 0,
            fontSize: 12,
            color: '#858585',
            formatter: (item) => { // 设置文本标签的格式
              if (item) {
                if (item.length > 3 && item.length < 7) {
                  return `${item.substr(0, 3)}\n${item.substr(3)}`;
                } else if (item.length > 7) {
                  return `${item.substr(0, 3)}\n${item.substr(3, 3)}…`;
                }
                return item;
              }
              return '';
            },
            lineHeight: 28,
            // width: 30,
            // showMaxLabel: true,
            // showMinLabel: true,
            // rotate: 45,
            // padding: -2,
          },
        },
        yAxis: {                 // y轴， 通常并默认为数值型
          axisLine: {
            lineStyle: {
              color: '#DCDCDC',
            },
            axisLabel: {
              color: '#858585',
              fontSize: 10,
              lineHeight: 10,
            },
          },
        },
        dataZoom: [             // 区域缩放控制器
          {
            type: 'inside',     // 内置控制缩放，slider表示有滑动块的
            zoomLock: true,     // 是否锁定选择区域（或叫做数据窗口）的大小。如果设置为 true 则锁定选择区域的大小，也就是说，只能平移，不能缩放。
            startValue: 0,      // 数据窗口范围的起始数值
            endValue: 4,        // 数据窗口范围的结束数值
            minValueSpan: 5,    // dataZoom的窗口大小的最小值（数据系列数）
            maxValueSpan: 5,    // dataZoom的窗口大小的最大值（数据系列数）
            xAxisIndex: 0,      // 指定控制窗口大小的轴，也可以是yAxisIndex，否则minValueSpan和maxValueSpan会无效
          },
        ],
        series: [{              // 数据系列数，一个图表可能包含多个系列，每一个系列可能包含多个数据
          name: '前景序列',      // 数据系列的前景部分（前景部分和背景部分的区别是颜色不一样，表示的数据不一样）
          type: 'bar',          // 柱状图
          data: [],             // 存放前景部分表示的数据和数据名称
          z: 1,                 // 相当于z-index,设置其显示在上面
          itemStyle: {
            normal: {           // 柱形默认颜色
              color: '#3DA5FE',
            },
            // emphasis: {
            //   color: '#3366FF',
            // },
          },
          barGap: '-100%',      // 柱间距离，默认为柱形宽度的30%，可设固定值
          barWidth: '33.33%',   // 柱形宽度
          tooltip: {
            show: false,
            trigger: 'none',    // 表示不使用默认的显示/隐藏触发规则
          },
        }, {
          name: '背景序列',
          type: 'bar',
          data: [],
          label: {             // 柱头文本标签
            normal: {
              show: true,
              position: 'top',
              formatter: params => `${params.data[2]}%`,
              color: '#3DA5FE',
              fontSize: 10,
              lineHeight: 12,
            },
          },
          z: 0,
          itemStyle: {
            normal: {
              color: '#EEEEEE',
            },
            emphasis: {        // 强调样式（鼠标悬浮时）
              color: '#EEEEEE',
            },
          },
          barWidth: '33.33%',
          tooltip: {
            show: false,
            trigger: 'none',
          },
        }],
      },
    };
  },
  props: {
    cusOpt: {},
  },
  methods: {
    drawBarGraph() {
      this.barGraph = echarts.init(this.$refs.barGraph);
      this.option.title.text = this.cusOpt.title;
      this.option.xAxis.data = this.cusOpt.xAxis;
      // this.option.xAxis.data.push('');
      const fgSeries = this.option.series[0];
      const bgSeries = this.option.series[1];
      const cusFgSeries = this.cusOpt.series.foregroundSeries;
      const cusBgSeries = this.cusOpt.series.backgroundSeries;
      fgSeries.name = cusFgSeries.name;
      bgSeries.name = cusBgSeries.name;
      this.option.legend.data = [bgSeries.name, fgSeries.name];
      cusBgSeries.data.forEach((item, index) => {
        if (cusBgSeries.data[index]) {
          const ratio = ((cusFgSeries.data[index] / cusBgSeries.data[index]) * 100);
          fgSeries.data[index] = ratio.toFixed(1);
        } else {
          fgSeries.data[index] = 0;
        }
        bgSeries.data[index] = [index, 100, fgSeries.data[index]];
      });
      this.barGraph.setOption(this.option);
      this.barGraph.on('click', (params) => {
        console.log(params);
        const position = {
          x: params.event.offsetX,
          y: params.event.offsetY,
        };
        const tipContent = [{
          title: cusBgSeries.name,
          content: cusBgSeries.data[params.dataIndex],
        }, {
          title: cusFgSeries.name,
          content: cusFgSeries.data[params.dataIndex],
        }];
        this.$refs.graphTip.showTip(position, tipContent);
      });
    },
  },
  mounted() {

  },
};
</script>

<style lang="less" scoped>
.container {
  position: relative; // overflow: hidden;
}

.bar-graph {
  // width: 108%;
  height: 100%;
}

.graph-tip {
  position: absolute;
}
</style>
