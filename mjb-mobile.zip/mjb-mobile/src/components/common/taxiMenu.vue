<template>
  <div class="taximenu-container" v-if="show">
    <div>
      <div class="list">
        <div class="close" @click="close">
          X
        </div>
        <div class="my-triplist">
          <span>我的行程</span>
          <img :src="mytrip" alt="" class="my-trip" @click.stop="myTrip">
        </div>
        <div class="my-triplist">
          <span>常用地址</span>
          <img :src="address_png" alt="" class="my-trip" @click.stop="address">
        </div>
        <div class="my-triplist">
          <span>打车券</span>
          <img :src="carTicket" alt="" class="my-trip" @click.stop="taxiVoucher">
        </div>
      </div>
      <div class="demo">
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import address from '../../assets/images/trade/didi/address.png';
  import mytrip from '../../assets/images/trade/didi/myTravel.png';
  import carTicket from '../../assets/images/trade/didi/vouchers.png';

  export default {
    components: {
    },
    data() {
      return {
        address_png: address,
        mytrip,
        carTicket,
      };
    },
    props: {
      show: {
        type: Boolean,
        required: true,
        default: false,
      },
    },
    methods: {
      myTrip() {
        console.log('点击了我的行程');
        this.$emit('update:show', false);
        this.$emit('trip', false);
      },
      address() {
        console.log('点击了常用地址');
        this.$emit('update:show', false);
        this.$emit('address', false);
      },
      taxiVoucher() {
        console.log('点击了打车劵');
        this.$emit('update:show', false);
        this.$emit('taxiVoucher', false);
      },
      close() {
        console.log('点击关闭');
        this.$emit('update:show', false);
      },
    },
  };
</script>
<style  lang="less" scoped>
  .list {
    position: absolute;
    top: 79px;
    right: 15px;
    z-index: 101;
    color: white;
      .close {
        text-align: end;
        position: absolute;
        top: -65px;
        right: 5px;
        font-size: 20px;
      }
      .my-triplist {
        display: flex;
        justify-content: flex-end;
        font-size: 14px;
        span {
          margin-right: 10px;
          margin-bottom: 15px;
        }
        img {
          width: 60px;
          height: 60px;
          margin-bottom: 15px;
        }
      }
  }
  .demo {
    position: fixed;
    top: 0;
    z-index: 100;
    width: 100%;
    height: 100%;
    opacity: 0.6;
    background: #000000;
  }
  .my-trip {
  }
</style>
