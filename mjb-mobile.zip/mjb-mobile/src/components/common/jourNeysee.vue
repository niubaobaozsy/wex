<!--
  describe：行程信息
  created by：张绍武
  date：2017-11-11
-->
<template>
  <div class='subject' v-if="show">
    <my-header :title='top.type' @previous="goBack"></my-header>
    <ul class='main'>
        <li v-for='(item,index) in title' :key="index" :class="{'stop' : Listshow.indexOf(index) !== -1}">
          <div class="border-bottom border-top"  @click="addclass(index)">
            <img :src='top.showbottom' v-show="Listshow.indexOf(index) === -1" class="img-show">
            <img :src='top.hidetop' v-show="Listshow.indexOf(index) !== -1" class="img-show">
            <section>行程{{index+1}}</section>
          </div>
          <div class='border-bottom'>
            <span>地点</span>
            <section>{{item.from_area_name}} → {{item.to_area_name}}</section>
          </div>
          <div class='border-bottom'>
            <span>日期</span>
            <section>{{item.start_date.split('-')[1]}}月{{item.start_date.split('-')[2].split(' ')[0]}}日 - {{item.end_date.split('-')[1]}}月{{item.end_date.split('-')[2].split(' ')[0]}}日</section>
          </div>
        </li>
    </ul>
  </div>
</template>

<script>
import MyHeader from './header';
import rtarrow from '../../assets/rt-arrow.png';
import hideTravel from '../../assets/images/fee/approve/hideTravel.png';
import showTravel from '../../assets/images/fee/approve/showTravel.png';

export default {
  components: {
    MyHeader,
  },
  props: {
    show: Boolean,
    title: Array,
  },
  data() {
    return {
      top: {
        type: '行程信息',
        arrow: rtarrow,
        hidetop: hideTravel,
        showbottom: showTravel,
      },
      Listshow: [],
    };
  },
  methods: {
    goBack() {
      this.$emit('on-hide');
    },
    // 点击收起
    addclass(index) {
      const newIndex = this.Listshow.indexOf(index);
      if (newIndex === -1) {
        this.Listshow.push(index);
      } else {
        this.Listshow.splice(newIndex);
      }
    },
  },
};
</script>

<style lang='less' scoped>
  .subject{
    width:100%;
    height:130%;
    background: #f2f2f2;
    position: fixed;
    top:0;
    left:0;
    bottom: 0;
    right:0;
    z-index: 99999;
  }
  .main{
    font-size: 16px;
    margin-top: 56px;
    color: #000000;
    list-style: none;
    p{
      width: 0;
      height: 0;
      border-left: 6px solid transparent;
      border-right: 6px solid transparent;
      border-top: 7px solid #AFAFAF;
      margin-right: 6px;
    }
    li{
      background: #ffffff;
      margin-top: 10px;
      &.stop{
            height:39px;    
            overflow: hidden;
           }
      div{
        height:40px;
        margin-left:15px;
        padding-right:15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 0 0 0 #DEDFE0, 0 0 0 0 #DEDFE0;
        span{
          color: #858585
        }
      }
      div:nth-child(1){
        box-sizing:content-box;
        justify-content: initial;
        margin:0;
        padding:0 15px;
        section{
          font-size:14px;
        }
      }
      div:nth-child(2){
        height:50px;
      }
      div:nth-child(3){
        height:50px;
      }
    }
  }
  .img-show{
    width:7px;
    height:6px;
    padding-right:8px;
  }
</style>
