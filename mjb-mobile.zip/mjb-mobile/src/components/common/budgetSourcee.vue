<!--
  describe：预算来源组件
  created by：欧倩伶
  date：2018-1-21
-->
<template>
  <div class="budget-source" v-if="show">
    <my-header :title="top.title" :showBack="true" :showRedDot="true" @previous="hide" v-show="!onSearch"></my-header>
    <div class="searchHeader" v-if="onSearch">
      <div class="search">
        <i class="iconfont icon-qietu03"></i>
        <input type="text" placeholder="搜索预算来源" v-model="search" v-focus>
      </div>
      <span class="cancel" @click="searchCancel">取消</span>
    </div>
    <div :class="['list', {'has-header': !onSearch}]">
      <div class="search-wrap" @click="handleSearch" v-show="!onSearch">
        <div class="search">
          <i class="iconfont icon-qietu03"></i>
          <input type="text" placeholder="搜索预算来源" />
        </div>
      </div>
      <div class="content" @touchmove.stop v-if="!onSearch">
        <div v-for="user in sourceList" :key="user.user_id" class="user" @click="onSelected(user)">
          <div class="row border-top">{{user.budget_node_desc}}</div>
        </div>
      </div>
      <div class="contentSearch" @touchmove.stop v-if="onSearch">
        <div v-for="user in searchRes" :key="user.user_id" class="user" @click="onSelected(user)">
          <div class="row border-top">{{user.budget_node_desc}}</div>
        </div>
        <div class="tipMsg has-header" v-if="searchEnd && !searchRes.length">暂无数据…</div>
      </div>
    </div>
  </div>
</template>
<script>
import MyHeader from './header';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {
      // style: '',
      top: {
        title: '选择预算来源',
      },
      sourceList: [],
      onSearch: false,
      search: '',
      searchRes: [],
      timer: null,
      searchEnd: false,
    };
  },
  props: {
    show: Boolean,
    deptId: String,
    sourcesId: String,
  },
  methods: {
    // 获取预算来源列表
    getSourceList() {
      this.showLoading();
      console.log(this.deptId, this.sourcesId);
      const params = {
        busi_org_id: this.deptId,
        fee_type_id: this.sourcesId,
        page_number: 1,
        page_size: 1000,
      };
      this.$store.dispatch('getBudgetSource', params)
        .then((rep) => {
          this.hideLoading();
          if (rep.code === '0000') {
            this.sourceList = rep.data.info;
            console.log(1111111111, this.sourceList);
            if (!rep.data.info) {
              this.showToast({ msg: '无可用预算来源，请重新选择!' });
            }
          } else {
            this.showToast({ msg: rep.msg });
          }
        }, () => {
          this.hideLoading();
          this.showToast({ msg: '页面开小差，请重试' });
        });
    },
    hide() {
      this.$emit('on-hide');
    },
    // 选择预算来源
    onSelected(item) {
      this.$emit('on-select', item);
    },
    debounce(action, delay) {
      return (() => {
        if (this.timer) clearTimeout(this.timer);
        this.timer = setTimeout(() => {
          action.apply(this);
        }, delay);
      })();
    },
    searchBudgetSource() {
      this.debounce(() => {
        this.showLoading();
        console.log(this.search, 'search');
        const params = {
          budget_node_desc: this.search,
          busi_org_id: this.deptId,
          fee_type_id: this.sourcesId,
          page_number: 1,
          page_size: 1000,
        };
        this.$store.dispatch('getBudgetSource', params)
          .then((res) => {
            this.hideLoading();
            if (res && res.code === '0000') {
              this.searchRes = res.data.info.filter(item => item.budget_node_desc.indexOf(this.search) !== -1);
              this.searchEnd = true;
            } else if (res && res.code) {
              this.showToast({ msg: `请求异常(${res.code})` });
            }
          });
      }, 500);
    },
    handleSearch() {
      this.onSearch = true;
      // this.style.height = `${window.screen.height - 56}px`;
    },
    searchCancel() {
      this.onSearch = false;
      // this.style.height = `${window.screen.height - 156}px`;
      if (this.$refs.sourceList) this.$refs.sourceList.scrollLeft = this.$refs.sourceList.scrollWidth;
      this.search = '';
      this.searchRes = [];
    },
  },
  watch: {
    search(newVal) {
      if (newVal) {
        this.searchBudgetSource();
        console.log(this.searchRes, 'searchRes');
      }
    },
    show(newVal) {
      this.searchEnd = false;
      this.onSearch = false;
      this.search = '';
      this.searchRes = [];
      if (newVal) {
        this.getSourceList();
      }
      // this.style.height = `${window.screen.height - 156}px`;
    },
  },
};
</script>
<style lang="less" scoped>
@searchBoxHeight: 32px;

.searchHeader {
  display: flex;
  background-color: #484759;
  .search {
    flex-grow: 1;
    margin: 10px 0 10px 10px;
  }
  .cancel {
    padding: 14px;
    font-size: 16px;
    color: #fff;
  }
}
.search-wrap {
  padding: 10px;
  background-color: #fff;
}
.search {
  position: relative;
  height: @searchBoxHeight;
  color: #7F8389;
  padding: 0 @searchBoxHeight/2 0 40px;
  line-height: @searchBoxHeight;
  border-radius: @searchBoxHeight/2;
  background-color: #F4F4F4;
  i {
    position: absolute;
    top: 0;
    left: 0;
    padding: 3px 15px 0;
  }
  input {
    width: 100%;
    height: @searchBoxHeight - 5px;
    font-size: 13px;
    outline: none;
    border: 0px;
    background-color: #F4F4F4;
  }
}
.budget-source {
  position: fixed;
  top: 0;
  bottom: 0;
  z-index: 100;
  width: 100%;
  // height: 100%;
  background: #F4F4F4;
}
.content {
  position: fixed;
  top: 98px;
  bottom: 0;
  left: 0;
  right: 0;
  overflow: auto;
  // background: #fff;
  .row {
    height: 50px;
    padding: 14px 15px;
    box-sizing: border-box;
    line-height: 22px;
    background: #fff;
  }
}
.contentSearch {
  position: fixed;
  top: 50px;
  bottom: 0;
  left: 0;
  right: 0;
  overflow: auto;
  // background: #fff;
  .row {
    height: 50px;
    padding: 14px 15px;
    box-sizing: border-box;
    line-height: 22px;
    background: #fff;
  }
}
.tipMsg {
  margin-top: 65px;
  text-align: center;
  color: #cecece;
  padding: auto;
}
</style>
