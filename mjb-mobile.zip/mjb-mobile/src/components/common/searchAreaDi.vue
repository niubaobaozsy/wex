<!--
  describe："搜索地点" 页面（滴滴）
  created by：Yim Lee
  date：2017-11-30
-->
<template>
  <div class="main">
    <div class="didi">
      <!-- 滴滴（搜索地点）————搜索框 -->
      <div class="didi-search columns is-mobile is-gapless">
        <div class="location-wrap column is-2" @click="openCity">
          <div class="location border-right">
            <div class="location-text">{{ this.selectedCity.name || locatedCity.city || '正在努力定位' }}</div>
            <div class="location-img"><img :src="selectImg"></div>
          </div>
        </div>
        <div class="border-right column input-wrap is-6.5">
          <input-box :placeholder="locationText" :focus="true" :inputValue="areaName" :textCenter="false" @get-value="getValue"></input-box>
        </div>
        <span class="didi-hide column is-2" @click="hideSearch">取消</span>
      </div>
      <!-- 滴滴（搜索地点）————常用地址和历史地址 -->
      <div v-if="!showResult" class="scroll-wrap">
        <div class="usually columns is-mobile is-gapless border-top">
          <div class="usually-item column border-right is-6" v-for="(perAddress, index) in commonList" :key="index" @click="selectArea(perAddress)">
            <img :src="usually">
            <div class="column item">
              <span>{{ perAddress.displayname || '常用地址' }}</span>
              <span>{{ perAddress.address || '使用该地址'}}</span>
            </div>
          </div>
        </div>
        <!-- 历史 -->
        <div class="usually-h border" v-if="showHistory" @click="delegate_selectHistoryAddress">
          <div class="usually-item column is-12" v-for="(item, index) in historyList" :key="index">
            <img :src="historyImg">
            <div :class="['column', 'item', {'border-top': index !== 0}, 'perAddress'] " :address-text="item.address" :data-index="index">
              {{ item.displayname }}<br/>
            </div>
          </div>
        </div>
      </div>
      <!-- 搜索结果 -->
      <div :class="['result-list', {'border': hasResult}, {'whiteBack': hasResult, 'greyBack': !hasResult}]" v-if="showResult">
        <div class="result column" v-for="(list, index) in areaList" @click="selectArea(list)" :key="index">
          <div :class="[{'border-top': index !== 0}, 'result-item']">
            <span>{{ list.displayname }}</span>
            <span>{{ list.address }}</span>
          </div>
        </div>
        <div class="no-result" v-if="!hasResult">
          <span>暂无结果，换个地址试试</span>
        </div>
      </div>
    </div>
    <!-- 选择城市 -->
    <select-city v-if="showCity"
      :locationText="locationText"
      :locationInfo="locationInfo"
      :tempType="'didi'"
      @select-city="selecCity"
      @hide-search="hideSearch"></select-city>
  </div>
</template>

<script type="es6">
import { debounce } from 'vux';
import { platform } from '@/platform';
import MyHeader from './header';
import selectImg from '../../assets/images/common/selectImg.png';
import usually from '../../assets/images/common/usually.png';
import historyImg from '../../assets/images/common/historyImg.png';
import InputBox from './input.vue';
import selectCity from 'common/selectCity';

export default {
  components: {
    MyHeader,
    InputBox,
    selectCity,
  },
  props: {
    locatedCity: {
      type: Object,
      default: () => ({})
    },
    locationType: {
      type: String,
      default: '',
    }
  },
  data() {
    return {
      historyImg,
      usually,
      selectImg,
      showCity: ((this.locatedCity && this.locatedCity.city) || this.$store.state.travel.car.selectedCity.cityid) ? false : true, // 显示选择城市页面
      hasResult: false, // 是否有搜索结果
      showResult: false, // 控制是否显示搜索结果
      showHistory: false,
      // commonList: [],  // 常用地址
      commonList: [
        {
          displayname: '',
          address: '',
        },
        {
          displayname: '',
          address: '',
        },
      ],
      // historyList: [], // 历史地址
      historyList: [
        {
          displayname: '',
          address: '',
        },
      ],
      locationInfo: {
        text: '正在努力定位',
      },
      locationText: '',
      areaName: '',
      areaList: [],
    };
  },
  watch: {
    show(val) {
      if (val) {
        this.init();
      } else {
        this.areaName = '';
      }
    },
    areaName(val) {
      if (val) {
        this.getAreaList();
        this.showResult = true;
      } else {
        this.showResult = false;
        this.hasResult = false;
        this.areaList = [];
      }
    },
  },
  computed: {
    // showCity: {
    //   get: function () {
    //     return (this.locatedCity && this.locatedCity.city) ? false : true;
    //   },
    //   set: function (newValue) {
    //     return newValue;
    //   }
    // },
    cityList() {
      return this.$store.state.common.views.cityList;
    },
    user() {
      return this.$store.state.travel.car.user;
    },
    selectedCity() {
      return this.$store.state.travel.car.selectedCity;
    }
  },
  methods: {
    init() {
      if (this.locationType === 'start') {
        this.locationText = '您在哪上车';
      } else if (this.locationType === 'end') {
        this.locationText = '您要去哪儿';
      } else {
        this.locationText = '请输入地址';
      }
    },
    // 打开选择城市页面
    openCity() {
      this.showCity = true;
      this.showResult = false;
      this.areaName = '';
    },
    // 获取用户搜索城市时的输入值
    getValue(value) {
      if (value) {
        this.areaName = value;
      } else {
        this.areaName = '';
      }
    },
    // 关闭搜索
    hideSearch() {
      this.$emit('closeLocationPanel');
    },
    // 选择城市
    selecCity(item) {
      this.locationInfo = item;
      this.$store.commit('CAR', Object.assign({}, this.$store.state.travel.car, { selectedCity: item }));
      console.log('城市', this.locationInfo);
      this.getAddress(item.cityid);
      // if (this.areaName) {
        this.getAreaList();
        this.showCity = false;
        this.showResult = false;
      // }
    },
    delegate_selectHistoryAddress(event) {
      if (event.target.className.indexOf('perAddress') >= 0) {
        this.selectArea(this.historyList[event.target.getAttribute('data-index')]);
      }
    },
    // 选择地点
    selectArea(item) {
      item.cityid = (item.area || item.cityId) + '';
      // debugger;
      console.log("------------------------");
      console.log(item);
      if(item.cityid === "undefined"){
        //弹窗提示不能选空的常用地址
        this.showToast({ msg: `常用地址未维护，请先编辑常用地址` });
      }else{
        this.$emit('select-area', item);
      }
      // item = Object.assign({}, item);
      
    },
    // 定位
    androidCordovaGetLocation() {
      console.log('定位');
      var _self = this;
      if (!sessionStorage.getItem('locationInfo')) {
        platform.location().then(function(data) {
          console.log('获取定位', data);
          if (data) {
            _self.locationInfo = data;
            _self.locationInfo.name = data.city;
          }
          console.log(_self.locationInfo);
          sessionStorage.setItem('locationInfo', JSON.stringify(data));
          _self.getCityId();
        }, () => {
          _self.locationInfo = {
            text: '定位失败',
          };
        });
      } else {
        this.locationInfo = JSON.parse(sessionStorage.getItem('locationInfo'));
        this.getCityId();
      }
    },
    // 获取cityId
    getCityId() {
      const params = {
        cityCode: this.locationInfo.citycode,
      }
      let cityId = 0;
      this.$store.dispatch('getCityId', params).then(res => {
        if (res && res.code === '00000') cityId = res.data;
        this.locationInfo.cityid = cityId;
        this.getAddress(cityId);
      });
    },
    // 请求接口获取热门、历史和常用地址
    getAddress(cityId) {
      console.log('获取常用城市');
      const param = {
        cityId: cityId || 36,
        sn: new Date().valueOf(),
      };
      this.$store.dispatch('getAddress', param)
        .then((rep) => {
          if (rep && rep.errcode === '00000') {
            console.log('热门地址', rep);
            if (rep.data === {}) {
              // this.commonList = [];
              this.showHistory = false;
            } else {
              this.showHistory = true;
              this.commonList = this.commonList.map(function (perAddress, index) {
                Object.assign(perAddress, rep.data.commonAddressList[index]);
                return perAddress;
              });
              this.historyList = Object.assign({}, rep.data.historyAddressList.concat(rep.data.topAddressList));
            }
          } else {
            this.showToast({ msg: rep.errmsg });
          }
        }, () => {
          this.showToast({ msg: '页面开小差，请稍候重试', width: '12em' });
        });
    },
    // 请求接口获取地点列表数据
    getAreaList: debounce( // 使用debounce设置方法执行的时间间隔，并且方法的执行是在输入结束后才会执行
      function() {
        const param = {
          city: this.selectedCity.name || this.locatedCity.city || this.locationInfo.city || this.locationInfo.name || this.locationInfo.text,
          input: this.areaName,
        };
        this.$store.dispatch('getSearchAddress', param)
          .then((rep) => {
            if (rep && rep.errcode === '00000') {
              if (!rep.data.place_data) {
                this.areaList = [];
                this.hasResult = false;
              } else {
                this.areaList = rep.data.place_data;
                this.hasResult = true;
              }
            } else if (rep) {
              this.showToast({ msg: rep.errmsg });
            }
          }, () => {
            this.showToast({ msg: '页面开小差，请稍候重试', width: '12em' });
          });
      },
      200),
  },
  mounted() {
    if (this.user.cityid || this.locatedCity.cityid) {
      this.getAddress(this.selectedCity.cityid || this.locatedCity.cityid || this.user.cityid);
    }
    // this.androidCordovaGetLocation();
  },
};
</script>
<style lang="less" scoped>
.columns {
  margin-bottom: 0 !important;
}

.whiteBack {
  background: #FFFFFF;
}

.greyBack {
  background: #F4F4F4;
}

.main {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  z-index: 99;
  width: 100%;
  background: #F4F4F4;
  animation-duration: .5s;
  .didi {
    height: 100%; // background: #fff;
    .didi-search {
      height: 45px;
      border: 0 solid #ADADAD;
      background: #fff;
      .location-wrap {
        margin: 0 15px;
        .location {
          position: relative;
          width: 100%;
          margin-top: 12px;
          padding-right: 18px;
          text-align: center;
          line-height: 22px;
          .location-text {
            width: 80%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: 16px;
            color: #666666;
          }
         .location-img {
            position: absolute;
            top: 0px;
            right: 15px;
            width: 7px;
            img {
              width: 7px;
              height: 6px;
            }
          }
        }
      }
      .input-wrap {
        height: 20px;
        margin: auto 0;
        &:nth-child(2) {
          margin-left: 15px;
        }
        &:nth-child(3) {
          margin-left: 15px;
        }
        input {
          font-size: 16px;
          text-shadow: 0px 0px 0px #000000; // 字体颜色
          &::-webkit-input-placeholder {
            color: #C3C3C3;
            opacity: 0.32;
          }
        }
      }
      .didi-hide {
        font-size: 16px;
        line-height: 45px;
        color: #666666; // margin: 0px 15px;
        text-align: center;
      }
    }
    .scroll-wrap {
      height: 100%;
      overflow: auto;
    .usually,
    .usually-h {
      background: #FFFFFF;
      .usually-item {
        display: flex;
        justify-content: center;
        align-items: center;
        img {
          width: 12px;
          height: 16px;
          margin: 0 15px;
        }
        .item {
          width: 65%;
          display: flex;
          padding: 9px 0;
          flex-direction: column;
          margin-right: 20px; // overflow: hidden;
          span {
            display: block;
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            &:first-child {
              font-size: 16px;
              color: #000000;
              line-height: 22px;
            }
            &:nth-child(2) {
              font-size: 14px;
              color: #858585;
              line-height: 20px;
            }
          }
        }
      }
    }
    .usually-h {
      .usually-item {
        padding: 0;
        .item {
          margin: 0;
        }
        img {
          width: 12px;
          height: 12px;
        }
      }
    }
    }
  }

  .perAddress:after {
    content: attr(address-text);
    display: inline-block;
    font-size: 14px;
    color: #858585;
    line-height: 20px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding-right: 1.5em;
  }

  .result-list {
    position: fixed;
    top: 55px;
    bottom: 0;
    width: 100%;
    overflow: auto;
    background: #F4F4F4;
    .result {
      display: flex;
      background: #FFFFFF;
      flex-direction: column;
      padding: 0 0 0 14px;
      .result-item {
        padding: 9px 0;
        span {
          display: block;
          width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          &:first-child {
            font-size: 16px;
            color: #000000;
            line-height: 22px;
          }
          &:nth-child(2) {
            font-size: 14px;
            color: #858585;
            line-height: 20px;
          }
        }
      }
    }
    .no-result {
      display: block;
      margin: auto;
      padding-top: 20px;
      font-size: 14px;
      color: #858585;
      text-align: center;
    }
  }
}
</style>
