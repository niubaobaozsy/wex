<!--
  describe："报表数据分析对比表格" 模块 (可复用)
  created by：Yim Lee
  date：2017-10-18
-->
<style lang="less" scoped>
@import '../../assets/css/common/collationTable.less';

</style>
<template>
  <div class="col-table" infinite-scroll-immediate-check="true" v-infinite-scroll="loadMore" infinite-scroll-disabled="busy">
    <!-- 表格头 -->
    <ul class="table-title columns is-mobile is-gapless">
      <li class="column is-4"><span>（单位： 百万）</span></li>
      <li class="column is-3"><span>预算总额</span></li>
      <li class="column is-2.5" v-if="budgetType == 'occupy'">
        <span>已占用</span>
        <span>剩余可用</span>
      </li>
      <li class="column is-2.5" style="font-size: 14px;" v-else>
        <span>已报销入账金额</span>
      </li>
      <li class="column is-2.5">
        <span v-if="budgetType == 'occupy'">占用比率</span>
        <span v-else>执行比率</span>
      </li>
    </ul>
    <!-- 无数据时显示 -->
    <div v-if="!graphTable.length && !isLoading && !hasNextPage">
      <!-- <img class="no-data-img" src="../../assets/images/ticket-booking/no_data.png" alt=""> -->
      <p class="no-data-text">{{noData}}</p>
    </div>
    <!-- 表格内容 -->
    <ul class="table-items columns is-mobile is-gapless" v-for="(item,index) in graphTable" :key="index">
      <li class="column is-4" v-if="tabType !== 'trendAnalysis'"><span>{{ item.budgetOrgName }}</span></li>
      <li class="column is-4" v-else><span>{{ item.month }}月</span></li>
      <li class="column is-3">
        <span v-if="item.budgetAmountAdjusted">{{ (item.budgetAmountAdjusted / 10000000).toFixed(2)}}</span>
        <span v-else>{{ '0.00' }}</span>
      </li>
      <li class="column is-2.5" v-if="budgetType == 'occupy'">
        <!-- 已占用字段 -->
        <span>{{ (item.budgetAmount / 10000000).toFixed(2) }}</span>
        <!-- 剩余可用字段 -->
        <span>{{ ((item.budgetAmountAdjusted - item.budgetAmount) / 10000000).toFixed(2) }}</span>
      </li>
      <li class="column is-2.5" v-else style="color: #000000; font-size: 16px; line-height: 22px;">
        <span v-if="item.invoiceAmount">{{ (item.invoiceAmount / 10000000).toFixed(2) }}</span>
        <span v-else>{{ '0.00' }}</span>
      </li>
      <li class="column is-2.5" v-if="budgetType == 'occupy'"><span>{{ (item.budgetOccupyRate).toFixed(1) }}%</span></li>
      <li class="column is-2.5" v-else><span>{{ (item.budgetExecuteRate).toFixed(1) }}%</span></li>
    </ul>
    <div class="no-data-text" v-if="graphTable.length && !hasNextPage">{{noMore}}</div>
  </div>
</template>
<script>
export default {
  props: {
    tabType: String,
    graphTable: Array,
    budgetType: String,
    busy: Boolean,
    isLoading: Boolean,
    hasNextPage: Boolean,
  },
  data() {
    return {
      noMore: '已无更多数据',
      noData: '暂无数据',
    };
  },
  methods: {
    loadMore() {
      this.$emit('loadMore');
    },
  },
  watch: {
  },
};
</script>
