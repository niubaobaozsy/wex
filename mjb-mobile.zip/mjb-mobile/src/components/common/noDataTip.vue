<script>
import noData from '@/assets/images/common/no_data.png';

export default {
  render (h) {
    return h('div', {
      class: this.$style.noDataTip,
    }, this.createChildrenNode(h))
  },
  methods: {
     createChildrenNode(h) {
      return [
        h('img', {
          attrs: {
            src: noData,
          },
        }),
        h('p', this.$slots.tip || '暂无数据')
      ];
    }
  }
}
</script>

<style lang="less" module>
.noDataTip {
  text-align: center;
  img {
    display: block;
    margin: 20% auto 10px;
    width: 50%;
  }
  p {
    color: #6e7481;
  }
}
</style>

