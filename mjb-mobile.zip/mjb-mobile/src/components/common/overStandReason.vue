<!--
  describe：超标原因组件
  created by：欧倩伶
  date：2017-11-10
-->
<template>
  <div class="over-stand" v-if="show">
    <my-header :title="top.title" :rightItem="'提交'" :showBack="true" :showRedDot="true"  @previous="hide" @on-click="sumbit(reason)"></my-header>
    <div class="has-header">
      <div class="overStansReason">
        <x-textarea :max="40" v-model="reason" placeholder="超标原因"></x-textarea>
      </div>
    </div>
  </div>
</template>
<script>
import { XTextarea } from 'vux';
import MyHeader from './header';

export default {
  components: {
    MyHeader,
    XTextarea,
  },
  props: {
    show: Boolean,
  },
  data() {
    return {
      reason: '',
      top: {
        title: '超标原因',
      },
    };
  },
  methods: {
    sumbit(reason) {
      if (this.reason) {
        this.$emit('on-select', reason);
      } else {
         this.showToast({ msg: '超标理由不可为空！' });
      }
    },
    hide() {
      this.$emit('on-hide');
    },
  },
  computed: {
    applyOverStdRes() {
      return this.$store.state.myApply.emseaapplyh.over_standard_reason;
    },
    reimOverStdRes() {
      return this.$store.state.myReimburse.emsecfeereimh.over_standard_reason;
    },
  },
  mounted() {
    this.reason = this.applyOverStdRes || this.reimOverStdRes || '';
  },
};
</script>
<style lang="less" scoped>
.over-stand {
  position: fixed;
  top: 0;
  z-index: 100;
  width: 100%;
  height: 100%;
  background: #F4F4F4;
}
</style>

