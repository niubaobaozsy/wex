 <!--
  describe：选择银行信息
  created by：周積坤
  date：2017-11-29
-->

<template>
  <div class="co-container" >
    <MyHeader :title="'选择开户行'" :showBack="true" @previous="goBack" v-show="!onSearch"></MyHeader>
    <div class="searchHeader" v-if="onSearch">
      <div class="search">
        <i class="iconfont icon-qietu03"></i>
        <input type="text" placeholder="搜索" v-model="search" v-focus>
      </div>
      <span class="cancel" @click="searchCancel">取消</span>
    </div>
    <div :class="{'has-header': !onSearch}">
      <div class="search-wrap" @click="handleSearch" v-show="!onSearch">
        <div class="search">
          <i class="iconfont icon-qietu03"></i>
          <input type="text" placeholder="搜索">
        </div>
      </div>
      <div :style="style" @touchmove.stop>
        <div class="wrap">
          <div v-for="(list,index) in bankList" :key="index" @click="onSelected(list)" class="co border-top">
             {{seachType === '0' ?list.bank_name :(seachType === '1'?list.city:list.bank_name )}}
          </div>
          <div class="tipMsg" v-if="onSearch&&!bankList">暂无匹配信息</div>
          <!-- <div class="tipMsg" v-if="!onSearch&&!defCo.length">无默认入账单位,去维护</div> -->
        </div>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import MyHeader from './header';
  import searchS from '../../assets/images/common/searchS.png';

  export default {
    components: {
      MyHeader,
    },
    data() {
      return {
        searched: searchS,
        bankList: [],
        dataList: [],
        seachType: '',
        search: '',
        searchCategory: '',
        searchCity: '',
        searchBank: '',
        num: 0,
        onSearch: false,
        style: {
          height: '100%',
          position: 'fixed',
          overflow: 'auto',
          width: '100%',
        },
        top: {
          title: '',
        },
      };
    },
    watch: {
      // search(newValue) {
      //   if (newValue) {
      //     if (this.seachType === '0') {
      //       this.searchCategory = this.search;
      //     } else if (this.seachType === '1') {
      //       this.searchCity = this.search;
      //     } else if (this.seachType === '2') {
      //       this.searchBank = this.search;
      //     }
      //     console.log(213);
      //     this.searchBdOrgDebounce();
      //   }
      // },
      search(newValue) {
        if (newValue) {
          this.getbankAddress();
        }
      },
    },
    computed: {
      collectTions() {
        return this.$store.state.mine.collectMsg;
      },
    },
    methods: {
      // init() {
      //   this.verdict();
      //   this.goBank();
      // },
      // debounce(action, delay) {
      //   return (() => {
      //     if (this.timer) clearTimeout(this.timer);
      //     this.timer = setTimeout(() => {
      //       action.apply(this);
      //     }, delay);
      //   })();
      // },
      // searchBdOrgDebounce() {
      //   this.debounce(() => {
      //     // this.goBank();
      //   }, 500);
      // },
      // goBank() {
      // // 请求数据
      //   if (this.seachType === '2') {
      //     const params = {
      //       type: this.seachType,
      //       bank_category_name: this.searchCategory || this.collectTions.bank_category_name,
      //       city: this.searchCity || this.collectTions.city,
      //       bank_name: this.searchBank,
      //     };
      //     this.getData(params);
      //   } else {
      //     const params = {
      //       type: this.seachType,
      //       bank_category_name: this.searchCategory,
      //       city: this.searchCity,
      //       bank_name: this.searchBank,
      //     };
      //     this.getData(params);
      //   }
      // },
      // getData(params) {
      //   this.$store.dispatch('mineGetBankInfo', params).then((res) => {
      //     if (res.code === '0000') {
      //       this.bankList = res.data.info;
      //       console.log(this.bankList);
      //     } else {
      //       this.showToast({ msg: `请求异常(${res.code})` });
      //     }
      //   });
      // },
      handleSearch() {
        this.onSearch = true;
        this.style.height = `${window.screen.height - 56}px`;
        // this.goBank();
      },
      searchCancel() {
        // this.onSearch = false;
        // this.style.height = `${window.screen.height - 109}px`;
        // this.search = '';
        // this.bankList = [];
        // this.getbankAddress();
        // this.goBank();
        this.$router.go(-1);
      },
      // verdict() {
      //   this.seachType = this.$route.query.type;
      //   if (this.seachType === '0') {
      //     this.top.title = '选择开户行';
      //   } else if (this.seachType === '1') {
      //     this.top.title = '选择城市';
      //   } else {
      //     this.top.title = '选择开户网点';
      //   }
      // },
      goBack() { // 返回
        this.$router.go(-1);
      },
      // 把当前点击的信息对象进行合并,从而覆盖
      onSelected(obj) {
        // if (this.seachType === '0') {
        //   console.log(obj, 111);
        //   const bankObj = {
        //     bank_category_name: obj.bank_category_name,
        //   };
        //   const bankCategoryName = Object.assign({}, this.collectTions, bankObj);
        //   this.$store.commit('COLLECT_MSG', bankCategoryName);
        //   this.$router.go(-1);
        // } else if (this.seachType === '1') {
        //   console.log(obj, 222);
        //   const cityObj = {
        //     city: obj.city,
        //   };
        //   const cityName = Object.assign({}, this.collectTions, cityObj);
        //   this.$store.commit('COLLECT_MSG', cityName);
        //   this.$router.go(-1);
        // } else {
        //   console.log(obj, '312312');
        //   const bankName = Object.assign({}, this.collectTions, obj);
        //   this.$store.commit('COLLECT_MSG', bankName);
        //   console.log(this.collectTions, '666666');
        //   this.$router.go(-1);
        // }
        const bankCategoryName = Object.assign({}, this.collectTions, obj);
        this.$store.commit('COLLECT_MSG', bankCategoryName);
        this.$router.go(-1);
      },
      getbankAddress() {
        const params = {
          page_number: 1,
          page_size: 100,
          bank_name: this.search || '',
        };
        console.log('传入参数：', params);
        this.$store.dispatch('mineGetBankAdress', params).then((res) => {
          if (res && res.code === '0000') {
            this.bankList = res.data.info;
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常${res.code}` });
          }
        });
      },
    },
    mounted() {
      this.getbankAddress();
      this.handleSearch();
    },
  };
</script>
<style lang="less" scoped>
@searchBoxHeight: 32px;

.searchHeader {
  display: flex;
  background-color: #484759;
  .search {
    flex-grow: 1;
    margin: 10px 0 10px 10px;
  }
  .cancel {
    padding: 14px;
    font-size: 16px;
    color: #fff;
  }
}

.co-container {
  position: fixed;
  top: 0;
  z-index: 100;
  width: 100%;
  height: 100%;
  background-color: #F4F4F4;
}

.search {
  position: relative;
  height: @searchBoxHeight;
  color: #7F8389;
  padding: 0 @searchBoxHeight/2 0 40px;
  line-height: @searchBoxHeight;
  border-radius: @searchBoxHeight/2;
  background-color: #F4F4F4;
  i {
    position: absolute;
    top: 0;
    left: 0;
    padding: 3px 15px 0;
  }
  input {
    width: 100%;
    height: @searchBoxHeight - 5px;
    font-size: 13px;
    outline: none;
    border: 0px;
    background-color: #F4F4F4;
  }
}

.search-wrap {
  padding: 10px;
  background-color: #fff;
}

.wrap {
  .co {
    padding: 12px 15px;
    font-size: 16px;
    background-color: #fff;
  }
  .tipMsg {
    margin-top: 65px;
    text-align: center;
    color: #cecece;
  }
}
</style>
