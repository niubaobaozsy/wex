<template>
  <div v-if="show" class="data-wrap">
    <my-header :title="title" @previous="goBack"></my-header>
    <div class="has-header data">
      <div class="data-item">
        <span class="border-bottom" v-for="(item,index) in selectData" :key="index" @click="addValue(item)">{{item.text}}</span>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
import myHeader from './header';

export default {
  components: {
    myHeader,
  },
  props: {
    show: Boolean,
    selectData: Array,
    title: String,
  },
  data() {
    return {
    };
  },
  watch: {
    show() {
    },
  },
  methods: {
    goBack() {
      this.$emit('update:show', false);
    },
    addValue(item) {
      this.$emit('select', item);
      this.$emit('update:show', false);
    },
  },
};
</script>

<style lang="less">
  .data-wrap {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 100;
    background: #F6F6F6;
    .data {
      .data-item {
        background: #FFFFFF;
        span {
          display: flex;
          flex: 1;
          line-height: 50px;
          padding-left: 15px;
          color: #858585;
          transform-origin: 0 0;
        }
      }
    }
  }
</style>
