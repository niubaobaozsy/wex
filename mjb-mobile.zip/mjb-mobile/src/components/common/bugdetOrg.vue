<!--
  describe：Pick bugdet organizational
  created by：Zhuangyh
  date：2017-11-20
-->

<template>
  <div class="org-container" v-if="show">
    <MyHeader title="选择预算部门" :showBack="true" @previous="goBack" v-show="!onSearch"></MyHeader>
    
    <div :class="{'has-header': !onSearch, 'search-wrap': !onSearch, 'searchHeader': onSearch}" >
      <div class="search">
        <i class="iconfont icon-qietu03"></i>
        <input type="text" placeholder="搜索预算部门" v-model="search" @click="handleSearch">
      </div>
      <span class="cancel" @click="searchCancel">取消</span>
    </div>
    <div @touchmove.stop :class="{'has-header': !onSearch}" class="has-search content">
      <div class="wrap">
        <div v-for="(org, index) in searchRes" :key="index" @click="pickBugdetOrg(org)" class="org border-top">
          {{org.busi_org_name}} &nbsp;&nbsp;&nbsp; {{org.parent_org_name ? org.parent_org_name : ''}}
        </div>
        <div class="tipMsg" v-if="!searchRes.length">暂无匹配预算部门</div>
      </div>
    </div>
  </div>
</template>

<script>
import MyHeader from './header';

export default {
  components: {
    MyHeader,
  },
  props: {
    show: {
      type: Boolean,
      required: true,
      default: false,
    },
    value: {
      type: Object,
      required: false,
      default: () => { },
    },
    defBdOrg: {
      type: Array,
      required: false,
      default: () => [],
    },
  },
  data() {
    return {
      search: '',
      onSearch: false,
      searchRes: [],
      timer: null,
    };
  },
  methods: {
    goBack() {
      this.searchCancel();
      this.$emit('goBack');
      this.$emit('update:show', false);
    },
    pickBugdetOrg(org) {
      this.$emit('input', org);
      this.$emit('confirm', org);
      setTimeout(() => {
        this.$emit('update:show', false);
        this.searchCancel();
      }, 200);
    },
    debounce(action, delay) {
      return (() => {
        if (this.timer) clearTimeout(this.timer);
        this.timer = setTimeout(() => {
          action.apply(this);
        }, delay);
      })();
    },
    searchBdOrg() {
      this.showLoading();
      this.$store.dispatch('getBusiOrg', {
        busi_org_name: this.search,
        page_number: 1,
        page_size: 1000,
      }).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          this.searchRes = res.data.info || [];
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    searchBdOrgDebounce() {
      this.debounce(() => {
        this.searchBdOrg();
      }, 500);
    },
    handleSearch() {
      this.onSearch = true;
    },
    searchCancel() {
      this.onSearch = false;
      this.search = '';
      this.searchBdOrg();
    },
  },
  watch: {
    search(newVal) {
      if (newVal) {
        this.searchBdOrgDebounce();
      }
    },
  },
  mounted() {
    this.searchBdOrg();
  },
};
</script>
<style lang="less" scoped>
@searchBoxHeight: 32px;

.has-search {
  padding-top: 52px;
}
.searchHeader {
  position: fixed;
  z-index: 99;
  width: 100%;
  display: flex;
  background-color: #484759;
  .search {
    flex-grow: 1;
    margin: 10px 0 10px 10px;
  }
  .cancel {
    padding: 14px;
    font-size: 16px;
    color: #fff;
  }
}

.org-container {
  position: fixed;
  top: 0;
  z-index: 100;
  width: 100%;
  height: 100%;
  background-color: #F4F4F4;
}

.search {
  position: relative;
  height: @searchBoxHeight;
  color: #7F8389;
  padding: 0 @searchBoxHeight/2 0 40px;
  line-height: @searchBoxHeight;
  border-radius: @searchBoxHeight/2;
  background-color: #F4F4F4;
  i {
    position: absolute;
    top: 0;
    left: 0;
    padding: 3px 15px 0;
  }
  input {
    width: 100%;
    height: @searchBoxHeight - 5px;
    font-size: 13px;
    outline: none;
    border: 0px;
    background-color: #F4F4F4;
  }
}

.search-wrap {
  position: fixed;
  z-index: 99;
  box-sizing: border-box;
  width: 100%;
  padding: 10px;
  background-color: #fff;

  .cancel {
    display: none;
  }
}

.content {
  position: fixed;
  top: 0;
  bottom: 0;
  overflow: auto;
  width: 100%;
}

.wrap {
  .org {
    padding: 12px 15px;
    font-size: 16px;
    background-color: #fff;
  }
  .tipMsg {
    margin-top: 65px;
    text-align: center;
    color: #cecece;
  }
}
</style>
