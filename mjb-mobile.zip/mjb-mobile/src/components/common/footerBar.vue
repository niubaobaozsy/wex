<!--
  describe：尾部footer模块 (可复用)
  created by：Yim Lee
  date：2017-10-18
-->
<style lang="less" scoped>
@import '../../assets/css/common/footerBar.less';
</style>
<template>
  <div>
    <transition name="mask-transition" enter-active-class="animated fadeIn" leave-active-class="animated fadeOut">
      <div v-if="showAdd" class="maskLayer" @touchmove.prevent @click="onAddBtnClose"></div>
    </transition>
    <transition name="add-btn-transition" enter-active-class="animatedFast fadeInUpBig" leave-active-class="animatedSlow fadeOutDownBig">
      <Add v-if="showAdd" class="addBtn" @close="onAddBtnClose" ref="addBtn"></Add>
    </transition>
    <div class="footer-bar">
      <ul class="footer-tab columns is-mobile is-gapless">
        <li class="tab-item column" v-for="(item,idx) in footerTab" :key="idx" :class="{addBtnIcon: idx === 2}" @click="(!showAdd || idx === 2) && changeTab(idx)">
          <img v-if="!showAdd || idx === 2" :src="tabName == item.tabName ? item.src_on : item.src_off" :class="{rotateOpen: addBtnAnimate && showAdd, rotateClose: addBtnAnimate && !showAdd}">
          <span v-if="idx === 2 || showAdd ? false : true" :id="tabName == item.tabName ? 'active' : ''">{{ item.tabText }}</span>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import costOff from '../../assets/images/common/footerBar/cost_off.png';
import costOn from '../../assets/images/common/footerBar/cost_on.png';
import journeyOff from '../../assets/images/common/footerBar/journey_off.png';
import journeyOn from '../../assets/images/common/footerBar/journey_on.png';
import addOff from '../../assets/images/common/footerBar/add_off.png';
import addOn from '../../assets/images/common/footerBar/add_on.png';
import dataOff from '../../assets/images/common/footerBar/data_off.png';
import dataOn from '../../assets/images/common/footerBar/data_on.png';
import meOff from '../../assets/images/common/footerBar/me_off.png';
import meOn from '../../assets/images/common/footerBar/me_on.png';
import showAdd from './showAdd';

export default {
  components: {
    Add: showAdd,
  },
  props: {
    index: '',
    tabName: '',
  },
  data() {
    return {
      tabIndex: '',
      showAdd: false,
      addBtnAnimate: false,
      footerTab: [ // tab导航项，这里有五项，tab项里有图标（暗色亮色两种）、文字、指向路由、索引号
        {
          src_off: journeyOff,
          src_on: journeyOn,
          tabText: '商旅',
          tabName: 'journey',
          routerPath: '/travel',
          index: 0,
        },
        {
          src_off: costOff,
          src_on: costOn,
          tabText: '费用',
          tabName: 'fee',
          routerPath: '/fee',
          index: 1,
        },
        {
          src_off: addOff,
          src_on: addOn,
          tabText: '',
          tabName: 'add',
          routerPath: '/fee',
          index: 2,
        },
        {
          src_off: dataOff,
          src_on: dataOn,
          tabText: '报表',
          tabName: 'report',
          routerPath: '/report',
          index: 3,
        },
        {
          src_off: meOff,
          src_on: meOn,
          tabText: '我的',
          tabName: 'mine',
          routerPath: '/mine',
          index: 4,
        },
      ],
    };
  },
  methods: {
    // 切换tab导航
    changeTab(idx) {
      // 判断点击的tab导航项的索引idx与当前所在的父组件传递回来的tab导航索引index(index一直被监听，把监听到的值赋给tabIndex)
      // 是否相等，若不相等则说明用户点击了其他的tab导航项，需要发生对应的路由跳转
      if (this.tabIndex !== idx) {
        switch (idx) {
          case 0:
            this.$router.push(this.footerTab[0].routerPath);
            break;
          case 1:
            this.$router.push(this.footerTab[1].routerPath);
            break;
          case 2:
            this.addBtnAnimate = true;
            this.addBtn();
            break;
          case 3:
            this.$router.push(this.footerTab[3].routerPath);
            break;
          case 4:
            this.$router.push(this.footerTab[4].routerPath);
            break;
          default:
            this.$router.push(this.footerTab[0].routerPath);
        }
      }
    },
    // 关闭“添加”页面
    addBtn() {
      if (this.showAdd) {
        this.$refs.addBtn.closeAdd(() => {
          this.showAdd = false;
        });
      } else {
        this.showAdd = true;
      }
    },
    onAddBtnClose() {
      this.showAdd = false;
    },
  },
  watch: {
    // 监听父组件传递回来的tab导航项的index，用来判断是否需要发生tab切换（路由跳转）
    index(val) {
      this.tabIndex = val;
    },
  },
};
</script>

<style lang="less" scoped>
.addBtn {
  position: fixed;
  z-index: 99;
  bottom: 50px;
}

.maskLayer {
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
}

.addBtnIcon {
  margin: 10px 0 !important;
  .rotateOpen {
    transform: rotate(45deg);
    animation: rotateOpen 500ms;
  }
  .rotateClose {
    animation: rotateClose 500ms;
  }
}

@keyframes rotateOpen {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(45deg);
  }
}

@keyframes rotateClose {
  from {
    transform: rotate(45deg);
  }
  to {
    transform: rotate(0);
  }
}

.animatedFast {
  animation-duration: 500ms;
  animation-fill-mode: both;
}

.animatedSlow {
  animation-duration: 2s;
  animation-fill-mode: both;
}

</style>

