<template>
  <div class="has-footer">
    <my-header title="测试DEMO" @previous="goBack" ></my-header>
    <div class="has-header mjblogo">
      <i class="iconfont icon-meijiebaologo"></i>
    </div>
    <div class="columns is-mobile flex-box">
      <h1 class="column title">【flex布局&动画效果】</h1>
      <div class="column btn" @click="reset">
        <p>点我恢复</p>
      </div>
    </div>
    <div class="columns is-mobile">
      <div class="column box" v-for="(item, index) in flexBoxMsg" :key="index">
        <transition name="hinge-transition" leave-active-class="animated hinge" enter-active-class="animated bounceInDown">
          <p @click="remove(index)" v-show="item.show">{{item.msg}}</p>
        </transition>
      </div>
    </div>
    <h1>【条形图组件】</h1>
    <barGraph ref="barChart" class="echart-container" :cusOpt="cusBarOpt"></barGraph>

    <h1>【折线图组件】</h1>
    <lineGraph ref="lineChart" class="echart-container lineChart" :cusOpt="cusLineOpt"></lineGraph>

    <h1>【日历组件】</h1>
    <group title="选择出差日期">
      <cell title="单选日期" @click.native="onCellAClick" :value="valueA" is-link primary="content"></cell>
      <cell title="日期区间" @click.native="onCellBClick" :value="valueB" is-link primary="content"></cell>
    </group>
    <p class="tip-msg">日历组件的用法和组件库vuex里的
      <a href="https://vux.li/#/zh-CN/components?id=inlinecalendar" target="_blank">InlineCalendar</a>基本一致，请参考相关用法。
      <a href="https://vux.li/#/zh-CN/components?id=inlinecalendar" target="_blank">去看看-></a>
    </p>

    <h1>【组织架构组件】</h1>
    <group title="选择出差人员">
      <cell title="双向绑定" :value="users" primary="content"></cell>
      <cell title="单选" @click.native="onCellCClick" :value="orgCStr" is-link primary="content"></cell>
      <cell title="多选" @click.native="onCellDClick" :value="orgDStr" is-link primary="content"></cell>
    </group>

    <h1>【预算组织及入账单位组件】</h1>
    <group title="选择预算组织及入账单位">
      <cell title="预算组织" @click.native="onCellEClick" :value="bdOrgStr" is-link primary="content"></cell>
      <cell title="入账单位" @click.native="onCellFClick" :value="coStr" is-link primary="content"></cell>
      <cell title="收款方" @click.native="onCellGClick" :value="receiverStr" is-link primary="content"></cell>
    </group>

    <calendar v-model="date" :show.sync="showCalendar" :start-date="startDate" :end-date="endDate" @pickDate="onPickDate" />

    <org v-model="orgnization" :show.sync="showOrg" :multi="multiUser" @confirm="onOrgConfirm" />

    <!-- <bugdet-org v-model="bugdet" :show.sync="showBdOrg" :defBdOrg="defaultConfig.busiOrgs" /> -->
    <!-- <co v-model="company" :show.sync="showCo" :defCo="defaultConfig.companys" /> -->
    <receiver v-model="receiver" :show.sync="showReceiver" :coId="coId" />

    <h1>【底座接口调试】</h1>
    <div class="columns is-mobile platform">
      <div class="column box btn" @click="registerPushService('1111')">
        <p>绑定推送</p>
      </div>
      <div class="column box btn" @click="untiePush">
        <p>解绑推送</p>
      </div>
      <div class="column box btn" @click="getPushMsg">
        <p>getPush</p>
      </div>
    </div>

    <footer-bar></footer-bar>

  </div>
</template>

<script>
import { Group, Cell } from 'vux';
import MyHeader from './common/header';
import footerBar from './common/footerBar'; // Yim Lee 导入footerBar组件
import barGraph from './common/barGraph';
import lineGraph from './common/lineGraph';
import calendar from './common/myCalendar';
import org from './common/org';
import bugdetOrg from './common/bugdetOrg';
import co from './common/company';
import receiver from './common/receiver';

export default {
  components: {
    MyHeader,
    footerBar, // Yim Lee注册footerBar组件
    barGraph,
    lineGraph,
    Group,
    Cell,
    calendar,
    org,
    bugdetOrg,
    co,
    receiver,
  },
  data() {
    return {
      // note: changing this line won't causes changes
      // with hot-reload because the reloaded component
      // preserves its current state and we are modifying
      // its initial state.
      msg: 'Hello World!',
      flexBoxMsg: [
        {
          msg: 'Hello Zhuangyh',
          show: true,
        }, {
          msg: '美捷报正在改版中……',
          show: true,
        }, {
          msg: '这里有动画效果，快来点击试试',
          show: true,
        }, {
          msg: '快点我，快点我',
          show: true,
        },
      ],
      cusBarOpt: {
        title: '各部门本月预算占用比率(%)',
        xAxis: ['慧享云事业部事业部', '美信云事业部', '数据云事业部', '制造云事业部', '营销云事业部', '慧享云事业部', '美信云事业部', '数据云事业部', '制造云事业部', '营销云事业部'],
        series: {
          backgroundSeries: {
            name: '预算总额',
            data: [0, 851, 0, 785, 960, 0, 980, 0, 750, 830],
          },
          foregroundSeries: {
            name: '已占用',
            data: [0, 324, 0, 200, 320, 0, 230, 0, 500, 320],
          },
        },
      },
      cusLineOpt: {
        title: '每月预算总额(百万)',
        xAxis: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
        series: [943, 851, 1020, 785, 960, 888, 980, 910, 750, 830, 230, 900],
      },
      date: [], // '2017-12-08', '2017-12-10'
      valueB: [],
      valueA: '',
      type: 'AA',
      showCalendar: false,
      startDate: '2017-11-01',
      endDate: '2018-05-30',
      orgnization: [],
      orgC: [],
      orgD: [],
      showOrg: false,
      multiUser: false,
      showBdOrg: false,
      showCo: false,
      bugdet: {},
      company: {},
      defaultConfig: {},
      receiver: {},
      showReceiver: false,
    };
  },
  mounted() {
    console.log('hello zhuangyh');
    this.$refs.barChart.drawBarGraph();
    this.$refs.lineChart.drawLineGraph();
    this.showToast({ msg: 'welcome!' });
    // this.getDefaultConfig();
  },
  methods: {
    goBack() { // 返回
      this.$router.go(-1);
    },
    // registerPushService() {
    //   this.registerPushService('1111');
    // },
    untiePush() {
      this.untiePushService('1111').then(() => {
        this.showToast({ msg: '解绑成功' });
      }).catch((err) => {
        this.showToast({ msg: `解绑失败：${err}` });
      });
    },
    getPushMsg() {
      this.getPush().then(() => {
        this.showToast({ msg: 'getPush成功' });
      }).catch((err) => {
        this.showToast({ msg: `getPush失败：${err}` });
      });
    },
    remove(index) {
      this.flexBoxMsg[index].show = false;
    },
    reset() {
      this.flexBoxMsg.forEach((i) => {
        i.show = true;
      });
    },
    onCellAClick() {
      this.date = this.valueA;
      this.type = 'AA';
      this.startDate = '';
      this.endDate = '';
      this.showCalendar = true;
    },
    onCellBClick() {
      this.date = this.valueB;
      this.type = 'BB';
      this.startDate = '2017-11-01';
      this.endDate = '2018-05-30';
      this.showCalendar = true;
    },
    onCellCClick() {
      this.orgnization = this.orgC;
      this.showOrg = true;
      this.multiUser = false;
    },
    onCellDClick() {
      this.orgnization = this.orgD;
      this.showOrg = true;
      this.multiUser = true;
    },
    onCellEClick() {
      this.showBdOrg = true;
    },
    onCellFClick() {
      this.showCo = true;
    },
    onCellGClick() {
      this.showReceiver = true;
    },
    onPickDate() {
      if (this.type === 'AA') {
        this.valueA = this.date;
        this.date = '';
      } else {
        this.valueB = this.date;
        this.date = [];
      }
      console.log('onPickDate');
    },
    onOrgConfirm(users) {
      if (this.multiUser) {
        this.orgD = users;
      } else {
        this.orgC = users;
      }
    },
    getDefaultConfig() {
      this.$store.dispatch('getDefaultConfig').then((res) => {
        this.defaultConfig = res.data;
        this.bugdet = this.defaultConfig.busiOrg || {};
        this.company = this.defaultConfig.company ? this.defaultConfig.company : {};
      });
    },
  },
  computed: {
    users() {
      let users = '';
      this.orgnization.forEach((user) => {
        users += `${user.user_full_name},`;
      });
      return users;
    },
    orgDStr() {
      let users = '';
      this.orgD.forEach((user) => {
        users += `${user.user_full_name},`;
      });
      return users;
    },
    orgCStr() {
      return this.orgC[0] ? this.orgC[0].user_full_name : '';
    },
    bdOrgStr() {
      return this.bugdet.busi_org_name;
    },
    coStr() {
      return this.company.company_name ? this.company.company_name : '';
    },
    coId() {
      return this.company.company_id || '';
    },
    receiverStr() {
      if (Object.keys(this.receiver).length) {
        return `${this.receiver.receiver}[尾号${this.receiver.bank_account.slice(-4)}]`;
      }
      return '';
    },
  },
};
</script>

<style lang="less" scoped>
.flex-box {
  align-items: center;
}

h1 {
  font-size: 14px;
  margin-left: 5px;
}

.title {
  padding: 0;
  text-align: left;
}

.btn {
  padding: 0;
  color: #fff;
  font-size: 12px;
  p {
    width: 48px;
    padding: 5px;
    background-color: #209cee;
    border-radius: 5px;
  }
}

.columns {
  margin: 0;
  overflow: hidden;
}

.box {
  height: 50px;
  text-align: center;
}

.box p {
  background-color: #209cee;
  color: #fff;
  font-size: 12px;
  border-radius: 5px;
}

.mjblogo {
  padding: 30px;
  text-align: center;
}

.mjblogo i {
  font-size: 50px;
  color: blue;
}

.echart-container {
  height: 400px;
}

.lineChart {
  margin-left: 10px;
}

.has-footer {
  margin-bottom: 60px;
}

.tip-msg {
  margin: 5px 0;
  padding: 5px 10px;
  color: #999;
  font-size: 12px;
  background-color: #fff;
}
.platform {
  padding: 10px;
}
</style>
