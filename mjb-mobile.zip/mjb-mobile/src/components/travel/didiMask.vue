<!--
  describe：“滴滴主页”
  created by：panjm2
  date：2018-08-14
-->
<template>
<div>
 <div class="content">
    <div class="passenger">
      <span>出发城市: </span>
      <span>佛山</span>
    </div>
    <div class="carReason">
      <div class="title">用车事由</div>
      <div class="reasonList">
        <!-- :class="['reason', {'reaAble': item.show === 'Y'}, {'reaDisable': item.show === 'N'}]" -->
        <div class="reason reaAble" v-for="(item, index) in reaList" :key="index">
          {{item.name}}
        </div>
      </div>
    </div>
  </div>
</div>
</template>
<script>
import addInvoice from '../../assets/images/common/showAdd/add_invoice.png';

export default {
  data() {
    return {
      reaList: [
        {
          name: '工作日加班',
          show: 'N',
        },
        {
          name: '节假日加班',
          show: 'Y',
        },
        {
          name: '双休日加班',
          show: 'Y',
        },
        {
          name: '出差',
          show: 'Y',
        },
      ],
    };
  },
};
</script>
<style lang="less" scoped>
.content {
  width: 100%;
  background: #ffffff;
  .passenger {
    width: 100%;
    padding: 19px 15px;
    color: #3DA5FE;
    border-bottom: 1px solid #DEDFE0;

  }
  .carReason {
    width: 100%;
    padding: 20px 15px;
    .title {
      font-size: 16px;
    }
    .reasonList {
      display: flex;
      justify-content: space-around;
      .reason {
        width: 105px;
        text-align: center;
        line-height: 16px;
        font-size: 13px;
        border-radius: 4px;
      }
      .reaAble {
        border: 1px solid #3DA5FE;
        background: #BEE1FE;
      }
      .reaDisable {
        border: 1px solid #3DA5FE;
        background: #DDDDDD;
      }
    }
  }
}

</style>

