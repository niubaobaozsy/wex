<template>
<div class="hotel-wrap">
  <my-header title="酒店预订" @previous="goBack"></my-header>
  <div class="has-header">
    <div class="hotel-list">
      <a v-for="(item, index) in hotelList" class="item" :key="index" @click="goItem(item)">
        <img :src="item.logo">
        <span>{{ item.name }}</span>
      </a>
    </div>
    <!-- <a @click="ctripHotel">携程酒店单点登录</a> -->
  </div>
  <div ref="form" style="display: none;"></div>
</div>
</template>

<script>
import Raven from 'raven-js';
import { mapState } from 'vuex';
import { platform } from '@/platform';
import ctripLogo from '@/assets/images/trade/hotel/ctriplogo.png';
import clyhLogo from '@/assets/images/trade/hotel/clyhlogo.png';
import MyHeader from '../../common/header';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {
      hotelList: [
        {
          logo: ctripLogo,
          name: '携程酒店',
          hdl: 'ctripHotel',
        }, {
          logo: clyhLogo,
          name: '壹号酒店',
          hdl: 'clyhHotel',
        },
      ],
    };
  },
  methods: {
    goBack() {
      this.$router.push('/travel');
    },
    goItem(item) {
      this[item.hdl]();
    },
    formCreate(action, params) {
      const form = document.createElement('form');
      form.action = action;
      form.method = 'post';
      Object.keys(params).forEach((name, index) => {
        const input = document.createElement('input');
        input.name = name;
        input.value = params[name];
        form.appendChild(input);
      });
      this.$refs.form.appendChild(form);
      return {
        getForm: () => { return form },
        submit: () => {
          form.submit();
          return form;
        },
      }
    },
    ctripHotel() {
      this.showLoading('页面跳转中…');
      this.$store.dispatch('getAccessParamsForCtrip').then((rep) => {
        this.hideLoading();
        if (rep && rep.code === '0000') {
          const ctrip = {
            action: 'https://ct.ctrip.com/m/SingleSignOn/H5SignInfo',
            params: {
              accessuserid: '',
              employeeid: '',
              signature: '',
              initpage: 'HotelSearch',
              appid: '',
              token: '',
              onerror: 'errorcode',
              callback: window.location.href.replace('file://', 'mclh://'),
            },
          };
          ctrip.params = Object.assign({}, ctrip.params, rep.data);
          this.ravenCaptureMessage(`携程单点登录表单参数: ${JSON.stringify(ctrip.params)}`).finally(() => {
            this.formCreate(ctrip.action, ctrip.params).submit();
          });
        } else {
          this.showToast({ msg: `请求异常[${rep.code}]:${rep.msg}` });
        }
      });
    },
    clyhHotel() {
      this.showToast({ msg: '尚未接入，敬请期待…' });
    },
  },
  mounted() {},
}
</script>

<style lang="less" scoped>
.hotel-wrap {
  position: fixed;
  top: 0;
  bottom: 0;
  width: 100%;
  background-image: url(../../../assets/images/trade/hotel/hotelbg.jpg);
  background-repeat: no-repeat;
  background-size: cover;
}
.hotel-list {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  display: flex;
  .item {
    text-align: center;
    margin: 0 20px;
    img {
      width: 70px;
      height: 70px;
    }
    span {
      display: block;
      color: #fff;
      white-space: nowrap;
    }
  }
}
</style>

