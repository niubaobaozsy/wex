<template>
  <div ref="container" class="vue-pull-refresh" @touchstart="ontouchStart($event)" @touchmove="ontouchMove($event)" @touchend="ontouchEnd($event)" :style="style">
    <div class="vue-pull-refresh-msg">
      <div class="loadmore">
        <div class="loader">
          <div class="ball-spin-fade-loader">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
          </div>
        </div>
        <div class="loadmoreTips" v-show="tip">{{tip}}</div>
      </div>
    </div>
    <slot name="list"></slot>
  </div>
</template>
<script>
export default {
  name: 'up-loading',
  props: {
    next: { // 刷新函数
      type: Function,
      required: true,
    },
    tip: String,
  },
  data() {
    return {
      msg: '',
      flag: 0, // 表示是否达到刷新条件
      loading: 0,  // 表示是否正在刷新中
      touchStart: 0,  // 手指触摸屏幕的起点
      distance: 0,
      style: '',
      scrollTop: 0,
    };
  },
  methods: {
    getScrollTop() {
      if (document.body.scrollTop) return document.body.scrollTop;
      if (document.documentElement.scrollTop) return document.documentElement.scrollTop;
      return 0;
    },
    ontouchStart(e) {
      if (this.loading) {
        e.preventDefault();
        return;
      }
      this.touchStart = e.targetTouches[0].clientY;
      this.scrollTop = this.getScrollTop();
    },
    ontouchMove(e) {
      if (!this.touchStart) {
        return;
      }
      if (this.loading) {
        e.preventDefault();
        return;
      }
      const touch = e.targetTouches[0];
      if (this.scrollTop === 0) {
        this.distance = touch.clientY - this.touchStart;
        if (this.distance > 0) {
          e.preventDefault();
          if (this.distance < 130) {
            this.style = `overflow: inherit; transform: translate3D(0px,${this.distance}px, 0px)`;
            if (this.distance > 50) {
              this.flag = 1;
            }
          }
        }
      }
    },
    ontouchEnd(e) {
      if (this.distance === 0) {
        return;
      }
      if (this.loading) {
        e.preventDefault();
        return;
      }

      if (this.flag && this.distance > 0) {
        this.style = 'overflow: inherit; transform: translate3D(0px, 110px, 0px)';
        this.loading = 1;
        if (this.scrollTop === 0) {
          this.next().then(() => {
            this.flag = 0;
            this.loading = 0;
            this.scrollTop = 0;
            this.style = 'overflow: auto; transform: translate3D(0px, 0px, 0px)';
          });
        }
        return;
      }
      // 重置变量
      this.flag = 0;
      this.style = 'overflow: auto; transform: translate3D(0px, 0px, 0px)';
    },
  },
};
</script>
<style>
.vue-pull-refresh {
  height: 100%;
  overflow-y: auto;
  transition: 330ms;
  -webkit-overflow-scrolling: touch;
}

.vue-pull-refresh-msg {
  margin-top: -97px;
}

.loadmore {
  width: 65%;
  margin: 25px auto 30px;
  line-height: 1.6em;
  font-size: 14px;
  text-align: center;
}

.loadmoreTips {
  margin-top: 20px;
  color: #9B9B9B;
}

.loader {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 5px 0 12px;
}

@keyframes ball-spin-fade-loader {
  50% {
    opacity: 0.3;
    -webkit-transform: scale(0.3);
    transform: scale(0.3);
  }

  100% {
    opacity: 1;
    -webkit-transform: scale(1);
    transform: scale(1);
  }
}

.ball-spin-fade-loader {
  position: relative;
  height: 0.01px;
}

.ball-spin-fade-loader>div:nth-child(1) {
  top: 10px;
  left: 0;
  -webkit-animation: ball-spin-fade-loader 1s 0s infinite linear;
  animation: ball-spin-fade-loader 1s 0s infinite linear;
}

.ball-spin-fade-loader>div:nth-child(2) {
  top: 6.04545px;
  left: 7.04545px;
  -webkit-animation: ball-spin-fade-loader 1s 0.12s infinite linear;
  animation: ball-spin-fade-loader 1s 0.12s infinite linear;
}

.ball-spin-fade-loader>div:nth-child(3) {
  top: 0;
  left: 10px;
  -webkit-animation: ball-spin-fade-loader 1s 0.24s infinite linear;
  animation: ball-spin-fade-loader 1s 0.24s infinite linear;
}

.ball-spin-fade-loader>div:nth-child(4) {
  top: -6.04545px;
  left: 7.04545px;
  -webkit-animation: ball-spin-fade-loader 1s 0.36s infinite linear;
  animation: ball-spin-fade-loader 1s 0.36s infinite linear;
}

.ball-spin-fade-loader>div:nth-child(5) {
  top: -10px;
  left: 0;
  -webkit-animation: ball-spin-fade-loader 1s 0.48s infinite linear;
  animation: ball-spin-fade-loader 1s 0.48s infinite linear;
}

.ball-spin-fade-loader>div:nth-child(6) {
  top: -6.04545px;
  left: -7.04545px;
  -webkit-animation: ball-spin-fade-loader 1s 0.6s infinite linear;
  animation: ball-spin-fade-loader 1s 0.6s infinite linear;
}

.ball-spin-fade-loader>div:nth-child(7) {
  top: 0;
  left: -10px;
  -webkit-animation: ball-spin-fade-loader 1s 0.72s infinite linear;
  animation: ball-spin-fade-loader 1s 0.72s infinite linear;
}

.ball-spin-fade-loader>div:nth-child(8) {
  top: 6.04545px;
  left: -7.04545px;
  -webkit-animation: ball-spin-fade-loader 1s 0.84s infinite linear;
  animation: ball-spin-fade-loader 1s 0.84s infinite linear;
}

.ball-spin-fade-loader>div {
  background-color: #8A8A8A;
  width: 5px;
  height: 5px;
  border-radius: 100%;
  margin: 2px;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
  position: absolute;
}
</style>
