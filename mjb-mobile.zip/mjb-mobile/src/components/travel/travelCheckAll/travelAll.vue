<!--
  describe："商旅"页面 查看全部
  created by：panjm
  date：2017-10-30
-->
<template>
  <div>
    <my-header :title="'商旅订单'" @previous="goBack"></my-header>
    <Tab :tabList="tabList"></Tab>
    <div class="has-header has-tab has-footer">
      <router-view></router-view>
    </div>
    <footerBar :index="1" :tabName="'journey'"></footerBar>
  </div>
</template>

<script>
import footerBar from '../../common/footerBar';
import MyHeader from '../../common/header';
import Tab from '../../common/Tab';

export default {
  components: {
    footerBar,
    MyHeader,
    Tab,
  },
  data() {
    return {
      top: {
        title: '商旅订单',
      },
    };
  },
  computed: {
    bizOrderMenuCfg() {
      return this.$store.state.menuConfig.travel.misc.bizOrder.children;
    },
    tabList() {
      const menuArr = [];
      Object.keys(this.bizOrderMenuCfg).forEach((item) => {
        const menu = this.bizOrderMenuCfg[item];
        if (!menu.hidden) {
          menu.linkTo = menu.alias.split('/').pop();
          menuArr.push(menu);
        }
      });
      return menuArr;
    },
  },
  methods: {
    goBack() {
      this.$router.push('/travel');
    },
  },
};
</script>
