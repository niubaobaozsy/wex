<template>
  <div class="mytrip-container" infinite-scroll-immediate-check="true" v-infinite-scroll="loadMoreFun" infinite-scroll-disabled="busy">
    <div class="type-content">
      <!-- 无数据时显示 -->
      <div class="no-data-text" v-if="!allOrders.length && isLoading">
        <img class="no_data_img" :src="noDataImg" alt="">
        <p>暂无用车订单</p>
      </div>
      <div class="data-list border-bottom" v-if="allOrders.length && isLoading" v-for="(item, index) in allOrders" :key="index" @click="orderDetail('didi', item.orderId, item)">
        <div class="list-title">
          <span class="car-type" v-if="item.useCarType==='301'" :class="[{'l-width': item.status!==610, 's-width': item.status===610}]">快车</span>
          <span class="car-type" v-if="item.useCarType==='201'" :class="[{'l-width': item.status!==610, 's-width': item.status===610}]">专车</span>
          <span class="cancel" v-if="item.status===610">取消用车</span>
          <span class="finish">{{ `¥ ${(item.actualPrice * 1).toFixed(2)}`}}</span>
        </div>
        <div class="list-time">
          <img :src="timeImg">
          <span class="time">{{ timeFormat(item.createTime) }}</span>
          <div class="reason" v-if="item.reason">
            <span>{{item.reason}}</span>
          </div>
        </div>
        <div class="list-area">
          <span class="dot green"></span>
          <span class="area">{{ item.startName }}</span>
        </div>
        <div class="list-area">
          <span class="dot orange"></span>
          <span class="area">{{ item.endName }}</span>
        </div>
      </div>
      <load-more v-if="loadMore" :tip="'加载中...'" style="width: 100%;padding: 22px 0px;box-sizing: border-box;margin:0 auto"></load-more>
      <div class="no-data-text" v-if="!hasNextPage && allOrders.length">无更多订单</div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
import { mapState } from 'vuex';
import { platform } from '@/platform';
import { LoadMore } from 'vux';
import MyHeader from '../../common/header';
import timeImg from '../../../assets/images/common/historyImg.png';
import noDataImg from '../../../assets/images/common/no_data.png';

export default {
  components: {
    MyHeader,
    LoadMore,
  },
  data() {
    return {
      noDataImg,
      timeImg,
      pageInfo: {
        pageIndex: 1,
        pageSize: 20,
      },
      busy: false,
      hasNextPage: true,
      isLoading: false,
      loadMore: false,
      allOrders: [],
      extModule: {},
    };
  },
  watch: {
    showTrip() { },
  },
  computed: {
    mipAccount() {
      return this.$store.state.userInfo.employeeNumber;
    },
    ...mapState({
      car: state => state.travel.car,
      state: state => state.travel.car.state,
      order: state => state.travel.car.order,
      beforeState: state => state.travel.car.beforeState,
      baseConfig: state => state.baseConfig,
      travelMenuCfg: state => state.menuConfig.travel.children,
    }),
  },
  mounted() {
    this.showLoading();
    this.getAllOrder(1);
    if (this.baseConfig.extModuleNameList.length) {
      const extModulePathList = this.baseConfig.extModulePathList;
      this.baseConfig.extModuleNameList.forEach((moduleName, index) => {
        this.extModule[moduleName] = extModulePathList[index];
      });
      console.log(this.extModule);
    }
  },
  methods: {
    goBack() {
      this.$store.commit('CAR', Object.assign({}, this.car, { state: this.beforeState }));
      this.$router.push('/travel/didi');
    },
    // 格式化时间
    timeFormat(time) {
      if (time) {
        let payTime = new Date(time);
        const months = payTime.getMonth() + 1 < 10 ? `0${payTime.getMonth() + 1}` : payTime.getMonth() + 1;
        const dates = payTime.getDate() < 10 ? `0${payTime.getDate()}` : payTime.getDate();
        const hours = payTime.getHours() < 10 ? `0${payTime.getHours()}` : payTime.getHours();
        const minutes = payTime.getMinutes() < 10 ? `0${payTime.getMinutes()}` : payTime.getMinutes();
        payTime = `${months}月${dates}日 ${hours}:${minutes}`;
        return payTime;
      }
      return '';
    },
    orderDetail(moduleName, orderId, orderInfo) {
      if (this.travelMenuCfg[moduleName].alias.indexOf('::') > -1) {
        const aliasComponents = this.travelMenuCfg[moduleName].alias.split('::');
        if (aliasComponents[0] === 'showMxWidget' && this.extModule[moduleName]) {
          console.log(`即将调起美信插件:${this.extModule[moduleName]},并跳转订单详情页，订单号为${orderId}`);
          document.addEventListener('deviceready', () => {
            platform.showWidget(this.extModule[moduleName], {
              subModuleName: 'orderDetail',
              orderId,
            });
          }, false);
        } else {
          this.showToast({ msg: '模块配置异常' });
        }
      } else {
        if (orderInfo.status === 610 || orderInfo.status === 700) {
          this.$router.push({ path: '/travel/didi', query: { orderId, redirect: '/travel/bizOrder/didi' } });
        } else {
          this.$router.push({ path: '/travel/didi', query: { redirect: '/travel/bizOrder/didi' } });
        }
      }
    },
    // orderDetail(moduleName, orderId) {
    //   if (this.baseConfig.extModuleNameList.indexOf(moduleName) !== -1 && this.extModule[moduleName]) {
    //     if (this.baseConfig.platform === 'meixin') {
    //       document.addEventListener('deviceready', () => {
    //         platform.showWidget(this.extModule[moduleName], {
    //           subModuleName: 'orderDetail',
    //           orderId,
    //         });
    //       }, false);
    //     } else {
    //       console.log(`Todo:直接跳转:${orderId}`);
    //     }
    //   } else {
    //     console.log(`Todo:直接跳转:${orderId}`);
    //   }
    // },
    // 加载更多
    loadMoreFun() {
      const self = this;
      this.busy = true; // 禁止再次滑动加载
      if (this.hasNextPage) {
        this.loadMore = true;
        setTimeout(() => {
          self.getAllOrder();
        }, 200);
      }
    },
    /**
     * 获取用户历史订单
     */
    getAllOrder(times) {
      if (times === 1) {
        this.allOrders = [];
        this.pageInfo.pageIndex = 1;
        this.pageInfo.pageSize = 10;
      }
      const params = {
        mipAccount: this.mipAccount,
        useCarType: null,
        perPage: this.pageInfo.pageSize,
        pageNo: this.pageInfo.pageIndex,
        startNum: '1',
      };
      this.$store.dispatch('getAllOrder', params)
        .then((res) => {
          this.isLoading = true;
          this.hideLoading();
          if (res && res.errcode === '00000') {
            this.busy = false;
            if ((res.data.pageTotal * this.pageInfo.pageSize) > (this.pageInfo.pageIndex * this.pageInfo.pageSize)) {
              this.hasNextPage = true;
              this.pageInfo.pageIndex++;
            } else {
              this.hasNextPage = false;
              this.loadMore = false;
            }
            this.allOrders = this.allOrders.concat(res.data.orders);
          } else if (res && res.errmsg) {
            this.showToast({ msg: res.errmsg });
          } else {
            this.showToast({ msg: '服务器开小差了，请稍候再试！', width: '16em' });
          }
        });
    },
  },
};
</script>
<style lang="less" scoped>
@white: #ffffff;

.font {
  font-size: 14px;
  color: #858585;
  line-height: 20px;
  margin: 0 10px;
}

.green {
  background: #6CC60A;
}

.orange {
  background: #FCB23C;
}

.l-width {
  width: 80%;
}

.s-width {
  width: 60%;
}

.mytrip-container {
  background: #F4F4F4;
  .type-content {
    display: flex;
    flex-direction: column;
    .type {
      background: #F4F4F4;
      font-size: 14px;
      line-height: 20px;
      color: #9B9B9B;
      padding: 10px 15px;
    }
    .data-list {
      flex-direction: column;
      padding: 12px 15px;
      background: @white;
      div {
        display: flex;
      }
      .list-title {
        .car-type {
          font-size: 16px;
          color: #000000;
          line-height: 22px;
        }
        .doing {
          width: 20%;
          text-align: right;
          font-size: 14px;
          color: #F59B0B;
          line-height: 20px;
        }
        .appoint,
        .cancel {
          width: 20%;
          text-align: right;
          font-size: 14px;
          color: #858585;
          line-height: 20px;
        }
        .appoint {
          width: 40%;
        }
        .cancel {
          width: 20%;
        }
        .finish {
          width: 20%;
          text-align: right;
          font-size: 14px;
          color: #000000;
          line-height: 20px;
        }
      }
      .list-time {
        margin-top: 12px;
        height: 20px;
        img {
          width: 8px;
          height: 8px;
          margin: auto 0;
        }
        .time {
          width: 75%;
          .font;
        }
        .reason {
          width: 61px;
          background: #3DA5FE;
          border-radius: 12px;
          text-align: center;
          line-height: 20px;
          margin: 0;
          span {
            font-size: 11px;
            transform: scale(0.85);
            color: #FFFFFF;
            margin: auto;
          }
        }
      }
      .list-area {
        margin-top: 8px;
        height: 20px;
        .dot {
          width: 8px;
          height: 8px;
          margin: auto 0;
          border-radius: 50%;
        }
        .area {
          .font;
        }
      }
    }
    .no-data-text {
      background: #F4F4F4;
      font-size: 14px;
      line-height: 20px;
      color: #9B9B9B;
      padding: 10px 15px;
      text-align: center;
      img {
        width: 50%;
        height: 50%;
        margin-top: 20%;
      }
    }
    .border-bottom {
      &:after {
        z-index: 1;
      }
    }
  }
}
</style>
