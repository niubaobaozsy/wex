<!--
  describe："商旅"页面 查看全部(酒店)
  created by：panjm
  date：2018-01-19
  modify by: zhuangyh@20180610
-->
<template>
  <div>
    <cellBox :list="ctripOrder" @click.native="viewCtripOrder"></cellBox>
    <div ref="form" style="display: none;"></div>
  </div>
</template>

<script>
import cellBox from '@/components/common/cellBox.vue';
import ctripLogo from '@/assets/images/trade/ctriplogo.png';

export default {
  components: {
    cellBox,
  },
  data() {
    return {
      ctripOrder: [
        {
          alias: '',
          icon: ctripLogo,
          name: '携程酒店订单',
          msgCnt: '',
          desc: '查看携程酒店实时订单',
          unreadCnt: 0,
        },
      ],
    };
  },
  methods: {
    viewCtripOrder() {
      console.log('going to view ctrip order');
      this.showLoading('页面跳转中…');
      this.$store.dispatch('ctripLogin', { ele: this.$refs.form, initpage: 'HotelOrder' }).then((res) => {
        this.hideLoading();
        if (res) this.showToast(res);
      });
    }
  },
};
</script>
