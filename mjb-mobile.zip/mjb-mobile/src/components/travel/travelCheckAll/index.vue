<!--
  describe: bizOrder
  created by: panjm
  date: 2017-01-19
-->
<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>
