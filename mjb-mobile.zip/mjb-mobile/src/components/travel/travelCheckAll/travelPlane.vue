<!--
  describe："商旅"页面 查看全部(飞机)
  created by：panjm
  date：2018-01-19
-->
<style lang="less" scoped>
@import '../../../assets/css/travel/travel.less';
</style>
<template>
  <div infinite-scroll-immediate-check="true" v-infinite-scroll="loadMoreFun" infinite-scroll-disabled="busy">
    <div v-if="orderInfos.length && isLoading" v-for="(orderInfo, index) in orderInfos" :key="index" class="border-bottom">
    <div :class="['orders', {'disable':getOrderStatus(orderInfo.orderStatus, orderInfo.orderType) === '订单已取消'}]" @click="getOrderDetail('flight', orderInfo.orderNo)">
      <div class="firstLine">
        <div class="firstLineLeft">
          <span class="firstLine-item mr-10">{{ orderInfo.orgCity }}</span>
          <span class="slot">···</span>
          <i class="iconfont icon-aircraft icon-flight"></i>
          <span class="slot">···</span>
          <span class="firstLine-item ml-10">{{ orderInfo.desCity }}</span>
        </div>
        <span class="firstLine-item" v-if="orderInfo.orderPrice">￥{{ orderInfo.orderPrice }}</span>
        <span class="firstLine-item" v-else></span>
      </div>
      <div class="secondLine">
        <div>
          <span class="time">出发时间</span>
          <span class="time">{{ formatDate(orderInfo.depTime, 'yyyy/MM/dd hh:mm') }}</span>
        </div>
        <div>
          <span class="state">{{ getOrderStatus(orderInfo.orderStatus, orderInfo.orderType) }}</span>
        </div>
      </div>
      <div class="thirdLine">
        <span class="flight">航班</span>
        <span class="flight">{{ orderInfo.flightNo }}</span>
        <span class="flight">{{ orderInfo.desAirport }}</span>
      </div>
      <div class="fourthLine">
        <div class="fourthLineBox">
          <span class="fourthLine-item">下单时间</span>
          <span class="fourthLine-item">{{ formatDate(orderInfo.createDate, 'yyyy/MM/dd') }}</span>
        </div>
        <div class="fourthLineBox">
          <span class="fourthLine-item">订单号</span>
          <span class="fourthLine-item">{{ orderInfo.orderNo }}</span>
        </div>
      </div>
    </div>
    </div>
    <load-more v-if="loadMore" :tip="'加载中...'" style="width: 100%;padding: 22px 0px;box-sizing: border-box;margin:0 auto 50px"></load-more>
    <div v-if="!orderInfos.length && isLoading" class="emptyBox">
      <img class="no_data_img" :src="noDataImg" alt="">
      <p class="no_data_text">暂无订单</p>
    </div>
  </div>
</template>

<script>
import { LoadMore } from 'vux';
import { platform } from '@/platform'; // 周六消费发版后放开
import { formatDate } from '../../../js/util.js';
import noDataImg from '../../../assets/images/common/no_data.png';

export default {
  components: {
    LoadMore,
  },
  data() {
    return {
      noDataImg,
      orderInfos: [],
      isLoading: false,
      busy: false,
      loadMore: false,
      hasNextPage: true,
      pageInfo: {
        pageIndex: 1,
        pageSize: 10,
      },
      extModule: {},
    };
  },
  computed: {
    baseConfig() {
      return this.$store.state.baseConfig;
    },
    travelMenuCfg() {
      return this.$store.state.menuConfig.travel.children;
    },
  },
  methods: {
    getPlaneOrder() {
      const param = {
        orderType: 1,
        pageIndex: this.pageInfo.pageIndex,
        pageSize: this.pageInfo.pageSize,
      };
      this.$store.dispatch('getTicketOrders', param).then((res) => {
        this.hideLoading();
        this.busy = false;
        this.loadMore = false;
        this.isLoading = true;
        if (res && res.code === '1') {
          if (res.data && res.data.data) {
            if (res.data.total > (this.pageInfo.pageIndex * this.pageInfo.pageSize)) {
              this.hasNextPage = true;
              this.pageInfo.pageIndex++;
            } else {
              this.hasNextPage = false;
            }
            this.orderInfos = this.orderInfos.concat(res.data.data);
            console.log('参数', this.orderInfos.length);
          }
        } else if (res && res.code) {
          this.loadMore = false;
          this.showToast({ msg: res.resultMsg });
        }
      });
    },
    getOrderDetail(moduleName, orderId) {
      if (this.travelMenuCfg[moduleName].alias.indexOf('::') > -1) {
        const aliasComponents = this.travelMenuCfg[moduleName].alias.split('::');
        if (aliasComponents[0] === 'showMxWidget' && this.extModule[moduleName]) {
          console.log(`即将调起美信插件:${this.extModule[moduleName]},并跳转订单详情页，订单号为${orderId}`);
          document.addEventListener('deviceready', () => {
            platform.showWidget(this.extModule[moduleName], {
              subModuleName: 'orderDetail',
              orderId,
            });
          }, false);
        } else {
          this.showToast({ msg: '模块配置异常' });
        }
      } else {
        this.$router.push({ path: '/travel/plane/orderDetail', query: { orderNo: orderId, redirect: '/travel/bizOrder/plane' } });
      }
    },
    // getOrderDetail(moduleName, orderId) {
    //   // console.log(`Todo:直接跳转:${moduleName}${orderId}`);
    //   if (this.baseConfig.extModuleNameList.indexOf(moduleName) !== -1 && this.extModule[moduleName]) {
    //     if (this.baseConfig.platform === 'meixin') {
    //       document.addEventListener('deviceready', () => {
    //         platform.showWidget(this.extModule[moduleName], {
    //           subModuleName: 'orderDetail',
    //           orderId,
    //         });
    //       }, false);
    //     } else {
    //       console.log(`Todo:直接跳转:${orderId}`);
    //       this.$router.push({ path: '/travel/plane/orderDetail', query: { orderNo: orderId, redirect: '/travel/bizOrder/plane' } });
    //     }
    //   } else {
    //     console.log(`Todo:直接跳转:${orderId}`);
    //     this.$router.push({ path: '/travel/plane/orderDetail', query: { orderNo: orderId, redirect: '/travel/bizOrder/plane' } });
    //   }
    // },
    formatDate(timestamp, fmt) {
      return formatDate(timestamp, fmt);
    },
    getOrderStatus(orderStatus, orderType) {
      let obj = {};
      if (orderType === 1) {
        obj = {
          ao_1: '待处理',
          ao_2: '出票中',
          ao_3: '出票成功',
          ao_4: '订单已取消',
          ao_5: '出票失败',
        };
      } else if (orderType === 2) {
        obj = {
          ao_1: '待退票',
          ao_2: '退票受理中',
          ao_3: '退票成功',
          ao_4: '订单已取消',
          ao_5: '退票失败',
        };
      } else if (orderType === 3) {
        obj = {
          ao_1: '待改签',
          ao_2: '改签受理中',
          ao_3: '改签成功',
          ao_4: '订单已取消',
          ao_5: '改签失败',
        };
      }
      return obj[`ao_${orderStatus}`];
    },
    loadMoreFun() {
      this.busy = true; // 禁止再次滑动加载
      if (this.hasNextPage) {
        this.loadMore = true;
        setTimeout(() => {
          this.getPlaneOrder();
        }, 800);
      }
    },
  },
  mounted() {
    this.showLoading();
    this.getPlaneOrder();
    if (this.baseConfig.extModuleNameList.length) {
      const extModulePathList = this.baseConfig.extModulePathList;
      this.baseConfig.extModuleNameList.forEach((moduleName, index) => {
        this.extModule[moduleName] = extModulePathList[index];
      });
      console.log(this.extModule);
    }
  },
};
</script>
<style lang="less" scoped>
.emptyBox{
  text-align: center;
  .no_data_img {
    display: block;
    margin: 20% auto 10px;
    width: 50%;
  }
  .no_data_text {
    color: #6e7481;
  }
}
</style>
