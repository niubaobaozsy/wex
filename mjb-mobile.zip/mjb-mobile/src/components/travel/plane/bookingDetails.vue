<!--
  describe：机票预订详情页
  created by：Guanxj
  date：2018-1-5
-->
<template>
  <div>
    <my-header  @previous="goBack" :rightTitle="searchTicket.departureText" :leftTitle="searchTicket.arrivalText" :titleImg="arrow" :showImgTitle="true"></my-header>
    <div class="has-header main">
      <ul class="information border-top">
        <li class="information-list border-bottom">
          <div class="list-left">
            <div class="baseInfo">
              <img :src="airlinesIcon" alt="" class="airlines">
              <span>{{flightInfo.airlineName}}</span>
              <span>{{flightInfo.flightNo}}</span>
              <span>{{flightInfo.departureDate}}</span>
            </div>
            <div class="flightInfo">
              <div class="departureTime">{{flightInfo.depTime}}</div>
              <img :src="arrow" alt="" class="arrow">
              <div class="arrivalTime">
                {{flightInfo.arrTime}}
                <span class="addDays" v-if="addDays">+{{addDays}}天</span>
              </div>
            </div>
            <div class="locationInfo">
              <span>{{flightInfo.orgAirport}}</span>
              <span class="duration">{{duration}}</span>
              <span>{{flightInfo.desAirport}}</span>
            </div>
          </div>
        </li>
      </ul>
      <ul class="information border-top">
        <li class="information-list">
          <div class="list-left">
            <div class="tabs-bar">
              <div class="tabs-bar-nav">
                <div class="tabs-tab" v-for="(tab,index) in tabList" :key="index" @click="changeTab(tab.linkTo)">
                  <div class="title" :class="{'tabs-active': currentLinkTo === tab.linkTo }">
                    {{tab.name}}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </li>
        <li class="information-list border-bottom" v-for="(item, index) in ticketList" :key="index">
          <div class="list-left">
            <p class="price"><span>￥{{item.ticketPrice}}</span></p>
            <p class="normal">
              <span>{{item.airlines}}</span>
              <span>{{item.cabin}}</span>
              <span class="protocol" v-if="item.protocolType">协议</span>
              <!-- todo: use event delegation to optimize -->
              <!-- <span @click="openInstruction4changeTicket(item.refundChangeInfo)" class="change">允许退改签</span> -->
              <span @click="openChangeRule(item.refundChangeInfo, item.ticketPrice, item.cabin)" class="change">允许退改签</span>
              <img :src="rArrow" alt="" class="r-arrow">
            </p>
          </div>
          <div class="list-right">
            <div class="badge" @click="advanceBooking(item)">
              <span>预订</span>
            </div>
            <div class="seatNum">余票：>{{ item.seatNum === 'A' ? 9 : item.seatNum }}</div>
          </div>

        </li>
        <li class="emptyBox" v-if="!ticketList.length && !isLoading">
          <img class="no_data_img" :src="noDataImg" alt="">
          <p class="no_data_text">暂无该类型舱位</p>
        </li>
      </ul>
    </div>
    <transition
      name="custom-classes-transition"
      enter-active-class="animated fadeInUp"
      leave-active-class="animated fadeOutDown"
    >
    <div class="instruction4changeTicket" v-if="instruction4changeTicket.visible">
      <h3 class="text-center">退改签说明</h3>
      <p class="instructionContent">{{instruction4changeTicket.content}}</p>
      <span v-html="'&#215;'" class="closeInstruction" @click="closeInstruction4changeTicket()"></span>
    </div>
    </transition>
    <plane-change-rule :show.sync="showPlaneRule" :changeInfo="changeInfo" @on-hide="hidePlaneRlue"/>
  </div>
</template>
<script>
import MyHeader from '../../common/header';
import planeChangeRule from '../../common/planeChangeRule';
import arrow from '../../../assets/images/trade/plane/arrow.png';
import easternAirlines from '../../../assets/images/trade/logo.png';
import noDataImg from '../../../assets/images/common/no_data.png';
import rArrow from '../../../assets/rt-arrow.png';

export default {
  components: {
    MyHeader,
    planeChangeRule,
  },
  data() {
    return {
      easternAirlines,
      arrow,
      noDataImg,
      rArrow,
      isLoading: true,
      tabList: [
        {
          name: '经济舱',
          linkTo: 'substantialTab',
        },
        {
          name: '头等舱',
          linkTo: 'luxuryTab',
        },
      ],
      airlinesIcon: easternAirlines,
      duration: '',
      currentLinkTo: 'substantialTab',
      substantialList: [],
      luxuryList: [],
      ticketList: [],
      addDays: 0,
      instruction4changeTicket: {
        visible: false,
        content: ''
      },
      showPlaneRule: false,
      changeInfo: []
    };
  },
  computed: {
    searchTicket() {
      return this.$store.state.travel.searchTicket;
    },
    flightInfo() {
      return this.$store.state.travel.selectedTicketInfo;
    },
    endorseOrderNo() {
      return this.$store.state.travel.endorse.orderNo;
    },
    suppliers() {
      const ticketFilter = this.$store.state.travel.ticketFilter;
      if (ticketFilter) {
        if (ticketFilter.suppliers.selected.length === 1) return ticketFilter.suppliers.selected[0];
      }
      return '';
    },
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    changeTab(linkTo) {
      this.currentLinkTo = linkTo;
      if (linkTo === 'substantialTab') {
        this.ticketList = this.substantialList;
      } else {
        this.ticketList = this.luxuryList;
      }
    },
    advanceBooking(data) {
      if (this.endorseOrderNo) {
        this.$store.commit('ENDORSE', { flightInfo: this.flightInfo, priceInfo: data });
        this.$router.push({ path: '/travel/plane/changeApply' });
      } else {
        this.$store.commit('BOOKINGTICKETINFO', data);
        this.$router.push({ path: '/travel/plane/ticketOrder' });
      }
    },
    getTicketList(params) {
      this.$store.dispatch('getFlightPrice', params).then((res) => {
        if (res.data !== null && res.code === '1') {
          res.data.forEach((item) => {
            item.airlines = item.vendorNumber === 100 ? '美亚' : '一起飞';
            if (item.cabin === '经济舱') {
              this.substantialList.push(item);
            } else {
              this.luxuryList.push(item);
            }
          });
          if (this.currentLinkTo === 'substantialTab') {
            this.ticketList = this.substantialList;
          } else {
            this.ticketList = this.luxuryList;
          }
        }
        this.isLoading = false;
      });
    },
    getTimeGap(starDate, starTime, endDate, endTime) {
      const star = `${starDate}T${starTime}`;
      const end = `${endDate}T${endTime}`;
      const dayGap = parseInt((Math.abs(new Date(endDate) - new Date(starDate))) / (24 * 60 * 60 * 1000), 0);
      const timeGap = Math.abs(new Date(end) - new Date(star));
      const hour = parseInt(timeGap / (60 * 60 * 1000), 0);
      const minute = parseInt((timeGap % (60 * 60 * 1000)) / (60 * 1000), 0);
      const timeGapStr = `约${hour}时${minute}分`;
      return {
        dayGap,
        timeGapStr,
      };
    },
    openInstruction4changeTicket(content) {
      // if (content) this.instruction4changeTicket.content = content;
      // this.instruction4changeTicket.visible = true;

    },
    closeInstruction4changeTicket() {
      this.instruction4changeTicket.content = '';
      this.instruction4changeTicket.visible = false;
    },
    openChangeRule(refundChangeInfo, ticketPrice, cabin) {
      this.changeInfo = [];
      let changeInfo = {
        refundChangeInfo,
        ticketPrice,
        cabin
      }
      this.changeInfo.push(changeInfo);
      this.showPlaneRule = true;
    },
    hidePlaneRlue() {
      this.showPlaneRule = false;
    }
  },
  mounted() {
    const params = {
      key: this.searchTicket.key,
      flightNo: this.flightInfo.flightNo,
    };
    if (this.suppliers) {
      params.suppliers = this.suppliers;
    }
    this.getTicketList(params);
    const timeGap = this.getTimeGap(this.flightInfo.depDate, this.flightInfo.depTime, this.flightInfo.arrDate, this.flightInfo.arrTime);
    this.duration = timeGap.timeGapStr;
    this.addDays = timeGap.dayGap;
    this.$store.commit('SELECTEDTICKETINFO', Object.assign({}, this.flightInfo, { duration: this.duration, addDays: this.addDays }));
  },
};
</script>
<style lang="less" scoped>
  .main {
    .information{
      margin-bottom: 8px;
      .information-list{
        display: flex;
        margin-bottom: 1px;
        padding: 0 15px;
        background: #FFFFFF;
        font-size: 14px;
        .list-left {
          display: flex;
          flex: 1;
          flex-flow: column;
          .baseInfo {
            display: flex;
            margin-top: 20px;
            .airlines {
              width: 16px;
              height: 16px;
            }
            span {
              margin-right: 10px;
              color: #808080;
            }
          }
          .flightInfo {
            display: flex;
            justify-content: center;
            .arrow {
              width: 44px;
              height: 16px;
              margin: auto 0;
              margin-bottom: 12px;
            }
            .departureTime {
              font-size: 24px;
              margin: 10px 40px 0 40px;
            }
            .arrivalTime{
              position: relative;
              display: flex;
              flex-direction: row;
              font-size: 24px;
              margin: 10px 40px 0 40px;
              .addDays {
                position: absolute;
                top: 0;
                right: -30px;
                word-break: keep-all;
                font-size: 12px;
              }
            }
          }
          .locationInfo {
            display: flex;
            justify-content: center;
            margin-bottom: 15px;
            span {
              color: #808080;
              font-size: 12px;
            }
            .duration {
              margin: 0 30px;
            }
          }
          .tabs-bar {
            height: 50px;
            line-height: 50px;
            background: #fff;
            font-size: 16px;
            .tabs-bar-nav {
              margin: 0 auto;
              height: 100%;
              width: 100%;
              display: flex;
              justify-content: center;
              align-items: center;
              .tabs-tab {
                margin: auto;
              }
              .title {
                height: 47px;
                display: -webkit-inline-box;
                position: relative;
              }
              .tabs-active {
                border-bottom: 3px solid #3DA5FE;
              }
            }
          }
          .price {
            font-size: 24px;
            color: #3DA5FE;
            margin-top: 12px;
          }
          .normal {
            margin-bottom: 15px;
            .change {
              color: #3DA5FE;
              margin-left: 3px;
            }
            .protocol {
              color: red;
              margin-left: 3px;
            }
            .r-arrow {
              width: 6px;
            }
          }
        }
        .list-right {
          width: auto;
          margin-top: 20px;
          .r-arrow {
            display: block;
            width: 9px;
            height: 16px;
            margin-left: 15px;
          }
          .badge {
            span {
              padding: 4px 16px;
              margin: 0 10px;
              border-radius: 16px;
              font-size: 14px;
              color: #3DA5FE;
              word-break: keep-all;
              border-color: #3DA5FE;
              border: solid 0.5px;
            }
          }
          .seatNum {
            color: grey;
            margin-left: 13px;
            margin-top: 7px;
          }
        }

      }
    }
  }
.emptyBox{
  text-align: center;
  background-color: #fff;
  .no_data_img {
    display: block;
    margin: 30px auto 10px;
    width: 50%;
  }
  .no_data_text {
    color: #6e7481;
    padding-bottom: 30px;
  }
}

.instruction4changeTicket {
  position: fixed;
  width: 100vw;
  height: 100vh;
  background-color: rgba(255, 255, 255, .7);
  padding: 2.5em 1em;

  .instructionContent {
    margin-top: 1.7em;
    text-indent:2em;
  }

  .closeInstruction {
    cursor: pointer;
    font-weight: lighter;
    position: absolute;
    bottom: 3em;
    left: 0;
    right: 0;
    margin: 0 auto;
  }
}
</style>

