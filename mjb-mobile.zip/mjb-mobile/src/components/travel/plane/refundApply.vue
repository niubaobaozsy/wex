<!--
  describe："机票———退票申请"
  created by：Yim Lee
  date：2018-1-9
-->
<template>
  <div>
    <my-header title="退票申请" @previous="goBack"></my-header>
    <div class="has-header change-wrap">
      <!-- 第一步 -->
      <div class="step-one border">
        <div class="text border-bottom">第一步：选择乘机人</div>
        <div class="passenger-select">
          <div :class="[{'border-top': index!==0, 'unable': item.ticketInstanceStatus!==2}, 'passenger']" v-for="(item, index) in passengers" :key="index" @click="selectPassenger(item)">
            <span class="name">{{ item.passengerName }}</span>
            <span :class="['to-select', {'selected': item.selected}]"></span>
          </div>
        </div>
      </div>
      <!-- 第二步 -->
      <div class="step-two border">
        <div class="text border-bottom">第二步：选择退票原因</div>
        <div class="reason-select" @click="showSelect = true">
          <span class="reason-text">退票原因</span>
          <span class="reason">{{ reason }}</span>
          <img :src="rightArrow">
        </div>
      </div>
    </div>
    <div class="footer" @click="submit">提交申请</div>
    <apply-tip v-if="showTip" mainTitle="申请退票成功" @go-home="$router.push('/travel')" @go-detail="goDetail"></apply-tip>
    <select-data :show.sync="showSelect" :title="'退票原因'" :selectData="refundReason" @select="selectReason"></select-data>
  </div>
</template>
<script type="text/ecmascript-6">
import { mapState } from 'vuex';
import MyHeader from '../../common/header';
import rightArrow from '../../../assets/rt-arrow.png';
import ApplyTip from './applyTip';
import SelectData from '../../common/selectData';

export default {
  components: {
    MyHeader,
    ApplyTip,
    SelectData,
  },
  data() {
    return {
      rightArrow,
      showTip: false,
      showSelect: false,
      refundOrder: {},
      passengers: [],
      refundReason: [ // 退票申请原因
        {
          text: '行程改变',
        },
        {
          text: '下单时选错日期/航班',
        },
        {
          text: '下单时填错乘机人/联系人信息',
        },
        {
          text: '在其他渠道发现更优惠的机票',
        },
        {
          text: '航班延误或取消，航班时刻变更',
        },
        {
          text: '其他',
        },
      ],
      reason: '行程改变',
      refundOrderNo: '',
    };
  },
  watch: {
  },
  computed: {
    ...mapState({
    }),
  },
  created() {
  },
  mounted() {
    this.getOrderDetail();
  },
  methods: {
    goBack() {
      this.$router.go(-1);
      // if (this.showTip) {
      //   this.showTip = false;
      // } else {
      //   this.$router.go(-1);
      // }
    },
    // 选择乘机人
    selectPassenger(item) {
      if (item.ticketInstanceStatus === 2) {
        item.selected = !item.selected;
      } else {
        this.showToast({ msg: '不支持该乘机人退票' });
      }
    },
    // 选择退票原因
    selectReason(reason) {
      this.reason = reason.text;
    },
    // 提交申请
    submit() {
      const passengerId = [];
      this.passengers.forEach((passenger) => {
        if (passenger.selected) {
          passengerId.push(passenger.passengerId);
        }
      });
      this.showLoading('提交中…');
      this.$store.dispatch('createRefundApply', {
        orderNo: this.$route.query.orderNo,
        passengerId,
        refundReason: this.reason,
      }).then((res) => {
        this.hideLoading();
        if (res.code === '1' && res.data) {
          this.refundOrderNo = res.data[0];
          this.showTip = true;
        } else if (res && res.resultMsg) {
          this.showToast({ msg: res.resultMsg });
        }
      });
    },
    // 获取订单详情
    getOrderDetail() {
      this.showLoading();
      this.$store.dispatch('getOrderByOrderNo', { orderNo: this.$route.query.orderNo })
      .then((res) => {
        this.hideLoading();
        if (res && res.resultFlag === 1) {
          res.data.passengerDtos.forEach((item) => {
            item.selected = false;
          });
          this.refundOrder = res.data;
          this.passengers = res.data.passengerDtos;
        } else if (res && res.resultMsg) {
          this.showToast({ msg: res.resultMsg });
        }
      });
    },
    // 点击查看订单详情
    goDetail() {
      this.$router.push({
        path: '/travel/plane/orderDetail', query: { orderNo: this.refundOrderNo, redirect: 'refundTicketOrders' },
      });
    },
  },
};
</script>
<style lang="less" scoped>
.change-wrap {
  overflow: hidden;
  .step-one,
  .step-two,
  .step-three {
    background: #FFFFFF;
    margin-top: 10px;
    .text {
      line-height: 44px;
      font-size: 14px;
      color: #858585;
      padding: 0 15px;
    }
    .passenger-select {
      padding-left: 15px;
      .passenger {
        height: 50px;
        display: flex;
        flex-wrap: nowrap;
        align-items: center;
        padding-right: 15px;
        .name {
          display: flex;
          flex: 1;
          font-size: 16px;
          color: #000000;
          line-height: 50px;
        }
        .to-select {
          display: flex;
          width: 18px;
          height: 18px;
          box-sizing: border-box;
          border-radius: 50%;
          border: 1px solid #ADADAD;
        }
        .selected {
          border: 0px;
          background-image: url(../../../assets/images/common/checked.png);
          background-repeat: no-repeat;
          background-position: center;
          background-size: contain;
        }
      }
      .unable {
        .name {
          color: #ADADAD;
        }
        .to-select {
          background-color: #d1d1d1;
        }
      }
    }
    .reason-select {
      padding: 0 15px;
      height: 50px;
      display: flex;
      flex-wrap: nowrap;
      align-items: center;
      .reason-text,
      .reason {
        display: flex;
        font-size: 16px;
        color: #000000;
        // line-height: 50px;
      }
      .reason-text {
        flex: 0.4;
      }
      .reason {
        flex: 1;
        justify-content: flex-end;
        color: #666666;
      }
      img {
        width: 8px;
        height: 13px;
        margin-left: 10px;
      }
    }
  }
}

.footer {
  position: fixed;
  width: 100%;
  bottom: 0;
  line-height: 50px;
  font-size: 18px;
  color: #FFFFFF;
  text-align: center;
  background: #3DA5FE;
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.10);
  padding: 0 15px;
  box-sizing: border-box;
  z-index: 99;
}
</style>
