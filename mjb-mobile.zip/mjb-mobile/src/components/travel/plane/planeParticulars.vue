<!--
  describe：机票详情组件
  created by：zhoujk
  date：2018-01-03
-->
<template>
  <div>
    <div class="plane-box" v-if="show">
      <div class="plane-bg" @click="goHide"></div>
      <div class="plane-content">
        <div class="plane-c-t">
          <div class="bd-plane">
            <div class="column-v timer">
            <span class="first-s fn-6">{{searchTicket.departureDate}}</span>
            <div>{{flightInfo.depTime}}</div>
            <span class="fn-6 second-s">{{flightInfo.orgAirport}}</span>
          </div>
          <div class="column-v text-c">
            <div class="fs-d">{{priceDetailInfo.airlines}} {{priceDetailInfo.cabin}}</div>
            <img :src = 'Arrows'>
            <div class='fn-6 fs-d'>{{flightInfo.flightNo}}&nbsp;|&nbsp;{{flightInfo.airlineName}}</div>
          </div>
          <div class='column-v timer'>
            <span class='first-s fn-6'>{{flightInfo.duration}}</span>
            <div class="reletive">{{flightInfo.arrTime}}<div class='add-date fn-6' v-if="flightInfo.addDays">+{{flightInfo.addDays}}天</div></div>
            <span class="fn-6 second-s">{{flightInfo.desAirport}}</span>
          </div>
          </div>
        </div>
        <div class="plane-c-b">
          <div class="fn-0">票价<span class='fn-1'>¥{{priceDetailInfo.ticketPrice}}</span></div>
          <div class="fn-6">基建+燃油<span class="fn-1">¥{{priceDetailInfo.airPortFee + priceDetailInfo.oilFee}}</span></div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import arrows from '../../../assets/images/trade/jiantou@2x.png';

export default {
  components: {
    // choicePeople,
  },
  props: {
    showList: Object,
    show: Boolean,
  },
  data() {
    return {
      Arrows: arrows,
    };
  },
  computed: {
    searchTicket() {
      return this.$store.state.travel.searchTicket;
    },
    priceDetailInfo() {
      return this.$store.state.travel.bookingTicketInfo;
    },
    flightInfo() {
      return this.$store.state.travel.selectedTicketInfo;
    },
  },
  methods: {
    goHide() {
      this.$emit('on-hide');
    },
  },
};
</script>
<style lang="less" scoped>
.fn-6 {
  color:#666666!important;
}
.fn-0 {
  color: #000000;
}
.fn-1 {
  color:#3DA5FE;
}
.fs-d {
  font-family: PingFang-SC-Regular;
  font-size: 14px;
  line-height: 14px;
}
.column-v {
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.text-c {
  display: flex;
  flex-direction: column;
  align-items: center;
  img {
    width:110px;
    height:5.7px;
    margin-top:7px;
    margin-bottom:10px;
  }
}
.plane-box {
  .plane-bg {
    position: fixed;
    z-index: 2002;
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    }
  .plane-content {
    position: fixed;
    z-index: 5000;
    top: 50%;
    left: 50%;
    width:100%;
    transform: translate(-50%, -50%);
    background-color: #FFFFFF;
    width:95%;
    padding:20px 0;
    .plane-c-t {
      padding: 0 22px;
      .bd-plane {
        padding-bottom:20px;
        display: flex;
        justify-content: space-between;
        border-bottom:  1px dotted #C1C1C1;
        .timer {
        .reletive {
          position: relative;
        }
        .add-date {
          font-family: HelveticaNeue;
          font-size: 12px;
          line-height: 16px;
          position: absolute;
          top:-8px;
          right:-14px;
        }
        .first-s {
          font-family: HelveticaNeue;
          font-size: 16px;
          line-height: 16px;
        }
        div {
          font-family: HelveticaNeue-Medium;
          font-size: 24px;
          color: #000000;
          line-height: 24px;
          margin-top:8px;
        }
        .second-s {
          font-family: PingFangSC-Regular;
          font-size: 12px;
          line-height: 12px;
          margin-top:10px;
        }
        }
      }
    }
    .plane-c-b {
      padding: 18px 0 0 22px;
      font-size: 16px;
      line-height: 22px;
      div:nth-child(2){
        margin-top:6px;
      }
      span {
        margin-left:5px;
      }
    }
  }
}
</style>
