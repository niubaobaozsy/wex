<!--
  describe：选择乘机人
  created by：zhoujk
  date：2018-01-03
-->
<template>
  <div class="main">
    <my-header title="选择乘机人" rightItem="完成" @previous="goBack" @on-click="onClose" ></my-header>
    <div>
      <div class='choice-box has-header has-footer'>
        <div class='choice-list fix-IOS-scroll'>
          <div class='choice-c border-bottom' v-for="(item, index) in  travelsData" :key="index">
            <div class='choice-l' @click="checkedChoose(item)">
              <span class="check-box" :class="{'checked': item.isSelected}"></span>
              <div class='choice-t'>
                <div><section>{{item.cnName}}</section>&nbsp;<div>({{item.name}} <span>{{item.certNumber}}</span>)</div></div>
                <div>手机号码&nbsp;{{item.mobile}}</div>
              </div>
            </div>
            <div class='choice-r' @click="passengerEdit(item)"><img :src="edit"/></div>
          </div>
        </div>
        <div class="addMsg" @click="addPassengerEdit()">
          <img :src="add">
          <span>新增乘机人</span>
        </div>
      </div>
    </div>
    <editPassenger v-if="showEdit" :passenger="currentEditPassenger" @on-hide="hideArea" @complete="editPsgComplete" />
  </div>
</template>
<script>
import MyHeader from '../../common/header';
import edit from '../../../assets/images/trade/plane/edit.png';
import add from '../../../assets/images/trade/plane/add.png';
import editPassenger from './passengerEdit';

export default {
  components: {
    MyHeader,
    editPassenger,
  },
  props: {
    passengers: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      edit,
      add,
      travelsData: [],
      currentEditPassenger: {},
      list: [
        {
          userName: '唐僧',
          praps: '身份证',
          number: '123123123241231231',
          tel: '13821312312',
        },
      ],
      showEdit: false,
    };
  },
  // computed: {
  //   passenger() {
  //     return this.$store.state.travel.passenger;
  //   },
  // },
  methods: {
    onClose() {
      this.$emit('updatePassengers', this.travelsData);
      this.$emit('on-hide');
    },
    goBack() {
      this.$emit('on-hide');
    },
    // 把选中的乘机人信息保存
    checkedChoose(item) {
      item.isSelected = !item.isSelected;
    },
    addPassengerEdit() {
      this.currentEditPassenger = {};
      // this.$store.commit('PASSENGERLIST', {});
      this.showEdit = true;
    },
    passengerEdit(passenger) {
      // this.$store.commit('PASSENGERLIST', list);  // 编辑乘机人
      this.currentEditPassenger = passenger;
      setTimeout(() => {
        this.showEdit = true;
      }, 300);
    },
    getTravelMsg() {},
    hideArea() {
      this.showEdit = false;
    },
    editPsgComplete(passenger, type) {
      if (type === 'addPassenger') {
        passenger.isSelected = false;
        this.travelsData.unshift(passenger);
      } else {
        this.travelsData.every((item, index) => {
          if (item.commPassengerId === passenger.commPassengerId) {
            if (type === 'editPassenger') {
              passenger.isSelected = false;
              this.travelsData[index] = passenger;
            } else if (type === 'delPassenger') {
              this.travelsData.splice(index, 1);
            }
            return false;
          }
          return true;
        });
      }
    },
  },
  mounted() {
    this.travelsData = this.passengers;
    // if (this.passenger.length > 0) {
    //   this.travelsData = this.passenger;
    // } else {
    //   setTimeout(() => {
    //     this.getTravelMsg();
    //   }, 500);
    // }
  },
};
</script>
<style lang="less" scoped>
.main {
  position: fixed;
  z-index: 99;
  top:0;
  left:0;
  right:0;
  bottom:0;
  background: #f2f2f2;
  overflow-y: scroll;
}
.f-col-0 {
  color:#000000;
}
.f-col-6 {
  color:#2A2A2A;
}
.choice-box {
  .choice-list {
    background: #ffffff;
    padding-left:14px;
    .choice-c {
      padding: 14px 23px 14px 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .choice-l {
        display: flex;
        align-items: center;
        .check-box {
          display: block;
          box-sizing: border-box;
          width: 18px;
          height: 18px;
          margin-right:15px;
          border-radius: 9px;
          border: 1px #ADADAD solid;
        }
        .checked {
          border: 0px;
          background-image: url(../../../assets/images/common/checked.png);
          background-repeat: no-repeat;
          background-position: center;
          background-size: contain;
        }
        .choice-t {
          div {
            font-size: 16px;
            color: #666666;
            line-height: 22px;
            display: flex;
            section {
              color:#000000;
            }
            span {
              width:138px;
              display: inline-block;
              overflow: hidden;
              text-overflow:ellipsis;
              white-space: nowrap;
            }
          }
        }
      }
      .choice-r {
        img {
          width:16.3px;
          height:16.3px;
        }
      }
    }
  }
  .addMsg {
    height: 50px;
    position: fixed;
    bottom:0;
    left: 0;
    right:0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3DA5FE;
    img {
      width:12px;
      height:12px;
      margin-right: 4px;
    }
    span {
      font-size: 18px;
      color: #FFFFFF;
    }
  }
}
</style>
