<!--
  describe：机票首页
  created by：Yim Lee
  date：2017-12-28
-->

<template>
  <div class="ticket-wrap">
    <my-header title="机票预订" @previous="goBack" rightItem="常用旅客" @on-click="setPassengers"></my-header>
    <div class="bg has-header"><img :src="bg"></div>
    <div class="main">
      <div class="message">
        <div class="area">
          <span @click="openArea('start')" :class="['border-bottom', {grey: !searchParams.departureText}]">{{ searchParams.departureText || '出发地' }}</span>
          <img :src="plane" @click="changeArea">
          <span @click="openArea('end')" :class="['border-bottom', {grey: !searchParams.arrivalText}]">{{ searchParams.arrivalText || '目的地' }}</span>
        </div>
        <div class="date border-bottom" @click="openCalendar">
          <span v-if="selectDate" class="big-date">{{ formatDate(selectDate) }}</span>
          <span v-if="selectDate" class="small-date">{{ getDay() }}</span>
          <span v-else class="small-date">请选择时间</span>
        </div>
        <div class="search-btn" @click="toSearch">搜索</div>
        <div class="btn">
          <div class="talk-btn border-right" @click="customService">联系客服</div>
          <div class="order-btn" @click="$router.push('/travel/plane/orderIndex')">我的订单
            <!-- <span class="dot"></span> -->
          </div>
        </div>
      </div>
      <div class="usually-travel">
        <span class="travel" v-for="(commonCitie, index) in commonCities" :key="index" @click="setAreaQuick(commonCitie)">
          {{ commonCitie.departureText }}-{{ commonCitie.arrivalText }}
        </span>
        <span class="clear" @click="clear">清除历史</span>
      </div>
    </div>
    <select-city v-if="showCity" :headTitle="headTitle"  @select-city="selectCity" tempType="plane" @close-panel="showCity=false;"></select-city>
    <calendar :show.sync="showCalendar" :disablePast="true" v-model="date" @pickDate="onPickDate">
    </calendar>
  </div>
</template>
<script>
import MyHeader from '../../common/header';
import bg from '../../../assets/images/trade/plane/bg.png';
import plane from '../../../assets/images/trade/plane/plane.png';
import selectCity from '../../common/selectCity';
import calendar from '../../common/myCalendar';

export default {
  components: {
    MyHeader,
    selectCity,
    calendar,
  },
  data() {
    return {
      plane,
      bg,
      headTitle: '',
      showCity: false,
      showCalendar: false,
      areaType: '',  // 当前正在选择的地点类型（出发地点或目的地点）
      defaultCommonCities: [
        {
          departureText: '北京',
          departureCity: '222',
          arrivalText: '上海',
          arrivalCity: '111',
        },
        {
          departureText: '广州',
          departureCity: 'CAN',
          arrivalText: '上海',
          arrivalCity: '111',
        },
        {
          departureText: '广州',
          departureCity: 'CAN',
          arrivalText: '北京',
          arrivalCity: '222',
        },
      ],
      commonCities: [],
      date: '',
      selectDate: new Date().toISOString().split('T')[0],
      searchParams: {
        departureCity: '',
        departureText: '',
        arrivalCity: '',
        arrivalText: '',
        departureDate: '',
        tripType: '1',
        tripNum: '0',
      },
    };
  },
  methods: {
    goBack() {
      this.$router.push('/travel');
    },
    // 设置常用旅客
    setPassengers() {
      this.$router.push('/travel/plane/travelTitle');
    },
    // 点击打开选择城市页面
    openArea(type) {
      this.showCity = true;
      this.areaType = type;
      if (type === 'start') {
        this.headTitle = '选择出发地点';
      } else if (type === 'end') {
        this.headTitle = '选择目的地点';
      }
    },
    // 点击选择地点
    selectCity(item) {
      if (this.areaType === 'start') {
        this.searchParams.departureCity = item.flightCityCode;
        this.searchParams.departureText = item.text;
      } else if (this.areaType === 'end') {
        this.searchParams.arrivalCity = item.flightCityCode;
        this.searchParams.arrivalText = item.text;
      }
      this.$store.commit('SEARCHTICKET', this.searchParams);
      this.showCity = false;
    },
    changeArea() {
      const departureText = this.searchParams.departureText;
      const departureCity = this.searchParams.departureCity;
      this.searchParams.departureText = this.searchParams.arrivalText;
      this.searchParams.departureCity = this.searchParams.arrivalCity;
      this.searchParams.arrivalText = departureText;
      this.searchParams.arrivalCity = departureCity;
      this.$store.commit('SEARCHTICKET', this.searchParams);
    },
    setAreaQuick(commonCitie) {
      this.searchParams = Object.assign(this.searchParams, commonCitie);
      this.$store.commit('SEARCHTICKET', this.searchParams);
    },
    // 点击选择时间
    onPickDate() {
      this.selectDate = this.date;
      this.searchParams.departureDate = this.selectDate;
      this.$store.commit('SEARCHTICKET', this.searchParams);
      this.date = '';
    },
    // 点击打开日历组件
    openCalendar() {
      this.date = this.selectDate;
      this.showCalendar = true;
    },
    // 将日期格式化成年月日的形式
    formatDate(date) {
      const dateObj = new Date(date.replace(/-/g, '/').split(' ')[0]);
      if (date && Object.prototype.toString.call(dateObj).slice(8, -1) === 'Date') {
        const month = dateObj.getMonth() + 1;
        const day = dateObj.getDate();
        return `${month}月${day}日`;
      }
      return '';
    },
    getDay() {
      const time = this.selectDate.replace(/-/g, '/');
      const cur = new Date(time);
      const day = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
      return day[cur.getDay()];
    },
    // 点击搜索
    toSearch() {
      if (!this.selectDate) {
        this.showToast({ msg: '请填写出发日期！' });
      } else if (!this.searchTicket.arrivalText) {
        this.showToast({ msg: '请填写出发地点！' });
      } else if (!this.searchTicket.departureText) {
        this.showToast({ msg: '请填写目的地点！' });
      } else {
        this.saveRecords(this.searchTicket);
        this.$store.commit('TICKETFILTER', null);
        this.$router.push('/travel/plane/ticketList');
      }
    },
    updateCommonCities() {
      const records = localStorage.ticketSearchRecords ? JSON.parse(localStorage.ticketSearchRecords) : [];
      this.commonCities = records.concat(this.defaultCommonCities).slice(0,3);
    },
    saveRecords(record) {
      if (localStorage.ticketSearchRecords) {
        const records = JSON.parse(localStorage.ticketSearchRecords);
        const isSave = records.find((item) => {
          return item.departureCity === record.departureCity && item.arrivalCity === record.arrivalCity;
        });
        if (!isSave) {
          records.unshift(record);
          localStorage.ticketSearchRecords = JSON.stringify(records.slice(0,3));
        }
      } else {
        localStorage.ticketSearchRecords = JSON.stringify([record]);
      }
      this.updateCommonCities();
    },
    clear() {
      localStorage.removeItem('ticketSearchRecords');
      this.updateCommonCities();
    },
    customService() {
      this.$router.push('/travel/plane/customService');
    },
  },
  computed: {
    searchTicket() {
      return this.$store.state.travel.searchTicket;
    },
  },
  mounted() {
    this.updateCommonCities();
    if (!this.searchTicket.departureCity && !this.searchParams.arrivalCity) {
      this.setAreaQuick(this.defaultCommonCities[0]);
    } else {
      this.searchParams = this.searchTicket;
    }
    if(this.searchParams.departureDate) {
      this.selectDate = this.searchParams.departureDate;
    } else {
      this.searchParams.departureDate = this.selectDate;
    }
  },
};
</script>
<style lang="less" scoped>
.ticket-wrap {
  .bg {
    img {
      width: 100%;
    }
  }
  .main {
    position: absolute;
    top: 166px;
    left: 8px;
    right: 8px;
    .message {
      padding: 16px 22px;
      background: #FFFFFF;
      box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.20);
      border-radius: 2px;
      .area {
        display: flex;
        height: 44px;
        padding-bottom: 9px;
        box-sizing: border-box;
        span {
          display: block;
          flex: 1;
          font-size: 22px;
          line-height: 30.5px;
          color: #333333;
          text-align: right;
        }
        span:first-child {
          text-align: left;
        }
        img {
          width: 36.5px;
          margin: 0 19.3px;
        }
        .grey {
          color: #bbbbbb;
        }
      }
      .date {
        height: 44px;
        .small-date {
          font-size: 14px;
          color: #666666;
          line-height: 46px;
        }
        .big-date {
          font-size: 22px;
          color: #333333;
          line-height: 46px;
        }
      }
      .search-btn {
        background: #3DA5FE;
        border-radius: 40px;
        font-size: 20px;
        color: #FFFFFF;
        letter-spacing: 3px;
        margin-top: 25px;
        text-align: center;
        line-height: 44px;
      }
      .btn {
        display: flex;
        height: 20px;
        margin-top: 17px;
        div {
          display: flex;
          flex: 1;
          align-items: flex-start;
          justify-content: center;
          line-height: 20px;
          font-size: 16px;
          color: #666666;
          .dot {
            width: 6px;
            height: 6px;
            background: #FF6262;
            border-radius: 50%;
          }
        }
      }
    }
    .usually-travel {
      margin: 20px auto;
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      .travel,
      .clear {
        margin: 0 10px;
        font-size: 12px;
        color: #82858B;
        letter-spacing: 1.8px;
      }
      .clear {
        color: #666666;
      }
    }
  }
  .grey {
    color: #bbbbbb;
  }
}
</style>

