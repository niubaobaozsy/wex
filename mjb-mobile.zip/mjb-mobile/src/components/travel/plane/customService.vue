<!--
  describe：联系客服
  created by：panjm
  date：2017-1-4
-->
<template>
  <div>
    <my-header :title="'联系客服'" @previous="goBack"></my-header>
    <div class="has-header">
      <a class="phoneInfo" v-for="(data, index) in phoneInfo" :key="index" :href="`tel:${data.phoneNum}`" v-if="suppliers.indexOf(data.mark)>-1">
        <div class="info">
          <div class="name">{{ data.name }}</div>
          <div class="phoneNum">{{ data.phoneNum }}</div>
        </div>
        <img :src="phone" class="call">
      </a>
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import MyHeader from '../../common/header';
import phone from '../../../assets/images/trade/phone.png';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {
      phone,
      phoneInfo: [
        {
          mark: 'meiya-flight',
          name: '美亚客服',
          phoneNum: '4006139139',
        },
        {
          mark: 'yqf-flight',
          name: '一起飞',
          phoneNum: '020022270825',
        },
      ],
    };
  },
  computed: mapState({
    suppliers: state => state.baseConfig.suppliers,
  }),
  methods: {
    goBack() {
      this.$router.push('/travel/plane');
    },
  },
};
</script>
<style lang="less" scoped>
  .phoneInfo {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 9px 20.7px 9px 15px;
    background-color: #ffffff;
    border-bottom: 0.3px solid #eeeeee;
    .info {
      .name {
        font-size: 16px;
        color: #333333;
        line-height: 22px;
      }
      .phoneNum {
        font-size: 14px;
        line-height: 20px;
        color: #666666;
      }
    }
    img {
      width: 19px;
      height: 19px;
    }
  }
</style>

