
<template>
  <div class="add-invoice-main">
    <my-header :title="title" rightItem="保存" @on-click="save"  @previous="goBack" ></my-header>
      <div class="has-header">
        <div class="z-companys" @click="showCo=true">
          <div class="border-bottom row">
            <p>入账单位</p>
            <div class="cloumns">
              <span>{{invoiceMsg.company_name}}</span>
              <img :src="r_arrow">
            </div>
            </div>
          </div>
        <ul>
          <li class="border-bottom">
            <span>名称</span>
            <p>{{invoiceMsg.invoice_head}}</p>
          </li>
          <li class="border-bottom">
            <span>税号</span>
            <p>{{invoiceMsg.tax_num}}</p>
          </li>
          <li class="border-bottom">
            <span>公司地址</span>
            <p>{{invoiceMsg.address}}</p>
          </li>
          <li class="border-bottom">
            <span>公司电话</span>
            <p>{{invoiceMsg.telephone}}</p>
          </li>
          <li class="border-bottom">
            <span>开户银行</span>
            <p>{{invoiceMsg.bank_name}}</p>
          </li>
          <li>
            <span>银行账户</span>
            <p>{{invoiceMsg.bank_account}}</p>
          </li>
        </ul>
        <group style="margin-top:-10px;">
        <x-switch title="设为默认" v-model="isDefault" @on-change="setDefault"></x-switch>
      </group>
      <div class="deleted" v-if="deleteShow" @click="del">删除信息</div>
      </div>
      <co :show.sync="showCo" :defCo="defaultConfig.companys" @confirm="onSelectCo" />
  </div>
</template>
<script>
import { Group, XSwitch } from 'vux';
import MyHeader from '../../common/header';
import co from '../../common/company';
import rArrow from '../../../assets/rt-arrow.png';

export default {
  components: {
    MyHeader,
    Group,
    XSwitch,
    co,
  },
  props: {
    invoice: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      showCo: false,
      isDefault: false,
      deleteShow: false,
      title: '',
      defaultConfig: {},
      invoiceMsg: {},
      r_arrow: rArrow,
    };
  },
  methods: {
    goBack() {
      this.$emit('on-hide');
    },
    setTitle() {
      if (this.invoice.config_id) {
        this.title = '编辑发票抬头';
        this.deleteShow = true;
      } else {
        this.title = '添加发票抬头';
        this.deleteShow = false;
      }
    },
    save() {
      const params = [
        {
          company: {
            company_id: this.invoiceMsg.company_id,
            company_name: this.invoiceMsg.company_name,
            invoice_head: this.invoiceMsg.invoice_head,
            config_id: this.invoiceMsg.config_id,
            is_default: this.invoiceMsg.is_default,
            config_type: 'company',
            ou_id: this.invoiceMsg.ou_id,
          },
        },
      ];
      this.$store.dispatch('saveDefalutInvoice', params).then((res) => {
        if (res && res.code === '0000') {
          this.showToast({ msg: '保存成功' });
          const companys = res.data.companys;
          this.$emit('complete', companys, 'editInvoice');
          setTimeout(() => {
            this.goBack();
          }, 800);
        } else if (res && res.code) {
          this.showToast({ msg: res.msg });
        }
      });
    },
    // 默认Value绑定
    setDefault(val) {
      this.invoiceMsg.is_default = val ? 'Y' : 'N';
    },
    // 入账单位
    onSelectCo(selCo) {
      this.invoiceMsg = Object.assign({}, selCo);
    },
    del() {
      const self = this;
      const params = this.invoice.config_id;
      self.$vux.confirm.show({
        title: '删除该信息？',
        onConfirm() {
          self.$store.dispatch('deletInvoice', params).then((res) => {
            console.log(res);
            if (res.code === '0000') {
              self.showToast({ msg: '删除成功', width: '14em', time: 800 });
              self.$emit('complete', self.invoiceMsg, 'delInvoice');
              setTimeout(() => {
                self.goBack();
              }, 800);
            } else if (res && res.code) {
              self.showToast({ msg: res.msg });
            }
          });
        },
      });
    },
  },
  mounted() {
    this.setTitle();
    this.invoiceMsg = this.invoice;
    this.isDefault = this.invoiceMsg.is_default === 'Y';
  },
};
</script>

<style lang="less" scoped>
@black:       #000000;
@grey:        #858585;
@border-grey: #DEDFE0;
.add-invoice-main {
  position: fixed;
  z-index: 99;
  top:0;
  left:0;
  right:0;
  bottom:0;
  background: #F4F4F4;
}
.cloumns {
  display: flex;
  align-items: center;
}
.has-header {
  font-size: 16px;
  margin-top:56px;
  .z-companys {
    padding-left:15px;
    background: #ffffff;
    margin-bottom:10px;
    .row {
        padding:14px 14px 9px 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        span {
          text-align: right;
          display: inline-block;
          width:232px;
          color:#858585;
          line-height: 22px;
        }
        p {
          width:64px;
        }
        img {
          margin-left:12px;
          width:7.5px;
          height:13px;
        }
    }
  }
  ul {
    padding-left:15px;
    overflow: hidden;
    background: #ffffff;
    li {
      padding:14px 14px 14px 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      p {
        color:@black;
        width: 240px;
        text-align: right;
        line-height: 22px;
        font-size: 16px;
      }
      span {
        color:@grey;

      }
    }
  }
  .deleted {
    height: 50px;
    line-height: 50px;
    text-align: center;
    color: #FC4B4C;
    background: #FFFFFF;
    margin-top:10px;
  }
}
</style>
