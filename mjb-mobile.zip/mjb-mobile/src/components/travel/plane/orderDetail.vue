<!--
  describe：机票预订列表
  created by：panjm
  date：2018-01-09
-->
<template>
  <div>
    <my-header  @previous="goBack" title="订单详情"></my-header>
    <div class="ticketInfo has-header">
      <div class="left">
        <div>{{ formatDate(orderDetail.ticket.depDate, "yyyy-MM-dd") }}</div>
        <div>{{ formatDate(orderDetail.ticket.depTime, "hh:mm") }}</div>
        <div>{{ orderDetail.ticket.orgAirport }}</div>
      </div>
      <div class="center" v-if="orderDetail.order.vendorNumber">
        <div class="supplierInfo">
          <span>{{ orderDetail.order.vendorNumber === 100 ? "美亚" : "一起飞" }}</span>
          <span>{{ orderDetail.ticketPrice.cabin }}</span>
        </div>
        <img :src="arrow">
        <div class="flightInfo">
          <span>{{ orderDetail.ticket.airlineCode }}</span>
          <span>{{ orderDetail.ticket.airlineName }}</span>
        </div>
      </div>
      <div class="right">
        <div>{{ duringTime }}</div>
        <div>
          <span>{{ formatDate(orderDetail.ticket.arrTime, "hh:mm") }}</span>
          <span v-if="showPlusDay">+{{ this.plusDay }}天</span>
        </div>
        <div>{{ orderDetail.ticket.desAirport }}</div>
      </div>
    </div>
    <div class="orderAmount">
      <div class="left">
        <div class="amount">
          <span v-html="getAmount(orderDetail.order.orderType)"></span>
          <img :src="tip" @click="showFeeDetail=true" v-if="orderDetail.order.orderType === 1">
        </div>
        <div class="orderNum">
          <span>订单号</span>
          <span>{{ orderDetail.contact.orderNo }}</span>
        </div>
      </div>

      <!-- Todo: remove style attribute -->
      <div v-if="orderDetail.order.orderStatus === 4 || orderDetail.order.orderStatus === 5"
        :class="['green', {'blue': orderDetail.order.orderStatus === 4}]" >{{ getOrderStatus(orderDetail.order.orderStatus, orderDetail.order.orderType) }}<img width="16" style="height: 1.12em;margin-left: .35em;vertical-align:text-bottom;" class="inline-block" src="~@/assets/images/trade/plane/tip.png" @click="showDetail4invalid()"/></div>
    </div>
    <div class="operateBtn">
      <div @click="refundApply" v-if="orderDetail.flag">我要退票</div>
      <div @click="changeApply" v-if="orderDetail.flag">我要改签</div>
      <div @click="confirmRefund" v-if="orderDetail.order.orderType===2&&orderDetail.order.orderStatus===1&&orderDetail.order.checkedStatus===1">确认退票</div>
      <div @click="cancelRefund" v-if="orderDetail.order.orderType===2&&orderDetail.order.orderStatus===1">取消退票</div>
      <div @click="confirmEndorse" v-if="orderDetail.order.orderType===3&&orderDetail.order.orderStatus===1&&orderDetail.order.checkedStatus===1">确认改签</div>
      <div @click="cancelEndorse" v-if="orderDetail.order.orderType===3&&orderDetail.order.orderStatus===1">取消改签</div>
    </div>
    <div class="header border-bottom">乘机人</div>
    <div class="content border-bottom" v-for="(data, index) in orderDetail.passengerDtos" :key="index">
      <div class="riderInfo">
        <div style="white-space: nowrap;">
          <span class="name">{{ data.passengerName }}</span>
          <span class="cert">
            ({{ data.certTypeStr }} {{ data.certNumber }}
          </span>)
        </div>
        <div>
          <span>手机号码</span>
          <span>{{ data.mobile }}</span>
        </div>
      </div>
      <div class="label" v-text="getTicketStatus(data.ticketInstanceStatus)"></div>
      <!-- <img class="rightArrow" :src="rightArrow"> -->
    </div>
    <div class="header border-bottom">联系人</div>
    <div class="content border-bottom">
      <div class="contacts">
        <div>{{ orderDetail.contact.contactName }}</div>
        <div><span>手机号码</span><span>{{ orderDetail.contact.mobile }}</span></div>
      </div>
      <!-- <img class="rightArrow" :src="rightArrow"> -->
    </div>
    <div class="header voucher-header border-bottom">
      <div class="left">{{chooseVouchers?'请选择消费券':'消费券'}}</div>
      <div class="right" @click="showVouchers = true" v-if="chooseVouchers&&voucherSelected">
        <img :src="rightArrow" alt="" class="rightArrow">
        <span>已选择{{voucherSelected.length}}张,共¥{{voucherSelectedTotalBalance.toFixed(2)}}元</span>
      </div>
    </div>
    <div class="couponBox border-bottom" v-if="!chooseVouchers||(voucherSelected&&voucherSelected.length)">
      <div class="voucher" v-for="(data, index) in (chooseVouchers ? voucherSelected : orderDetail.eaVoucherLists)" :key="index">
        <div class="check-box" @click="unSelectedVouchers(data)" v-if="chooseVouchers">
          <img :src="sub" alt="" class="sub">
        </div>
        <div class="coupon">
          <div class="title">
            <div>{{ data.voucherResc }}</div>
            <div>{{chooseVouchers?'余额':data.description}}</div>
          </div>
          <div class="info">
            <div>{{ data.voucherReturnCode }}</div>
            <div>{{ chooseVouchers?data.voucherBalance:data.lockAmount }}元</div>
          </div>
        </div>
      </div>
    </div>
    <div class="header border-bottom">发票抬头</div>
    <div class="content mb-30 border-bottom">
      <div class="invoice">
        <div>{{ orderDetail.order.buyersName }}</div>
        <div><span>税号</span><span>{{ orderDetail.order.buyersNo }}</span></div>
      </div>
      <!-- <img class="rightArrow" :src="rightArrow"> -->
    </div>
    <fee-detail :show.sync="showFeeDetail" :info="orderDetail" @hide="showFeeDetail=false"></fee-detail>
    <choose-vouchers  v-if="showVouchers" :vouchers="vouchers"  @complete="updateVouchers"/>
    <apply-tip v-if="showTip" mainTitle="出票中请稍候" @go-home="$router.push('/travel')" @go-detail="showTip=false"></apply-tip>
  </div>
</template>
<script>
import MyHeader from '../../common/header';
import feeDetail from './feeDetail.vue';
import ChooseVouchers from './chooseVouchers';
import ApplyTip from './applyTip';
import arrow from '../../../assets/images/trade/plane/flight_arrow.png';
import rightArrow from '../../../assets/images/trade/right2x.png';
import tip from '../../../assets/images/trade/plane/tip.png';
import sub from '../../../assets/images/trade/plane/sub.png';
import { formatDate } from '../../../js/util.js';

export default {
  components: {
    MyHeader,
    feeDetail,
    ChooseVouchers,
    ApplyTip,
  },
  data() {
    return {
      tip,
      arrow,
      rightArrow,
      sub,
      orderDetail: {
        ticket: {},
        order: {},
        passengers: {},
        contact: {},
        ticketPrice: {},
      },
      duringTime: '',
      showFeeDetail: false,
      showPlusDay: false,
      plusDay: 0,
      showVouchers: false,
      vouchers: [],
      chooseVouchers: false,
      showTip: false,
    };
  },
  computed: {
    voucherSelected() {
      return this.vouchers.filter((voucher) => {
        return voucher.isChecked;
      });
    },
    voucherSelectedTotalBalance() {
      return this.voucherSelected.map(item => parseFloat(item.voucherBalance)).reduce((a, b) => a + b, 0);
    },
  },
  methods: {
    goBack() {
      if (this.showTip) {
        this.showTip = false;
      } else {
        let redirect = this.$route.query.redirect || 'allOrders';
        if (redirect.slice(0,1) !== '/') {
          redirect = `/travel/plane/orderIndex/${redirect}`;
        }
        this.$router.push({
          path: redirect,
        });
      }
    },
    getOrderInfo() {
      return new Promise((resolve, reject) => {
        this.$store.dispatch('getOrderByOrderNo', { orderNo: this.$route.query.orderNo }).then((res) => {
          this.chooseVouchers = false;
          if (res.code === '1' && res.data) {
            this.orderDetail = res.data;
            this.dateCount();
            resolve();
          } else if (res && res.resultMsg) {
            const _this = this;
            this.alert({
              title: '提示',
              content: res.resultMsg,
              onHide() {
                _this.$router.go(-1);
              },
            });
          }
        });
      });
    },
    refundApply() {
      this.$router.push({
        path: '/travel/plane/refundApply', query: { orderNo: this.orderDetail.ticket.orderNo },
      });
    },
    changeApply() {
      this.orderDetail.passengerDtos.forEach((item) => {
        item.selected = false;
      });
      this.$store.commit('ENDORSE', {
        orderNo: this.orderDetail.ticket.orderNo,
        contact: JSON.stringify(this.orderDetail.contact),
        passengers: this.orderDetail.passengerDtos,
        ticket: this.orderDetail.ticket,
        endorseReason: '',
        flightInfo: '',
        priceInfo: '',
      });
      this.$router.push({
        path: '/travel/plane/changeApply',
      });
    },
    dateCount() {
      const intervalTime = (this.orderDetail.ticket.arrTime - this.orderDetail.ticket.depTime) / (1000 * 60);
      let intervalTimeHours = Math.floor(intervalTime / 60);
      const intervalTimeMinutes = intervalTime % 60;
      // 判断是否跨天数
      if (this.orderDetail.ticket.arrDate !== this.orderDetail.ticket.depDate) {
        intervalTimeHours = intervalTimeHours > 24 ? (intervalTiintervalTimeHoursmeHours % 24) : intervalTimeHours;
        this.duringTime = `${intervalTimeHours}时${intervalTimeMinutes}分`;
        this.plusDay = Math.floor(intervalTimeHours / 24);
        this.showPlusDay = true;
      } else {
        this.showPlusDay = false;
        this.duringTime = `${intervalTimeHours}时${intervalTimeMinutes}分`;
      }
    },
    getAmount(orderType) {
      if (orderType === 1) {
        return `订单金额&nbsp;&nbsp;¥${this.orderDetail.order.totalAmount}`;
      } else if (orderType === 2) {
        return `退款金额&nbsp;&nbsp;¥${this.orderDetail.order.payAmount}`;
      } else if (orderType === 3) {
        return `改签金额&nbsp;&nbsp;¥${this.orderDetail.order.payAmount}`;
      }
    },
    formatDate(timestamp, fmt) {
      return formatDate(timestamp, fmt);
    },
    getOrderStatus(orderStatus, orderType) {
      let obj = {};
      if (orderType === 1) {
        obj = {
          ao_1: '待处理',
          ao_2: '出票中',
          ao_3: '出票成功',
          ao_4: '订单已取消',
          ao_5: '出票失败',
        };
      } else if (orderType === 2) {
        obj = {
          ao_1: '待退票',
          ao_2: '退票受理中',
          ao_3: '退票成功',
          ao_4: '订单已取消',
          ao_5: '退票失败',
        };
      } else if (orderType === 3) {
        obj = {
          ao_1: '待改签',
          ao_2: '改签受理中',
          ao_3: '改签成功',
          ao_4: '订单已取消',
          ao_5: '改签失败',
        };
      }
      return obj[`ao_${orderStatus}`];
    },
    getTicketStatus(status) {
      switch (status) {
        case 1: return '待出票';
        case 2: return '已出票';
        case 3: return '待退票';
        case 4: return '已退票';
        case 5: return '待改签';
        case 6: return '已改签';
        case 7: return '出票失败';
        default: return 'test';
      }
    },
    confirmRefund() {
      this.$store.dispatch('confirmRefundApply', { orderNo: this.orderDetail.ticket.orderNo }).then((res) => {
        this.hideLoading();
        if (res && res.resultMsg) {
          this.showToast({ msg: res.resultMsg });
        }
        if (res.code === '1') {
          this.getOrderInfo();
        }
      });
    },
    cancelRefund() {
      this.showLoading();
      this.$store.dispatch('cancelRefundApply', { orderNo: this.orderDetail.ticket.orderNo }).then((res) => {
        this.hideLoading();
        if (res && res.resultMsg) {
          this.showToast({ msg: res.resultMsg });
        }
        if (res.code === '1') {
          this.getOrderInfo();
        }
      });
    },
    confirmEndorse() {
      let eaVoucherLists = this.orderDetail.eaVoucherLists;
      if (this.chooseVouchers) {
        eaVoucherLists = this.voucherSelected;
      }
      eaVoucherLists.forEach((item) => {
        item.createTime = this.formatDate(item.createTime, 'yyyy-MM-dd') || null;
        item.startDate = this.formatDate(item.startDate, 'yyyy-MM-dd') || null;
        item.endDate = this.formatDate(item.endDate, 'yyyy-MM-dd') || null;
      })
      this.$store.dispatch('confirmEndorse', {
        orderNo: this.orderDetail.ticket.orderNo,
        eaLists: JSON.stringify(eaVoucherLists),
      }).then((res) => {
        this.hideLoading();
        if (res.code === '1') {
          // this.showToast({ msg: res.resultMsg });
          this.getOrderInfo().then(() => {
            this.chooseVouchers = false;
            this.showTip = true;
          });
        } else if (res.resultMsg) {
          const _this = this;
          this.alert({
            title: '提示',
            content: res.resultMsg,
            onHide() {
              _this.onConfirmEndorseFail();
            },
          });
        }
      });
    },
    onConfirmEndorseFail() {
      if (!this.chooseVouchers && !this.vouchers.length) {
        this.showLoading();
        this.$store.dispatch('chooseVouchers', {
          user_email: '',
          extend_param: '',
          voucher_return_code: '',
          biz_type: 'JP_GN',
        }).then((res) => {
          this.hideLoading();
          this.chooseVouchers = true;
          if (res && res.code === '1') {
            const defaultVoucherId = this.orderDetail.eaVoucherLists.map(item => item.voucherId);
            res.data.forEach((item) => {
              item.isChecked = false;
              if (defaultVoucherId.indexOf(item.voucherId) > -1) {
                item.isChecked = true;
              }
            });
            this.vouchers = res.data;
            this.showVouchers = true;
          } else {
            this.showToast({ msg: res.resultMsg });
          }
        });
      } else {
        this.showVouchers = true;
      }
    },
    cancelEndorse() {
      this.showLoading();
      this.$store.dispatch('cancelEndorseOrder', { orderNo: this.orderDetail.ticket.orderNo }).then((res) => {
        this.hideLoading();
        if (res && res.resultMsg) {
          this.showToast({ msg: res.resultMsg });
        }
        if (res.code === '1') {
          this.getOrderInfo();
        }
      });
    },
    updateVouchers(vouchers) {
      this.vouchers = vouchers;
      this.showVouchers = false;
    },
    unSelectedVouchers(voucher) {
      voucher.isChecked = false;
    },
    showDetail4invalid() {
      if (this.orderDetail.order.orderStatus !== 4 && this.orderDetail.order.orderStatus !== 5) return;
      if (this.orderDetail.order.orderStatus === 4 && !this.orderDetail.order.description) return;

      let content = '出票失败，请联系供应商客服！';

      if (this.orderDetail.order.orderStatus === 4 && this.orderDetail.order.description) {
        content = this.orderDetail.order.description;
      }

      this.$vux.confirm.show({
        title: '',
        content,
        confirmText: '确定',
        showCancelButton: false
      });
    }
  },
  mounted() {
    this.getOrderInfo();
  },
};
</script>
<style lang="less" scoped>
.ticketInfo {
  display: flex;
  justify-content: space-between;
  padding: 20px;
  color: #ffffff;
  background: linear-gradient(top, #2CBCFF, #3DA5FE);
  .left {
    div:nth-child(1) {
      margin-bottom: 4.5px;
      font-size: 16px;
      line-height: 14px;
    }
    div:nth-child(2) {
      margin: 4.5px 0 5.5px;
      font-size: 24px;
    }
    div:nth-child(3) {
      margin-top: 5.5px;
      font-size: 12px;
    }
  }
  .center {
    text-align: center;
    font-size: 14px;
    .supplierInfo {
      span:nth-child(1) {
        margin-right: 10px;
      }
    }
    .flightInfo {
      span:nth-child(1) {
        padding-right: 5px;
      }
      span:nth-child(2) {
        padding-left: 8px;
        border-left: 0.5px solid #ffffff;
      }
    }
    img {
      width: 110px;
      height: 5.7px;
      position: relative;
      top: -5px;
    }
  }
  .right {
    div:nth-child(1) {
      margin-bottom: 4.5px;
      font-size: 16px;
      line-height: 14px;
    }
    div:nth-child(2) {
      display: flex;
      align-items: flex-start;
      margin: 4.5px 0 5.5px;
      span:nth-child(1) {
        font-size: 24px;
      }
      span:nth-child(2) {
        margin-top: 5px;
        font-size: 10px;
        line-height: 16px;
      }
    }
    div:nth-child(3) {
      margin-top: 5.5px;
      font-size: 12px;
    }
  }
}
.orderAmount {
  display: flex;
  justify-content: space-between;
  padding: 10px 15px;
  background-color: #ffffff;
  font-size: 16px;
  line-height: 22px;
  .left {
    .amount {
      display: flex;
      align-items: center;
      margin-bottom: 6px;
      img {
        margin-left: 6.3px;
        width: 16px;
      }
    }
    .orderNum {
      color: #666;
      span {
        margin-right: 10px;
      }
    }
  }
  .blue {
    color: #3DA5FE;
  }
  .green {
    color: #6CC60A;
  }
}
.operateBtn {
  display: flex;
  justify-content: flex-end;
  background-color: #ffffff;
  padding: 0 10px 12px;
  div {
    padding: 4px 16px;
    margin-right: 10px;
    font-size: 16px;
    line-height: 22px;
    color: #3DA5FE;
    border: 1px solid #3DA5FE;
    border-radius: 40px;
  }
}
.header {
  padding: 15px;
  margin-top: 10px;
  font-size: 14px;
  color: #858585;
  background-color: #ffffff;
  margin-bottom: 1px;
}
.voucher-header {
  display: flex;
  .right {
    flex-grow: 1;
    display: flex;
    flex-wrap: nowrap;
    flex-direction: row-reverse;
    align-items: center;
    img {
      margin-left: 10px;
    }
  }
}
.rightArrow {
  width: 7.5px;
  height: 13px;
}
.content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px;
  background-color: #ffffff;
}
.mb-30 {
  margin-bottom: 30px;
}
.riderInfo {
  font-size: 16px;
  line-height: 22px;
  color: #666;
  div:nth-child(1) {
    span:nth-child(2) {
      margin-left: 10px;
    }
  }
  div:nth-child(2) {
    span:nth-child(2) {
      margin-left: 10px;
    }
  }
  .name {
    color: #000;
  }
  .cert {
    display: inline-block;
    text-overflow: ellipsis;
    overflow: hidden;
    vertical-align: bottom;
    white-space: nowrap;
    width: 70%;
  }
}
.contacts {
  div:nth-child(1) {
    font-size: 16px;
    line-height: 22px;
  }
  div:nth-child(2) {
    color: #666666;
    span:nth-child(2) {
      margin-left: 10px;
    }
  }
}
.couponBox {
  padding: 14px 20px 4px 20px;
  background-color: #ffffff;
  .voucher {
    display: flex;
    align-items: center;
    .check-box {
      padding: 30px 10px;
      margin-left: -10px;
      .sub {
        display: block;
        width: 18px;
        height: 18px;
      }
    }
    .coupon {
      flex-grow: 1;
      padding: 20px 10px 20px 20px;
      background-image: url(../../../assets/images/trade/vaildSTicket2x.png);
      margin-bottom: 10px;
      box-shadow: 4px 4px 10px #eee;
      .title {
        display: flex;
        justify-content: space-between;
        color: #666666;
        font-size: 12px;
        margin-bottom: 10px;
        div {
          &:nth-child(1) {
            padding-right: 10px;
          }
          &:nth-child(2) {
            white-space: nowrap;
          }
        }
      }
      .info {
        display: flex;
        justify-content: space-between;
        font-size: 16px;
        line-height: 22px;
      }
    }
  }
}
.invoice {
  div:nth-child(1) {
    font-size: 16px;
    line-height: 22px;
  }
  div:nth-child(2) {
    color: #666;
    font-size: 14px;
    line-height: 20px;
    span:nth-child(2) {
      margin-left: 10px;
    }
  }
}
.label {
  color: #fff;
  font-size: 11px;
  background-color: #FCB23C;
  border-radius: 12px;
  padding: 2px 10px;
  white-space: nowrap;
}
</style>
