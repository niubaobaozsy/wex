<!--
  describe：选择消费券组件
  created by：zhouJk
  date：2017-1-4
-->
<template>
  <div class='ticketList'>
    <my-header title="选择消费券" @previous="goBack"></my-header>
    <div class='main has-header'>
      <div class='main-c'>
        <div class='available' v-if="available.length">
          <div class='title'>可用消费券</div>
            <div :class="['dataList', {'selectList': item.isChecked},{'unselect': !item.isChecked}]" @click="select(item)" v-for="(item, index) in available" :key="index">
              <ul>
                <li>
                  <div class="userInfo">
                  <!-- <span>消费券-</span>
                  <span>{{item.voucherReturnCode ? '个人' : '公共'}}</span> -->
                  <span>{{item.remark}}</span>
                  </div>
                  <div class="dataTime">
                    {{item.voucherReturnCode ? '余额' : '有效期至'}}
                  </div>
                </li>
                <li>
                  <div class='numOrResc'>
                    {{ item.voucherReturnCode }}
                  </div>
                  <div class='balance'>{{(item.voucherBalance * 1).toFixed(2)}}元</div>
                </li>
              </ul>
            </div>
        </div>
        <div class='unavailable' v-if="unavailable.length">
          <div class='untitle'>不可用消费券</div>
          <div class='dataList unlist' v-for="(item, index) in unavailable" :key="index">
              <ul>
                <li>
                  <div class="userInfo">
                  <!-- <span>消费券-</span>
                  <span>{{item.voucherReturnCode ? '个人' : '公共'}}</span> -->
                  <span>{{item.voucherResc}}</span>
                  </div>
                  <div class="dataTime">
                    {{item.voucherReturnCode ? '余额' : '有效期至'}}
                  </div>
                </li>
                <li>
                  <div class='numOrResc'> {{item.voucherReturnCode ? item.voucherReturnCode : item.voucherResc}}</div>
                  <div class='balance'>{{(item.voucherBalance * 1).toFixed(2)}}元</div>
                </li>
              </ul>
            </div>
        </div>
        <div class="no-data-tip" v-if="!available.length&&!unavailable.length">
          <img src="../../../assets/images/common/no_data.png" alt="">
          <p>暂无消费券</p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import MyHeader from '../../common/header';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {};
  },
  props: {
    vouchers: {
      type: Array,
      required: true,
      default: [],
    },
    // type: {
    //   type: String,
    //   required: false,
    //   default: '',
    // },
  },
  computed: {
    available() {
      return this.vouchers.filter((voucher) => {
        return voucher.enableFlag === 'Y';
      });
    },
    unavailable() {
      return this.vouchers.filter((voucher) => {
        return voucher.enableFlag !== 'Y';
      });
    },
  },
  methods: {
    goBack() {
      this.$emit('complete', this.vouchers);
    },
    select(voucher) {
      voucher.isChecked = !voucher.isChecked;
    },
  },
};
</script>
<style lang="less" scoped>
ul,li {
  list-style: none;
}
.ticketList {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 6000;
  width: 100%;
  .main {
    height: 100%;
    background: #f2f2f2;
    padding: 0 15px;
    overflow-y: scroll;
    .main-c {
      // height:100%;
      padding-bottom:50px;
      .title {
      font-size: 14px;
      color: #9B9B9B;
      line-height: 14px;
      padding: 15px 0;
    }
    .selectList {
      background: url("../../../assets/images/trade/plane/chooseSelect.png") no-repeat center center;
      background-size: 100% 100%;
    }
    .unselect {
      background: url("../../../assets/images/trade/plane/available.png") no-repeat center center;
      background-size: 100% 100%;
    }
    .dataList {
      margin-bottom:10px;
      padding: 20px 15px;
       ul {
         li {
           display: flex;
           justify-content: space-between;
           &:nth-of-type(1) {
            color: #666666;
            font-size: 12px;
            line-height:12px;
            margin-bottom:10px;
          }
          &:nth-of-type(2) {
            font-size: 16px;
            color: #344663;
            line-height:16px;
          }
          .numOrResc {
            overflow : hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 1;
            -webkit-box-orient: vertical;
          }
          .balance {
            white-space: nowrap;
          }
         }
         .userInfo {
           width: 220px;
           overflow: hidden;
           text-overflow: ellipsis;
           white-space: nowrap;
         }
       }
      }
    }
    .untitle {
      font-size: 14px;
      color: #9B9B9B;
      line-height: 14px;
      padding: 5px 0 15px 0;
    }
    .unlist {
      background: url("../../../assets/images/trade/plane/unavailable.png") no-repeat center center;
      background-size: 100% 100%;
      ul {
        height:78px;
        margin-bottom:10px;
        li {
          color:#999999!important;
        }
      }
    }
    .no-data-tip {
      font-size: 14px;
      line-height: 20px;
      color: #9B9B9B;
      text-align: center;
      img {
        width: 50%;
        height: 50%;
        margin-top: 20%;
      }
    }
  }
}

</style>

