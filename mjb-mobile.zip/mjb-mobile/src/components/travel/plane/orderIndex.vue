<!--
  describe："机票———我的订单列表"
  created by：Yim Lee
  date：2017-1-4
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div>
    <my-header :title="top.title" @previous="goBack"></my-header>
    <Tab :tabList="tabList"></Tab>
    <div class="has-header has-tab">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
import MyHeader from '../../common/header';
import Tab from '../../common/Tab';

export default {
  components: {
    MyHeader,
    Tab,
  },
  data() {
    return {
      top: {
        title: '机票订单',
      },
      tabList: [
        {
          name: '全部订单',
          linkTo: 'allOrders',
        },
        {
          name: '待出票',
          linkTo: 'waitTicketOrders',
        },
        {
          name: '已出票',
          linkTo: 'outTicketOrders',
        },
        {
          name: '退改单',
          linkTo: 'refundTicketOrders',
        },
      ],
    };
  },
  methods: {
    goBack() {
      this.$router.push('/travel/plane');
    },
  },
};
</script>
