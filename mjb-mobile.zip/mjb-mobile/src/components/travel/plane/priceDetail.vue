<!--
  describe：价格明细组件
  created by：zhoujk
  date：2018-01-03
-->
<template>
  <div>
    <div class="plane-box">
      <div class="plane-bg" @click="goHide"></div>
      <div class="plane-c border-bottom">
        <ul>
          <li><span>票价</span><div class="plane-c-r">¥{{priceInfo.ticketPrice}}<div>x{{passengerNum}}</div></div></li>
          <li><span>基建</span><div class="plane-c-r">¥{{priceInfo.airPortFee}}<div>x{{passengerNum}}</div></div></li>
          <li><span>燃油</span><div class="plane-c-r">¥{{priceInfo.oilFee}}<div>x{{passengerNum}}</div></div></li>
          <li><span>服务费</span><div class="plane-c-r">¥{{priceInfo.serviceAmount}}<div>x{{passengerNum}}</div></div></li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>

export default {
  props: {
    priceInfo: {},
    passengerNum: 0,
  },
  data() {
    return {};
  },
  methods: {
    goHide() {
      this.$emit('on-hide');
    },
  },
};
</script>
<style lang="less" scoped>
ul,li {
  list-style: none;
}
.fn-6 {
  color:#666666!important;
}
.fn-0 {
  color: #000000;
}
.fn-1 {
  color:#3DA5FE;
}
.fs-d {
  font-size: 14px;
  line-height: 14px;
}
.plane-box {
  .plane-bg {
    position: fixed;
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    margin-bottom: 50px;
    background: rgba(0, 0, 0, 0.5);
  }
  .plane-c {
      padding:14px 15px 4px 15px;
      background: #FFFFFF;
      position: fixed;
      bottom:50px;
      left:0;
      right:0;
      ul {
        li {
          display: flex;
          justify-content: space-between;
          line-height: 22px;
          margin-bottom:10px;
          span {
            color:#000000;
            font-size:16px;
          }
          .plane-c-r {
            display: flex;
            color:#666666;
            div {
              margin-left:6px;
              font-size: 12px;
              color: #858585;
            }
          }
        }
      }
    }
}
</style>
