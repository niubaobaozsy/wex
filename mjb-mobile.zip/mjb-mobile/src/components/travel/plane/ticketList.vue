<!--
  describe：机票预订列表
  created by：panjm
  date：2017-12-28
-->
<template>
  <div>
    <my-header  @previous="goBack" :rightTitle="searchTicket.departureText" :leftTitle="searchTicket.arrivalText" :titleImg="arrow" :showImgTitle="true"></my-header>
    <div class="has-header select-wrap">
      <div class="selectDate border-bottom">
        <div class="followDate" @click="dateSearch(-1)">
          <img class="mr" :src="leftArrow">
          <span>前一天</span>
        </div>
        <div class="date" @click="openCalendar">
          <img :src="calendar">
          <span>{{ formatDate(selectDate) }}</span>
          <span>{{ getDay() }}</span>
          <span>￥{{ minPrice }}</span>
        </div>
        <div class="followDate" @click="dateSearch(1)">
          <span class="mr">后一天</span>
          <img :src="rightArrow">
        </div>
      </div>
    </div>
    <div class="has-header has-footer list-container">
      <div class="ticketList border" v-for="(data, index) in (ticketInfo.length ? ticketInfo : filterResult)" :key="index" @click="goDetail(data)">
        <div class="firstInfo">
          <div class="left">
            <div class="date1">
              <div class="time">{{ data.depTime }}</div>
              <div class="area">{{ data.orgAirport }}</div>
            </div>
            <div class="center">
              <span class="stop" v-if="false">经停：长沙</span>
              <span class="change" v-if="false">中转：湖南</span>
              <img :src="passThrough">
              <span class="timeSpan" v-if="true">{{data.timeSpan}}</span>
            </div>
            <div class="date2">
              <div class="time">{{ data.arrTime }}</div>
              <div class="area">{{ data.desAirport }}</div>
            </div>
          </div>
          <div class="right">￥{{ data.lowestPrice.toFixed(2) }}</div>
        </div>
        <div class="secondInfo">
          <img :src="logo">
          <span>{{ data.airlineName }}</span>
          <span>{{ data.airlineCode }}</span>
          <span class="flightNo">{{ data.flightNo }}</span>
          <span class="shareFlag" v-if="data.isCodeShare">共享</span>
        </div>
      </div>
    </div>
    <div v-show="filterShow" class="maskLayer" @touchmove.prevent @click="cancel" ></div>
    <!--筛选内容-->
    <div class="filter" v-if="filterShow" ref="parentsDom">
      <div class="head">
        <div class="cancel" @click="cancel">取消</div>
        <div class="clear" @click="clear">清空筛选</div>
        <div class="confirm" @click="confirm">确定</div>
      </div>
      <div class="leftTab">
        <div v-for="(item, index) in filterData" :key="index" :class="{'active': selectType(item.filter)}" @click="selected(item.filter)">
          {{item.name}}
        </div>
      </div>
      <div class="rightTab" ref="scrollDom">
        <div class="small-item" @click="chooseLimit">
          <span class="text">不限</span>
          <i class="icon-select" :class="{'active': filterData[filterItem].selected.length === 0}"></i>
        </div>
        <div v-show="filterItem === 'flightsTime'">
          <div class="small-item" v-for="(item, index) in filterData.flightsTime.container" :key="index" @click="chooseItem(item)">
            <span class="text">{{item}}</span>
            <i class="icon-select" :class="{'active': selectItem('flightsTime', item)}"></i>
          </div>
        </div>
        <div v-show="filterItem === 'airline'">
          <div class="small-item" v-for="(item, index) in filterData.airline.container" :key="index" @click="chooseItem(item.airlineCode)">
            <span class="text">{{item.airlineName}} </span>
            <i class="icon-select" :class="{'active': selectItem('airline', item.airlineCode)}"></i>
          </div>
        </div>
        <div v-show="filterItem === 'suppliers' && !$route.query.vendorNum">
          <div class="small-item" v-for="(item, index) in filterData.suppliers.container" :key="index" @click="chooseItem(item)" v-if="globalSuppliers.indexOf(item.mark)>-1">
            <span class="text">{{filterItem === 'flightsTime' ? item : item.name}} </span>
            <i class="icon-select" :class="{'active': selectItem('suppliers', item.code)}"></i>
          </div>
        </div>
      </div>
    </div>
    <!--底部-->
    <div class="footer" v-show="!filterShow">
      <div class="aside">
        <div @click="startChoose">
          <i class="icon-filter"></i><br>筛选
        </div>
        <div @click="sortTime" :class="{'active': sortType === 'time'}">
          <i class="icon-to-night" :class="{'active': sortType === 'time'}"></i><br>{{sortTimeWay === -1 ? '从晚到早' : '从早到晚'}}
        </div>
        <div @click="sortPrice" :class="{'active': sortType === 'price'}">
          <i class="icon-price" :class="{'active': sortType === 'price'}"></i><br>{{sortPriceWay === -1 ? '由高到低' : '由低到高'}}
        </div>
      </div>
    </div>
    <div v-if="!ticketInfo.length && !filterResult.length && !isLoading" class="emptyBox">
      <img class="no_data_img" :src="noDataImg" alt="">
      <p class="no_data_text">暂无航班信息</p>
    </div>
    <my-calendar :show.sync="showCalendar" :disablePast="true" v-model="date" @pickDate="onPickDate" @goBack="onCalendarHide"></my-calendar>
  </div>
</template>
<script>
import MyHeader from '../../common/header';
import myCalendar from '../../common/myCalendar';
import leftArrow from '../../../assets/images/trade/leftArrow.png';
import rightArrow from '../../../assets/images/trade/rightArrow.png';
import passThrough from '../../../assets/images/trade/jiantou@2x.png';
import calendar from '../../../assets/images/trade/plane/calendar.png';
import logo from '../../../assets/images/trade/logo.png';
import arrow from '../../../assets/images/trade/plane/arrow.png';
import noDataImg from '../../../assets/images/common/no_data.png';

export default {
  components: {
    MyHeader,
    myCalendar,
    // ticketFliter,
  },
  data() {
    return {
      calendar,
      leftArrow,
      rightArrow,
      passThrough,
      logo,
      arrow,
      noDataImg,
      ticketInfo: [],
      key: '',
      minPrice: '暂无',
      date: '',
      selectDate: '',
      showCalendar: false,
      isLoading: true,
      // 筛选
      filterShow: false,
      sortType: 'time', // 默认按时间排序
      sortTimeWay: -1, // 从早到晚排序方式
      sortPriceWay: 1, // 由低到高排序方式
      filterData: {
        flightsTime: {
          name: '起飞时间',
          filter: 'flightsTime',
          selected: [],
          container: ['00:00-06:00', '6:00-12:00', '12:00-18:00', '18:00-24:00'],
        },
        airline: {
          name: '航空公司',
          filter: 'airline',
          selected: [],
          container: [],
        },
        suppliers: {
          name: '供应商',
          filter: 'suppliers',
          selected: [],
          container: [{ mark: 'meiya-flight', name: '美亚', code: 100 }, { mark: 'yqf-flight', name: '一起飞', code: 300 }],
        },
      },
      filterItem: 'flightsTime',
      filterResult: [], // 筛选结果
      filterStatus: 0, // 筛选状态 0 显示全部， 1 显示筛选结果
    };
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    onCalendarHide() {
      if (!this.searchTicket.departureDate) {
        if (this.endorseOrderNo) {
          this.$router.go(-1);
        } else {
          this.$router.push('/travel/plane');
        }
      }
    },
    goDetail(data) {
      this.$store.commit('SELECTEDTICKETINFO', data);
      this.$router.push({ path: '/travel/plane/bookingDetails' });
    },
    getAirlines() {
      const params = {
        departureCity: this.searchTicket.departureCity,
        arrivalCity: this.searchTicket.arrivalCity,
        departureDate: this.selectDate,
        tripType: '1',
        tripNum: '0',
      };
      this.ticketInfo = [];
      this.isLoading = true;
      this.showLoading();
      this.$store.dispatch('getAirlines', params).then((res) => {
        this.hideLoading();
        if (res && res.code === '1') {
          this.sortType = 'time';
          if (res.data && res.data.dtos) {
            this.filterData.airline.container = res.data.airlines;
            this.minPrice = res.data.minPrice || '暂无';
            this.key = res.data.key;
            this.$store.commit('TICKETINFO', this.ticketInfo);
            this.$store.commit('SEARCHTICKET', Object.assign({}, this.searchTicket, { key: this.key }));
            if (!this.ticketFilter) {
              this.isLoading = false;
              this.ticketInfo = res.data.dtos;
              this.ticketInfo.forEach((item) => {
                let timeSpan = item.flightTime;
                let hour = parseInt(10, timeSpan/60);
                let minute = timeSpan%60;
                item.timeSpan = (hour>=1) ? `${hour}小时${minute}分` : `${minute}分`
              })
              this.$store.commit('TICKETFILTER', JSON.parse(JSON.stringify(this.filterData)));
            } else {
              this.filterData = JSON.parse(JSON.stringify(this.ticketFilter));
              this.confirm();
            }
          }
        } else if (res && res.resultMsg) {
          this.showToast({ msg: res.resultMsg });
        }
      });
    },
    // 点击选择时间
    onPickDate() {
      this.selectDate = this.date;
      this.$store.commit('SEARCHTICKET', Object.assign({}, this.searchTicket, { departureDate: this.selectDate }));
      this.getAirlines();
      this.date = '';
    },
    openCalendar() {
      this.date = this.selectDate || '';
      this.showCalendar = true;
    },
    formatDate(date) {
      date = date || this.searchTicket.departureDate;
      const formatDate = new Date(date.replace(/-/g, '/').split(' ')[0]);
      const month = formatDate.getMonth() + 1;
      const day = formatDate.getDate();
      return `${month}-${day}`;
    },
    followDate(num) {
      const time = this.selectDate.replace(/-/g, '/');
      const cur = new Date(time);
      const ms = 24 * 60 * 60 * 1000 * num;
      const result = new Date(cur.getTime() + ms);
      return `${result.getFullYear()}-${(1 + result.getMonth())}-${result.getDate()}`;
    },
    dateSearch(num) {
      this.ticketInfo = [];
      this.selectDate = this.followDate(num);
      this.$store.commit('SEARCHTICKET', Object.assign({}, this.searchTicket, { departureDate: this.selectDate }));
      this.getAirlines();
    },
    getDay() {
      const time = this.selectDate.replace(/-/g, '/');
      const cur = new Date(time);
      const day = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
      return day[cur.getDay()];
    },
    startChoose() {
      if (this.ticketFilter) {
        this.filterData = JSON.parse(JSON.stringify(this.ticketFilter));
      }
      this.filterShow = true;
      this.$nextTick(() => {
        this.smartScroll(this.$refs.parentsDom, this.$refs.scrollDom);
      });
    },
    sortTime() {
      this.sortType = 'time';
      this.sortTimeWay *= -1;
      const ticket = this.filterStatus ? this.filterResult : this.ticketInfo;
      ticket.sort((a, b) => (new Date(`${b.depDate}T${b.depTime}`) - new Date(`${a.depDate}T${a.depTime}`)) * this.sortTimeWay);
    },
    sortPrice() {
      this.sortType = 'price';
      this.sortPriceWay *= -1;
      const ticket = this.filterStatus ? this.filterResult : this.ticketInfo;
      ticket.sort((a, b) => (b.lowestPrice - a.lowestPrice) * this.sortPriceWay);
    },
    selected(filter) {
      this.filterItem = filter;
    },
    chooseLimit() {
      if (this.filterItem === 'flightsTime') {
        this.filterData.flightsTime.selected = [];
      } else if (this.filterItem === 'airline') {
        this.filterData.airline.selected = [];
      } else if (this.filterItem === 'suppliers') {
        this.filterData.suppliers.selected = [];
      }
    },
    chooseItem(item) {
      if (this.filterItem === 'flightsTime') {
        if (this.filterData.flightsTime.selected.indexOf(item) === -1) {
          this.filterData.flightsTime.selected.push(item);
        } else {
          const index = this.filterData.flightsTime.selected.indexOf(item);
          this.filterData.flightsTime.selected.splice(index, 1);
        }
      } else if (this.filterItem === 'airline') {
        if (this.filterData.airline.selected.indexOf(item) === -1) {
          this.filterData.airline.selected.push(item);
        } else {
          const index = this.filterData.airline.selected.indexOf(item);
          this.filterData.airline.selected.splice(index, 1);
        }
      } else if (this.filterItem === 'suppliers') {
        if (this.filterData.suppliers.selected.indexOf(item.code) === -1) {
          this.filterData.suppliers.selected.push(item.code);
        } else {
          const index = this.filterData.suppliers.selected.indexOf(item.code);
          this.filterData.suppliers.selected.splice(index, 1);
        }
      }
    },
    selectItem(type, item) {
      if (this.filterData[type].selected.indexOf(item) !== -1) {
        return true;
      }
      return false;
    },
    selectType(filter) {
      if (filter === this.filterItem) {
        return true;
      }
      return false;
    },
    cancel() {
      this.filterShow = false;
    },
    clear() {
      this.filterData.flightsTime.selected = [];
      this.filterData.airline.selected = [];
      this.filterData.suppliers.selected = [];
    },
    // 确定筛选
    confirm() {
      const code = this.filterData.airline.selected; // 航司编码
      const time = this.filterData.flightsTime.selected; // 起飞、到达时间
      const suppliers = this.filterData.suppliers.selected; // 供应商编码
      let result = [];
      this.$store.commit('TICKETFILTER', JSON.parse(JSON.stringify(this.filterData)));
      // if (code.length === 0 && time.length === 0 && suppliers.length === 0) {
      //   this.filterResult = [];
      //   this.filterStatus = 0;
      //   this.getAirlines();
      // } else if (code.length === this.filterData.airline.container.length &&
      // time.length === this.filterData.flightsTime.container.length &&
      // suppliers.length === this.filterData.suppliers.container.length) {
      //   this.getAirlines();
      // } else {
        let params = '';
        if (time.length && time.length !== this.filterData.flightsTime.container.length) {
          time.forEach((item) => {
            const timeArr = item.split('-');
            const time1 = timeArr[0].split(':');
            const time2 = timeArr[1].split(':');
            console.log(timeArr[0].substring(''));
            params += `airDate=%5B${time1[0]}-${time2[0]}%5D&`;
          });
        }
        if (code.length && code.length !== this.filterData.airline.container.length) {
          code.forEach((item) => {
            params += `airlines=${item}&`;
          });
        }
        if (suppliers.length && suppliers.length !== this.filterData.suppliers.container.length) {
          suppliers.forEach((item) => {
            params += `suppliers=${item}&`;
          });
        }
        params += `key=${this.key}`;
        console.log('请求参数：', params);
        this.showLoading();
        this.$store.dispatch('ticketFilterFlights', params).then((rep) => {
          this.sortType = 'time';
          this.isLoading = false;
          this.hideLoading();
          if (rep && rep.resultFlag === 1) {
            result = rep.data;
            this.filterStatus = 1;
            this.ticketInfo = [];
            this.filterResult = result;
            console.log(result);
            this.filterResult.forEach((item) => {
              let timeSpan = item.flightTime;
              let hour = parseInt(10, timeSpan/60)
              let minute = timeSpan%60;
              item.timeSpan = (hour>=1) ? `${hour}小时${minute}分` : `${minute}分`
            })
          } else {
            this.showToast({ msg: rep.resultMsg });
          }
        });
      // }
      this.cancel();
    },
  },
  computed: {
    searchTicket() {
      return this.$store.state.travel.searchTicket;
    },
    endorseOrderNo() {
      return this.$store.state.travel.endorse.orderNo;
    },
    ticketFilter() {
      return this.$store.state.travel.ticketFilter;
    },
    globalSuppliers() {
      return this.$store.state.baseConfig.suppliers;
    },
  },
  mounted() {
    if (this.searchTicket.departureDate) {
      this.selectDate = this.searchTicket.departureDate;
      this.getAirlines();
    } else {
      this.openCalendar();
    }
  },
};
</script>
<style lang="less" scoped>
.select-wrap {
  position: fixed;
  z-index: 99;
  top: 0;
  width: 100%;
}
.selectDate {
  padding: 8px 15px;
  background-color: #fff;
  box-sizing: border-box;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .followDate {
    font-size: 14px;
    line-height: 20px;
    display: flex;
    align-items: center;
    .mr {
      margin-right: 7.5px;
    }
    img {
      width: 7.5px;
      height: 13px;
    }
    span {
      display: inline-block;
    }
  }
  .date {
    display: flex;
    align-items: center;
    padding: 9px 16.5px;
    background-color: #EBF6FE;
    border: 0.5px #A0D3FF solid;
    border-radius: 100px;
    img {
      padding: 0 3.5px;
      width: 10px;
    }
    span {
      padding: 0 3.5px;
      color: #3DA5FE;
      font-size: 14px;
      line-height: 20px;
    }
  }
}
.list-container {
  padding: 55px 0 10px 0;
}
.ticketList {
  margin-top: 10px;
  padding: 15px 10px;
  background-color: #ffffff;
  box-sizing: border-box;
  .firstInfo {
    margin-bottom: 4px;
    display: flex;
    justify-content: space-between;
    .left {
      display: flex;
      justify-content: space-between;
      .date1 {
        text-align: center;
        .time {
          font-size: 22px;
          line-height: 30px;
        }
        .area {
          font-size: 12px;
          line-height: 17px;
          color: #999999;
          white-space: nowrap;
        }
      }
      .date2 {
        text-align: center;
        margin-left: 80px;
        .time {
          font-size: 22px;
          line-height: 30px;
        }
        .area {
          font-size: 12px;
          line-height: 17px;
          color: #999999;
          white-space: nowrap;
        }
      }
      .center {
        margin: 0 18px;
        img {
          width: 86px;
          position: absolute;
          margin-top: 22px;
        }
        .stop {
          position: absolute;
          margin-top: -8px;
          margin-left: 3px;
          color: #0080ff;
          background-color: #fff;
          line-height: 16px;
          font-size: 12px;
        }
        .change {
          position: absolute;
          margin-top: 10px;
          margin-left: 3px;
          color: #0080ff;
          background-color: #fff;
          line-height: 16px;
          font-size: 12px;
        }
        .timeSpan {
          position: absolute;
          margin-top: 35px;
          margin-left: 3px;
          color: #0080ff;
          background-color: #fff;
          line-height: 16px;
          font-size: 12px;
        }
      }
    }
    .right {
      font-size: 22px;
      line-height: 30px;
      color: #3DA5FE;
    }
  }
  .secondInfo {
    img {
      width: 10px;
      margin-right: 4px;
    }
    span {
      font-size: 12px;
      line-height: 17px;
      color: #999999;
    }
    span:nth-child(2) {
      padding-right: 5px;
      border-right: 1px solid #EDEDED;
    }
    .shareFlag {
      padding-right: 5px;
      border-left: 1px solid #EDEDED;
      padding-left: 5px;
      color: #45a9fe;
    }
    .flightNo {
      padding-left: .5em;
    }
  }
}
.emptyBox{
  text-align: center;
  .no_data_img {
    display: block;
    margin: 20% auto 10px;
    width: 50%;
  }
  .no_data_text {
    color: #6e7481;
  }
}
.filter {
  position: fixed;
  z-index: 99;
  bottom: 0;
  height: 270px;
  width: 100%;
  .head {
    background: #484759;
    div {
      display: inline;
      line-height: 50px;
      font-size: 16px;
      text-align: center;
      color: #FFFFFF;
    }
    .cancel {
      border-right: 0.5px solid;
      padding: 0 20px 0 20px;
    }
    .clear {
      padding: 0 76px 0 76px;
    }
    .confirm {
      border-left: 0.5px solid;
      padding: 0 20px 0 20px;
    }
  }
  .leftTab {
    float: left;
    width: 30%;
    height: 220px;
    background-color: #F5F5F5;
    div {
      width: 100%;
      text-align: center;
      padding-top: 9px;
      padding-bottom: 9px;
      &.active {
        background: #FFFFFF;
      }
    }
  }
  .rightTab {
    height: 220px;
    overflow: scroll;
    background: #FFFFFF;
    .small-item {
      display: flex;
      align-items: center;
      padding: 9px 16px 9px 25px;
      border-bottom: 0.001px solid #DEDFE0;
      .text {
        flex-grow: 1;
      }
      .icon-select {
        display: inline-block;
        width: 18px;
        height: 18px;
        background: url('../../../assets/images/trade/plane/unselect.png') center center no-repeat;
        background-size: 100%; // 选中
        &.active {
          background: url('../../../assets/images/trade/plane/selected.png') center center no-repeat;
          background-size: 100%;
        }
      }
    }
  }
}
.footer {
  position: fixed;
  right: 0;
  bottom: 0;
  left: 0;
  padding: 3px 0;
  background-color: #FFFFFF;
  box-shadow: 0 -2px 8px 0 rgba(0,0,0,0.10);
  .aside {
    display: flex;
    align-content: center;
    align-items: center;
    div {
      flex-grow: 1;
      text-align: center;
      font-size: 12px;
      color: #484759;
      &.active {
        color: #48D1CC;
      }
    }
  }
}
.icon-filter {
  display: inline-block;
  width: 20px;
  height: 20px;
  background: url('../../../assets/images/trade/plane/filter.png') center center no-repeat;
  background-size: 100%;
  transform: translateY(25%);
} // 不显示伪元素
.icon-filter:before {
  display: none;
} // 从早到晚
.icon-to-night {
  display: inline-block;
  width: 20px;
  height: 20px;
  background: url('../../../assets/images/trade/plane/to_night.png') center center no-repeat;
  background-size: 100%;
  transform: translateY(25%);
  &.active {
    background: url('../../../assets/images/trade/plane/to_night_active.png') center center no-repeat;
    background-size: 100%;
  }
} // 价格
.icon-price {
  display: inline-block;
  width: 20px;
  height: 20px;
  background: url('../../../assets/images/trade/plane/price.png') center center no-repeat;
  background-size: 100%;
  transform: translateY(25%);
  &.active {
    background: url('../../../assets/images/trade/plane/price_active.png') center center no-repeat;
    background-size: 100%;
  }
}

.maskLayer {
  position: fixed;
  z-index: 99;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
}
</style>

