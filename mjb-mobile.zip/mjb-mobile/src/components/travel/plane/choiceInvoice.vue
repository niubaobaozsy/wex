<!--
  describe: pick invoice
  created by: zhuangyh
  date: 2018-03-21
-->
<template>
  <div class="main">
    <my-header title="选择发票抬头" @previous="goBack"></my-header>
    <div>
      <div class='choice-box has-header has-footer'>
        <div class='choice-list'>
          <div class='choice-c border-bottom' v-for="(item, index) in  invoices" :key="index">
            <div class='choice-l' @click="chooseInvoice(item)">
              <span class="check-box" :class="{'checked': item.isSelected}"></span>
              <div class='choice-t'>
                <span>{{ item.invoice_head || item.company_name }}</span>
                <span class="grey">税号:&nbsp;{{item.tax_num}}</span>
              </div>
            </div>
            <div class='choice-r' @click="invoiceEdit(item)"><img :src="edit"/></div>
          </div>
        </div>
        <div class="addMsg" @click="addInvoice()">
          <img :src="add">
          <span>新增发票抬头</span>
      </div>
      </div>
    </div>
    <addInvoice v-if="showEdit" :invoice="currentEditInvoice" @on-hide="showEdit=false" @complete="editInvoiceComplete" />
  </div>
</template>
<script>
import MyHeader from '../../common/header';
import edit from '../../../assets/images/trade/plane/edit.png';
import add from '../../../assets/images/trade/plane/add.png';
import addInvoice from './addInvoice';

export default {
  components: {
    MyHeader,
    addInvoice,
  },
  props: {
    invoices: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      edit,
      add,
      currentEditInvoice: {},
      showEdit: false,
    };
  },
  methods: {
    goBack() {
      this.$emit('on-hide');
    },
    chooseInvoice(item) {
      this.invoices.forEach((invoice) => {
        if(invoice.config_id !== item.config_id) {
          invoice.isSelected = false;
        }
      });
      item.isSelected = !item.isSelected;
      if (item.isSelected) {
        setTimeout(() => {
          this.$emit('on-hide');
        }, 300);
      }
    },
    addInvoice() {
      this.currentEditInvoice = {};
      this.showEdit = true;
    },
    invoiceEdit(invoice) {
      this.currentEditInvoice = invoice;
      setTimeout(() => {
        this.showEdit = true;
      }, 300);
    },
    editInvoiceComplete(invoice, type) {
      let invoices = [];
      if (type === 'editInvoice') {
        const invoiceSelected = this.invoices.filter(item => item.isSelected)[0] || {};
        invoice.forEach((item) => {
          if (item.config_id === invoiceSelected.config_id) {
            item.isSelected = true;
          } else {
            item.isSelected = false;
          }
        });
        invoices = invoice;
      } else if (type === 'delInvoice') {
        invoices = this.invoices.filter(item => item.config_id !== invoice.config_id);
      }
      this.$emit('updateInvoices', invoices);
    },
  },
  mounted() {},
};
</script>
<style lang="less" scoped>
.main {
  position: fixed;
  z-index: 99;
  top:0;
  left:0;
  right:0;
  bottom:0;
  background: #f2f2f2;
  overflow-y: scroll;
}
.f-col-0 {
  color:#000000;
}
.f-col-6 {
  color:#2A2A2A;
}
.choice-box {
  .choice-list {
    background: #ffffff;
    padding-left:14px;
    .choice-c {
      padding: 14px 23px 14px 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .choice-l {
        display: flex;
        align-items: center;
        .check-box {
          flex-shrink: 0;
          display: block;
          box-sizing: border-box;
          width: 18px;
          height: 18px;
          margin-right:15px;
          border-radius: 9px;
          border: 1px #ADADAD solid;
        }
        .checked {
          border: 0px;
          background-image: url(../../../assets/images/common/checked.png);
          background-repeat: no-repeat;
          background-position: center;
          background-size: contain;
        }
        .choice-t {
          span {
            display: block;
          }
          .grey {
            color: #808080;
          }
        }
      }
      .choice-r {
        img {
          width:16.3px;
          height:16.3px;
        }
      }
    }
  }
  .addMsg {
    height: 50px;
    position: fixed;
    bottom:0;
    left: 0;
    right:0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3DA5FE;
    img {
      width:12px;
      height:12px;
      margin-right: 4px;
    }
    span {
      font-size: 18px;
      color: #FFFFFF;
    }
  }
}
</style>
