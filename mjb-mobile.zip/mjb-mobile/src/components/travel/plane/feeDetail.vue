<!--
  describe：费用明细（订单详情）
  created by：panjm
  date：2018-01-15
-->
<template>
  <div class="feeDeteil" v-if="show">
    <my-header  @previous="goBack" :title="'订单明细'"></my-header>
    <div class="header" v-if="!showHeader">{{ headerTitle }}</div>
    <div class="extraFee" v-if="!showHeader">
      <div>{{ contentTitle }}</div>
      <div>
        <span>￥{{ extraFee }}</span>
        <span>×{{ ticketNum }}</span>
      </div>
    </div>
    <div :class="['normalFee', {'m10': !this.showHeader}]">
      <div class="title" v-if="!this.showHeader">原订单</div>
      <div :class="['content', {'mt-56': this.showHeader}]">
        <div class="item mb-10">
          <div :class="[{'grey': !this.showHeader}]">票价</div>
          <div>
            <span>{{ info.ticketPrice.ticketPrice }}</span>
            <span>×{{ ticketNum }}</span>
          </div>
        </div>
        <div class="item mb-10">
          <div :class="[{'grey': !this.showHeader}]">基建</div>
          <div>
            <span>{{ info.ticketPrice.airportFee }}</span>
            <span>×{{ ticketNum }}</span>
          </div>
        </div>
        <div class="item mb-10">
          <div :class="[{'grey': !this.showHeader}]">燃油</div>
          <div>
            <span>{{ info.ticketPrice.oilFee }}</span>
            <span>×{{ ticketNum }}</span>
          </div>
        </div>
        <div class="item">
          <div :class="[{'grey': !this.showHeader}]">服务费</div>
          <div>
            <span>{{ info.ticketPrice.serviceAmount }}</span>
            <span>×{{ ticketNum }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import MyHeader from '../../common/header';

export default {
  components: {
    MyHeader,
  },
  props: {
    show: {
      type: Boolean,
      required: true,
      default: false,
    },
    info: {
      type: Object,
      default: {},
    },
  },
  data() {
    return {
      showHeader: false,
      headerTitle: '',
      contentTitle: '',
      extraFee: '300',
    };
  },
  computed: {
    ticketNum() {
      return this.info.passengerDtos.length;
    },
  },
  methods: {
    goBack() {
      this.$emit('hide');
    },
    getTitle() {
      if (this.info.order.orderType === 1) {
        this.showHeader = false;
        this.headerTitle = '';
        this.contentTitle = '';
      } else if (this.info.order.orderType === 2) {
        this.showHeader = true;
        this.headerTitle = '退票';
        this.contentTitle = '退票费';
      } else {
        this.showHeader = true;
        this.headerTitle = '需支付';
        this.contentTitle = '改签费差额';
      }
    },
  },
  mounted() {
    this.getTitle();
  },
};
</script>
<style lang="less" scoped>
.feeDeteil {
  position: fixed;
  background-color: #f4F4F4;
  top: 0;
  bottom: 0;
  width: 100%;
  z-index: 99;
  .header {
    padding: 15px;
    margin-top: 56px;
    font-size: 14px;
    color: #858585;
    background-color: #ffffff;
    border-bottom: 0.3px solid #eeeeee;
  }
  .extraFee {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 15px 14px 15px;
    background-color: #ffffff;
    div:nth-child(1) {
      font-size: 16px;
      line-height: 22px;
    }
    div:nth-child(2) {
      color: #3DA5FE;
      span:nth-child(2) {
        font-size: 12px;
        line-height: 17px;
      }
    }
  }
  .normalFee {
    background-color: #ffffff;
    .m10 {
      margin: 10px 8px;
    }
    .mt-56 {
      margin-top: 56px;
    }
    .title {
      padding: 12px 15px;
      color: #858585;
      border-bottom: 1px solid #eeeeee;
    }
    .content {
      padding: 14px 12px;
      .item {
        display: flex;
        justify-content: space-between;
        .grey {
          color: #666666;
        }
        .black {
          color: #000000;
        }
        div:nth-child(1) {
          font-size: 16px;
          line-height: 22px;
        }
        div:nth-child(2) {
          span:nth-child(1) {
            font-size: 16px;
            line-height: 22px;
            color: #666666;
          }
          span:nth-child(2) {
            font-size: 12px;
            line-height: 17px;
            color: #858585;
          }
        }
      }
      .mb-10 {
        margin-bottom: 10px;
      }
    }
  }
}
</style>

