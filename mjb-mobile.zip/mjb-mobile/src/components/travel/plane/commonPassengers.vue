<!--
  describe："机票———常用旅客"
  created by：Yim Lee
  date：2018-1-9
-->
<template>
  <div>
    <my-header :title="'常用旅客'" @previous="goBack"></my-header>
    <div class="has-header passenger-wrap"></div>
  </div>
</template>
<script type="text/ecmascript-6">
import { mapState } from 'vuex';
import MyHeader from '../../common/header';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {
    };
  },
  watch: {
  },
  computed: {
    ...mapState({
    }),
  },
  created() {
  },
  mounted() {
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
  },
};
</script>
<style lang="less" scoped>
</style>

