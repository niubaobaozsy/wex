 <!--
  describe：旅客信息
  created by：周積坤
  date：2017-11-29
-->

<template>
  <div>
    <my-header :title="top.title" :headerClass="top.headerTop" @previous="goBack" ></my-header>
    <div class="has-header">
      <div class="travel-main">
      <swipeout>
      <swipeout-item v-for="(items, index) in travelsData" :key="index" ref="swip">
        <div slot="right-menu">
          <swipeout-button @click.native="showPlugin(items.commPassengerId, index)" style="font-size:17px;background:#FC4B4B;width: 66px;border-top:0.5px solid #DEDFE0;border-bottom:1px solid #DEDFE0;">删除</swipeout-button>
        </div>
        <div slot="content" @click="checkMsg(items, index)">
          <div class="travel-box">
              <div class="travelSecondCol">
                <span>{{items.cnName}}</span>
                <div><section>手机号</section><p>{{items.mobile}}</p></div>
                <div><section>{{items.name}}</section><p>{{items.certNumber}}</p></div>
              </div>
          </div>
        </div>
      </swipeout-item>
      </swipeout>
        <div class="addMsg" @click="add()">
          <img :src="addMsg">
          <span>{{top.addTitle}}</span>
      </div>
      </div>
    </div>
    <!-- <under-dev v-if="unavailale"></under-dev> -->
  </div>
</template>
<script type="text/ecmascript-6">
  import { Swipeout, SwipeoutItem, SwipeoutButton, Group, XSwitch } from 'vux';
  import myHeader from '../../common/header';
  // import underDev from '../../common/underDevTip';
  import add from '../../../assets/images/trade/flight/add.png';

  export default {
    components: {
      myHeader,
      Group,
      Swipeout,
      SwipeoutItem,
      XSwitch,
      SwipeoutButton,
      // underDev,
    },
    data() {
      return {
        show1: true,
        unavailale: true,
        travelsData: [],
        addMsg: add,
        certType: '',
        top: {
          title: '旅客信息',
          addTitle: '添加旅客信息',
        },
      };
    },
    methods: {
      goBack() {
        this.$router.push('/travel/plane');
      },
      add() {
        this.$store.commit('TRAVELMSG', {});
        this.$router.push({ path: '/travel/plane/travelMsg' });
      },
      vuxChangeWidth() {
      // 修改vux-swiper-item距离content的宽
        (this.$refs.swip || []).forEach((swip) => {
          const list = swip.$slots['right-menu'][0].children.filter(one => one.tag);
          list.forEach((one) => {
            one.componentOptions.propsData.width = 66;
          });
        });
      },
      checkType() {
        // 转换证件类型
        this.listType.forEach((data) => {
          console.log(data);
          if (data.type === toString(this.certType)) {
            console.log(112);
            console.log(data.name);
          }
        });
      },
      getTravelMsg() {
        const self = this;
        const params = {
          page_size: 50,
          page_number: 1,
        };
        this.$store.dispatch('mineTravelMsg', params).then((res) => {
          console.log(res);
          if (res && res.code === '1') {
            if (res.data) {
              console.log(res.data.data);
              this.travelsData = res.data.data;
              this.travelsData.forEach((data) => {
                switch (data.certType) {
                  case 1:
                    data.name = '身份证';
                    break;
                  case 2:
                    data.name = '护照';
                    break;
                  case 3:
                    data.name = '护照';
                    break;
                  case 4:
                    data.name = '回乡证';
                    break;
                  case 5:
                    data.name = '港澳通行证';
                    break;
                  case 6:
                    data.name = '军人证';
                    break;
                  case 8:
                    data.name = '台胞证';
                    break;
                  default:
                }
              });
              this.$nextTick(() => {
                self.vuxChangeWidth();
              });
            }
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      },
      // 删除弹框
      showPlugin(Id, index) {
        console.log(Id);
        const self = this;
        this.$vux.confirm.show({
          title: '删除',
          content: '删除该收款信息？',
          onConfirm() {
            self.deletInvoice(Id, index);
          },
        });
      },
      // 确认删除
      deletInvoice(Id, index) {
        const params = {
          commPassengerId: Id,
        };
        this.$store.dispatch('deleteTravel', params).then((res) => {
          if (res.code === '1') {
            console.log(res);
            this.travelsData.splice(index, 1);
            setTimeout(() => {
              this.$router.replace('/travel/plane/travelTitle');
            }, 800);
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      },
      checkMsg(obj, index) {
        console.log(index);
        this.$store.commit('TRAVELMSG', obj);
        setTimeout(() => {
          this.$router.push({
            path: '/travel/plane/travelMsg', query: { id: obj.commPassengerId },
          });
        }, 800);
      },
    },
    mounted() {
      console.log(this.show1);
      this.getTravelMsg();
    },
};
</script>
<style lang="less" scoped>

.travel-main {
  .vux-swipeout {
    .vux-swipeout-item {
      margin-top:10px;
      .travel-box {
        padding:12px 15px;
        box-sizing: border-box;
        .travelSecondCol {
          span {
            color:#000000;
            line-height: 22px;
            font-size: 16px;
          }
          div {
            display: flex;
            color:#9B9B9B;
            font-size: 14px;
            line-height: 20px;
            p{
              margin-left:20px;
            }
          }
        }
      }
    }
  }
  .addMsg {
    height: 50px;
    margin-top:10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #FFFFFF;
    img {
      width:12px;
      height:12px;
      margin-right: 5px;
    }
    span {
      font-size: 16px;
      color: #000000;
    }
  }
}
</style>

