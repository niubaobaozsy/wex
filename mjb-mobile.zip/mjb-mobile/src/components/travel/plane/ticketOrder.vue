<!--
  describe：机票下单页
  created by：Guanxj
  date：2018-1-4
-->
<template>
  <div>
    <my-header  @previous="goBack" :rightTitle="searchTicket.departureText" :leftTitle="searchTicket.arrivalText" :titleImg="arrow" :showImgTitle="true"></my-header>
    <div class="has-header has-footer main">
      <ul class="information border-top">
        <li class="information-list border-bottom" @click=" trick = true">
          <div class="list-left">
            <p>
              <span>{{searchTicket.departureDate}}</span>
              <span>{{weekDay}}</span>
              <span>{{flightInfo.depTime}}</span>
            </p>
            <p>
              <span>{{priceDetailInfo.price}}</span>
              <span>基建+燃油</span>
              <span>￥{{priceDetailInfo.airPortFee + priceDetailInfo.oilFee}}</span>
            </p>
          </div>
          <div class="list-right">
            <img :src="rArrow" alt="" class="r-arrow">
          </div>
        </li>
        <li class="information-list border-bottom">
          <div class="list-left">
            <p class="gray">下单后预计<span>20</span>分钟内出票</p>
          </div>
        </li>
      </ul>
      <ul class="information border-top">
        <li class="information-list border-bottom">
          <div class="list-left">
            <span class="gray">请选择乘机人</span>
          </div>
          <div class="list-right">
            <span class="gray">已选择:{{passengersSelected.length}}人</span>
          </div>
        </li>
        <li class="information-list border-bottom">
          <div class="passengers">
            <div v-for="(item, index) in passengers" :key="index" class="passengerButton" :class="{'active': item.isSelected}" @click="choosePassengers(item)" v-if="index<7">
              {{item.cnName}}
            </div>
            <div class="passengerButton" @click="passegerShow = true">
              <img :src="addPassengers" alt="" class="addPassengers">
              <span class="addText">新增</span>
            </div>
          </div>
        </li>
      </ul>
      <ul class="information border-top">
        <li class="information-list border-bottom" v-for="(item, index) in passengers" :key="index" v-if="item.isSelected">
          <div class="list-left" @click="deletePassengerInfo(item)">
            <img :src="sub" alt="" class="sub">
          </div>
          <div class="list-between" @click="passengerEdit(item)">
            <p><span class="name">{{item.cnName}}</span>&nbsp;&nbsp;&nbsp;<span>{{item.certNumber}}</span></p>
            <p class="gray">电话号码&nbsp;&nbsp;&nbsp;{{item.mobile}}</p>
          </div>
          <div class="list-right" @click="passengerEdit(item)">
            <img :src="rArrow" alt="" class="r-arrow">
          </div>
        </li>
      </ul>
      <ul class="information border-top">
        <li class="information-list border-bottom">
          <div class="list-left">
            <span class="gray">联系人默认为下单人，暂不支持修改</span>
          </div>
        </li>
        <li class="information-list border-bottom">
          <div class="list-left">
            <p><span class="name">{{contacts.cnName}}</span></p>
            <p class="gray">电话号码&nbsp;&nbsp;&nbsp;<span>{{contacts.mobile}}</span></p>
          </div>
        </li>
      </ul>
      <ul class="information border-top">
        <li class="information-list border-bottom">
          <div class="list-left">
            <span class="gray">请选择消费券</span>
          </div>
          <div class="list-right" @click="showVouchers = true">
            <span class="gray">已选择{{voucherSelected.length}}张,共¥{{voucherSelectedTotalBalance.toFixed(2)}}元</span>
            <img :src="rArrow" alt="" class="r-arrow">
          </div>
        </li>
        <li class="information-list border-bottom" v-for="(item, index) in voucherSelected" :key="index">
          <div class="list-left" @click="unSelectedVouchers(item)">
            <img :src="sub" alt="" class="sub">
          </div>
          <div class="list-between">
            <div class="coupon">
              <div class="couponInfo">
                <span class="couponText">{{item.remark}}</span>
                <span class="balanceHead">{{item.voucherReturnCode ? '余额' : '有效期至'}}</span>
              </div>
              <div class="couponInfo">
                <span class="code">{{item.voucherReturnCode ? item.voucherReturnCode : item.voucherResc}}</span>
                <span class="balanceNum">{{(item.voucherBalance * 1).toFixed(2)}}</span>
              </div>
            </div>
          </div>
        </li>
      </ul>
      <ul class="information border-top" style="margin-bottom: 100px;">
        <li class="information-list border-bottom">
          <div class="list-left">
            <span class="gray">发票抬头</span>
          </div>
        </li>
        <li class="information-list border-bottom" @click="invoiceShow=true" v-if="invoice">
          <div class="list-left">
            <p><span class="name">{{invoice.invoice_head || invoice.company_name}}</span></p>
            <p class="gray">税号：{{invoice.tax_num}}</p>
          </div>
          <div class="list-right">
            <div class="badge" v-if="invoice.is_default==='Y'">
              <span>默认</span>
            </div>
            <img :src="rArrow" alt="" class="r-arrow">
          </div>
        </li>
        <li class="add-invoice border-bottom" v-else @click="invoiceShow=true">
          <img :src="add">
          <span>添加发票</span>
        </li>
      </ul>
    </div>
    <div class="footer">
      <div class="price">￥{{totalPrice}}</div>
      <div class="mingxi" @click="showMX">
        <div class="text" :style="textStyle">明细</div>
        <img :src="triangleUp" alt="" v-if="!showMingXi">
        <img :src="triangleDown" alt="" v-if="showMingXi">
      </div>
      <div class="badge" @click="submit">
        <span>提交订单</span>
      </div>
    </div>
    <plane-particulars :show="trick" @on-hide="onHide"/>
    <price-detail v-if="showMingXi" :priceInfo="priceDetailInfo" :passengerNum="passengersSelected.length" @on-hide="onHide"/>
    <choose-vouchers  v-if="showVouchers" :vouchers="vouchers"  @complete="updateVouchers"/>
    <choice-people v-if="passegerShow" :passengers="passengers"  @on-hide="onHide"  @updatePassengers="updatePassengers"/>
    <editPassenger v-if="showEdit" :passenger="currentEditPassenger" @on-hide="onHide" @complete="editPsgComplete"/>
    <choice-invoice v-if="invoiceShow" :invoices="invoices"  @on-hide="onHide"  @updateInvoices="updateInvoices"/>
    <apply-tip v-if="showTip" mainTitle="预定成功" subTitle="出票中请耐心等候" @go-home="$router.push('/travel')" @go-detail="goDetail"></apply-tip>
  </div>
</template>
<script>
import MyHeader from '../../common/header';
import PlaneParticulars from './planeParticulars';
import PriceDetail from './priceDetail';
import ChoicePeople from './choicePeople';
import ChooseVouchers from './chooseVouchers';
import choiceInvoice from './choiceInvoice';
import editPassenger from './passengerEdit';
import ApplyTip from './applyTip';
import rArrow from '../../../assets/rt-arrow.png';
import addPassengers from '../../../assets/images/trade/plane/addPassengers.png';
import sub from '../../../assets/images/trade/plane/sub.png';
import triangleUp from '../../../assets/images/trade/plane/triangleUp.png';
import triangleDown from '../../../assets/images/trade/plane/triangleDown.png';
import arrow from '../../../assets/images/trade/plane/arrow.png';
import add from '../../../assets/images/trade/flight/add.png';

export default {
  components: {
    MyHeader,
    PlaneParticulars,
    PriceDetail,
    ChoicePeople,
    ChooseVouchers,
    editPassenger,
    choiceInvoice,
    ApplyTip,
  },
  data() {
    return {
      rArrow,
      addPassengers,
      sub,
      triangleUp,
      triangleDown,
      arrow,
      add,
      showVouchers: false,
      trick: false,
      passegerShow: false,
      budgetShow: false,
      passengers: [],
      contacts: '',
      vouchers: [],
      showMingXi: false,
      textStyle: {
        color: '#000000',
      },
      showEdit: false,
      weekDay: '',
      invoices: [],
      invoiceShow: false,
      orderNo: '',
      showTip: false,
    };
  },
  computed: {
    searchTicket() {
      return this.$store.state.travel.searchTicket;
    },
    userInfo() {
      return this.$store.state.userInfo.user;
    },
    priceDetailInfo() {
      return this.$store.state.travel.bookingTicketInfo;
    },
    flightInfo() {
      return this.$store.state.travel.selectedTicketInfo;
    },
    passengersSelected() {
      return this.passengers.filter((passenger) => {
        return passenger.isSelected;
      });
    },
    voucherSelected() {
      return this.vouchers.filter(voucher => voucher.isChecked);
    },
    voucherSelectedTotalBalance() {
      return this.voucherSelected.map(item => parseFloat(item.voucherBalance)).reduce((a, b) => a + b, 0);
    },
    totalPrice() {
      const p = this.priceDetailInfo;
      return ((p.ticketPrice + p.airPortFee + p.oilFee + p.serviceAmount) * this.passengersSelected.length).toFixed(2);
    },
    invoice() {
      return this.invoices.filter(invoice => invoice.isSelected)[0];
    },
  },
  methods: {
    goBack() {
      if (this.showTip) {
        this.$router.push('/travel/plane/orderIndex/waitTicketOrders');
      } else {
        this.$router.go(-1);
      }
    },
    onHide() {
      this.trick = false;
      this.passegerShow = false;
      this.budgetShow = false;
      this.showEdit = false;
      this.showMingXi = false;
      this.invoiceShow = false;
    },
    choosePassengers(item) {
      item.isSelected = !item.isSelected;
    },
    unSelectedVouchers(voucher) {
      voucher.isChecked = false;
    },
    updateVouchers(vouchers) {
      this.vouchers = vouchers;
      this.showVouchers = false;
    },
    deletePassengerInfo(item) {
      item.isSelected = false;
    },
    showMX() {
      if (this.showMingXi) {
        this.showMingXi = false;
        this.textStyle = {
          color: '#000000',
        };
      } else {
        this.showMingXi = true;
        this.textStyle = {
          color: '#1E90FF',
        };
      }
    },
    passengerEdit(passenger) {
      this.currentEditPassenger = passenger;
      this.showEdit = true;
    },
    updatePassengers(passengers) {
      this.passengers = passengers;
    },
    editPsgComplete(passenger, type) {
      if (type === 'addPassenger') {
        this.passengers.unshift(passenger);
      } else {
        this.passengers.every((item, index) => {
          if (item.commPassengerId === passenger.commPassengerId) {
            if (type === 'editPassenger') {
              this.passengers[index] = passenger;
            } else if (type === 'delPassenger') {
              this.passengers.splice(index, 1);
            }
            return false;
          }
          return true;
        });
      }
    },
    getVouchers() {
      const params = {
        user_email: '',
        extend_param: '',
        voucher_return_code: '',
        biz_type: 'JP_GN',
      };
      this.$store.dispatch('chooseVouchers', params).then((res) => {
        if (res && res.code === '1') {
          let hasDefaultVoucher = false;
          res.data.forEach((item) => {
            item.isChecked = false;
            if (item.voucherBalance >= this.priceDetailInfo.ticketPrice && !hasDefaultVoucher) {
              item.isChecked = true;
              hasDefaultVoucher = true;
            }
          });
          this.vouchers = res.data;
        } else if (res && res.resultMsg) {
          this.showToast({ msg: res.resultMsg.split('，')[0] });
        }
      });
    },
    getCommonPassengers() {
      this.$store.dispatch('mineTravelMsg', {
        page_size: 50,
        page_number: 1,
      }).then((res) => {
        if (res.data.data.length > 0 && res.code === '1') {
          res.data.data.forEach((item) => {
            // item.checked = true; // checked 为选择乘机人组件中已勾选的
            item.isSelected = false;
            switch (item.certType) {
              case 1:
                item.name = '身份证';
                break;
              case 2:
                item.name = '护照';
                break;
              case 3:
                item.name = '护照';
                break;
              case 4:
                item.name = '回乡证';
                break;
              case 5:
                item.name = '港澳通行证';
                break;
              case 6:
                item.name = '军人证';
                break;
              case 8:
                item.name = '台胞证';
                break;
              default:
            }
          });
          this.passengers = res.data.data;
        }
      });
    },
    getDefalutInvoice() {
      this.$store.dispatch('getDefaultConfig').then((res) => {
        if (res && res.code === '0000') {
          if (res.data) {
            res.data.companys.forEach((item) => {
              if (item.is_default === 'Y') {
                item.isSelected = true;
              } else {
                item.isSelected = false;
              }
            });
            this.invoices = res.data.companys;
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    getUserInfo() {
      this.$store.dispatch('getUserInfo', { id: this.userInfo.userId }).then((rep) => {
        if (rep.code === '0000') {
          console.log(rep);
          this.contacts = {
            cnName: rep.data.user_full_name,
            mobile: rep.data.user_mobile,
            email: rep.data.email,
          };
        }
      });
    },
    getWeekDay(date) {
      const weekDay = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
      const myDate = new Date(Date.parse(date.replace(/-/g, '/')));
      return weekDay[myDate.getDay()];
    },
    submit() {
      if (this.passengersSelected.length === 0) {
        this.showToast({ msg: '请选择乘机人' });
        return false;
      } else if (!this.voucherSelected.length) {
        this.showToast({ msg: '请选择消费券' });
        return false;
      } else if (this.invoice.invoice_head === undefined) {
        this.showToast({ msg: '请选择发票抬头' });
        return false;
      }
      const params = {
        companyId: this.invoice.company_id,
        companyName: this.invoice.company_name,
        contactName: this.contacts.cnName,
        email: this.contacts.email,
        esBills: JSON.stringify(this.voucherSelected),
        flightInfo: JSON.stringify(this.flightInfo),
        invoiceHead: this.invoice.invoice_head,
        mobile: this.contacts.mobile,
        passenegers: JSON.stringify(this.passengersSelected),
        priceInfo: JSON.stringify(this.priceDetailInfo),
        tlementType: '2',
      };
      this.showLoading('订单提交中…');
      this.$store.dispatch('submitTicketOrders', params).then((res) => {
        this.hideLoading();
        if (res && res.data && res.data.order) {
          this.orderNo = res.data.order.orderNo;
          this.showTip = true;
        } else if (res && res.resultMsg) {
          this.showToast({ msg: res.resultMsg });
        }
      });
      return true;
    },
    updateInvoices(invoices) {
      this.invoices = invoices;
    },
    goDetail() {
      this.$router.push({
        path: '/travel/plane/orderDetail', query: { orderNo: this.orderNo, redirect: 'allOrders' },
      });
    },
  },
  mounted() {
    this.getCommonPassengers();
    this.getVouchers();
    this.getDefalutInvoice();
    this.getUserInfo();
    this.weekDay = this.getWeekDay(this.searchTicket.departureDate);
  },
};
</script>
<style lang="less" scoped>
  .main {
    .information{
      margin-bottom: 8px;
      .information-list{
        display: flex;
        margin-bottom: 1px;
        padding: 12.5px 15px 12.5px 15px;
        background: #FFFFFF;
        font-size: 14px;
        .passengers {
          display: flex;
          flex-flow: wrap;
          align-items: center;
          width: 100%;
          height: 100%;
          .passengerButton {
            box-sizing: border-box;
            border-radius: 5px;
            width: 21%;
            height: 100%;
            text-align: center;
            padding: 4px 2px ;
            margin: 2%;
            .addPassengers {
              float: left;
              height: 20px;
              width: 20px;
            }
            .addText {
              float: left;
              color: #1E90FF;
            }
            &.active {
              background: #1E90FF;
              border-color: #1E90FF;
              color: #FFFFFF;
            }
          }
        }
        .list-left {
          display: flex;
          flex-flow: column;
          .sub {
            display: block;
            width: 18px;
            height: 18px;
            margin: auto 0; // 垂直方向居中
          }
        }
        .list-between{
          flex: 3; // 缩放倍数为3
          display: flex;
          flex-flow: column;
          padding-left: 15px;
          .r-arrow {
            display: block;
            width: 9px;
            height: 16px;
            margin-left: 15px;
            margin-top: 6px;
          }
          .coupon {
            border: #808080 0.5px dotted;
            .couponInfo {
              width: 100%;
              margin-left: 0;
              margin-right: 0;
              display: flex;
              justify-content: space-between;
              flex-flow: wrap;
              // padding: 10px;
              .couponText {
                width: 210px;
                padding-top: 10px;
                margin-left: 5%;
                text-align: left;
                color: #808080;
                font-size: 12px;
                overflow: hidden;
                text-overflow:ellipsis;
                white-space: nowrap;
              }
              .code {
                width: 120px;
                padding-bottom: 10px;
                margin-left: 5%;
                text-align: left;
              }
              .balanceHead {
                width: 50px;
                margin-right: 5%;
                padding-top: 10px;
                text-align: right;
                color: #808080;
                font-size: 12px;
              }
              .balanceNum {
                width: 85px;
                margin-right: 5%;
                padding-bottom: 10px;
                text-align: right;
              }
            }
          }

        }
        .list-right {
          flex: 1; // 占满剩余的水平空间
          display: flex;
          justify-content: flex-end; // 位于容器的结尾
          align-items: center;
          width: auto;
          .r-arrow {
            display: block;
            width: 9px;
            height: 16px;
            margin-left: 15px;
          }
          .badge {
            span {
              padding: 3px 14px;
              margin: 0 10px;
              border-radius: 11px;
              font-size: 12px;
              color: #fff;
              word-break: keep-all;
              background-color: #FFA500;
            }
          }
        }
        span.name {
          font-weight: bold;
          font-size: 16px;
        }
        p.gray {
          color: #808080;
        }
        span.gray {
          color: #808080;
        }
      }
      .add-invoice {
        text-align: center;
        line-height: 72px;
        background-color: #fff;
      }
    }
  }
  .footer {
    position: fixed;
    height: 50px;
    right: 0;
    bottom: 0;
    left: 0;
    height: 50px;
    background: #FFFFFF;
    .price {
      position: absolute;
      left: 5px;
      color: #1E90FF;
      margin: 12px 10px;
    }
    .badge {
      span {
        position: absolute;
        right: 5px;
        padding: 6px 20px;
        margin: 10px 10px;
        border-radius: 15px;
        font-size: 14px;
        color: #fff;
        word-break: keep-all;
        background-color: #1E90FF;
      }
    }
    .mingxi {
      position: absolute;
      right: 120px;
      display: flex;
      margin: 9px 0;
      .text {
        margin: auto 0;
      }
      img {
        display: block;
        padding: 0;
        width: 30px;
        height: 30px;
      }
    }
  }
</style>
