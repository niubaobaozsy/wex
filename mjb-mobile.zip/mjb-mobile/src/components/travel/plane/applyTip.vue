<!--
  describe："机票———改签/退票 申请成功" 页面
  created by：Yim Lee
  date：2018-1-9
-->
<template>
  <div class="tip-wrap">
    <img :src="tipImg">
    <div class="main-title">{{ mainTitle }}</div>
    <div class="sub-title">{{ subTitle }}</div>
    <div class="go-back" @click="goHome">返回美捷报</div>
    <div class="go-detail" @click="goDetail">订单详情</div>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import tipImg from '../../../assets/images/trade/plane/tipImg.png';

export default {
  components: {
  },
  props: {
    mainTitle: '',
    subTitle: '',
  },
  data() {
    return {
      tipImg,
    };
  },
  watch: {
  },
  computed: {
    ...mapState({
    }),
  },
  created() {
  },
  mounted() {
  },
  methods: {
    // 返回美捷报
    goHome() {
      this.$emit('go-home');
    },
    goDetail() {
      this.$emit('go-detail');
    },
  },
};
</script>
<style lang="less" scoped>
.tip-wrap {
  position: fixed;
  top: 46px;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 0 15px;
  background: #FFFFFF;
  z-index: 10px;
  text-align: center;
  z-index: 100;
  background: #FFFFFF;
  img {
    margin-top: 62px;
    width: 172px;
    height: 127.5px;
  }
  div {
    width: 100%;
  }
  .main-title {
    margin-top: 29px;
    font-size: 24px;
    color: #000000;
  }
  .sub-title {
    margin-top: 10px;
    font-size: 14px;
    color: #666666;
  }
  .go-back {
    margin-top: 37px;
    font-size: 14px;
    color: #666666;
    background: #3DA5FE;
    border-radius: 40px;
    line-height: 41px;
    font-size: 16px;
    color: #FFFFFF;
  }
  .go-detail {
    margin-top: 15px;
    font-size: 14px;
    color: #666666;
    border: 1px solid #3DA5FE;
    border-radius: 40px;
    line-height: 41px;
    font-size: 16px;
    color: #3DA5FE;
  }
}
</style>
