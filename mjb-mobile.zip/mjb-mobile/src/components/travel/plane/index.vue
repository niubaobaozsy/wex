<!--
  describe: plane
  created by: panjm
  date: 2017-12-28
-->
<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>
