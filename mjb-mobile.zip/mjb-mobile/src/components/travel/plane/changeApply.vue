<!--
  describe："机票———改签申请"
  created by：Yim Lee
  date：2018-1-9
-->
<template>
  <div>
    <my-header title="改签申请" @previous="goBack"></my-header>
    <div class="has-header change-wrap">
      <!-- 第一步 -->
      <div class="step-one border">
        <div class="text border-bottom">第一步：选择乘机人</div>
        <div class="passenger-select">
          <div :class="[{'border-top': index!==0, 'unable': item.ticketInstanceStatus!==2}, 'passenger']" v-for="(item, index) in passengers" :key="index" @click="selectPassenger(item)">
            <span class="name">{{ item.passengerName }}</span>
            <span :class="['to-select', {'selected': item.selected}]"></span>
          </div>
        </div>
      </div>
      <!-- 第二步 -->
      <div class="step-two border">
        <div class="text border-bottom">第二步：选择改签原因</div>
        <div class="reason-select" @click="showSelect = true">
          <span class="reason-text">改签原因</span>
          <span class="reason">{{ endorseReason }}</span>
          <img :src="rightArrow">
        </div>
      </div>
      <!-- 第三步 -->
      <div class="step-three border">
        <div class="text border-bottom">第三步：选择改签航班</div>
        <div class="ticket" @click="goSelect" v-if="flightInfo">
          <div class="start">
            <span class="date">{{ formatDate(flightInfo.depDate, "yyyy-MM-dd") }}</span>
            <span class="time">{{ flightInfo.depTime }}</span>
            <span class="place">{{ flightInfo.orgAirport }}</span>
          </div>
          <div class="to">
            <span class="plane-type">{{ priceInfo.vendorNumber === 100 ? "美亚" : "一起飞" }} {{ priceInfo.cabin }}</span>
            <img :src="toIcon">
            <span class="plane-name">{{ flightInfo.flightNo }} | {{ flightInfo.airlineName }}</span>
          </div>
          <div class="end">
            <span class="date">{{ flightInfo.duration }}</span>
            <div class="end-time">
              <span>{{ flightInfo.arrTime }}</span>
              <span v-if="flightInfo.addDays">+{{ flightInfo.addDays }}天</span>
            </div>
            <span class="place">{{ flightInfo.desAirport }}</span>
          </div>
          <img :src="rightArrow">
        </div>
        <div v-else class="add-flight" @click="goSelect">
          <img :src="add">
          <span>添加航班</span>
        </div>
      </div>
    </div>
    <div class="footer" v-if="!isChange" @click="submit">提交申请</div>
    <div class="footer white" v-if="isChange">
      <div class="money">
        <span>改签费用：</span>
        <span>¥1678.00</span>
      </div>
      <div class="submit" @click="submit">提交申请</div>
    </div>
    <apply-tip v-if="showTip" mainTitle="申请改签成功" subTitle="正在为您重新预定机票" @go-home="$router.push('/travel')" @go-detail="goDetail"></apply-tip>
    <select-data :show.sync="showSelect" :title="'改签原因'" :selectData="changeReason" @select="selectReason"></select-data>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import MyHeader from '../../common/header';
import ApplyTip from './applyTip';
import SelectData from '../../common/selectData';
import { formatDate } from '../../../js/util.js';
import rightArrow from '../../../assets/rt-arrow.png';
import toIcon from '../../../assets/images/trade/plane/to.png';
import add from '../../../assets/images/trade/flight/add.png';

export default {
  components: {
    MyHeader,
    ApplyTip,
    SelectData,
  },
  data() {
    return {
      rightArrow,
      toIcon,
      add,
      isChange: false,
      showTip: false,
      showSelect: false,
      changeReason: [ // 退票申请原因
        {
          text: '行程改变',
        },
        {
          text: '下单时选错日期/航班',
        },
        {
          text: '下单时填错乘机人/联系人信息',
        },
        {
          text: '在其他渠道发现更优惠的机票',
        },
        {
          text: '航班延误或取消，航班时刻变更',
        },
        {
          text: '其他',
        },
      ],
      endorseOrderNo: '',
    };
  },
  watch: {
  },
  computed: {
    ...mapState({
    }),
    passengers() {
      return this.$store.state.travel.endorse.passengers;
    },
    ticket() {
      return this.$store.state.travel.endorse.ticket;
    },
    endorseReason() {
      return this.$store.state.travel.endorse.endorseReason || '行程改变';
    },
    orderNo() {
      return this.$store.state.travel.endorse.orderNo;
    },
    flightInfo() {
      return this.$store.state.travel.endorse.flightInfo;
    },
    priceInfo() {
      return this.$store.state.travel.endorse.priceInfo;
    },
    contact() {
      return this.$store.state.travel.endorse.contact;
    },
  },
  methods: {
    goBack() {
      this.$router.push({
        path: '/travel/plane/orderDetail', query: { orderNo: this.orderNo },
      });
      // if (this.showTip) {
      //   this.showTip = false;
      // } else {
      //   this.$router.push({
      //     path: '/travel/plane/orderDetail', query: { orderNo: this.orderNo },
      //   });
      // }
    },
    // 选择改签航班
    goSelect() {
      const searchTicket = {};
      searchTicket.departureText = this.ticket.orgCity;
      searchTicket.departureCity = this.ticket.orgCityCode;
      searchTicket.arrivalText = this.ticket.desCity;
      searchTicket.arrivalCity = this.ticket.desCityCode;
      searchTicket.departureDate = '';
      this.$store.commit('SEARCHTICKET', searchTicket);
      this.$router.push('/travel/plane/ticketList');
    },
    // 选择乘机人
    selectPassenger(item) {
      if (item.ticketInstanceStatus === 2) {
        item.selected = !item.selected;
        this.$store.commit('ENDORSE', { passengers: this.passengers });
      } else {
        this.showToast({ msg: '不支持该乘机人改签' });
      }
    },
    // 选择退票原因
    selectReason(reason) {
      this.$store.commit('ENDORSE', { endorseReason: reason.text });
    },
    // 提交申请
    submit() {
      this.showLoading('提交中…');
      this.$store.dispatch('createEndorseOrder', {
        contact: this.contact,
        endorseReason: this.endorseReason,
        flightInfo: JSON.stringify(this.flightInfo),
        orderNo: this.orderNo,
        passengers: JSON.stringify(this.passengers.filter((passenger) => { return passenger.selected })),
        priceInfo: JSON.stringify(this.priceInfo),
      }).then((res) => {
        this.hideLoading();
        if (res.code === '1' && res.data) {
          this.endorseOrderNo = res.data;
          this.showTip = true;
        } else if (res && res.resultMsg) {
          this.showToast({ msg: res.resultMsg });
        }
      });
    },
    formatDate(timestamp, fmt) {
      return formatDate(timestamp, fmt);
    },
    // 点击查看订单详情
    goDetail() {
      this.$router.push({
        path: '/travel/plane/orderDetail', query: { orderNo: this.endorseOrderNo, redirect: 'refundTicketOrders' },
      });
    },
  },
  beforeRouteLeave(to, from, next) {
    if (to.path !== '/travel/plane/ticketList') {
      this.$store.commit('ENDORSE', {
        orderNo: '',
        contact: '',
        passengers: '',
        ticket: '',
        endorseReason: '',
        flightInfo: '',
        priceInfo: '',
      });
    }
    next();
  }
};
</script>
<style lang="less" scoped>
.change-wrap {
  overflow: hidden;
  .step-one,
  .step-two,
  .step-three {
    background: #FFFFFF;
    margin-top: 10px;
    .text {
      line-height: 44px;
      font-size: 14px;
      color: #858585;
      padding: 0 15px;
    }
    .passenger-select {
      padding-left: 15px;
      .passenger {
        height: 50px;
        display: flex;
        flex-wrap: nowrap;
        align-items: center;
        padding-right: 15px;
        .name {
          display: flex;
          flex: 1;
          font-size: 16px;
          color: #000000;
          line-height: 50px;
        }
        .to-select {
          display: flex;
          width: 18px;
          height: 18px;
          box-sizing: border-box;
          border-radius: 50%;
          border: 1px solid #ADADAD;
        }
        .selected {
          border: 0px;
          background-image: url(../../../assets/images/common/checked.png);
          background-repeat: no-repeat;
          background-position: center;
          background-size: contain;
        }
      }
      .unable {
        .name {
          color: #ADADAD;
        }
        .to-select {
          background-color: #eee;
        }
      }
    }
    .reason-select {
      padding: 0 15px;
      height: 50px;
      display: flex;
      flex-wrap: nowrap;
      align-items: center;
      .reason-text,
      .reason {
        display: flex;
        font-size: 16px;
        color: #000000;
        // line-height: 50px;
      }
      .reason-text {
        flex: 0.4;
      }
      .reason {
        flex: 1;
        justify-content: flex-end;
        color: #666666;
      }
      img {
        width: 8px;
        height: 13px;
        margin-left: 10px;
      }
    }
    .ticket {
      display: flex;
      align-items: center;
      padding: 20px 15px;
      .start,
      .end,
      .to {
        display: flex;
        width: 27%;
        flex-direction: column;
        .date {
          font-size: 16px;
          color: #666666; // line-height: 16px;
        }
        .time {
          font-size: 24px;
          color: #000000; // line-height: 24px;
        }
        .place {
          font-size: 12px;
          color: #666666; // line-height: 12px;
        }
        .end-time {
          display: flex;
          flex-wrap: nowrap;
          width: 100%;
          span {
            display: flex;
            &:nth-of-type(1) {
              font-size: 24px;
              color: #000000;
              width: 65%;
            }
            &:nth-of-type(2) {
              width: 35%;
              line-height: 30px;
              text-align: left;
              color: #666666;
              font-size: 10px;
              transform: scale(0.8);
            }
          }
        }
        .plane-type {
          font-size: 14px;
          color: #000000;
          text-align: center;
        }
        img {
          width: 82%;
          height: 6px;
          margin: 7px auto 10px;
        }
        .plane-name {
          font-size: 14px;
          color: #666666;
          text-align: center;
        }
      }
      .start {
        width: 26%;
      }
      .to {
        width: 39%;
        margin: 0 10px;
      }
      img {
        width: 8px;
        height: 13px;
      }
    }
    .add-flight {
      text-align: center;
      line-height: 122px;
    }
  }
}

.footer {
  position: fixed;
  width: 100%;
  bottom: 0;
  line-height: 50px;
  font-size: 18px;
  color: #FFFFFF;
  text-align: center;
  background: #3DA5FE;
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.10);
  padding: 0 15px;
  box-sizing: border-box;
  z-index: 99;
  .money {
    display: inline-block;
    width: 68%;
    line-height: 22px;
    span:nth-of-type(1) {
      font-size: 16px;
      color: #000000;
    }
    span:nth-of-type(2) {
      font-size: 16px;
      color: #3DA5FE;
    }
  }
  .submit {
    display: inline-block;
    width: 30%;
    background: #3DA5FE;
    border-radius: 40px;
    font-size: 16px;
    color: #FFFFFF;
    text-align: center;
    line-height: 30px;
  }
}

.white {
  background: #FFFFFF;
  text-align: left;
}
</style>
