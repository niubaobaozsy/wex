<!--
  describe：乘客信息编译组件
  date：2018-1-12
-->
<template>
  <div class="passenger-edit">
    <my-header :title="top.title" rightItem="保存" @on-click="save" @previous="goBack" ></my-header>
    <div class="has-header">
      <div class="travelMsg-c">
      <div class="travel-m">
        <div :class="['travel-list', {'changeBg' : trick1 && !passengerList.cnName}]">
          <div class="active border-bottom">
            <span>姓名</span>
            <input type="text" placeholder="请填写" :class="{'changeBg' : trick1 && !passengerList.cnName}" v-model="passengerList.cnName" required>
          </div>
        </div>
        <div :class="['travel-list', {'changeBg' : trick2 && !passengerList.mobile}]">
          <div class="active border-bottom">
            <span>移动电话</span>
            <input type="text" placeholder="请填写" :class="{'changeBg' : trick2 && !passengerList.mobile}" v-model="passengerList.mobile" maxlength="11" required>
          </div>
        </div>
        <div @click="showAction=true" class="travel-list">
          <div class="active">
            <span>性别</span>
            <div class="arrow">
            <p :class="['choice', {'randomly': passengerList.gender }]">{{passengerList.gender || '请选择'}}</p>
              <img :src="r_arrow" >
            </div>
          </div>
        </div>
        <div class="hideBg"></div>
        <div class="travel-list" @click="show = true">
          <div class="active border-bottom">
            <span>证件类型</span>
            <div class="arrow">
              <p :class="['choice', {'randomly':  passengerList.name }]">{{ passengerList.name || '请选择'}}</p>
              <img :src="r_arrow" >
            </div>
          </div>
        </div>
        <div :class="['travel-list', {'changeBg' : trick3 && !passengerList.certNumber}]">
          <div class="active">
            <span>证件号</span>
            <input type="text" placeholder="请填写" :class="{'changeBg' : trick3 && !passengerList.certNumber}" v-model="passengerList.certNumber" required>
          </div>
        </div>
      </div>
      <div class="deleted" v-if="deleteShow" @click="del">删除信息</div>
      </div>
    </div>
    <papers-type :show="show" @on-select="show=true"  @on-hide="show=false" @ievent = "ievent"></papers-type>
    <actionsheet v-model="showAction" :menus="menus" :show-cancel="showCancel" @on-click-menu="addtxt"></actionsheet>
  </div>
</template>
<script>
import { Actionsheet } from 'vux';
import myHeader from '../../common/header';
import papersType from './papersType';
import rArrow from '../../../assets/rt-arrow.png';

export default {
  props: {
    passenger: {},
  },
  components: {
    myHeader,
    Actionsheet,
    papersType,
  },
  data() {
    return {
      r_arrow: rArrow,
      showAction: false, // 是否显示弹出差旅单类型选择组件
      showCancel: true, // 是否显示取消按钮
      show: false,
      deleteShow: false,
      trick1: false,
      trick2: false,
      trick3: false,
      trick4: false,
      trick5: false,
      top: {
        title: '',
      },
      menus: {
        menu0: '<span style="color: #666666;">男</span>',
        menu1: '<span style="color: #666666;">女</span>',
      },
      passengerList: {},
    };
  },
  computed: {
    // travelMsg: {
    //   get() {
    //     return this.$store.state.travel.travelMsg;
    //   },
    //   set(val) {
    //     this.$store.state.travel.travelMsg = val;
    //   },
    // },
    // passengerList() {
    //   return this.$store.state.travel.passengerList;
    // },
    // passenger() {
    //   return this.$store.state.travel.passenger;
    // },
  },
  methods: {
    goBack() {
      this.$emit('on-hide');
    },
    save() { // 保存添加旅客信息
      const params = {
        certNumber: this.passengerList.certNumber,
        certType: this.passengerList.certType,
        cnName: this.passengerList.cnName,
        commPassengerId: this.passengerList.commPassengerId,
        mobile: this.passengerList.mobile,
        gender: this.passengerList.gender,
      };
      if (this.verify()) {
        this.showLoading();
        this.$store.dispatch('addTravelMsg', params).then((res) => {
          this.hideLoading();
          if (res && res.code === '1' && res.data) {
            this.showToast({ msg: res.resultMsg });
            if (this.passengerList.commPassengerId) {
              this.$emit('complete', this.passengerList, 'editPassenger');
            } else {
              this.$emit('complete', res.data, 'addPassenger');
            }
            this.trick1 = false;
            this.trick2 = false;
            this.trick3 = false;
            this.deleteShow = true;
            // this.$store.commit('PASSENGER', []);
            setTimeout(() => {
              this.$emit('on-hide');
            }, 800);
          } else {
            this.showToast({ msg: res.resultMsg });
          }
        });
      } else {
        this.showToast({ msg: this.verifyMsg });
      }
    },
    // 保存前校验
    verify() {
      // const regUser = /^[\u4e00-\u9fa5]+$/;
      // const regCarNumber = /[0-9]{16}/;
      // if (!regUser.test(this.passengerList.cnName)) {
      if (!this.passengerList.cnName) {
        this.verifyMsg = '请填写姓名';
        this.trick1 = true;
        return false;
      } else if (!this.passengerList.mobile) {
        this.verifyMsg = '请填写：移动电话';
        this.trick2 = true;
        return false;
      } else if (!this.passengerList.gender) {
        this.verifyMsg = '请选择性别';
        return false;
      } else if (!this.passengerList.name) {
        this.verifyMsg = '请选择证件类型';
        return false;
      } else if (!this.passengerList.certNumber) {
        this.verifyMsg = '请填写证件号';
        this.trick3 = true;
        return false;
      }
      return true;
    },
    addtxt(ket, item) { // 点击弹出差旅单类型选择组件
      if (item) {
        let str = '';
        str = item.split('>');
        str = str[1].split('<')[0];
        this.passengerList.gender = str;
      }
    },
    del() {
      const self = this;
      this.$vux.confirm.show({
        content: '确定要删除该乘客？',
        onConfirm() {
          self.showLoading();
          self.$store.dispatch('deleteTravel', { commPassengerId: self.passengerList.commPassengerId }).then((res) => {
            self.hideLoading();
            if (res.code === '1') {
              self.showToast({ msg: '删除成功', width: '14em', time: 800 });
              self.$emit('complete', self.passengerList, 'delPassenger');
              // self.$store.commit('PASSENGER', []);
              // self.$emit('delPassenger', self.passengerList.commPassengerId);
              setTimeout(() => {
                self.$emit('on-hide');
              }, 800);
            }
          });
        },
      });
    },
    ievent(item) {
      this.passengerList.name = item.name;
      this.passengerList.certType = item.type;
    },
  },
  mounted() {
    if (Object.keys(this.passenger).length) {
      this.top.title = '编辑旅客信息';
      this.passengerList = Object.assign({}, this.passenger);
      this.deleteShow = true;
    } else {
      this.top.title = '添加旅客信息';
      this.deleteShow = false;
    }
  },
};
</script>
<style lang="less" scoped>
@black:       #000000;
@grey:        #C3C3C3;
@border-grey: #DEDFE0;
.passenger-edit {
  position: fixed;
  z-index: 99;
  top:0;
  left:0;
  right:0;
  bottom:0;
  background-color: #f2f2f2;
  overflow-y: -webkit-paged-x;
}
.travelMsg-c {
  font-size: 16px;
  .travel-m {
    background: #ffffff;
    .travel-list {
      background: #FFFFFF;
      box-sizing: border-box;
      padding:0 13px 0 15px;
      &.changeBg{
      background: rgba(255,127,127,0.2);
      }
      .active {
        height:50px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        input {
          height:22px;
          border:none;
          text-align: right;
          color:#858585;
          outline: medium;
          font-size: 16px;
          &::-webkit-input-placeholder {
            color: @grey;
          }
          &.changeBg {
            background: rgba(255,127,127,0);
          }
        }
        .choice {
          color:@grey;
        }
        .randomly {
          color: #858585;
          line-height: 20px;
        }
        span {
          color:@black;
          line-height: 22px;
        }
        .arrow {
          display: flex;
          align-items: center;
          img {
            width:7.5px;
            height:16px;
            margin-left:11.5px;
          }
        }
      }
    }
    .hideBg{
      height:10px;
      background: #F4F4F4;
    }
  }
}
</style>

