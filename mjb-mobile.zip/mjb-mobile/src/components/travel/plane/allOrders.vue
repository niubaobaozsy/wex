<!--
  describe："机票订单列表———全部订单"
  created by：Yim Lee
  date：2018-1-4
-->
<template>
  <div class="mytrip-container" infinite-scroll-immediate-check="true" v-infinite-scroll="loadMore" infinite-scroll-disabled="busy">
    <div class="type-content">
      <!-- 无数据时显示 -->
      <div class="no-data-text" v-if="!orderList.length && !isLoading">
        <img :src="noDataImg" alt="">
        <p>暂无订单</p>
      </div>
      <!-- 机票订单 -->
      <div v-if="orderList.length">
        <div class="ticket" v-for="(item, index) in orderList" :key="index">
          <!-- 机票信息 -->
          <div class="ticket-info border" @click="goDetail(item.orderNo)">
            <div class="area-state columns is-mobile is-gapless">
              <div class="area column">
                <span>{{ item.orgCity }}</span>
                <span class="route-icon">···</span>
                <img :src="plane">
                <span class="route-icon">···</span>
                <span>{{ item.desCity }}</span>
              </div>
              <span class="state column">{{ getOrderStatus(item, item.orderStatus) }}</span>
            </div>
            <!-- 飞机航班 -->
            <div class="number-money columns is-mobile is-gapless">
              <div class="number column">
                <span>{{ item.airlineName }}</span>
                <span>{{ item.flightNo }}</span>
              </div>
              <span class="money column">￥{{ item.orderPrice.toFixed(2) }}</span>
            </div>
            <!-- 起飞时间 -->
            <div class="number-money columns is-mobile is-gapless">
              <div class="number column">
                <span>起飞时间</span>
                <span>{{ formatTime(item.depTime, 'yy-MM-dd hh:mm:ss') }}</span>
              </div>
            </div>
            <!-- 到达时间 -->
            <div class="number-money columns is-mobile is-gapless">
              <div class="number column">
                <span>到达时间</span>
                <span>{{ formatTime(item.arrTime, 'yy-MM-dd hh:mm:ss') }}</span>
              </div>
            </div>
          </div>
          <!-- 机票退改签情况 v-if="item.orderType === 2 || item.orderType === 3"  v-if="item.orderType === 3"  v-if="item.orderType === 2"-->
          <div class="ticket-change border-top" v-if="item.changeOrders.length">
            <div class="border-bottom situation">退改签情况</div>
            <div v-for="(changeOrder, index) in item.changeOrders" :key="index" @click="goDetail(changeOrder.orderNo)">
              <div v-if="changeOrder.orderType === 3" class="change border-bottom columns is-mobile is-gapless">
                <span class="column name is-4.5">{{ getPassengers(changeOrder.passengers) }}</span>
                <span class="column time is-7">改签到 {{ formatTime(changeOrder.depTime, 'yy-MM-dd hh:mm') }}</span>
                <img :src="rightArrow">
              </div>
              <div v-if="changeOrder.orderType === 2" class="return border-bottom columns is-mobile is-gapless">
                <span class="column name">{{ getPassengers(changeOrder.passengers) }}</span>
                <span class="column type">退票</span>
                <img :src="rightArrow">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import noDataImg from '../../../assets/images/common/no_data.png';
import plane from '../../../assets/images/trade/flight.png';
import rightArrow from '../../../assets/rt-arrow.png';
import { formatDate } from '../../../js/util.js';

export default {
  components: {
  },
  data() {
    return {
      noDataImg,
      plane,
      rightArrow,
      pageInfo: {
        pageIndex: 1,
        pageSize: 20,
      },
      busy: false,
      hasNextPage: true,
      isLoading: true,
      orderList: [],
      orderType: 'allOrders',
    };
  },
  watch: {
  },
  computed: {
    ...mapState({
      // orderListType: state => state.travel.plane.orderListType,
    }),
  },
  created() {
    this.orderType = this.$route.params.orderType;
    this.getTicketOrders(true);
  },
  mounted() {},
  methods: {
    // 格式化时间

    formatTime(timestamp, fmt) {
      return formatDate(timestamp, fmt);
    },
    // 点击查看订单详情
    goDetail(num) {
      this.$router.push({
        path: '/travel/plane/orderDetail', query: { orderNo: num, redirect: this.orderType },
      });
    },
    /**
     *  获取订单状态
     */
    getOrderStatus(info, orderStatus) {
      if (info.createStatus === 0 && info.orderStatus === 1) {
        return '下单中';
      } else if (info.orderStatus === 1 && info.checkedStatus === 0) {
        return '客服审核中';
      }
      const obj = {
        state_1: '待用户确认',
        state_2: '出票中',
        state_3: '出票完成',
        state_4: '订单已取消',
        state_5: '出票失败',
      };
      return obj[`state_${orderStatus}`];
    },
    // 获取乘机人
    getPassengers(passengers) {
      const nameList = passengers.map(item => item.passengerName);
      return nameList.join('、');
    },
    // // 加载更多
    loadMore() {
      const self = this;
      this.busy = true; // 禁止再次滑动加载
      if (this.hasNextPage) {
        setTimeout(() => {
          self.getTicketOrders();
        }, 200);
      }
    },
    /**
     * 获取订单列表
     */
    getTicketOrders(refresh) {
      // const self = this;
      if (refresh) {
        this.orderList = [];
        this.pageInfo.pageIndex = 1;
      }
      const params = {
        orderType: 1,
        pageIndex: this.pageInfo.pageIndex,
        pageSize: this.pageInfo.pageSize,
      };
      if (this.orderType === 'refundTicketOrders') {
        params.orderType = 4;
      }
      this.showLoading();
      this.isLoading = true;
      this.$store.dispatch('getTicketOrders', params)
        .then((res) => {
          this.hideLoading();
          this.isLoading = false;
          if (res && res.resultFlag === 1) {
            this.busy = false;
            console.log('订单信息', res);
            if (res.data.total > (this.pageInfo.pageIndex * this.pageInfo.pageSize)) {
              this.hasNextPage = true;
              this.pageInfo.pageIndex++;
            } else {
              this.hasNextPage = false;
            }
            let orders = res.data.data;
            if (this.orderType === 'waitTicketOrders') {
              orders = orders.filter((item) => {
                return item.orderStatus === 2;
              });
            } else if (this.orderType === 'outTicketOrders') {
              orders = orders.filter((item) => {
                return item.orderStatus === 3;
              });
            }
            this.orderList = this.orderList.concat(orders);
          } else if (res && res.resultMsg) {
            this.showToast({ msg: res.resultMsg });
          }
        });
    },
  },
  beforeRouteUpdate(to, from, next) {
    this.orderType = to.params.orderType;
    this.getTicketOrders(true);
    next();
  },
};
</script>
<style lang="less" scoped>
.mytrip-container {
  .type-content {
    display: flex;
    flex-direction: column;
    .no-data-text {
      background: #F4F4F4;
      font-size: 14px;
      line-height: 20px;
      color: #9B9B9B;
      padding: 10px 15px;
      text-align: center;
      img {
        width: 50%;
        height: 50%;
        margin-top: 20%;
      }
    }
    .ticket {
      .ticket-info {
        padding: 12px 15px;
        margin-top: 10px;
        background: #FFFFFF;
        .area-state,
        .number-money {
          display: flex;
          flex-wrap: nowrap;
          align-items: center;
          line-height: 22px;
          margin-bottom: 0;
          .area,
          .number {
            display: flex;
            flex: 3;
            align-items: center;
            span {
              font-size: 16px;
              color: #000000;
              &:nth-of-type(2) {
                color: #60B4FF;
                margin-left: 10px;
              }
              &:nth-of-type(3) {
                color: #60B4FF;
                margin-right: 10px;
              }
            }
            .route-icon {
              letter-spacing: 3px;
            }
            img {
              width: 25px;
              height: 25px;
            }
          }
          .state,
          .money {
            flex: 1;
            text-align: right;
            color: #6CC60A;
            font-size: 16px; // line-height: 22px;
          }
        }
        .area-state {
          margin-bottom: 5px;
        }
        .number-money {
          margin-top: 3px;
          .number {
            span {
              font-size: 14px;
              color: #666666;
              &:nth-of-type(2) {
                font-size: 14px; // color: #2A2A2A;
                color: #666666;
                margin-left: 5px;
                line-height: 20px;
              }
            }
          }
          .money {
            font-size: 14px;
            color: #666666;
          }
        }
      }
      .ticket-change {
        background: #FFFFFF;
        margin-top: 5px;
        .situation {
          // height: 44px;
          padding: 0 15px;
          font-size: 14px;
          line-height: 44px;
          color: #858585;
        }
        .change,
        .return {
          padding: 0 15px;
          height: 50px;
          margin: 0;
          align-items: center;
          font-size: 16px;
          img {
            height: 13px;
            width: 8px;
            margin-left: 10px;
          }
          .name {
            color: #000000;
          }
          .type {
            color: #666666;
          }
          .time {
            color: #FC4B4C;
          }
          span:nth-of-type(2) {
            text-align: right;
          }
        }
      }
    }
  }
}
</style>

