<!--
  describe：商旅主页
  created by:panjm
  date：2017-10-31
-->
<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>
