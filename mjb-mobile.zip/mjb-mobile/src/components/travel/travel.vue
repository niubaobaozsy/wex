<!--
  describe："商旅"页面 一级页面
  created by：panjm
  date：2017-10-25
-->
<style lang="less" scoped>
@import '../../assets/css/travel/travel.less';
</style>
<template>
    <div class="main has-footer">
      <my-header :title="top.title" @previous="goBack" :showBack="top.showBack"></my-header>
      <div class="Travel-booking has-header">
        <div class="Title-box border-bottom">
          <div class="title">行程预定</div>
        </div>
        <div class="travel">
          <div class="columns is-multiline is-mobile">
            <div class="column is-one-quarter item" v-for="(traBooking, index) in travelBooking" :key="index" @click="onClick(traBooking)" v-if="!traBooking.hidden">
              <img :src="icons[traBooking.icon]" class="icon">
              <div class="travelType">{{ traBooking.name }}</div>
            </div>
          </div>
        </div>
      </div>
      <div ref="form" style="display: none;"></div>
      <downPullLoading @loading="freshOrder">
        <div slot="list">
          <div class="Recent-orders border-bottom">
              <div class="Title-box">
                <div class="title">最近订单</div>
              </div>
              <div class="checkAll">
                <span class="all" @click="checkAll">查看全部</span>
                <i class="iconfont icon-fanhui-copy icon-arrowRight"></i>
              </div>
            </div>
            <!-- 最近订单——展示机票订单 -->
            <div v-for="(orderInfo, index) in showOrder" :key="index">
              <div v-if="orderInfo.airlineCode" class="orders border-bottom" @click="getOrderDetail('flight', orderInfo.orderNo, orderInfo)">
                <div class="firstLine">
                  <div class="firstLineLeft">
                    <span class="firstLine-item mr-10">{{ orderInfo.orgCity }}</span>
                    <span class="slot">···</span>
                    <i class="iconfont icon-aircraft icon-flight"></i>
                    <span class="slot">···</span>
                    <span class="firstLine-item ml-10">{{ orderInfo.desCity }}</span>
                  </div>
                  <span class="firstLine-item" v-if="orderInfo.orderPrice">￥{{ orderInfo.orderPrice }}</span>
                  <span class="firstLine-item" v-else></span>
                </div>
                <div class="secondLine">
                  <div>
                    <span class="time">出发时间</span>
                    <span class="time">{{ formatDate(orderInfo.depTime, 'yyyy/MM/dd hh:mm') }}</span>
                  </div>
                  <div>
                    <span class="state">{{ getFlightOrderStatus(orderInfo, orderInfo.orderStatus) }}</span>
                  </div>
                </div>
                <div class="thirdLine">
                  <span class="flight">航班</span>
                  <span class="flight">{{ orderInfo.flightNo }}</span>
                  <span class="flight">{{ orderInfo.desAirport }}</span>
                </div>
                <div class="fourthLine">
                  <div class="fourthLineBox">
                    <span class="fourthLine-item">下单时间</span>
                    <span class="fourthLine-item">{{ formatDate(orderInfo.createDate, 'yyyy/MM/dd') }}</span>
                  </div>
                  <div class="fourthLineBox">
                    <span class="fourthLine-item">订单号</span>
                    <span class="fourthLine-item">{{ orderInfo.orderNo }}</span>
                  </div>
                </div>
              </div>
              <!-- 最近订单——展示用车订单 -->
              <div v-else class="data-list border-bottom" @click="getOrderDetail('didi', orderInfo.orderId, orderInfo)">
                <div class="list-title">
                  <span class="car-type">{{getCarTypeName(orderInfo.useCarType)}}</span>
                  <span class="time">{{ formatDate(orderInfo.createTime, 'yyyy年MM月dd日 hh:mm') }}</span>
                  <span class="price">{{ `¥ ${(orderInfo.actualPrice * 1).toFixed(2)}`}}</span>
                </div>
                <div class="real-time-info" v-if="orderInfo.driver">
                  <div class="car-info">
                    <span class="car-card">{{ orderInfo.driver.driverCard }}</span>
                    <span>{{ orderInfo.driver.driverCarType }}</span>
                  </div>
                  <span class="order-status">{{getDidiOrderStatus(orderInfo.status)}}</span>
                </div>
                <div class="main-info">
                  <div class="trip-info">
                    <div class="star-area">
                      <p>{{ orderInfo.startName }}</p>
                    </div>
                    <div class="end-area">
                      <p>{{ orderInfo.endName }}</p>
                    </div>
                  </div>
                  <a :href="`tel:${orderInfo.driver.driverPhone}`" class="driver-phone" v-if="orderInfo.status!==700&&orderInfo.driver">
                    <img src="../../assets/images/trade/phone.png">
                  </a>
                </div>
              </div>
            </div>
            <load-more v-if="!showOrder.length && isloading" :tip="'加载中...'" style="width: 100%;padding: 22px 0px;box-sizing: border-box;margin:0 auto;background-color: #fff;"></load-more>
            <div v-if="!showOrder.length && !isloading" class="empty-tip">暂无行程</div>
        </div>
      </downPullLoading>
      <footerBar :index="1" :tabName="'journey'"></footerBar>

    </div>
</template>

<script>
import { LoadMore } from 'vux';
import { platform } from '@/platform';
import didi from '@/assets/images/trade/didi.png';
import flight from '@/assets/images/trade/flight.png';
import szzcGrey from '@/assets/images/trade/carGrey.png';
import szzc from '@/assets/images/trade/car.png';
import hotel from '@/assets/images/trade/hotel.png';
import hotelGrey from '@/assets/images/trade/hotelGrey.png';
import travelTest from '@/assets/images/trade/travelTest.png';
import ctripLogo from '@/assets/images/trade/ctriplogo.png';
import clyhLogo from '@/assets/images/trade/clyhlogo.png';
import { formatDate } from '@/js/util.js';
import downPullLoading from '../common/downPullLoading';
import footerBar from '../common/footerBar';
import MyHeader from '../common/header';


export default {
  components: {
    LoadMore,
    footerBar,
    MyHeader,
    downPullLoading,
  },
  data() {
    return {
      icons: {
        didi,
        flight,
        hotel,
        hotelGrey,
        szzcGrey,
        szzc,
        travelTest,
        ctripLogo,
        clyhLogo,
      },
      isloading: false,
      top: {
        title: '商旅',
        showBack: true,
      },
      travelBooking: [],
      extModule: {},
      didiOrders: [],
      planeOrders: [],
    };
  },
  computed: {
    baseConfig() {
      return this.$store.state.baseConfig;
    },
    userInfo() {
      return this.$store.state.userInfo;
    },
    hasDefaultConfig() {
      return this.$store.state.hasDefaultConfig;
    },
    appVisibility() {
      return this.$store.state.appVisibility;
    },
    showOrder() {
      return this.$store.state.travel.travelIndexMsgFeed;
    },
    travelMenuCfg() {
      return this.$store.state.menuConfig.travel.children;
    },
  },
  watch: {
    appVisibility(nVal) {
      if (nVal) {
        this.getOrderList().then((showOrder) => {
          this.$store.commit('TRAVELINDEXMSGFEED', showOrder);
        });
      }
    },
  },
  methods: {
    // 应该退出应用
    goBack() {
      platform.exit();
    },
    checkAll() {
      this.$router.push('/travel/bizOrder');
    },
    onClick(traBooking) {
      if (traBooking.alias.indexOf('::') > -1) {
        const aliasComponents = traBooking.alias.split('::');
        if (aliasComponents[0] === 'showMxWidget' && this.extModule[aliasComponents[1]]) {
          console.log(`即将调起美信插件:${this.extModule[aliasComponents[1]]}`);
          document.addEventListener('deviceready', () => {
            platform.showWidget(this.extModule[aliasComponents[1]], {
              orgId: this.userInfo.extension && this.userInfo.extension.full_path ? this.userInfo.extension.full_path.split('/')[3] : '',
            });
          }, false);
        } else if (aliasComponents[0] === 'executeFunc' && this[aliasComponents[1]]) {
          this[aliasComponents[1]]();
        } else if (aliasComponents[0] === 'jumpExtUrl' && this.extModule[aliasComponents[1]]) {
          this.setInnerNavigateFlag(this.extModule[aliasComponents[1]]);
          window.location.href = this.extModule[aliasComponents[1]];
        } else {
          this.showToast({ msg: '模块配置异常' });
        }
      } else {
        this.$router.push(traBooking.alias);
      }
    },
    getOrderDetail(moduleName, orderId, orderInfo) {
      if (this.travelMenuCfg[moduleName].alias.indexOf('::') > -1) {
        const aliasComponents = this.travelMenuCfg[moduleName].alias.split('::');
        if (aliasComponents[0] === 'showMxWidget' && this.extModule[moduleName]) {
          console.log(`即将调起美信插件:${this.extModule[moduleName]},并跳转订单详情页，订单号为${orderId}`);
          document.addEventListener('deviceready', () => {
            platform.showWidget(this.extModule[moduleName], {
              subModuleName: 'orderDetail',
              orderId,
              orgId: this.userInfo.extension && this.userInfo.extension.full_path ? this.userInfo.extension.full_path.split('/')[3] : '',
            });
          }, false);
        } else {
          this.showToast({ msg: '模块配置异常' });
        }
      } else {
         this.$router.push(traBooking.alias);
      }
    },
    getPlaneOrder() {
      return new Promise((resolve) => {
        const params = {
          orderType: 1,
          pageIndex: 1,
          pageSize: 10,
        };
        this.$store.dispatch('getTicketOrders', params).then((res) => {
          if (res && res.code === '1') {
            if (res.data && res.data.data) {
              this.planeOrders = res.data.data;
              resolve();
            }
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常${res.code}` });
            resolve();
          }
        });
      });
    },
    getDidiOrders() {
      return new Promise((resolve) => {
        console.log('employeeNumber', this.userInfo);
        const params = {
          mipAccount: this.userInfo.employeeNumber,
          useCarType: null,
          perPage: 3,
          pageNo: 1,
          startNum: '1',
        };
        this.$store.dispatch('getAllOrder', params)
          .then((res) => {
            if (res && res.errcode === '00000') {
              if (res.data && res.data.orders) {
                this.didiOrders = res.data.orders;
                resolve();
              }
            } else if (res && res.errmsg) {
              if(res.code !== '00004') this.showToast({ msg: res.errmsg });
              resolve();
            }
          });
      });
    },
    getOrderList() {
      let showOrder = [];
      const modulesList = [];
      const hasDidiAuth = !this.travelMenuCfg.didi.hidden;
      const hasPlaneAuth = !this.travelMenuCfg.flight.hidden;
      if (hasDidiAuth) modulesList.push(this.getDidiOrders());
      if (hasPlaneAuth) modulesList.push(this.getPlaneOrder());
      return new Promise((resolve) => {
        Promise.all(modulesList).then(() => {
          if (hasPlaneAuth) {
            this.planeOrders.forEach((item, index) => {
              if (item.depTime - Date.now() > 24 * 60 * 60) {
                showOrder.push(item);
                this.planeOrders.splice(index, 1);
              }
            });
          }
          if (hasDidiAuth) {
            this.didiOrders.forEach((item, index) => {
              if (item.status !== 700) {
                showOrder.push(item);
                this.didiOrders.splice(index, 1);
              }
            });
          }
          if (showOrder.length < 3) {
            const restOrder = this.planeOrders.concat(this.didiOrders).sort((a, b) => {
              const aTime = a.createDate || a.createTime;
              const bTime = b.createDate || b.createTime;
              return bTime - aTime;
            });
            showOrder = showOrder.concat(restOrder).slice(0, 3);
          }
          showOrder.sort((a, b) => {
            const aTime = a.createDate || a.createTime;
            const bTime = b.createDate || b.createTime;
            return bTime - aTime;
          });
          resolve(showOrder);
        });
      });
    },
    getCarTypeName(useCarType) {
      let carTypeName = '';
      if (useCarType === '301') {
        carTypeName = '快车';
      } else if (useCarType === '201') {
        carTypeName = '专车';
      }
      return carTypeName;
    },
    getDidiOrderStatus(orderStatus) {
      let statusName = '';
      switch (orderStatus) {
        case 300:
          statusName = '等待接单';
          break;
        case 311:
          statusName = '订单超时';
          break;
        case 400:
          statusName = '等待接驾';
          break;
        case 410:
          statusName = '司机已到达';
          break;
        case 500:
          statusName = '行程中';
          break;
        case 600:
          statusName = '行程结束';
          break;
        case 610:
          statusName = '已取消';
          break;
        case 700:
          statusName = '已支付';
          break;
        default:
          break;
      }
      return statusName;
    },
    getFlightOrderStatus(info, orderStatus) {
      if (info.createStatus === 0 && info.orderStatus === 1) return '下单中';
      if (info.orderStatus === 1 && info.checkedStatus === 0) return '客服审核中';
      const obj = {
        state_1: '待用户确认',
        state_2: '出票中',
        state_3: '出票完成',
        state_4: '订单已取消',
        state_5: '出票失败',
      };
      return obj[`state_${orderStatus}`];
    },
    formatDate(timestamp, fmt) {
      return formatDate(timestamp, fmt);
    },
    getDefaultConfig() {
      if (this.hasDefaultConfig) return;
      const _this = this;
      this.showLoading('正在加载页面');
      this.$store.dispatch('getDefaultConfig').then((rep) => {
        this.hideLoading();
        if (rep) {
          if (!(rep.data && rep.data.busiOrg && rep.data.busiOrg.config_id && rep.data.company && rep.data.company.company_id)) {
            this.$vux.confirm.show({
              content: '使用美捷报需填写报销基础信息，前往填写？',
              confirmText: '好',
              cancelText: '退出',
              onConfirm() {
                _this.$router.push({ path: '/mine/reimburseTitle', query: { redirect: '/travel' } });
              },
              onCancel() {
                platform.exit(true);
              },
            });
          } else {
            this.$store.commit('HAS_DEFAULT_CONFIG', true);
          }
        } else if (rep && rep.code) {
          this.showToast({ msg: `请求异常[${rep.code}]:${rep.msg}` });
        }
      });
    },
    freshOrder() {
      if (this.isloading) return false;
      this.isloading = true;
      this.getOrderList().then((showOrder) => {
        this.isloading = false;
        this.$store.commit('TRAVELINDEXMSGFEED', showOrder);
      }, () => {
        this.isloading = false;
      });
    },
    ctripHotel() {
      this.showLoading('页面跳转中…');
      this.$store.dispatch('ctripLogin', { ele: this.$refs.form }).then((res) => {
        this.hideLoading();
        if (res) this.showToast(res);
      });
    },
    unable() {
      this.showToast({ msg: '尚未接入，敬请期待…' });
    },
  },
  created() {
    Object.keys(this.travelMenuCfg).forEach((item) => {
      this.travelMenuCfg[item].moduleName = item;
      this.travelBooking.push(this.travelMenuCfg[item]);
    });
  },
  mounted() {
    this.top.showBack = this.baseConfig.platform !== 'meixinBase';
    this.getDefaultConfig();
    this.getOrderList().then((showOrder) => {
      this.$store.commit('TRAVELINDEXMSGFEED', showOrder);
    });
    // this.freshOrder();
    if (this.baseConfig.extModuleNameList.length) {
      const extModulePathList = this.baseConfig.extModulePathList;
      this.baseConfig.extModuleNameList.forEach((moduleName, index) => {
        this.extModule[moduleName] = extModulePathList[index];
      });
    }
  },
};
</script>

