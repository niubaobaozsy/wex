<!--
  describe：费用金额组件
  created by：ouql
  date：2017-11-28
-->
<template>
  <div class="car-fare" v-if="show">
    <!-- 呼叫- 费用估算 -->
    <div v-if="showA">
      <div class="sum">
        约
        <span>{{ price }}</span>元
      </div>
    </div>
    <!-- 支付 -->
    <div v-if="showB">
      <div class="desc">车费</div>
      <div class="sum">
        共
        <span :class="{'black':failed}">{{((totalPrice.total_price || car.order.totalPrice) * 1).toFixed(2)}}</span>元
      </div>
      <!-- 2018-3-10 阶段性移除相关规则入口 -->
      <!-- <div class="rule" v-if="state === 'cancelled'">消费规则<img src="../../../assets/images/trade/right2x.png" alt=""> </div>
      <div class="rule" v-if="state !== 'cancelled'">费用疑问<img src="../../../assets/images/trade/right2x.png" alt=""> </div> -->
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex';

export default {
  props: {
  },
  data() {
    return {
      // desc: '车费',
      // amount: '8.20',
      // rule: '消费规则',
      // failed: false,
      // showA: false,
      // showB: false,
      // showC: false,
    };
  },
  methods: {

  },
  computed: {
    show() {
      return this.state === 'nonCall' || this.state === 'toCall' || this.state === 'calling' || this.state === 'payFail' || this.state === 'paid' || this.state === 'paying' || this.state === 'endTrip';
    },
    showA() {
      return this.state === 'nonCall' || this.state === 'toCall' || this.state === 'calling';
    },
    showB() {
      return this.state === 'payFail' || this.state === 'paid' || this.state === 'endTrip' || this.state === 'paying';
    },
    failed() {
      return this.state === 'payFail';
    },
    price() {
      const price = this.car.evaluatePrice;
      return (price * 1).toFixed(2);
    },
    ...mapState({
      car: state => state.travel.car,
      state: state => state.travel.car.state,
      totalPrice: state => state.travel.car.totalPrice,
    }),
  },
  mounted() {
  },
};
</script>
<style lang="less" scoped>
.car-fare {
  background: #fff;
  padding: 20px 0;
  .desc {
    display: flex;
    justify-content: center;
    font-size: 12px;
    color: #858585;
    line-height: 12px;
    height: 12px;
  }
  .sum {
    line-height: 1;
    display: flex;
    justify-content: center;
    align-items: baseline;
    box-sizing: border-box;
    padding: 8px 0;
    span {
      font-size: 36px;
      color: #F59B0B;
      padding: 0 5px;
      line-height: 28px;
    }
    .black {
      color: #000;
    }
  }
  .rule {
    display: flex;
    justify-content: center;
    font-size: 12px;
    color: #858585;
    height: 12px;
    line-height: 12px;
    img {
      width: 8px;
      height: 12px;
      margin: auto 5px auto 5px;
    }
  }
}
</style>
