<!--
  describe: card-按钮组件
  created by: panjm
  date: 2017-11-28
-->
<template>
  <div class="containerBox">
    <div :class="['buttonBox', {'blue': state == 'toCall' || state == 'calling'}, {'grey': enableCall}]" v-if="showCall" @click="startCall">
      <span>呼叫快车</span>
    </div>
    <div :class="['buttonBox', {'white': state == 'calling' || state == 'waitOrder'}]" v-if="showCancel" @click="endCall">
      <span>取消叫车</span>
    </div>
    <div :class="['buttonBox', {'blue': state == 'endTrip' || state == 'paid' || state == 'paying'}, {'grey': state == 'payFail'}]" v-if="showPay" @click="paid">
      <span>确认支付</span>
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex';

export default {
  data() {
    return {
    };
  },
  methods: {
    startCall() {
      if (!this.enableCall) {
        this.$emit('start-call');
      }
    },
    endCall() {
      this.$emit('end-call');
    },
    paid() {
      if (this.state !== 'payFail') {
        this.$emit('paid');
      }
    },
  },
  computed: {
    showCall() {
      return this.state === 'toCall' || this.state === 'nonCall' || this.state === 'calling';
    },
    showCancel() {
      return this.state === 'waitOrder';
    },
    showPay() {
      return this.state === 'paid' || this.state === 'endTrip' || this.state === 'paying' || this.state === 'payFail';
    },
    ...mapState({
      state: state => state.travel.car.state,
      enableCall: state => state.travel.car.enableCall,
    }),
  },
};
</script>
<style lang="less" scoped>
.containerBox {
  .buttonBox {
    width: 100%;
    height: 50px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 16px;
    line-height: 22px;
  }
  .blue{
    background-color: #3DA5FE;
    color: #ffffff;
  }
  .white{
    background-color: #ffffff;
    color: #666666;
  }
  .grey{
    background-color: #C1C1C1;
    color: #ffffff;
  }
}
</style>
