<!--
  describe：更换乘车人组件
  created by：欧倩伶
  date：2017-11-27
-->
<template>
  <div class="cRider">
    <my-header :titleText="'更换乘车人'">
      <img src="~@/assets/images/common/nav_back.png" width="20" slot="left" @click="close">
      <span slot="right" @click="sumbit">确认</span>
    </my-header>
      <div class="changeRider border">
        <div class="inpN border-right">
          <input type="telephone" v-model="inpNum" placeholder="请输入手机号码" maxlength="11">
        </div>
        <div class="org" @click="selectOrg">
          <span class="inline-block">组织架构</span>
          <img src="../../../assets/images/trade/right2x.png" class="inline-block" alt="">
        </div>
      </div>
      <div class="history">
        <p>历史记录</p>
        <div class="content border">
          <div class="list">
            <div class="row border-bottom" v-for="(item, index) in list" :key="index" @click="changeTel(item)">
              {{item.name}} ({{item.phone}})
            </div>
          </div>
          <div class="clean" @click="clearHistory" v-if="list.length">清除历史记录</div>
          <div class="clean" @click="clearHistory" v-if="!list.length">暂无历史记录</div>
        </div>
      </div>
    <org :show.sync="showOrg" @confirm="onOrgConfirm" v-model="orgnization" />
  </div>
</template>
<script>
import { mapState } from 'vuex';
import MyHeader from 'common/newHeader';
import org from 'common/org';

export default {
  components: {
    MyHeader,
    org,
  },
  data() {
    return {
      showOrg: false,
      inpNum: '',
      list: [],
      orgnization: [],
    };
  },
  methods: {
    selectOrg() {
      this.showOrg = true;
    },
    onOrgConfirm(users) {
      this.orgnization = users;
      this.inpNum = users[0].telephone_number;
      this.list.push({ name: users[0].user_full_name, phone: users[0].telephone_number });
      this.$store.commit('CAR', Object.assign({}, this.car, { historyCallers: this.list }));
    },
    changeTel(item) {
      this.inpNum = item.phone;
    },
    clearHistory() {
      this.list = [];
      this.$store.commit('CAR', Object.assign({}, this.car, { historyCallers: this.list }));
    },
    sumbit() {
      const pattern = /^0{0,1}(1[0-9][0-9]|15[7-9]|153|156|18[7-9])[0-9]{8}$/;
      if (!pattern.test(this.inpNum)) {
        this.showToast({ msg: '请输入正确的手机号码', width: '12em' });
      } else {
        this.$emit('on-select', this.inpNum);
        this.$emit('update:showCR', false);
      }
    },
    close() {
      this.$emit('close');
    },
  },
  computed: {
    ...mapState({
      car: state => state.travel.car,
      user: state => state.travel.car.user,
      historyCallers: state => state.travel.car.historyCallers,
    }),
  },
  created() {
    this.inpNum = this.car.passenger_phone;
    if (this.historyCallers.length) {
      this.list = this.historyCallers;
    } else {
      this.list.push({ name: '自己', phone: this.user.phone });
    }
  },
};
</script>
<style lang="less" scoped>
@import '../../../assets/css/base.less';
.cRider {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 100;
  width: 100%;
  height: 100%;
  background: #F4F4F4;
  animation-duration: .5s;
}

.changeRider {
  height: 50px;
  background: #fff;
  margin-top: 17px;
  display: flex;
  justify-content: space-between;
  padding: 14px;
  box-sizing: border-box;
  .inpN {
    width: 60%;
    line-height: 22px;
    input {
      border: none;
      font-size: 16px; // color: #C3C3C3;
      outline: none;
    }
  }
  .org {
    width: 40%;
    padding-left: 10px;
    line-height: 22px;
    text-align: justify;

    &:after {
      content: '';
      display: inline-block;
      width: 100%;
    }
  }
}

.history {
  margin-top: 20px;
  p {
    margin: 10px 14px;
    font-size: 12px;
    color: #9B9B9B;
  }
  .content {
    background: #fff;
    box-sizing: border-box;
    color: #666;
    .list {
      .row {
        height: 50px;
        padding: 14px;
        box-sizing: border-box;
      }
    }
    .clean {
      height: 50px;
      padding: 14px 0;
      box-sizing: border-box;
      text-align: center;
    }
  }
}
</style>

