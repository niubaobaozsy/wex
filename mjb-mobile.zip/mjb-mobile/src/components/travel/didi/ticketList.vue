<!--
  describe：获取打车券组件
  created by：yw
  date：2017-12-4
-->
<template>
    <div class="ticketList flex-column">
      <my-header :titleText="'打车券'">
        <img src="~@/assets/images/common/nav_back.png" width="20" slot="left" @click="closePanel()">
      </my-header>
      <div class="main rest-area">
          <div class="title" v-if="availableTickets.length && !readOnly">可用打车券</div>
          <div :class="['dataList', {'dataListSelect': (selectedTicket.voucherId === data.voucherId) && !readOnly}]" v-for="(data, index) in availableTickets" :key="'available_' + index" @click="toSelectVoucher(data, index)">
            <ul>
              <li>
                <div class="userInfo">打车券 - {{data.voucherReturnCode ? '个人' : '公共'}}</div>
                <div class="dataTime">
                  {{data.voucherReturnCode ? '余额' : data.endDate ? '有效期至' + data.endDate : ''}}
                </div>
              </li>
              <li :class="{'fontBase' : data.voucherReturnCode}">
                <div class="overDots">
                  {{data.remark}}
                </div>
                <div class="voucherBalance" v-if="!!data.voucherReturnCode">
                  {{ (data.voucherBalance * 1).toFixed(2) + '元'}}
                </div>
              </li>
            </ul>
          </div>
          <div v-if="unavailableTickets.length">
            <div class="untitle">
              不可用打车券
            </div>
            <div class="describe">
              预估金额与实际金额有误差，为保证顺利用车，打车券可用余额需要比预估金额大才可使用。
            </div>
          </div>
          <div class="dataList unList" v-for="(data, index) in unavailableTickets" :key="'unavailable_' + index">
            <ul>
              <li>
                <div class="userInfo">
                  <span>打车券-</span>
                  <span>{{data.voucherReturnCode ? '个人' : '公共'}}</span>
                </div>
                <div class="dataTime">
                  {{data.voucherReturnCode ? '余额' : data.endDate ? '有效期至' + data.endDate : ''}}
                </div>
              </li>
              <li :class="{'fontBase' : data.voucherReturnCode}">
                <div class="overDots">
                  {{data.remark}}
                </div>
                <div class="voucherBalance" v-if="!!data.voucherReturnCode">
                  {{ (data.voucherBalance * 1).toFixed(2) + '元' }}
                </div>
              </li>
            </ul>
          </div>
          <no-data-tip v-if="!availableTickets.length && !unavailableTickets.length && !loadingIsShow">
            <p slot="tip" v-if="tip">{{tip}}</p>
          </no-data-tip>
      </div>
    </div>
</template>
<script>
import { mapState } from 'vuex';
import noDataTip from '@/components/common/noDataTip';
import myHeader from '@/components/common/newHeader';

export default {
  name: 'ticketList',
  components: {
    noDataTip,
    myHeader,
  },
  props: {
    readOnly: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      selectIndex: 0,
      tip: '',
      loadingIsShow: false,
    };
  },
  watch: {
    showList() {},
  },
  computed: {
    availableTickets() {
      if (this.readOnly) return this.$store.state.travel.car.voucherList;

      const useEA = (this.currentOrder.orderId || this.currentOrder.id) ? !!this.selectedTicket.voucherReturnCode : (this.startArea.cityid !== this.user.cityid || this.endArea.cityid !== this.user.cityid);

      let orderPrice = this.car.evaluatePrice;
      if (this.state === 'endTrip') {
        orderPrice = this.car.order.totalPrice ? this.car.order.totalPrice * 1 : (this.car.totalPrice.total_price * 1);
      }

      return this.$store.state.travel.car.voucherList.filter((perTicket) => {
        return perTicket.enableFlag === 'Y' && (perTicket.voucherBalance >= orderPrice) && useEA === !!perTicket.voucherReturnCode;
      });
    },
    unavailableTickets() {
      if (this.readOnly) return [];

      const useEA = (this.currentOrder.orderId || this.currentOrder.id) ? !!this.selectedTicket.voucherReturnCode : (this.startArea.cityid !== this.user.cityid || this.endArea.cityid !== this.user.cityid);

      let orderPrice = this.car.evaluatePrice;
      if (this.state === 'endTrip') {
        orderPrice = this.car.order.totalPrice ? this.car.order.totalPrice * 1 : (this.car.totalPrice.total_price * 1);
      }

      return this.$store.state.travel.car.voucherList.filter((perTicket) => {
        return perTicket.enableFlag === 'N' || (perTicket.voucherBalance < orderPrice) || useEA !== !!perTicket.voucherReturnCode;
      });
    },
    ...mapState({
      car: state => state.travel.car,
      currentOrder: state => state.travel.car.order,
      voucherList: state => state.travel.car.voucherList,
      selectedTicket: state => state.travel.car.selectVoucher,
      state: state => state.travel.car.state,
      startArea: state => state.travel.car.startArea,
      endArea: state => state.travel.car.endArea,
      user: state => state.travel.car.user
    }),
  },
  methods: {
    closePanel() {
      this.$emit('update:show', false);
    },
    // 选择打车券
    toSelectVoucher(data, index) {
      if (this.readOnly) return;

      this.selectIndex = index;
      this.$store.commit('CAR', Object.assign({}, this.car, { selectVoucher: data }));
      this.closePanel();
    },
  },
  created() {
    var actionName = 'getCard';

    if (this.state === 'endTrip') actionName = 'getTicketsAfterTrip';
    this.loadingIsShow = this.showLoading();
    this.$store.commit('CAR', Object.assign({}, this.car, { voucherList: [] }));

    this.$store.dispatch(actionName, {
      voucherType: null
    }).then((response) => {
      this.loadingIsShow = this.hideLoading();
      if (response && response.code === '00000') {
        this.$store.commit('CAR', Object.assign({}, this.car, { voucherList: response.data }));
        // this.$nextTick(() => this.hideLoading());
      } else if (response && response.errmsg) {
        this.tip = response.errmsg;
        // this.showToast({ msg: response.errmsg });
      }
    })
  },
};
</script>
<style lang="less" scoped>
  .ticketList {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 112;
    width: 100%;
    animation-duration: .5s;
    .main {
      background: #fff;
      padding: 15px;
      overflow-y: scroll;
         .dataList {
            background: url("../../../assets/images/trade/top.png") repeat-x top;
            box-sizing: border-box;
            border-left: 1px solid #DFDFDF;
            border-right: 1px solid #DFDFDF;
            border-bottom: 1px solid #DFDFDF;
            box-shadow: 0 2px 4px 0 #E7E7E7;
            border-radius: 2px;
            height: 78px;
            padding: 0 15px;
            margin-bottom: 10px;
            li {
              display: flex;
              justify-content:space-between;
              font-size: 12px;
              &:nth-of-type(1) {
                color: #666666;
                padding: 18px 0 0px 0;
                font-size: 12px;
              }
              &:nth-of-type(2) {
                padding: 3px 0 5px 0;
                font-size: 16px;
                color: #344663;
              }
            }
            .fontBase {
              font-size: 16px !important;
            }
         }
         .unList {
           background: url("../../../assets/images/trade/untop.png") repeat-x top, #E9E9E9;
         }
         .dataListSelect {
           background: url("../../../assets/images/trade/top_hover.png") repeat-x top, url("../../../assets/images/trade/selectState.png") no-repeat bottom right;
           border-left: 1px solid rgba(108,198,10,0.50);
           border-right: 1px solid rgba(108,198,10,0.50);
           border-bottom: 1px solid rgba(108,198,10,0.50);
         }
        .title {
          padding: 15px 0 15px 0;
          color:#182C4E;
          font-size: 14px;
          color:#9B9B9B;
        }
        .untitle {
          padding: 5px 0;
          color:#182C4E;
          font-size: 14px;
          color:#9B9B9B;
        }
        .describe {
          font-size: 12px;
          color: #9B9B9B;
          line-height: 17px;
          margin-bottom:12px;
        }
        .voucherBalance {
          width: 120px;
          text-align: right;
          flex-shrink: 0;
        }
    }
    ::-webkit-scrollbar{
      height: 0;
      width: 0;
    }
  }
</style>
