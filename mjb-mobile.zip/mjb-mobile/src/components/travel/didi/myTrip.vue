<template>
  <div class="mytrip-container flex-column">
    <MyHeader :titleText="'我的行程'">
      <img src="~@/assets/images/common/nav_back.png" width="20" slot="left" @click="goBack()">
    </MyHeader>
    <div class="rest-area">
          <div class="type-content" infinite-scroll-immediate-check="true" v-infinite-scroll="loadMore" infinite-scroll-disabled="busy">
      <!-- 无数据时显示 -->
      <div class="no-data-text" v-if="!appointOrder && !finishOrder.length">
        <img class="no_data_img" :src="noDataImg" alt="">
        <p>暂无已完成订单</p>
      </div>
      <!-- 未完成订单 -->
      <p class="type" v-if="doingOrders.length">未完成订单</p>
      <div class="perOrder" v-for="(perOrder, index) in doingOrders" :key="index" v-if="doingOrders.length" @click="orderDetail(perOrder)">
        <div class="list-title justify-align">
          <span class="car-type inline-block">{{ perOrder.text4carType }}</span>
          <span class="doing inline-block">进行中</span>
        </div>
        <div class="list-time">
          <img :src="timeImg">
          <span class="time">{{ timeFormat(perOrder.createTime) || timeFormat(perOrder.order_time) }}</span>
          <div class="reason" v-if="perOrder.reason">
            <span>{{perOrder.reason}}</span>
          </div>
        </div>
        <div class="list-area">
          <span class="dot green inline-block"></span>
          <span class="area">{{ perOrder.startName || perOrder.start_name}}</span>
        </div>
        <div class="list-area">
          <span class="dot orange inline-block"></span>
          <span class="area">{{ perOrder.endName || perOrder.end_name }}</span>
        </div>
      </div>
      <template v-if="appointOrder.orderId">
        <p class="type">已预约订单</p>
        <div class="perOrder" @click="orderDetail(appointOrder)">
          <div class="list-title justify-align">
            <span class="car-type inline-block">{{ appointOrder.text4carType }}</span>
            <span class="appoint inline-block">等待司机接驾</span>
          </div>
          <div class="list-time">
            <img :src="timeImg">
            <span class="time">{{ timeFormat(appointOrder.createTime) || timeFormat(appointOrder.order_time) }}</span>
            <div class="reason" v-if="appointOrder.reason">
              <span>加班用车</span>
            </div>
          </div>
          <div class="list-area">
            <span class="dot green inline-block"></span>
            <span class="area">{{ appointOrder.startName || appointOrder.start_name}}</span>
          </div>
          <div class="list-area">
            <span class="dot orange inline-block"></span>
            <span class="area">{{ appointOrder.endName || appointOrder.end_name }}</span>
          </div>
        </div>
      </template>
      <p class="type" v-if="finishOrder.length">已完成订单</p>
      <div class="perOrder" v-for="(item, index) in finishOrder" :key="index" @click="orderDetail(item)">
        <div class="list-title flex-row">
          <span class="car-type" v-if="item.useCarType==='301'" :class="[{'l-width': item.status!==610, 's-width': item.status===610}]">快车</span>
          <span class="car-type" v-if="item.useCarType==='201'" :class="[{'l-width': item.status!==610, 's-width': item.status===610}]">专车</span>
          <span class="cancel" v-if="item.status===610">取消用车</span>
          <span class="finish">{{ `¥ ${(item.actualPrice * 1).toFixed(2)}`}}</span>
        </div>
        <div class="list-time">
          <img :src="timeImg">
          <span class="time">{{ timeFormat(item.createTime) }}</span>
          <div class="reason" v-if="item.reason">
            <span>加班用车</span>
          </div>
        </div>
        <div class="list-area">
          <span class="dot green inline-block"></span>
          <span class="area">{{ item.startName }}</span>
        </div>
        <div class="list-area">
          <span class="dot orange inline-block"></span>
          <span class="area">{{ item.endName }}</span>
        </div>
      </div>
      <div class="no-data-text" v-if="!hasNextPage">无更多订单</div>
    </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
import { mapState } from 'vuex';
import MyHeader from '../../common/newHeader';
import timeImg from '../../../assets/images/common/historyImg.png';
import noDataImg from '../../../assets/images/common/no_data.png';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {
      noDataImg,
      timeImg,
      pageInfo: {
        pageIndex: 1,
        pageSize: 20,
      },
      busy: false,
      hasNextPage: true,
      isLoading: true,
      allOrders: [],
    };
  },
  watch: {
    showTrip() { },
  },
  computed: {
    mipAccount() {
      return this.$store.state.userInfo.employeeNumber;
    },
    ...mapState({
      car: state => state.travel.car,
      state: state => state.travel.car.state,
      order: state => state.travel.car.order,
      beforeState: state => state.travel.car.beforeState,
    }),
    // 正在进行的订单
    doingOrders() {
      return this.allOrders.filter((perOrder) => {
        return (perOrder.confirmState === 0 && perOrder.status !== 610 && perOrder.type !== 1);
      });
    },
    // 预约的订单
    appointOrder() {
      return this.allOrders.filter((perOrder) => {
        return (perOrder.type === 1 && perOrder.status === 400);
      })[0] || {};
    },
    // 已完成的订单
    finishOrder() {
      return this.allOrders.filter((perOrder) => {
        return (perOrder.confirmState === 1 || perOrder.confirmState === 3 || perOrder.status === 610);
      });
    },
  },
  created() {
  },
  mounted() {
    this.getAllOrder(1);
  },
  methods: {
    goBack() {
      // this.$store.commit('CAR', Object.assign({}, this.car, { state: '' }));
      this.$emit('close');
    },
    // 格式化时间
    timeFormat(time) {
      if (time) {
        let payTime = new Date(time);
        const months = payTime.getMonth() + 1 < 10 ? `0${payTime.getMonth() + 1}` : payTime.getMonth() + 1;
        const dates = payTime.getDate() < 10 ? `0${payTime.getDate()}` : payTime.getDate();
        const hours = payTime.getHours() < 10 ? `0${payTime.getHours()}` : payTime.getHours();
        const minutes = payTime.getMinutes() < 10 ? `0${payTime.getMinutes()}` : payTime.getMinutes();
        payTime = `${months}月${dates}日 ${hours}:${minutes}`;
        return payTime;
      }
      return '';
    },
    orderDetail(orderObj) {
      if (orderObj.status === 610 || orderObj.status === 700) {
        this.$emit('showOrder', orderObj.orderId)
        // this.$store.commit('CAR', Object.assign({}, this.car, { state: 'toDetail' }));
        // this.$router.push({
        //   path: '/travel/didi', query: { orderId: orderObj.orderId },
        // });
      } else {
        this.$router.push('/travel/didi');
      }
    },
    // 加载更多
    loadMore() {
      const self = this;
      this.busy = true; // 禁止再次滑动加载
      if (this.hasNextPage) {
        setTimeout(() => {
          self.getAllOrder();
        }, 200);
      }
    },
    /**
     * 获取用户历史订单 operation=10
     */
    getAllOrder(times) {
      if (times === 1) {
        this.allOrders = [];
        this.pageInfo.pageIndex = 1;
        this.pageInfo.pageSize = 10;
      }
      const params = {
        mipAccount: this.mipAccount,
        useCarType: null,
        perPage: this.pageInfo.pageSize,
        pageNo: this.pageInfo.pageIndex,
        startNum: '1',
      };
      this.showLoading();
      this.isLoading = true;
      this.$store.dispatch('getAllOrder', params)
        .then((res) => {
          if (res && res.errcode === '00000') {
            this.hideLoading();
            this.isLoading = false;
            this.busy = false;
            if ((res.data.pageTotal * this.pageInfo.pageSize) > (this.pageInfo.pageIndex * this.pageInfo.pageSize)) {
              this.hasNextPage = true;
              this.pageInfo.pageIndex++;
            } else {
              this.hasNextPage = false;
            }
            const allData = res.data.orders.map((perOrder) => {
              perOrder.text4carType = (perOrder.useCarType==='301' || perOrder.rule==='301') ? '快车' : '专车';

              return perOrder;
            });
            this.allOrders = this.allOrders.concat(allData);
          } else if (res && res.errmsg) {
            this.hideLoading();
            this.isLoading = false;
            this.showToast({ msg: res.errmsg });
          } else {
            this.hideLoading();
            this.isLoading = false;
            this.showToast({ msg: '服务器开小差了，请稍候再试！', width: '16em' });
          }
        });
    },
  },
};
</script>
<style lang="less" scoped>
@white: #ffffff;

.font {
  font-size: 14px;
  color: #858585;
  line-height: 20px;
  margin: 0 10px;
}

.green {
  background: #6CC60A;
}

.orange {
  background: #FCB23C;
}

.l-width {
  width: 80%;
}

.s-width {
  width: 60%;
}

.mytrip-container {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 900;
  overflow: hidden;
  width: 100%;
  background: #F4F4F4;
  animation-duration: .5s;

  >.rest-area {
    overflow: scroll;
  }

  .type-content {
    .type {
      background: #F4F4F4;
      font-size: 14px;
      line-height: 20px;
      color: #9B9B9B;
      padding: 10px 15px;
    }
    .perOrder {
      padding: 12px 15px;
      background: @white;
      border-bottom: .7px solid #ddd;

      .list-title {
        .car-type {
          font-size: 16px;
          color: #000000;
          line-height: 22px;
        }
        .doing {
          width: 20%;
          text-align: right;
          font-size: 14px;
          color: #F59B0B;
          line-height: 20px;
        }
        .appoint,
        .cancel {
          width: 20%;
          text-align: right;
          font-size: 14px;
          color: #858585;
          line-height: 20px;
        }

        .appoint {
          width: auto;
        }
        .cancel {
          width: 20%;
        }
        .finish {
          width: 20%;
          text-align: right;
          font-size: 14px;
          color: #000000;
          line-height: 20px;
        }
      }
      .list-time {
        margin-top: 12px;
        height: 20px;
        img {
          width: 8px;
          height: 8px;
          margin: auto 0;
        }
        .time {
          width: 75%;
          .font;
        }
        .reason {
          width: 61px;
          background: #3DA5FE;
          border-radius: 12px;
          text-align: center;
          line-height: 20px;
          margin: 0;
          span {
            font-size: 11px;
            transform: scale(0.85);
            color: #FFFFFF;
            margin: auto;
          }
        }
      }
      .list-area {
        margin-top: 8px;
        height: 20px;
        .dot {
          width: 8px;
          height: 8px;
          margin: auto 0;
          border-radius: 50%;
        }
        .area {
          .font;
        }
      }
    }
    .no-data-text {
      background: #F4F4F4;
      font-size: 14px;
      line-height: 20px;
      color: #9B9B9B;
      padding: 10px 15px;
      text-align: center;
      img {
        width: 50%;
        height: 50%;
        margin-top: 50%;
      }
    }
  }
}
</style>

