<!--
  describe: card-目的地/出发地
  created by: panjm
  date: 2017-11-27
-->
<template>
  <div class="containerBox" v-if="show">
    <div class="positionBox" v-if="showPositionBox">
      <div class="transfer" v-if="showTime">
        <div class="sign">
          <img :src="timeImg">
        </div>
        <div class="border-bottom leftBox">
          <input class="grey" :class="{'black': time}" @click="openTimePicker()" :value="time || '请选择上车时间'" readonly>
        </div>
      </div>
      <div class="passengerContainer">
        <div class="sign">
          <div class="greenSlot dot"></div>
        </div>
        <div class="passenger-main">
          <div class="reason border-right" @click="showAction=true">
            <input :value="selectReason.content" placeholder="用车事由" readonly>
          </div>
          <div class="select-passenger" @click="showCR=true">
            <span class="passenger">{{person}}</span>
            <img :src="transfer" />
          </div>
        </div>
      </div>
      <div class="transfer">
        <div class="sign">
          <div class="greenSlot dot"></div>
        </div>
        <div class="leftBox border-top border-bottom" @click="openArea('start')" >
          <input :value="startArea.displayname || $attrs.currentLocationInfo.address || '当前位置'" readonly class="startLocation">
        </div>
      </div>
      <div class="transfer">
        <div class="sign">
          <div class="orangeSlot dot"></div>
        </div>
        <div class="leftBox" @click="openArea('end')">
          <input :class="[{'grey': !endArea.displayname}]" :value="endArea.displayname || '您要去哪儿'" readonly>
        </div>
      </div>
    </div>
    <transition
      name="custom-classes-transition"
      enter-active-class="animated fadeInRight"
      leave-active-class="animated fadeOutRight"
    >
      <change-rider v-if="showCR"
        @close="showCR = false"
        @on-select="changeRider"></change-rider>
    </transition>

    <Actionsheet v-model="showAction" :menus="menus" @on-click-menu="selectReasons" :show-cancel="menus.length !== 0" :close-on-clicking-mask="false"></Actionsheet>

    <transition
      name="custom-classes-transition"
      enter-active-class="animated fadeInRight"
      leave-active-class="animated fadeOutRight"
    >
      <search-area v-if="showCity"
        :locatedCity="$attrs.currentLocationInfo"
        :locationType="areaType"
        @selectCity="selectCity"
        @select-area="selectAdress"
        @closeLocationPanel="closeLocationPanel()"></search-area>
    </transition>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import { Datetime, Actionsheet } from 'vux';
import changeRider from './changeRider';
import searchArea from '../../common/searchAreaDi.vue';
import transfer from '../../../assets/images/trade/transfer.png';
import timeImg from '../../../assets/images/common/historyImg.png';
import { formatDate, addDays, addMinutes } from '../../../js/util.js';

var currentDateTime = addMinutes(new Date(), 40);

export default {
  inheritAttrs: false,
  components: {
    changeRider,
    Actionsheet,
    searchArea,
  },
  props: {
    showTime: Boolean,  // 预约时间
  },
  data() {
    return {
      configureForDatetime: {
        cancelText: '取消',
        confirmText: '确定',
        value: formatDate(addMinutes(new Date(), 40), 'dd hh:mm'),
        startDate:formatDate(Date.now(), 'yyyy-MM-dd'),
        endDate:formatDate(addDays(new Date(), 2).valueOf(), 'yyyy-MM-dd'),
        format: 'DD HH:mm',
        dayRow(dateObj, value) {
          let dateMap = {};
          const date = currentDateTime.getDate();
          dateMap[date] = '今天';
          dateMap[date + 1] = '明天';
          dateMap[date + 2] = '后天';

          return dateMap[value * 1];
        },
        hourRow: '{value}时',
        minuteRow: '{value}分',
        computeHoursFunction (date, isToday, generateRange) {
          const currentHour = currentDateTime.getHours();
          if (isToday) return generateRange(currentHour, 23);

          return generateRange(0, 23);
        },
        computeMinutesFunction (selectedHour, generateRange) {
          if (currentDateTime.getFullYear() === selectedHour.getFullYear() && currentDateTime.getMonth() === selectedHour.getMonth() && currentDateTime.getDate() === selectedHour.getDate() && currentDateTime.getHours() === selectedHour.getHours()) return generateRange(currentDateTime.getMinutes(), 59);

          return generateRange(0, 59)
        },
        onConfirm: (value) => {
          this.changeTime(value)
        }
      },
      // currentDateTime: util.formatDate(Date.now(), 'yyyy-MM-dd'),
      transfer,
      timeImg,
      showAction: false,
      showSecond: false,
      visibility: false,
      showCR: false,
      showCity: false,
      minuteListValue: formatDate(addMinutes(new Date(), 40), 'dd hh:mm'),
      areaType: '',
      time: '', // 起程时间
      person: '换乘车人', // 乘车人电话号码
    };
  },
  watch: {
    // isEmpty(newValue) {
    //   if (newValue) {
    //     this.$emit('get-price');
    //   }
    // },
    selectReason(newValue, oldValue) {
      console.log(newValue, oldValue)
      if (newValue.content) {
        this.showAction = false;
      } else {
        this.showAction = true;
      }
    }
  },
  computed: {
    menus() {
      const menus = [];
      this.reasonList.forEach((item) => {
        menus.push(item.content);
      });
      return menus;
    },
    departure_time() {
      if (!this.$store.state.travel.car.departure_time) this.time = '';
      return this.$store.state.travel.car.departure_time;
    },
    ...mapState({
      car: state => state.travel.car,
      state: state => state.travel.car.state,
      startArea: state => state.travel.car.startArea,
      endArea: state => state.travel.car.endArea,
      selectReason: state => state.travel.car.selectReason,
      reasonList: state => state.travel.car.reasonList,
      passenger_phone: state => state.travel.car.passenger_phone,
      user: state => state.travel.car.user
    }),
    nowTime() {
      return new Date();
    },
    show() {
      return this.state === 'canCall' || this.state === 'nonCall';
    },
    showPositionBox() {
      return (this.state === 'canCall' || this.state === 'nonCall') && this.reasonList.length;
    },
    // isEmpty() {
    //   if (this.showTime) {
    //     return this.departure_time && this.selectReason && this.passenger_phone && (this.startArea.cityid || this.startArea.cityId) && (this.endArea.cityid || this.endArea.cityId);
    //   }
      // return this.selectReason && this.passenger_phone && (this.startArea.cityid || this.startArea.cityId) && (this.endArea.cityid || this.endArea.cityId);
    // },
  },
  methods: {
    showEstimatedPriceAndOrderCar() {
      var lastChange;

      return this.$store.watch((state) => {
        return [state.travel.car.departure_time, state.travel.car.passenger_phone, state.travel.car.startArea, state.travel.car.endArea];
      }, (newValue, oldValue) => {
        if (newValue[0] === oldValue[0] && newValue[1] === oldValue[1] && newValue[2].displayname === oldValue[2].displayname && newValue[3].displayname === oldValue[3].displayname) return;
        const generalParams = !!newValue[1] && !!(newValue[2].cityid || newValue[2].cityId) && !!(newValue[3].cityid || newValue[3].cityId);
        // 201 是专车，301 是快车
        if (!this.car.nowCalling ? newValue[0] && generalParams : generalParams) {
          this.$emit('get-price');
        }
      })
    },
    openTimePicker() {
      console.log(this)
      // showPlugin () {
      this.$vux.datetime.show(this.configureForDatetime)
    // },
      // currentDateTime = new Date();
      // this.visibility = true;
    },
    selectCity() {},
    init() {
      if (this.passenger_phone && this.passenger_phone === this.user.phone) {
        this.person = '换乘车人';
      } else if (this.passenger_phone && this.passenger_phone !== this.user.phone) {
        this.changeRider(this.passenger_phone);
      } else if (!this.passenger_phone) {
        this.showToast({ msg: '未从MIP获取到您的手机号，请手动输入乘车人手机号码。' , width: '14em' });
      }
      // if (this.departure_time) {
      //   this.changeTime(this.departure_time);
      // }
    },
    closeLocationPanel() {
      this.showCity = false;
    },
    // 选择日期
    changeTime(value) {      //  value 格式为2017-11-29 11:37
      console.log(value);
      const myTime = value.split(' ');  // myTime 格式为 (2) ["2017-11-29", "11:07"]
      const myTimeA = myTime[0].split('-');  // 年月日
      const myTimeB = myTime[1].split(':');   // 时分
      const myYear = parseInt(myTimeA[0], 0);
      const myMonth = parseInt(myTimeA[1], 0);
      const mydate = parseInt(myTimeA[2], 0);
      const myHours = parseInt(myTimeB[0], 0);
      const myMinutes = parseInt(myTimeB[1], 0);
      const nowYear = this.nowTime.getFullYear();
      const nowMonth = this.nowTime.getMonth() + 1;
      const nowDate = this.nowTime.getDate();
      const nowHours = this.nowTime.getHours();
      const nowMinutes = this.nowTime.getMinutes();
      // 与现在时间比较
      if (mydate < nowDate) {
        if (myMonth < nowMonth) {
          if (myYear < nowYear) {
            if (myMinutes < nowMinutes) {
              if (myHours < nowHours) {
                this.showToast({ msg: '请重新选择时间' });
              }
            }
          }
        }
      } else {
        // 时间的请求格式是YYYY-MM-DD hh:mm:ss
        // value = `${value}:00`;
        value = value.replace('ss', '00');
        this.$store.commit('CAR', Object.assign({}, this.car, { departure_time: value }));
        this.configureForDatetime.value = formatDate(value, 'dd hh:mm');
        if (myYear === nowYear && myMonth === nowMonth) {
          if ((mydate - nowDate) === 0) {
            this.time = `${myMonth}月${mydate}日   今天${myHours < 10 ? `0${myHours}` : myHours}:${myMinutes < 10 ? `0${myMinutes}` : myMinutes}`;
          } else if ((mydate - nowDate) === 1) {
            this.time = `${myMonth}月${mydate}日   明天${myHours < 10 ? `0${myHours}` : myHours}:${myMinutes < 10 ? `0${myMinutes}` : myMinutes}`;
          } else if ((mydate - nowDate) === 2) {
            this.time = `${myMonth}月${mydate}日   后天${myHours < 10 ? `0${myHours}` : myHours}:${myMinutes < 10 ? `0${myMinutes}` : myMinutes}`;
          } else {
            this.time = `${myMonth}月${mydate}日   ${myHours < 10 ? `0${myHours}` : myHours}:${myMinutes < 10 ? `0${myMinutes}` : myMinutes}`;
          }
        } else {
          this.time = `${myMonth}月${mydate}日   ${myHours < 10 ? `0${myHours}` : myHours}:${myMinutes < 10 ? `0${myMinutes}` : myMinutes}`;
        }
      }
    },
    // 选择加班事由
    selectReasons(key) {
      let obj = {};
      if (key === 0) {
        obj = this.reasonList[0];
      } else if (key === 1) {
        obj = this.reasonList[1];
      } else if (key === 2) {
        obj = this.reasonList[2];
      } else if (key === 3) {
        obj = this.reasonList[3];
      } else if (key === 4) {
        obj = this.reasonList[4];
      } else {
        obj = this.selectReason;
      }
      this.$store.commit('CAR', Object.assign({}, this.car, { selectReason: obj }));
      this.init();
    },
    // 换乘车人
    changeRider(tel) {
      this.$store.commit('CAR', Object.assign({}, this.car, { passenger_phone: tel }));
      if (this.passenger_phone !== this.user.phone) {
        const num = tel.substr(7, 4);
        this.person = `尾号[${num}]`;
      } else {
        this.person = '自己';
      }

      this.showCR = false;
    },
    // 点击选择地点
    selectAdress(item) {
      console.log('热门城市', item);
      const obj = {};
      if (this.areaType === 'start') {
        obj.startArea = item;
      } else if (this.areaType === 'end') {
        obj.endArea = item;
      }
      this.$store.commit('CAR', Object.assign({}, this.car, obj));
      this.showCity = false;
    },
    // 点击打开选择城市页面
    openArea(type) {
      // if (this.$attrs.currentLocationInfo.city) {

      // }
      this.showCity = true;
      this.areaType = type;
    },
  },
  mounted() {
    this.showEstimatedPriceAndOrderCar()
    if (this.selectReason.content) {
      this.init();
    }
  },
};
</script>
<style lang="less" scoped>
input {
  background: none;
  outline: none;
  border: none;
  font-size: 16px;
  color: #666666;
}

.containerBox {
  .positionBox {
    .startLocation {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .passengerContainer {
      padding: 14px 0;
      .sign {
        float: left;
        width: 38px;
        text-align: center;
      }

      .dot {
          border-radius: 50%;
          width: 8px;
          height: 8px;
          display: inline-block;
          align-self: center;
        }
        .greenSlot {
          background-color: #6CC60A;
        }

      .passenger-main {
        display: flex;
        align-items: center;
        margin-left: 38px;
        padding-right: 22px;
        .reason {
          width: 45%;
          // border-right: 0.5px solid #DEDFE0;
          input {
            width: 100%;
          }
        }
        .select-passenger {
          width: 55%;
          padding: 0 16px;
          display: flex;
          justify-content: space-between;
          .passenger {
            line-height: 24px;
          }
          img {
            width: 24px;
            height: 24px;
          }
        }
      }
    }
    // box-shadow: 0px 2px 10px #c5c3c3;
    .transfer {
      display: flex;
      align-items: center;
      height: 50px;
      box-sizing: border-box;
      font-size: 16px;
      color: #666666;
      .sign {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 38px;
        img {
          width: 8px;
          height: 8px;
        }
        .dot {
          border-radius: 50%;
          width: 8px;
          height: 8px;
          display: inline-block;
          align-self: center;
        }
        .greySlot {
          background-color: #9E9E9E;
        }
        .greenSlot {
          background-color: #6CC60A;
        }
        .orangeSlot {
          background-color: #FCB23C;
        }
      }
      .grey {
        color: #C3C3C3;
      }
      .black {
        color: #000;
      }
      .leftBox {
        display: flex;
        padding: 14px 0;
        width: 100%;
        input {
          line-height: 22px;
          width: 100%;
        }
      }
    }
    .transfer:last-child {
      .leftBox {
        border-bottom: none;
      }
    }
  }
}
</style>
