  <!--
  describe: card-司机信息
  created by: panjm
  date: 2017-11-28
-->
<template>
  <div class="containerBox">
    <div class="bookingTime" v-if="order.type && order.status === 400">预约时间：{{ order.departure_time | formatTime}}</div>
    <div :class="['driverBox', {'has-shadow': !showOnlyPhone}]" v-if="showDriverBox">
      <div :class="['driverInfo', 'border-bottom', {'l-padding': !showOnlyPhone, 's-padding': showOnlyPhone}]">
        <div class="leftItem">
          <img :src="driver">
          <div class="info">
            <div>{{ order.driver_name }}</div>
            <span>{{ order.driver_card }}</span>
            <div>{{ `${order.driver_car_color} • ${order.driver_car_type}` }}</div>
          </div>
        </div>
        <!-- 司机接单后但还没上车显示 (可以call司机也可以分享)-->
        <div class="rightItem" v-if="showBoth">
          <div class="phone">
            <a :href="'tel:' + order.driver_phone_real"><img src="~@/assets/images/trade/phone.png"></a>
          </div>
          <div class="share border-left">
            <img src="../../../assets/images/trade/share.png">
          </div>
        </div>
        <!-- 付款页面，即付款中、付款失败或付款成功 (可以call司机不可以分享)-->
        <div class="rightItem center" v-if="showOnlyPhone">
          <div class="share border-left pay-phone">
            <a :href="'tel:' + order.driver_phone_real"><img src="~@/assets/images/trade/phone.png"></a>
          </div>
        </div>
        <!-- 行程中 (可以分享，可以紧急求助，但无需call司机)-->
        <div class="rightItem" v-if="showOnlyShare">
          <div class="phone">
            <img src="../../../assets/images/trade/share.png">
          </div>
        </div>
      </div>
      <div class="button" v-if="showOnlyShare || showCancel">
        <div v-if="showOnlyShare"><a :href="'tel:' + 110" class="grayFont">紧急呼叫</a></div>
        <div v-if="showCancel" @click="endOrder">取消订单</div>
        <div class="border-left"><a href="tel:400-000-0999" class="grayFont">联系客服</a></div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import { formatDate } from '@/js/util.js';
import driver from '../../../assets/images/trade/driver.png';

export default {
  props: {
  },
  data() {
    return {
      driver
    };
  },
  methods: {
    endOrder() {
      this.$emit('end-order');
    }
  },
  computed: {
    showDriverBox() {
      return this.state === 'takeOrder' || this.state === 'takeCar' || this.state === 'onTheWay' || this.state === 'endTrip' || this.state === 'paying' || this.state === 'payFail' || this.state === 'paid';
    },
    showBoth() {
      return this.state === 'takeOrder' || this.state === 'takeCar';
    },
    showOnlyPhone() {
      return this.state === 'endTrip' || this.state === 'paying' || this.state === 'payFail' || this.state === 'paid';
    },
    showOnlyShare() {
      return this.state === 'onTheWay';
    },
    showCancel() {
      return this.state === 'takeCar' || this.state === 'takeOrder';
    },
    ...mapState({
      state: state => state.travel.car.state,
      order: state => state.travel.car.order,
    }),
  },
  filters: {
    formatTime(value) {
      if (!value) return ''
      const textMap = ['今天', '明天', '后天'];

      const current = new Date();
      const standardFormat = value.replace(/-/g, '/');

      return formatDate(standardFormat, 'M月d日 hh:mm').replace(' ', ` ${textMap[(new Date(standardFormat)).getDate() - current.getDate()]} `);
    }
  }
};
</script>
<style lang="less" scoped>
.has-shadow {
  box-shadow: 0 2px 4px 0 #9B9B9B;
  border-radius: 2px;
}

.l-padding {
  padding: 22px 15px;
}

.s-padding {
  padding: 9px 0px;
}

.containerBox {
  .bookingTime {
    line-height: 2.5;
    padding-left: 1em;
    color: #666666;
  }
  .driverBox {
    .driverInfo {
      display: flex;
      justify-content: space-between;
      .leftItem {
        display: flex;
        img {
          width: 60px;
          height: 60px;
          margin-right: 10px;
        }
        .info {
          div:nth-of-type(1) {
            font-size: 16px;
            line-height: 22px;
            color: #000000;
          }
          span {
            font-size: 12px;
            line-height: 17px;
            padding: 3px 5px;
            background-color: #ECECEC;
            border-radius: 2px;
          }
          div:nth-of-type(2) {
            font-size: 12px;
            line-height: 20px;
            color: #666666;
          }
        }
      }
      .rightItem {
        display: flex;
        align-items: flex-end;
        .phone {
          padding: 0 19.7px;
          img {
            width: 19.3px;
            height: 18.3px;
          }
        }
        .share {
          padding: 0 19.7px;
          img {
            width: 19.3px;
            height: 18.3px;
          }
        }
        .pay-phone {
          padding: 7px 20px 7px 35px;
        }
      }
      .center {
        align-items: center;
      }
    }
    .button {
      width: 100%;
      padding: 10px 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 0 0 0 #DEDFE0, 0 0 0 0 #DEDFE0;
      div {
        width: 50%;
        font-size: 16px;
        line-height: 22px;
        padding: 4px 0;
        text-align: center;
        color: #666666;
      }
    }
  }
}
</style>
