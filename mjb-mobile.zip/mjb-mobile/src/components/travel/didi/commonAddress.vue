<!--
  describe：常用地址组件
  created by：欧倩伶
  date：2017-12-13
-->
<template>
  <div>
    <my-header :title="top.title" :showBack="true" @previous="goBack"></my-header>
    <div class="has-header">
      <div :class="[$style.perAddress, 'border']" style="" @click="changeAddress(index-1)" v-for="index in 2" :key="index">
        <img :class="$style.icon" src="~@/assets/images/common/usually.png" alt="">
        <div :class="$style['no-address']" v-if="!commonAddress[index-1]">设置常用地址{{index}}</div>
        <div :class="$style['has-address']" v-else>
          {{commonAddress[index-1].displayname}}<br/><span :class="$style.addressText">{{ commonAddress[index-1].address || '' }}</span>
        </div>
        <img :class="$style.rightIcon" src="~@/assets/images/trade/right2x.png" alt="">
      </div>

    </div>
    <search-area v-if="showCity"
      @select-area="selectAdress"
      @closeLocationPanel="showCity = false"></search-area>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import MyHeader from '../../common/header';
import searchArea from '../../common/searchAreaDi.vue';

var selectedIndex;

export default {
  props: {
  },
  components: {
    MyHeader,
    searchArea,
  },
  data() {
    return {
      showCity: false,
      top: {
        title: '常用地址',
      },
      commonAddress: [
        {
          displayname: '',
          address: '',
        },
        {
          displayname: '',
          address: '',
        },
      ],
    };
  },
  computed: {
    ...mapState({
      car: state => state.travel.car,
      user: state => state.travel.car.user,
    }),
  },
  methods: {
    goBack() {
      this.$router.push('/travel/didi');
    },
    changeAddress(index) {
      this.showCity = true;
      selectedIndex = index;
    },
    selectAdress(address) {
      this.commonAddress[selectedIndex] = address;
      this.setCommonAddress(address);
      this.showCity = false;
    },
    // 获取常用地址 operation=26
    getCommonAddress() {
      console.log('获取常用地址');
      this.$store.dispatch('getCommonAddress', { cityId: 36, sn: new Date().valueOf() }).then((res) => {
        if (res && res.errcode === '00000' && res.data) {
          console.log('常用地址', res);
          this.commonAddress = res.data.commonAddressList;
        } else if (res && res.errmsg) {
          this.showToast({ msg: res.errmsg });
        }
      });
    },
    // 设置常用地址
    setCommonAddress(address) {
      console.log('设置常用地址', address);
      const params = {
        id: address.id,
        cityId: address.cityid,
        cityName: address.city,
        displayname: address.displayname,
        address: address.address,
        lat: address.lat,
        lng: address.lng,
      };
      return this.$store.dispatch('setCommonAddress', params).then((res) => {
        if (res && res.errcode === '00000') {
          this.showToast({ msg: '设置成功' });
        } else if (res && res.errmsg) {
          this.showToast({ msg: res.errmsg });
          Promise.reject({ msg: res.errmsg })
        }
      });
    },
  },
  created() {
    this.getCommonAddress();
  },
};
</script>
<style lang="less" module>
@import '~@/assets/css/base.less';
  .perAddress {
    background: #fff;
    font-size: 16px;
    height: 60px;
    margin-top: 10px;
    padding: 9px 17px;
    box-sizing: border-box;
    display: flex;
    width: 100%;
    justify-content: space-between;
    align-items: center;
    color: #000;
    .icon {
      width: 12px;
      height: 16px;
      margin: auto 10px auto 0;
    }
    .rightIcon {
      width: 8px;
      height: 13px;
      margin: auto 0px auto 12px;
    }
    .no-address {
      color: #000;
      width: 80%;
    }
    .has-address {
      width: 80%;
      text-align: left;
      line-height: 1;

      .addressText {
        display: inline-block;
        font-size: 14px;
        color: #858585;
        margin: .5em 0 0 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
  }
</style>

