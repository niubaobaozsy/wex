<template>
	<div class="didiMenus">
    <img src="~@/assets/images/trade/didi/cancel.png" class="cancel" @click="closeMenu"><br/>
    <ul class="list-unstyled" @click="openPanel">
    	<li class="perMenu" v-for="(menuObj, index) in menus" :key="'menu_' + index" :menu-name="menuObj.name" :menu-open="menuObj.type">
    		<img :src="menuObj.icon" :alt="menuObj.name" class="menuIcon" :menu-open="menuObj.type">
    	</li>
    </ul>
  </div>
</template>

<script>
/* eslint-disable global-require */
export default {
  data() {
    return {
      menus: [
        {
          name: '我的行程',
          type: 'myTrip',
          icon: require('@/assets/images/trade/didi/myTravel.png')
        },
        {
          name: '常用地址',
          type: 'address',
          icon: require('@/assets/images/trade/didi/address.png')
        },
        {
          name: '打车券',
          type: 'vouchers',
          icon: require('@/assets/images/trade/didi/vouchers.png')
        },
        {
          name: '常驻办公地址',
          type: 'baseCity',
          icon: require('@/assets/images/trade/didi/baseCity.png')
        }
      ]
    };
  },
  methods: {
    closeMenu() {
      this.$emit('close');
    },
    openPanel(event) {
      var classNameOfClickedEl = event.target.className;
      if (classNameOfClickedEl === 'perMenu' || classNameOfClickedEl === 'menuIcon') {
        this.$emit('selectMenu', event.target.getAttribute('menu-open'));
      }
    }
  }
};
</script>

<style lang="less">
.didiMenus {
  position: absolute;
  width: 100%;
  top: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  z-index: 112;
  text-align: right;
  color: #fff;
  font-size: 0;
  .cancel {
    width: 20px;
    height: 20px;
    display: inline-block;
    font-size: 14px;
    margin: 1em 1em 2em 0;
  }

  .list-unstyled {
    display: inline-block;
    font-size: 14px;
    padding-right: 1em;

    .perMenu {
      line-height: 1;
      margin-bottom: 1em;

      &:before {
        content: attr(menu-name);
        line-height: 50px;
      }
    }

    .menuIcon {
      width: 50px;
      height: 50px;
      display: inline-block;
      vertical-align: middle;
      margin-left: 1em;
    }
  }
}
</style>
