<!--
  describe：车券组件
  created by：ouql
  date：2017-11-26
-->
<template>
  <div class="carTicket" v-if="show">
    <!-- 有券 -->
    <template v-if="selectVoucher.voucherId">
      <!-- 普通车券 -->
      <div class="valid" v-if="!showA">
        <div class="declare">
          <p>打车券 - {{selectVoucher.voucherReturnCode ? '个人' : '公共'}}</p>
          <p>{{selectVoucher.voucherReturnCode ? '余额' : selectVoucher.endDate ? '有效期至' : ''}}</p>
        </div>
        <div class="detail flex-row">
          <div class="overDots rest-area">{{selectVoucher.remark}}</div>
          <div>{{selectVoucher.voucherReturnCode ? (selectVoucher.voucherBalance * 1).toFixed(2) + '元': selectVoucher.endDate || ''}}</div>
        </div>
      </div>
      <!-- 不可用车券 -->
      <div class="invalid" v-if="showA">
        <div class="declare">
          <p>{{selectVoucher.voucherResc}}</p>
          <p>余额</p>
        </div>
        <div class="detail">
          <p>{{selectVoucher.voucherReturnCode}}</p>
          <p>{{(selectVoucher.voucherBalance * 1).toFixed(2)}} 元</p>
        </div>
      </div>
      <div class="moreTicket" @click="showList = true">
        选择其他打车券
        <img src="../../../assets/images/trade/right2x.png" alt="">
      </div>
    </template>
    <!-- 无券可用 -->
    <div class="noticket text-center" :class="{'withBorderTop': car.rule === '201'}" v-else>
      暂无可用打车券
    </div>

    <transition
      name="custom-classes-transition"
      enter-active-class="animated fadeInRight"
      leave-active-class="animated fadeOutRight"
    >
    <voucher-list v-if="showList"
      :readOnly="false"
      @update:show="(show) => {showList = show}"></voucher-list>
    </transition>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import voucherList from './ticketList';

export default {
  components: {
    voucherList,
  },
  props: {
  },
  data() {
    return {
      showList: false,
    };
  },
  computed: {
    show() {
      return this.state === 'nonCall' || this.state === 'toCall' || this.state === 'calling' || this.state === 'payFail' || this.state === 'paid' || this.state === 'endTrip' || this.state === 'paying';
    },
    showA() {
      return this.state === 'payFail';
    },
    ...mapState({
      car: state => state.travel.car,
      selectVoucher: state => state.travel.car.selectVoucher,
      state: state => state.travel.car.state,
      enableCall: state => state.travel.car.enableCall,
    }),
  },
  methods: {
  },
};
</script>
<style lang="less" scoped>
.carTicket {
  .valid {
    width: 95%;
    margin: auto;
    height: 78px;
    background-image: url(../../../assets/images/trade/vaildSTicket2x.png);
    background-size: 100% 78px;
    background-repeat: no-repeat;
    padding: 20px 10px;
    box-sizing: border-box;
    .declare {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      color: #666;
      height: 12px;
      line-height: 12px;
    }
    .detail {
      font-size: 16px;
      color: #000;
      height: 16px;
      line-height: 16px;
      margin-top: 10px;
    }

    .overDots {
      padding-right: 2em;
    }
  }
  .invalid {
    width: 100%;
    height: 78px;
    background-image: url(../../../assets/images/trade/invaildSTicket2x.png);
    background-size: 100% 78px;
    background-repeat: no-repeat;
    padding: 20px 10px;
    box-sizing: border-box;
    .declare {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      color: #666;
      height: 12px;
      line-height: 12px;
    }
    .detail {
      display: flex;
      justify-content: space-between;
      font-size: 16px;
      color: #000;
      height: 16px;
      line-height: 16px;
      margin-top: 10px;
    }
  }
  .moreTicket {
    display: flex;
    justify-content: flex-end;
    line-height: 12px;
    font-size: 12px;
    color: #666;
    padding: 15px 0;
    img {
      width: 8px;
      height: 12px;
      margin: auto 5px;
    }
  }
  .noticket{
    height: 74px;
    font-size: 14px;
    color: #000;
    line-height: 74px;
    border-top: 1px solid #dfdfdf;

    &.withMargin {
      margin-top: 20px;
    }
  }
}
</style>
