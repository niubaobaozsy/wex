<!--
  describe: didi home page
  created by: zhuangyh
  date: 2017-11-26
-->
<template>
  <div class="didi-wrap">
    <my-header :titleText="title">
      <img src="~@/assets/images/common/nav_back.png" width="20" slot="left" @click="goBack">
      <img src="~@/assets/images/trade/didi/person.png" width="20" slot="right" v-show="!showMenus" @click="showMenus = true">
    </my-header>

    <div class="container has-header">
      <div id="mapContainer"></div>
      <div class="car-tab columns is-mobile is-gapless" v-if="showTab">
        <div class="fast-car column" @click="changTab('301')">
          <span :class="[{'blue-border': rule==='301'}]">快车</span>
        </div>
        <div class="special-car column"  @click="changTab('201')">
          <span :class="[{'blue-border': rule==='201'}]">专车</span>
        </div>
      </div>
      <div class="tips4noMap" v-if="!hasMap">抱歉，地图加载失败T_T<br/>您仍可继续打车，建议您刷新地图试试<br/><span class="reloadMap" @click="mapInit">刷新</span></div>
      <car-tab
        :currentLocationInfo="currentLocationInfo"
        @get-price="getEvaluatePrice"
        @centerLocation="centerLocationInToView()"></car-tab>
      <message-card
        v-if="showPanel4pay"
        @paid="readyForNewOrder"></message-card>
      <!-- <common-address :showAddress.sync="showAddress"></common-address> -->

      <order-detail v-if="showDetail" :orderId="detailOrderId2show"></order-detail>
    </div>

    <transition
      name="custom-classes-transition"
      enter-active-class="animated fadeInRight"
      leave-active-class="animated fadeOutRight"
    >
      <voucher-list v-if="showList" @update:show="(show) => {showList = show}"></voucher-list>
    </transition>

    <ask-base v-if="showPanel4askBase"
        @cancel="exitToMain"
        @close="closePanel4askBase"></ask-base>

    <transition
      name="custom-classes-transition"
      enter-active-class="animated fadeInRight"
      leave-active-class="animated fadeOutRight"
    >
      <base-city v-if="showBaseCity"
        @close="showBaseCity = false"></base-city>
    </transition>

    <menus v-if="showMenus"
      @selectMenu="openTo"
      @close="showMenus = false"></menus>

    <transition
      name="custom-classes-transition"
      enter-active-class="animated fadeInRight"
      leave-active-class="animated fadeOutRight"
      @after-enter="showDetail = false"
    >
      <history-orders v-if="showHistoryOrders"
        @showOrder="showOrderDetails"
        @close="closeList4historyOrders"></history-orders>
    </transition>

  </div>
</template>
<script type='text/ecmascript-6'>
/* eslint-disable global-require */
import { convertToSnakeCase, isIOSEnviron, formatSecondsToMinutes, formatDate } from '@/js/util';
import { mapState } from 'vuex';
import { isEmpty, clone } from 'lodash';
import addStylesheet from 'add-style-sheet';
import { platform } from '@/platform';
import AskBase from '@/components/travel/didi/askBase';
import titleMap from '@/assets/js/didi/titleMap.js';
import { style2insert } from '@/assets/js/didi/map/index.js';
import carTab from './carTab';
import menus from './menus';
import baseCity from './baseCityInfo';
import messageCard from './messageCard';
import MyHeader from '../../common/newHeader';
import VoucherList from './ticketList';
import orderDetail from './travelSituationBox.vue';
import historyOrders from './myTrip.vue';

console.log(style2insert)

const object4map = {
  interval4timing: null
};
const mapIcons = {
  start: require('@/assets/images/trade/didi/depar.png'),
  end: require('@/assets/images/trade/didi/des.png'),
  car: require('@/assets/images/trade/didi/car.png')
}

function drag4map() {

}

function ReqError(obj) {
  this.code = obj.errcode || obj.code || '';
  this.msg = obj.msg || obj.errmsg || '';
}

export default {
  inheritAttrs: false,
  components: {
    historyOrders,
    menus,
    baseCity,
    AskBase,
    carTab,
    messageCard,
    MyHeader,
    // CommonAddress,
    VoucherList,
    orderDetail,
  },
  data() {
    return {
      title: '滴滴出行',
      showTab: true,
      stepTwo: false,
      getLocationTimer: '',
      map: {},
      location: [],
      userLocation: [113.219788, 22.934801],
      departure: [113.219788, 22.934801],
      destination: [113.217128, 22.907962],
      carLocation: [113.215046, 22.932647],
      currentLocationInfo: {
        city: '',
        address: ''
      },
      drivingRouter: {},
      userMarker: {},
      deparMarker: {},
      desMarker: {},
      infoWindow: {},
      infoWindowContent: '',
      timer: '', // setInterval调用执行完毕时返回的timer ID
      storeCar: {}, // 存放原始的store数据
      choice: false, // 是否显示设置选择
      showMenus: false,
      showBaseCity: false,
      showHistoryOrders: false,
      showSet: true, // 是否显示设置图标
      detailOrder: {}, // 查看订单详情的订单
      showDetail: false,
      // showAddress: false, // 是否显示设置常用地址页
      showList: false, // 是否显示打车券页
      hasMap: false,
      showPanel4askBase: false,
      detailOrderId2show: ''
    };
  },
  watch: {
    state(val) {
      if (titleMap[val]) this.title = titleMap[val];
      if (val === 'canCall' || val === 'nonCall') {
        this.showTab = true;
        if (this.car.nowCalling) {
          this.$store.commit('CAR', Object.assign({}, this.car, { endArea: {} }));
        }else {
          this.$store.commit('CAR', Object.assign({}, this.car, { departure_time: ''}));
        }
        this.$store.commit('CAR', Object.assign({}, this.car, { specialCar: this.storeCar.specialCar }));
        this.$store.commit('CAR', Object.assign({}, this.car, { specialCarType: this.storeCar.specialCarType }));
        this.$store.commit('CAR', Object.assign({}, this.car, { fastCar: {} }));
        this.$store.commit('CAR', Object.assign({}, this.car, { order_id: '' }));
        this.$store.commit('CAR', Object.assign({}, this.car, { order: {} }));
        this.$store.commit('CAR', Object.assign({}, this.car, { selectVoucher: {} }));
        this.$store.commit('CAR', Object.assign({}, this.car, { order_selectedVoucher: {} }));

        if (object4map.endMarker) object4map.endMarker.hide();
        if (object4map.carMarker) object4map.carMarker.hide();
        if (object4map.recommendedLine) object4map.recommendedLine.clear();
        if (object4map.mapInstance) object4map.mapInstance.setCenter(this.userLocation);

      } else if (val === 'toCall' || val === 'calling' || val === 'waitOrder' || val === 'cancelling') {
        this.showTab = true;
        if (val === 'calling') {
          this.calling();
        }
        if (val === 'cancelling') {
          this.cancelOrder();
        }
      } else if (val === 'takeOrder' || val === 'waitCar' || val === 'takeCar') {
        this.showTab = false;
      } else if (val === 'onTheWay') {
        this.showTab = false;
      } else if (val === 'endTrip' || val === 'paying' || val === 'payFail' || val === 'paid' || val === 'cancelled') {
        this.showTab = false;
        if (val === 'paying') {
          this.ensurePaid();
        }
      } else if (val === 'detail') {
        this.showTab = false;
        this.showSet = false;
        this.showDetail = true;
      }
    },
    startArea(newValue) {
      if(!object4map.startMarker)return;
      if (newValue.lat && newValue.lng) {
        object4map.startMarker.show();
        object4map.startMarker.setPosition([newValue.lng, newValue.lat]);
      }
    },
    endArea(newValue) {
      if(!object4map.endMarker)return;
      if (newValue.lat && newValue.lng) {
        object4map.endMarker.show();
        object4map.endMarker.setPosition([newValue.lng, newValue.lat]);
      }
    }
  },
  computed: {
    mipAccount() {
      return this.$store.state.userInfo.employeeNumber;
    },
    showPanel4pay() {
      return this.state === 'endTrip' || this.state === 'paying' || this.state === 'paid' || this.state === 'payFail' || this.state === 'evaluating' || this.state === 'evaluated' || this.state === 'notEvaluate';
    },
    ...mapState({
      car: state => state.travel.car,
      state: state => state.travel.car.state,
      startArea: state => state.travel.car.startArea,
      endArea: state => state.travel.car.endArea,
      user: state => state.travel.car.user,
      nowCalling: state => state.travel.car.nowCalling,
      specialCar: state => state.travel.car.specialCar,
      specialCarType: state => state.travel.car.specialCarType,
      rule: state => state.travel.car.rule,
      reasonList: state => state.travel.car.reasonList,
      selectReason: state => state.travel.car.selectReason,
      order_id: state => state.travel.car.order_id,
      order: state => state.travel.car.order,
      fastCar: state => state.travel.car.fastCar,
      selectVoucher: state => state.travel.car.selectVoucher,
      voucherList: state => state.travel.car.voucherList,
      passenger_phone: state => state.travel.car.passenger_phone,
      commentOrComplaint: state => state.travel.car.commentOrComplaint,
      level: state => state.travel.car.level,
      totalPrice: state => state.travel.car.totalPrice,
      departure_time: state => state.travel.car.departure_time,
      enableCall: state => state.travel.car.enableCall,
      beforeState: state => state.travel.car.beforeState,
      userInfo: state => state.userInfo
    }),
  },
  methods: {
    startTiming(startTime) {
      object4map.cartips.setText(formatSecondsToMinutes(parseInt((new Date() - startTime)/1000, 10)));
      object4map.interval4timing = setInterval(() => {
        object4map.cartips.setText(formatSecondsToMinutes(parseInt((new Date() - startTime)/1000, 10)))
      }, 1000);
    },
    closeList4historyOrders() {
      this.showHistoryOrders = false;
      this.title = titleMap[this.state];
    },
    showOrderDetails(orderId) {
      this.title = '订单详情';
      this.showHistoryOrders = false;
      this.detailOrderId2show = orderId;
      this.showDetail = true;
    },
    exitToMain() {
      const redirect = this.$route.query.redirect || '/travel';
      this.$router.push(redirect);
      // 退出清空store数据
      this.$store.commit('CAR', this.storeCar);
    },
    closePanel4askBase(selectedCity) {
      var userData = clone(this.user);
      userData.cityid = selectedCity.cityid;
      userData.cityname = selectedCity.name;
      this.$store.commit('CAR', Object.assign({}, this.car, { user: userData}));
      this.showPanel4askBase = false;
      this.getVoucherList()
        .then(this.getUnPaidOrders)
          .then(this.orderStatusInit)
            .catch(err => this.showToast({ msg: err.msg }));
    },
    goBack() {
      if (this.showDetail && !this.$route.query.orderId) {
        this.showHistoryOrders = true;
      } else if (this.car.order.status === 400 && this.car.order.type === 1) {
        this.readyForNewOrder();
      } else if (this.state !== 'toCall' && this.state !== 'detail') {
        this.exitToMain();
      } else if (this.state === 'toCall' && !this.enableCall) {
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'canCall' }));
      } else if (this.state === 'toCall' && this.enableCall) {
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'nonCall' }));
      }
    },
    // 点击进入弹出设置选择
    showChoice(item) {
      if (item === 'cancel') {
        this.showSet = true;
        this.choice = false;
      } else {
        this.showSet = false;
        this.choice = true;
      }
    },
    // 点击打开“我的行程”/“常用地址”/“打车券”
    openTo(item) {
      // this.showChoice('cancel');
      this.showMenus = false;

      switch (item) {
        case 'baseCity':
          this.showBaseCity = true;
          break;

        case 'vouchers':
          this.showList = true;
          break;

        case 'address':
          this.showAddress = true;
          this.$router.push('/travel/didi/commonAddress');
          break;

        case 'myTrip':
          this.showHistoryOrders = true;
          // this.$store.commit('CAR', Object.assign({}, this.car, { beforeState: this.state }));
          // this.orderStatusInit().then(() => {
          //   if (this.timer) {
          //     clearInterval(this.timer);
          //   }
          //   this.$router.push('/travel/didi/myTrip');
          // });
          break;
        default:
      }
    },
    // 点击Tab(快车/专车)时向
    changTab(ruleNum) {
      if (this.state === 'canCall' || this.state === 'nonCall' || this.state === 'toCall') {
        this.$store.commit('CAR', Object.assign({}, this.car, { rule: ruleNum }));
        console.log('改变车型为', this.rule);
        if (this.state === 'toCall') {
          this.getEvaluatePrice();
        }
      }
    },
    // 地图
    mapInit() {
      if (window.AMap) {
        this.hasMap = true;

        object4map.mapInstance = new window.AMap.Map('mapContainer', {
          resizeEnable: true,
          zoom: 15,
          center: this.userLocation
        });
        object4map.currentLocation = new AMap.Marker({
          map: object4map.mapInstance,
          content: `<div style="position: relative; width: 32px; height: 32px; border-radius: 16px; background-color: rgba(145,204,255,0.50);">
          <div style="position: absolute; top: 7px; left: 7px; width: 14px; height: 14px; border: solid #fff 2px; border-radius: 9px; background-color: #3DA5FE;">
          </div></div>`,
          offset: new AMap.Pixel(-16, -16),
          position: this.userLocation
        });
        object4map.startMarker = new AMap.Marker({
          map: object4map.mapInstance,
          content: `<img style="width: 30px; height: 43px;" src="${mapIcons.start}">`,
          offset: new AMap.Pixel(-15, -41),
          raiseOnDrag: true,
          visible: false,
          position: this.departure,
        });
        object4map.endMarker = new AMap.Marker({
          map: object4map.mapInstance,
          content: `<img style="width: 30px; height: 43px;" src="${mapIcons.end}">`,
          offset: new AMap.Pixel(-15, -41),
          visible: false,
          position: this.destination,
        });
        object4map.carMarker = new AMap.Marker({
          map: object4map.mapInstance,
          content: `<img style="width: 53px; height: 26px;" src="${mapIcons.car}">`,
          offset: new AMap.Pixel(-26, -16),
          visible: false,
          position: this.carLocation,
        });

        object4map.cartips= new AMap.Text({
          map: object4map.mapInstance,
          text:'',
          offset: new AMap.Pixel(0,-70),
          visible:true,
          position: this.userLocation,
          textAlign:'center'
        });
        object4map.cartips.setStyle({
          'font-size': '12px',
          'background-color': 'white',
          padding: '5px',
          'border-radius': '20px',
        })

        const departureIcon = document.createElement('img');
        departureIcon.src = mapIcons.start;
        departureIcon.className = 'customControl';
        object4map.marker4departure = { // 自定义控件，需要实现addTo和removeFrom两个方法
            dom: departureIcon,
            addTo() {
                object4map.mapInstance.getContainer().appendChild(object4map.marker4departure.dom);
            },
            removeFrom() {
                if (object4map.marker4departure.dom.parentNode === object4map.mapInstance.getContainer()) {
                    object4map.mapInstance.getContainer().removeChild(object4map.marker4departure.dom);
                }
            }
        }

        AMap.service('AMap.Driving',() => {
          object4map.recommendedLine = new AMap.Driving({
            map: object4map.mapInstance,
            hideMarkers: true
          });
        })

        console.log(object4map)
      }else {
        throw new ReqError({ msg: '高德地图sdk 未加载！' });
      }
    },
    drawRecommendedLine(startCoordinate, endCoordinate) {
      return new Promise((resolve, reject) => {
        if (!AMap.Driving) {
          reject({
            msg: '插件未加载！'
          });
        }

        object4map.recommendedLine.search(startCoordinate, endCoordinate, (status, result) => {
          if (status === 'complete') {
            console.log(result)
            resolve((result.routes[0].distance / 1000).toFixed(2));
            // const time = Math.ceil(result.routes[0].time / 60);
            // this.infoWindowContent = `距您<span>${distance}</span>公里<span>${time}</span>分钟`;
            // this.showToast({ msg: `距您<span style="color: #FCB23C">${distance}</span>公里<span style="color: #FCB23C">${time}</span>分钟` });
            // this.infoWindow = new AMap.InfoWindow({
            //   isCustom: true,
            //   content: `<div class="didi-info-window-content">${this.infoWindowContent}</div>`,
            //   offset: new AMap.Pixel(0, 40),
            // });
            // this.infoWindow.open(object4map.mapInstance, this.destination);
          }
        });
      })

    },
    // 设置实时状态
    setStatus(status) {
      if (status === 300) { // 等待应答
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'waitOrder' }));
      } else if (status === 311) { // 订单超时（重新填写信息叫车）
        if (this.state !== 'calling') {
          this.$store.commit('CAR', Object.assign({}, this.car, { state: 'canCall' }));
          this.canUseVoucher();
        } else {
          this.$store.commit('CAR', Object.assign({}, this.car, { state: 'toCall' }));
        }
      } else if (status === 400) { // 已接单，等待接驾
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'takeOrder' }));
      } else if (status === 410) { // 司机已到达
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'takeCar' }));
      } else if (status === 500) { // 行程中
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'onTheWay' }));
      } else if (status === 600) { // 行程结束
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'endTrip' }));
      } else if (status === 610) { // 行程异常结束
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'canCall' }));
        this.canUseVoucher();
      } else if (status === 700) { // 已付款
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'canCall' }));
        this.canUseVoucher();
      }
    },
    // 判断是否有可用的券
    canUseVoucher() {
      console.log('所有券', this.voucherList);
      const self = this;
      let canUse = false;
      this.voucherList.forEach((item) => {
        if (item.enableFlag === 'Y') {
          canUse = true;
        }
      });
      if (!canUse) {
        this.$vux.confirm.show({
          content: '暂无可用打车劵，您将无法打车，但仍可继续查看线路及费用',
          onConfirm() {
            self.$store.commit('CAR', Object.assign({}, self.car, { state: 'nonCall' }));
            self.$store.commit('CAR', Object.assign({}, self.car, { enableCall: true }));
            if (self.state === 'canCall' || self.state === 'nonCall') {
              if (!self.selectReason.content) {
                self.getReasonList().catch(err => self.showToast({ msg: err.msg }));
              }
            }
          },
          onCancel() {
            self.$router.push('/travel');
          },
        });
      } else if (canUse && (this.state === 'canCall' || this.state === 'nonCall')) {
        if (!this.selectReason.content) {
          this.getReasonList().catch(err => this.showToast({ msg: err.msg }));
        }
      }
    },
    // 判断选择的打车券余额是否充足
    isEnough() {
      const self = this;
      if (this.selectVoucher.voucherBalance < this.totalPrice.total_price) {
        this.$vux.confirm.show({
          title: '支付失败',
          content: '打车劵余额不足！请重新选择打车券，如无可用打车券，可尝试联系系统管理员或补EA申请单。',
          // 点击“确定”时触发
          onConfirm() {
            self.showList = true;
          },
          onCancel() {
            if (self.timer) {
              clearInterval(self.timer);
            }
            console.log('确认支付失败');
            self.showToast({ msg: '确认支付失败' });
            self.$store.commit('CAR', Object.assign({}, self.car, { state: 'payFail' }));
          },
        });
      }
    },
    // 获取用户最后的订单（判断最后一单是否已经付款，如果未付款，则不能进行下一个订单）
    orderStatusInit() {
        return this.$store.dispatch('getLastOrder', { mipAccount: this.mipAccount }).then((res) => {
          console.log('用户最后的订单的信息', res.data);
          if (res && res.errcode === '00000' && res.data) {
            const orderObj = res.data;
            const status = res.data.status;

            this.$store.commit('CAR', Object.assign({}, this.car, { order_id: orderObj.orderId }));
            this.$store.commit('CAR', Object.assign({}, this.car, { order: orderObj }));
            // 最后一单如果是等待应答 / 等待接驾（现在叫车而不是预约的）/司机已到达 / 行程中 时，需要调到相应状态的页面
            // 并且开始轮询监测状态
            if (status === 300 || (status === 400 && orderObj.type === 0) || status === 410 || status === 500 || res.data.sub_status === 6104) {
              this.setStatus(status);
              this.$store.commit('CAR', Object.assign({}, this.car, { nowCalling: true }));
              // this.$store.commit('CAR', Object.assign({}, this.car, { order: orderObj }));
              this.$store.commit('CAR', Object.assign({}, this.car, { rule: orderObj.useCarType }))

              style2insert.styleEl = addStylesheet(style2insert.waitingOrder);
              object4map.cartips.show();
              object4map.cartips.setPosition([orderObj.flng, orderObj.flat]);
              clearInterval(object4map.interval4timing);
              this.startTiming(new Date(orderObj.createTime));

              if (this.timer) {
                clearInterval(this.timer);
              }
              this.timer = setInterval(this.getOrderDetail, 5000);
              this.getOrderDetail();
            } else if (status === 400 && orderObj.type === 1) { // 如果是预约单，并且是等待接驾中则判断如果现在时间离预约时间还有半个小时以上则不做处理，少于半个小时则开始查看状态提醒用户还有多长时间到点
              const depTime = orderObj.departureTime;
              const nowTime = Date.now();
              if (nowTime + 1800000 < depTime) {
                this.setStatus(700);
                // this.setStatus(status);
                // if (this.timer !== '') {
                //   clearInterval(this.timer);
                // }
                // this.timer = setInterval(this.getOrderDetail, 5000);
                // this.getOrderDetail();
              } else {
                this.$vux.confirm.show({
                  title: '提示',
                  content: `您有一笔即将在${formatDate(orderObj.departureTime, 'M月d日 hh:mm')}出发的预约单，是否查看该订单？`,
                  confirmText: '查看',
                  cancelText: '不查看',
                  onConfirm: () => {
                    this.$store.commit('CAR', Object.assign({}, this.car, { nowCalling: false }));
                    this.$store.commit('CAR', Object.assign({}, this.car, { rule: orderObj.useCarType }));
                    this.setStatus(status);
                    if (this.timer !== '') {
                      clearInterval(this.timer);
                    }
                    this.timer = setInterval(this.getOrderDetail, 5000);
                    this.getOrderDetail();
                  },
                  onCancel: () => {
                    this.setStatus(700);
                  }
                });

              }
            // } else if (orderObj.confirmState === 0) {
            //   if (type === 1) {
            //     const self = this;
            //     this.$vux.confirm.show({
            //       content: '您有一笔订单未确认支付，前往支付？',
            //       onConfirm() {
            //         self.$store.commit('CAR', Object.assign({}, self.car, { rule: orderObj.useCarType }));
            //         if (self.timer !== '') {
            //           clearInterval(self.timer);
            //         }
            //         // self.timer = setInterval(self.getOrderDetail, 5000);
            //         self.getOrderDetail(orderObj.orderId).then((receivedDatas) => {
            //           self.$store.commit('CAR', Object.assign({}, self.car, receivedDatas.order, {
            //             state: 'paying',
            //             totalPrice: receivedDatas.price
            //           }));
            //         })
            //       },
            //       onCancel() {
            //         self.$router.push('/travel');
            //       },
            //     });
            //   }
            } else {
              this.setStatus(status);
            }

          } else if (res && res.errcode === '40010') {
            this.setStatus(700)
          } else if (res && res.errmsg && res.errcode !== '40010') {
            throw new ReqError(res);
          }
        });
    },
    getLocation() {
      if (object4map.method4locate) {
        return object4map.method4locate().then((data) => {
          let didiLike;
          this.userLocation = [data.longitude, data.latitude];
          didiLike = clone(data);
          didiLike.lat  = didiLike.latitude;
          didiLike.lng  = didiLike.longitude
          didiLike.displayname = didiLike.displayname || didiLike.address;
          this.$store.dispatch('getCityId', {
            cityCode: String(didiLike.citycode)
          }).then((response) => {
            if (response && response.code !== '00000') return;
            didiLike.cityid = String(response.data);
            this.currentLocationInfo = didiLike;
            if (isEmpty(this.startArea)) {
              this.$store.commit('CAR', Object.assign({}, this.car, {
                startArea: didiLike
              }));
            }
          });
        }, () => { this.locationInfo.text = '定位失败'; });
      }
    },
    getUserLocation(opt) {
      const defaultOpt = {
        setCenter: false,
        continue: false,
        freshUserMarker: true,
        interval: 2000,
      };
      opt = Object.assign(defaultOpt, (opt || {}));
      this.getLocation().then(() => {
        object4map.mapInstance.setZoom(17);
        object4map.mapInstance.setCenter(this.userLocation);
        object4map.currentLocation.setPosition(this.userLocation);
      }).catch((err) => {
        this.showToast({ msg: `获取定位失败(${err})` });
      });
      if (opt.continue) {
        if (this.getLocationTimer) {
          clearInterval(this.getLocationTimer);
          this.getLocationTimer = '';
        }
        this.getLocationTimer = setInterval(() => {
          this.getLocation().then(() => {
            if (opt.setCenter) {
              object4map.mapInstance.setZoom(17);
              object4map.mapInstance.setCenter(this.userLocation);
            }
            if (opt.freshUserMarker) object4map.currentLocation.setPosition(this.userLocation);
          }).catch((err) => {
            this.showToast({ msg: `获取定位失败(${err})` });
          });
        }, opt.interval);
      }
    },
    beginLocation(opt) {
      const defaultOpt = {
        continue: true,
      };
      opt = Object.assign(defaultOpt, (opt || {}));
      this.getUserLocation(opt);
    },
    stopLocation() {
      if (this.getLocationTimer) {
        clearInterval(this.getLocationTimer);
        this.getLocationTimer = '';
      }
    },
    /**
     * 获取用户基本信息
     */
    getCarUserInfo() {
      const { userId } = this.userInfo.user;
      return Promise.all([
          this.$store.dispatch('getUserInfo', { id: userId }),
          this.$store.dispatch('getCarUserInfo', { mipAccount: this.mipAccount })
        ]).then((responses) => {
        if (responses[0] && responses[0].code === '0000' && responses[1] && responses[1].code === '00000') {
          responses[1].data.user.phone = responses[0].data.telephone_number;
          this.$store.commit('CAR', Object.assign({}, this.car, { user: responses[1].data.user }));
          this.$store.commit('CAR', Object.assign({}, this.car, { passenger_phone: responses[0].data.telephone_number }));

          if (!responses[1].data.user.cityname) {
            this.showPanel4askBase = true;
            throw new ReqError({ msg: '未设置常用办公地！' });
          }
        } else if (responses[0] && responses[0].code !== '0000') {
          throw new ReqError(responses[0]);
        } else if (responses[1] && responses[1].code !== '00000') {
          throw new ReqError(responses[1]);
        }
      })
    },
    /**
     * 获取乘车事由列表
     */
    getReasonList() {
      return this.$store.dispatch('getReason', {}).then((res) => {
        if (res && res.errcode === '00000') {
          const arr = res.data;
          this.$store.commit('CAR', Object.assign({}, this.car, { reasonList: arr }));
          console.log('乘车事由', this.reasonList);
        } else if (res && res.errmsg) {
          // this.showToast({ msg: `请求异常(${res.errmsg})` });
          throw new ReqError(res);
        }
      });
    },
    /**
     * 获取打车券列表
     */
    getVoucherList() {
      console.log('获取所有的打车券')
      const params = {
        voucherType: null
      };
      return this.$store.dispatch('getCard', params).then((response) => {
          if (response && response.errcode === '00000') {
            const receivedTickets = response.data;
            this.$store.commit('CAR', Object.assign({}, this.car, { voucherList: receivedTickets }));
            // this.$store.commit('CAR', Object.assign({}, this.car, { selectVoucher: arr[0] }));
          } else if (response && response.errmsg) {
            // this.showToast({ msg: `请求异常(${response.errmsg})` });
            throw new ReqError(response);
          }
        });
    },
    // 按顺序执行的异步操作，实现同时显示专车三种车型的估价
    promise(params) {
      return this.$store.dispatch('getEvaluatePrice', params).then((res) => {
        var useEA = false;
        if (this.startArea.cityid !== this.user.cityid || this.endArea.cityid !== this.user.cityid) useEA = true;

        if (res && res.errcode === '00000') {
          if (res.data.data) {
            if (params.require_level === 100) {
              const carArr = this.specialCar;
              console.log('carArr', carArr);
              carArr[0] = res.data.data[100];
              this.$store.commit('CAR', Object.assign({}, this.car, { specialCar: carArr }));
            } else if (params.require_level === 200) {
              const carArr = this.specialCar;
              carArr[1] = res.data.data[200];
              carArr[1].name = '豪华型';
              this.$store.commit('CAR', Object.assign({}, this.car, { specialCar: carArr }));
            } else if (params.require_level === 400) {
              const carArr = this.specialCar;
              carArr[2] = res.data.data[400];
              this.$store.commit('CAR', Object.assign({}, this.car, { specialCar: carArr }));
            } else if (params.require_level === 600) {
              const fastCarObj = res.data.data[600];
              this.$store.commit('CAR', Object.assign({}, this.car, { evaluatePrice: fastCarObj.price }));
              this.$store.state.travel.car.voucherList.every((perTicket) => {
                if (perTicket.voucherBalance > fastCarObj.price && useEA === !!perTicket.voucherReturnCode) {
                  this.$store.commit('CAR', Object.assign({}, this.car, { selectVoucher: perTicket }));
                  return false;
                }

                return true;
              });
              this.$store.commit('CAR', Object.assign({}, this.car, { fastCar: fastCarObj }));
              this.$store.commit('CAR', Object.assign({}, this.car, { enableCall: !this.$store.state.travel.car.selectVoucher.voucherId }));
            }

            return res.data;
          }
          this.showToast({ msg: `请求异常(${res.data.errmsg})` });
          Promise.reject({ msg: `请求异常(${res.data.errmsg})` })
        } else if (res && res.errmsg) {
          this.showToast({ msg: `请求异常(${res.errmsg})` });
          Promise.reject({ msg: `请求异常(${res.errmsg})` })
        }
      });
    },
    /**
     * 价格预估
     */
    getEvaluatePrice: async function getEvaluatePrice () {
      this.showLoading();
      this.$store.commit('CAR', Object.assign({}, this.car, { selectVoucher: {} }));
      console.log('哪种车', this.rule);
      let useEA = false;
      if (this.startArea.cityid !== this.user.cityid || this.endArea.cityid !== this.user.cityid) useEA = true;

      const params = {
        sn: new Date().valueOf(),
        rule: this.rule,
        type: this.nowCalling ? 0 : 1, // 现在叫车为0， 预约叫车为1
        city: this.startArea.cityid,
        flat: this.startArea.lat,
        flng: this.startArea.lng,
        tlat: this.endArea.lat,
        tlng: this.endArea.lng,
        departure_time: this.nowCalling ? null : this.departure_time,
      };
      // 快车
      if (this.rule === '301') {
        params.require_level = 600;
        await this.promise(params);
      } else { // 专车
        params.require_level = 100;
        await this.promise(params);
        params.require_level = 200;
        await this.promise(params);
        params.require_level = 400;
        await this.promise(params).then(() => {
          this.$store.state.travel.car.voucherList.every((perTicket) => {
            if (perTicket.voucherBalance > this.specialCar[0].price && useEA === !!perTicket.voucherReturnCode) {
              this.$store.commit('CAR', Object.assign({}, this.car, { selectVoucher: perTicket }));
              return false;
            }

            return true;
          });
        });
      }
      this.$store.commit('CAR', Object.assign({}, this.car, { state: 'toCall' }));
      this.hideLoading();
    },
    /**
     * 发起叫车
     */
    calling() {
      const params = {
        sn: new Date().valueOf(),
        order_id: '',
        rule: this.rule,
        type: this.nowCalling ? '0' : '1', // 现在叫车为0， 预约叫车为1,
        city: this.startArea.cityid,
        endCity: this.endArea.cityid,
        flat: this.startArea.lat,
        flng: this.startArea.lng,
        tlat: this.endArea.lat,
        tlng: this.endArea.lng,
        clat: null,
        clng: null,
        reason: this.selectReason.content,
        reasonId: this.selectReason.id,
        start_name: this.startArea.displayname,
        start_address: this.startArea.address,
        end_name: this.endArea.displayname,
        end_address: this.endArea.address,
        departure_time: this.nowCalling ? '' : this.departure_time,
        require_level: this.rule === '301' ? 600 : this.specialCarType,
        app_time: '', // 客户端时间
        map_type: 'soso',
        combo_id: 0, // 套餐ID number 写死
        sms_policy: 3, // 发送短信策略 写死
        extra_info: '', //
        callback_info: '',
        mipAccount: this.mipAccount,
        voucherCode: '',
        voucherList: [this.selectVoucher],
        passenger_phone: this.passenger_phone,
      };
      if (this.rule === '301') {
        params.dynamic_md5 = this.fastCar.dynamic_md5;
      } else {
        this.specialCar.forEach((item) => {
          if (item.code === this.specialCarType) {
            params.dynamic_md5 = item.dynamic_md5;
          }
        });
      }
      console.log('发起叫车', params);
      this.$store.dispatch('calling', params).then((res) => {
        if (res && res.errcode === '00000') {
          if (res.data && res.data.errno === '0') {
            console.log('发起叫车成功', res.data.order);
            const obj = res.data.order;
            this.$store.commit('CAR', Object.assign({}, this.car, { order: obj }));
            this.$store.commit('CAR', Object.assign({}, this.car, { order_id: obj.id }));
            this.orderStatusInit().catch(err => this.showToast({ msg: err.msg }));
          } else if (res.data && res.data.errno === '20004') {
            this.$store.commit('CAR', Object.assign({}, this.car, { state: 'toCall' }));
            this.showToast({ msg: res.errmsg }); // 出发时间太近了，应该叫实时单
          } else if (res.data && res.data.errno === '20007') {
            this.$store.commit('CAR', Object.assign({}, this.car, { state: 'toCall' }));
            this.showToast({ msg: res.errmsg }); // 叫车失败,选择的打车券余额不足
          } else {
            this.$store.commit('CAR', Object.assign({}, this.car, { state: 'toCall' }));
            this.showToast({ msg: res.errmsg });
          }
        } else if (res && res.errcode === '60002') {
          this.$store.commit('CAR', Object.assign({}, this.car, { totalPrice: { total_price: this.order.totalPrice } }));
          const self = this;
          this.$vux.confirm.show({
            content: res.errmsg,
            onConfirm() {
              if (self.timer !== '') {
                clearInterval(self.timer);
              }
              self.timer = setInterval(self.getOrderDetail, 5000);
              self.getOrderDetail();
            },
            onCancel() {
              self.$store.commit('CAR', Object.assign({}, self.car, { state: 'toCall' }));
            },
          });
        } else if (res && res.errmsg) {
          this.$store.commit('CAR', Object.assign({}, this.car, { state: 'toCall' }));
          this.showToast({ msg: res.errmsg });
        }
      });
    },
    /**
     * 获取订单详情
     */
    getOrderDetail(id) {
      if (id) {
        const params = {
          order_id: id,
        };
        return this.$store.dispatch('getOrderDetail', params).then((res) => {
            if (res && res.errcode === '00000') {
              console.log('订单详情', res);
              this.detailOrder = res.data;
              if (res.data.commentOrComplaint) {
                delete res.data.commentOrComplaint.orderId;
                delete res.data.commentOrComplaint.type;
                delete res.data.commentOrComplaint.id;
                res.data.commentOrComplaint.commentType *= 1;
                res.data.order.commentOrComplaint = res.data.commentOrComplaint;
                res.data.order.price = res.data.price;
              }
              this.$store.commit('CAR', Object.assign({}, this.car, { order: res.data.order }));
              return res.data;
            } else if (res && res.errmsg) {
              this.showToast({ msg: res.errmsg });
              Promise.reject({ msg: res.errmsg });
            }
          });
      }
      const params = {
        order_id: this.order_id,
      };
      return new Promise((resolve) => {
        this.$store.dispatch('getOrderDetail', params).then((res) => {
          if (res && res.errcode === '00000') {
            let orderObj = res.data.order;
            if (!orderObj) {
              clearInterval(this.timer);
            } else {

              if (this.car.order.status !== orderObj.status) {
                switch(orderObj.status) {
                  case 400:
                    if (style2insert.styleEl) {
                      document.head.removeChild(style2insert.styleEl);
                    }
                    style2insert.styleEl = addStylesheet(style2insert.waitingDriver);
                    clearInterval(object4map.interval4timing);
                    this.startTiming(new Date(orderObj.order_time.replace(/-/g, '/')));
                    break;
                  default:
                }
              }

              // 保存订单详情
              this.$store.commit('CAR', Object.assign({}, this.car, { order: orderObj }));
              object4map.startMarker.setPosition([orderObj.flng, orderObj.flat]);
              object4map.endMarker.setPosition([orderObj.tlng, orderObj.tlat]);
              object4map.startMarker.show();
              object4map.endMarker.show();

              if (orderObj.dlng && orderObj.dlat) {
                object4map.carMarker.setPosition([orderObj.dlng, orderObj.dlat]);
                object4map.carMarker.show();
              }

              switch (this.order.status) {
                case 300:
                  this.$store.commit('CAR', Object.assign({}, this.car, { state: 'waitOrder' }));
                  console.log('正在等待司机接单', res.data.order);
                  break;
                case 311:
                  this.$store.commit('CAR', Object.assign({}, this.car, { state: 'toCall' }));
                  console.log('订单超时，请稍后尝试重新叫车', res.data.order);
                  object4map.cartips.hide()
                  clearInterval(this.timer);
                  break;
                case 400:
                  this.$store.commit('CAR', Object.assign({}, this.car, { state: 'takeOrder' }));
                  console.log(object4map.carMarker)
                  object4map.carMarker.show();
                  console.log('已接单，等待司机到达', res.data.order);
                  break;
                case 410:
                  this.$store.commit('CAR', Object.assign({}, this.car, { state: 'takeCar' }));
                  console.log('司机已到达，准备上车', res.data.order);
                  object4map.cartips.hide();
                  clearInterval(object4map.interval4timing);
                  this.drawRecommendedLine([res.data.order.flng, res.data.order.flat], [res.data.order.tlng, res.data.order.tlat])
                  break;
                case 500:
                  this.$store.commit('CAR', Object.assign({}, this.car, { state: 'onTheWay' }));
                  console.log('已上车，行程中', res.data.order);

                  this.drawRecommendedLine([res.data.order.flng, res.data.order.flat], [res.data.order.tlng, res.data.order.tlat])
                    .then((distance) => {
                      if (style2insert.styleEl) {
                        document.head.removeChild(style2insert.styleEl);
                      }
                      style2insert.styleEl = addStylesheet(style2insert.going);
                      object4map.cartips.setText(distance);
                      object4map.cartips.setPosition([orderObj.dlng, orderObj.dlat]);
                      object4map.cartips.setOffset(new AMap.Pixel(0, 30));
                      object4map.cartips.show();
                    })
                  break;
                case 600:
                  this.$store.commit('CAR', Object.assign({}, this.car, { totalPrice: res.data.price }));
                  this.$store.commit('CAR', Object.assign({}, this.car, { state: 'endTrip' }));
                  console.log('到达目的地，行程结束', res.data.order);
                  object4map.cartips.hide();
                  break;
                case 610:
                  if (orderObj.sub_status === 6104) {
                    this.alert({
                      title: '请确认',
                      content: '订单被司机取消，系统已为您重新叫车！'
                    });
                    this.$store.commit('CAR', Object.assign({}, this.car, { state: 'waitOrder' }));
                    this.$store.commit('CAR', Object.assign({}, this.car, { order_id: orderObj.reassign_info.latest_order_id }));
                    console.log('正在等待司机接单', res.data.order);
                    // var now=new Date();
                    // var old=new Date(res.data.order.order_time.replace(/-/g, '/'))
                    style2insert.styleEl = addStylesheet(style2insert.waitingOrder);
                    object4map.cartips.setText('00:00');
                    object4map.cartips.show();
                    object4map.cartips.setPosition([orderObj.flng, orderObj.flat]);

                    if (this.timer) {
                      clearInterval(this.timer);
                    }
                    this.timer = setInterval(this.getOrderDetail, 5000);
                    this.getOrderDetail();
                  }else {
                    clearInterval(this.timer);
                    object4map.cartips.hide();
                  }
                  break;
                case 700:
                  this.$store.commit('CAR', Object.assign({}, this.car, { totalPrice: res.data.price }));
                  this.$store.commit('CAR', Object.assign({}, this.car, { selectVoucher: res.data.voucher }));
                  this.$store.commit('CAR', Object.assign({}, this.car, { order_selectedVoucher: res.data.voucher }));
                  this.$store.commit('CAR', Object.assign({}, this.car, { state: res.data.order.confirmState === 0 ? 'endTrip' : 'paid' }));
                  object4map.cartips.hide();
                  clearInterval(this.timer);
                  break;
                default:
                  object4map.cartips.hide();
                  clearInterval(this.timer);
                  break;
              }

              object4map.carMarker.setPosition([orderObj.dlng, orderObj.dlat]);
            }
            resolve();
          } else if (res && res.errmsg) {
            this.showToast({ msg: res.errmsg });
          }
        });
      });
    },
    /**
     * 取消订单
     */
    cancelOrder() {
      const params = {
        force: true,
        order_id: this.order_id,
      };
      this.$store.dispatch('cancelOrder', params).then((res) => {
        if (res && res.errcode === '00000') {
          if (res.data && res.data.errno === '0') {
            const orderObj = this.order;
            this.showToast({ msg: '取消订单成功！' });
            if (object4map.cartips) object4map.cartips.hide();
            clearInterval(object4map.interval4timing);
            if (this.timer) {
              clearInterval(this.timer);
            }
            if (orderObj.status === '300' || orderObj.status === 300) {
              this.$store.commit('CAR', Object.assign({}, this.car, { state: 'toCall' }));
            } else {
              orderObj.cancelCost = res.data.cost;
              this.$store.commit('CAR', Object.assign({}, this.car, { order: orderObj }));
              this.$store.commit('CAR', Object.assign({}, this.car, { state: 'cancelled' }));
            }
          } else if (res.data && res.data.errno) {
            this.showToast({ msg: `请求异常(${res.data.errmsg})` });
            if (this.timer) {
              clearInterval(this.timer);
            }
          }
        } else if (res && res.errcode) {
          this.showToast({ msg: `请求异常(${res.errmsg})` });
          if (this.timer) {
            clearInterval(this.timer);
          }
        }
      });
    },
    getUnPaidOrders() {
      return this.$store.dispatch('getUnPaidOrder').then((receivedDatas) => {
        if (receivedDatas && receivedDatas.errcode === '00000') {
          if (receivedDatas.data && receivedDatas.data.orderId) {
              Object.assign(receivedDatas.data, convertToSnakeCase(receivedDatas.data.driver || {}));
              const selectVoucher = receivedDatas.data.voucher;
              delete receivedDatas.data.voucher;
              delete receivedDatas.data.driver;
              this.$vux.confirm.show({
                content: '您有一笔订单未确认支付，前往支付？',
                onConfirm: () => {
                  this.$store.commit('CAR', Object.assign({}, this.car, {
                    rule: receivedDatas.data.useCarType,
                    state: 'endTrip',
                    order_id: receivedDatas.data.orderId,
                    order: receivedDatas.data,
                    selectVoucher,
                    order_selectedVoucher: selectVoucher
                  }));
                  if (this.timer !== '') {
                    clearInterval(this.timer);
                  }

                  // this.timer = setInterval(this.getOrderDetail, 5000);
                  // this.getOrderDetail(receivedDatas.data.orderId).then(((receivedDatas) => {
                  //   this.$store.commit('CAR', Object.assign({}, this.car, receivedDatas.order, {
                  //     totalPrice: receivedDatas.price
                  //   }));
                  // }).bind(this))
                },
                onCancel: () => {
                  this.$router.push('/travel');
                },
              });

              this.hideLoading();
              throw new ReqError({ msg: '有未确认订单！' });
          }

        } else if (receivedDatas && receivedDatas.errmsg) {
          // this.showToast({ msg: receivedDatas.errmsg });
          throw new ReqError(receivedDatas);
        }
      });
    },
    readyForNewOrder() {
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'canCall' }));
        object4map.endMarker.hide();
        object4map.recommendedLine.clear();
        object4map.mapInstance.setZoomAndCenter(16, this.userLocation);
        clearInterval(object4map.interval4timing);
        this.getVoucherList().catch(err => this.showToast({ msg: err.msg }));
    },
    /**
     * 确认支付 operation=24
     */
    ensurePaid() {
      // this.isEnough();
      // if (this.selectVoucher.voucherBalance >= this.totalPrice.total_price && this.state !== 'payFail') {
        let params = {
          orderId: this.order_id,
          level: this.level, // 五星好评中的几星
          comment: this.commentOrComplaint,
          voucherList: []
        };

        if (this.car.selectVoucher.voucherId !== this.car.order_selectedVoucher.voucherId) params.voucherList = this.selectVoucher;

        return this.$store.dispatch('ensurePay', params).then(response => {
          if (response && response.errcode === '00000') {
            console.log('确认支付', response);
            this.showToast({ msg: '支付成功' });
            this.$store.commit('CAR', Object.assign({}, this.car, { state: 'canCall' }));
            object4map.endMarker.hide();
            object4map.recommendedLine.clear();
            object4map.mapInstance.setZoomAndCenter(16, this.userLocation);
            clearInterval(object4map.interval4timing);
            this.getVoucherList().catch(err => this.showToast({ msg: err.msg }));
          } else if (response && response.errmsg) {
            this.showToast({ msg: response.errmsg });
          }
        })
      // }
    },
    centerLocationInToView() {
      object4map.mapInstance.setZoom(17);
      object4map.mapInstance.setCenter(this.userLocation);
    }
  },
  created() {
    if (isIOSEnviron()) {
      object4map.method4locate = platform.locationForIOS;
    }else {
      object4map.method4locate = platform.location;
    }
    if (!this.beforeState && !this.$route.query.orderId) {
      console.log('无参数');

      this.showLoading();
      this.getCarUserInfo()
        .then(this.getReasonList)
          .then(this.getVoucherList)
            .then(this.getUnPaidOrders)
              .then(this.orderStatusInit)
                .catch(err => {
                  if (err.code === '00004') {
                    const _this = this;
                    this.alert({
                      title: '提示',
                      content: err.msg,
                      onHide() {
                        _this.$router.push('/travel');
                      },
                    });
                  } else {
                    this.showToast({ msg: err.msg });
                  }
                })
                .finally(() => this.hideLoading());
    }
  },
  mounted() {
    if (this.state === '') {
      this.storeCar = this.car;
    }
    this.mapInit();
    this.beginLocation();
    if (this.$route.query.orderId) {
      this.showOrderDetails(this.$route.query.orderId);
      // this.getOrderDetail(this.$route.query.orderId).then(() => {
      //   // this.$store.commit('CAR', Object.assign({}, this.car, { state: 'detail' }));
      // });
    }
  },

  beforeDestroy() {
    if (object4map.mapInstance) object4map.mapInstance.destroy();
    clearInterval(object4map.interval4timing);
  },

  beforeRouteLeave(to, from, next) {
    if (this.getLocationTimer) {
      clearInterval(this.getLocationTimer);
      this.getLocationTimer = '';
    }
    next();
  },
};
</script>
<style lang="less" scoped>
.blue-border {
  border-bottom: 3px solid #3DA5FE;
}
.didi-wrap {
  .set-choice {
    position: fixed;
    width: 100%;
    top: 0;
    bottom: 0;
    background: rgba(0,0,0,.6);
    z-index: 112;
    padding-top: 60px;
    .cancel {
      position: absolute;
      right: 15px;
      top: 13px;
      width: 20px;
      height: 20px;
      img {
        width: 100%;
        height: 100%;
      }
    }
    div {
      display: flex;
      margin-right: 15px;
      justify-content: flex-end;
      margin-bottom: 15px;
      span {
        font-size: 14px;
        line-height: 50px;
        color: #FFFFFF;
        margin-right: 10px;
      }
      img {
        width: 50px;
        height: 50px;
      }
    }
  }
  .container {
    position: absolute;
    width: 100%;
    top: 0;
    bottom: 0;
    .car-tab {
      width: 100%;
      position: fixed;
      top: 46px;
      left: 0;
      right: 0;
      background: rgba(255, 255, 255, 0.75);
      padding-bottom: 3px;
      box-sizing: border-box;
      margin: 0;
      box-shadow: 0 2px 2px 0px rgba(0, 0, 0, 0.1);
      .fast-car,
      .special-car {
        text-align: center;
        height: 50px;
        span {
          text-align: center;
          font-size: 16px;
          color: #666666;
          line-height: 50px;
          display: block;
          width: 28%;
          margin: auto;
        }
      }
    }
  }
}

#mapContainer {
  width: 100%;
  height: 100%;
}

.tips4noMap {
  position: absolute;
  top: 33%;
  left: 0;
  width: 100%;
  text-align: center;
  color: #858585;
  font-size: 14px;

  .reloadMap {
    font-size: 16px;
    height: 30px;
    line-height: 30px;
    width: 70px;
    display: inline-block;
    border-radius: 40px;
    border: 1px solid;
    margin-top: .7em;
  }
}
</style>
