### To Be Released

#### Fixed

- Fixed an issue about can not select another ticket in confirm panel 「在确认订单的时候允许选择其他可用券」
- Fixed an issue about limit choose range for booking time 「没有限制预约时间」
- Fixed an issue about missing current user's phone data 「缺少当前用户电话」
- Fixed an issue about duplicate key warning in ticketList 「vue 重复 key 」
- Fixed an issue about missing base city check 「缺少判断常驻办公地逻辑」
- Fixed an issue about reorder cause by driver 「改派」
- Fixed an issue about the ticket's restrictions(compare about location's city and base city) 「修正打车券限制错误」
- Fixed an issue about missing cityid in located data 「定位的数据没有cityid」
- Fixed an issue about unexpecpted alert if user has no orders 「没有打过车的一直弹出没有打过车的错误」
- Fixed an issue about error tickets source in paying stage 「修正确认支付的时候，错误的打车券来源」
- Fixed an issue about position error after some panel close 「修正在某些页面关闭的时候产生的定位错误（输入法打开）」
- Fixed an issue about icon error after menu is opened 「修正菜单打开后，头像图标还显示」
- Fixed an issue about layout error on layour error in panel about change rider 「修正修改乘车人页面的组织结构入口」
- Fixed an issue about wrong description on tickets in didi 「修正滴滴打车xx券为打车券」
- Fixed an issue about missing destination after change from now to booking 「修正从现在切换到预约时丢失目的地的问题」
- Fixed an issue about not using persecond to record time 「修正没有按每秒记录时间的问题」