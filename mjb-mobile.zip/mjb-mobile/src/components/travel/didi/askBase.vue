<template>
  <div :class="$style.container">
    <div :class="$style.askBase">
      <div :class="$style.title" @click="showCity = true;">
        <span class="inline-block">常用办公地{{ selectedCity.name ? '：' + selectedCity.name : ''}}</span>
        <span class="inline-block iconfont icon-icon10"></span>
      </div>
      <div :class="$style.content">请您设置常用地，不设置将导致无法打车，且一经设置不能自行修改！</div>
      <div :class="[$style.confirmBottom, 'flex-row', 'text-center']">
        <div class="rest-area" @click="cancel">返回</div>
        <div class="rest-area linkBlue_font" @click="confirm">确定</div>
      </div>
    </div>

    <select-city v-if="showCity"
      :locationText="''"
      :locationInfo="{}"
      :tempType="'didi'"
      @select-city="selecCity"
      @hide-search="showCity = false"></select-city>
  </div>
</template>

<script>
import selectCity from 'common/selectCity';

var timeout4alert;

export default {
  data() {
    return {
      selectedCity: {},
      showCity: false
    };
  },
  components: {
    selectCity
  },
  methods: {
    cancel() {
      this.$emit('cancel');
    },
    confirm() {
      if (!this.selectedCity.name) {
        timeout4alert = this.showToast({
          msg: '请选择城市后再操作！',
          time: 1000
        });
        console.log(timeout4alert)
        return;
      }

      this.$store.dispatch('setBaseCity', {
        sn: new Date().valueOf(),
        cityname: this.selectedCity.name,
        cityid: this.selectedCity.cityid
      }).then(this.closePanel)
        .catch(() => {
          this.showToast({
            msg: '设置常驻地失败，请联系管理员！',
            time: 1000
          })
        });
    },
    closePanel() {
      this.showToast({
        msg: '设置常驻地成功！',
        time: 1000
      });
      this.$emit('close', this.selectedCity);
    },
    selecCity(city) {
      this.selectedCity = city;
      this.showCity = false;
    }
  }
};
</script>

<style lang="less" module>
  .container {
    background-color: rgba(0,0,0,.6);
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    z-index: 110;

    .askBase {
      background-color: #EAEAEA;
      width: 65%;
      padding: 1em 1em 0 1em;
      border-radius: .3em;
      overflow: hidden;
      margin: 10em auto 0 auto;

      .title {
        font-size: 0;
        padding-bottom: 0.85rem;
        text-align: justify;
  
        :global(.inline-block) {
          font-size: 16px;
        }

        &:after {
          display: inline-block;
          content: '';
          width: 100%;
        }
      }

      .content {
        font-size: 12px;
        padding-bottom: 1.2em;
      }

      .confirmBottom {
        padding: .6em 0;
        line-height: 1;
        position: relative;
        font-size: 17px;

        &:before {
          content: '';
          width: 130%;
          height: 1px;
          background-color: #ddd;
          position: absolute;
          top: 0;
          left: -15%;
        }

        &:after {
          content: '';
          position: absolute;
          height: 100%;
          width: 1px;
          top: 0;
          left: 50%;
          background-color: #ddd;
        }
      }
    }
  }
</style>
