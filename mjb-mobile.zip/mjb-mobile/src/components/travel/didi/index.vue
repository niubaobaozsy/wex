<!--
  describe: didi
  created by: zhuangyh
  date: 2017-11-26
-->
<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>
