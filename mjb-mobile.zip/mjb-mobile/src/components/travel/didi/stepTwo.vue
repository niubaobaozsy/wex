<!--
  describe：呼叫前第二步页面
  created by：ouql
  date：2017-11-26
-->
<template>
  <div class="secondStep">
    <div class="noBt">
      <div class="bookTime border-bottom" v-if="showTime">
        <div class="dot"><img :src="timeImg"></div>
        <!-- <p>11月13日 明天 23:00</p> -->
        <span>{{ departure_time }}</span>
      </div>
      <car-fare v-if="rule==='301'"></car-fare>
      <car-ticket :class="[{'has-top': rule==='201'}]"></car-ticket>
      <div class="carType" v-if="rule==='201'">
        <div class="car comfortable" v-for="(item, index) in specialCar" :key="index" :class="{'active': specialCarType === item.code}" @click="changeType(item)">
          <div class="type">{{item.name}}</div>
          <div class="fare">约
            <p>{{(item.price * 1).toFixed(2)}}</p>元</div>
        </div>
      </div>
    </div>
    <button-box @start-call="startCall"></button-box>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import carFare from './carFare';
import carTicket from './carTicket';
import buttonBox from './buttonBox';
import timeImg from '../../../assets/images/common/historyImg.png';

export default {
  components: {
    carFare,
    carTicket,
    buttonBox,
  },
  props: {
    showTime: Boolean,
  },
  data() {
    return {
      timeImg,
    };
  },
  watch: {
    state(val) {
      if (val) {
        console.log('现在的状态是：', val);
      }
    },
  },
  methods: {
    // 换专车类型
    changeType(carType) {
      var useEA = false;
      if (this.startArea.cityid !== this.user.cityid || this.endArea.cityid !== this.user.cityid) useEA = true;

      this.$store.commit('CAR', Object.assign({}, this.car, {
        evaluatePrice: carType.price,
        specialCarType: carType.code
      }));

      this.$store.commit('CAR', Object.assign({}, this.car, { selectVoucher: {} }));
      this.$store.state.travel.car.voucherList.every((perTicket) => {
        if (perTicket.voucherBalance > carType.price && useEA === !!perTicket.voucherReturnCode) {
          this.$store.commit('CAR', Object.assign({}, this.car, { selectVoucher: perTicket }));
          return false;
        }

        return true;
      });
    },
    startCall() {
      const str = 'calling';
      this.$store.commit('CAR', Object.assign({}, this.car, { state: str }));
    },
  },
  mounted() {
  },
  computed: {
    ...mapState({
      car: state => state.travel.car,
      user: state => state.travel.car.user,
      startArea: state => state.travel.car.startArea,
      endArea: state => state.travel.car.endArea,
      state: state => state.travel.car.state,
      rule: state => state.travel.car.rule,
      specialCar: state => state.travel.car.specialCar,
      specialCarType: state => state.travel.car.specialCarType,
      departure_time: state => state.travel.car.departure_time,
    }),
  },
};
</script>
<style lang="less" scoped>
.has-top {
  margin-top: 20px;
}
.secondStep {
  background: #fff;
  .noBt {
    padding: 0 15px;
    overflow: hidden;
    .bookTime {
      display: flex;
      align-items: center;
      padding: 10px 0;
      .dot {
        img {
          width: 8px;
          height: 8px;
        }
        margin: auto 15px auto 0;
      }
      span {
        font-size: 16px;
        color: #666666;
        line-height: 16px;
      }
    }
    .ticket {
      width: 100%;
      height: 78px;
      background-image: url(../../../assets/images/trade/vaildSTicket2x.png);
      background-size: 100% 78px;
      background-repeat: no-repeat;
      padding: 20px 10px;
      box-sizing: border-box;
      .declare {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        color: #666;
        height: 12px;
        line-height: 12px;
      }
      .detail {
        display: flex;
        justify-content: space-between;
        font-size: 16px;
        color: #000;
        height: 16px;
        line-height: 16px;
        margin-top: 10px;
      }
    }
    .moreTicket {
      height: 50px;
      display: flex;
      justify-content: flex-end;
      line-height: 50px;
      font-size: 12px;
      color: #666;
      img {
        width: 8px;
        height: 12px;
        margin: auto 5px;
      }
    }
    .carType {
      position: relative;
      padding: 0 10px 15px 10px;
      display: flex;
      justify-content: space-between;
      font-size: 12px; // background: #fff;
      color: #666;
      &::after {
        .borderScale;
        bottom: 50%;
        border-bottom: 1px solid #DFDFDF;
        width: 100%;
      }
      .car {
        text-align: center;
        .type {
          height: 40px;
          line-height: 40px;
        }
        .fare {
          height: 30px;
          display: flex;
          align-items: baseline;
          line-height: 47px;
          p {
            font-size: 16px;
            padding: 0 5px;
          }
        }
      }
      .active {
        color: #000;
        .type {
          font-size: 14px;
        }
        .fare {
          line-height: 35px;
          border-top: 3px solid #3DA5FE;
          p {
            font-size: 24px;
            color: #F59B0B;
            padding: 0 5px;
          }
        }
      }
    }
  }
}

.borderScale {
  content: "";
  position: absolute;
  left: 0px;
  right: 0px;
  transform: scaleY(.5);
  transform-origin: 0 0;
}
</style>
