<!--
  describe：支付&评价页面
  created by：ouql
  date：2017-11-26
-->
<template>
  <div class="card has-header">
    <div class="shadow">
      <!-- 支付页面 -->
      <div class="ending">
        <div class="content">
          <car-fare></car-fare>
          <car-ticket class="border-bottom" :status="state"></car-ticket>
          <driver></driver>
          <div class="score">
            <p>评价</p>
            <rater v-model="score"
              :margin="13.2"
              :active-color="'#FCB23C'"></rater>
          </div>
          <textarea class="evaluation" v-model="commentContent" placeholder="请输入您宝贵的评价！"></textarea>
          <div class="tip">您的评价会让司机做得更好</div>
        </div>
        <button-box @paid="confirmOrder()"></button-box>
      </div>
    </div>
  </div>
</template>

<script>

import { Rater } from 'vux';
import { mapState } from 'vuex';
import carFare from './carFare';
import carTicket from './carTicket';
import driver from './driverBox';
import evaluation from './evaluationBox';
import buttonBox from './buttonBox';

export default {
  components: {
    Rater,
    carFare,
    carTicket,
    driver,
    evaluation,
    buttonBox,
  },
  data() {
    return {
      loading: false,
      score: 0,
      commentContent: ''
    }
  },
  computed: {
    show() {
      return this.state === 'endTrip' || this.state === 'paying' || this.state === 'paid' || this.state === 'payFail' || this.state === 'evaluating' || this.state === 'evaluated' || this.state === 'notEvaluate';
    },
    ...mapState({
      car: state => state.travel.car,
      state: state => state.travel.car.state,
    }),
  },
  methods: {
    /**
     * 确认支付 operation=24
     */
    confirmOrder() {
      if (this.loading) return;
      this.loading = true;
      // this.isEnough();
      // if (this.selectVoucher.voucherBalance >= this.totalPrice.total_price && this.state !== 'payFail') {
        let params = {
          orderId: this.car.order_id,
          level: this.score, // 五星好评中的几星
          comment: this.commentContent,
          voucherList: []
        };

        if (this.car.selectVoucher.voucherId !== this.car.order_selectedVoucher.voucherId) params.voucherList = [this.car.selectVoucher];

        return this.$store.dispatch('ensurePay', params).then(response => {
          if (response && response.errcode === '00000') {
            this.showToast({ msg: '支付成功' });
            this.$emit('paid');
          } else if (response && response.errmsg) {
            this.showToast({ msg: response.errmsg });
          }

          this.loading = false;
        });
    },
  },
};
</script>
<style lang="less" scoped>
@import '../../../assets/css/base.less';
.card {
  width: 100%;
  height: 100%;
  background-color: #000;
  background: rgba(0, 0, 0, 0.5);
  position: absolute;
  bottom: 0;
  left: 0;
  z-index: 667;
  .shadow {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    overflow: hidden;
    .ending {
      background: #FFFFFF;
      .content {
        padding: 0 20px;
      }
    }
    .feeIllu {
      margin: 15px;
    }
  }

  .score{
    width: 100%;
    padding: 17px 0 10px;
    text-align: center;
    p{
      font-size: 14px;
      margin-bottom: 6px;
    }
  }
  .evaluation{
    width:100%;
    height: 77px;
    font-size: 12px;
    line-height: 17px;
    padding: 10px 10px;
    border: 0.5px solid #DFDFDF;
    box-sizing: border-box;
    outline:none;
    resize:none;
  }
  textarea::-webkit-input-placeholder { /* WebKit*/
    color: #DEDEDE;
  }
  .tip{
    padding: 10px 0 10px;
    font-size: 12px;
    color: #858585;
    text-align: center;
    margin-bottom: 10px;
  }
}
</style>
