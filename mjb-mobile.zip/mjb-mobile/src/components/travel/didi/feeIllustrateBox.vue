<!--
  describe: card-扣费说明
  created by: panjm
  date: 2017-11-27
-->
<template>
  <div class="containerBox">
    <div class="feeIllustrateBox">
      <div class="transfer-wrap border-bottom">
        <div class="transfer">
          <div class="sign">
            <div class="greySlot dot"></div>
          </div>
          <span>{{ order.order_time }}</span>
        </div>
        <div class="transfer">
          <div class="sign">
            <div class="greenSlot dot"></div>
          </div>
          <span>{{ order.start_name }}</span>
        </div>
        <div class="transfer">
          <div class="sign">
            <div class="orangeSlot dot"></div>
          </div>
          <span>{{ order.end_name }}</span>
        </div>
      </div>
      <div class="fee border-bottom">
        <div v-if="order.cancelCost">
          <div class="cancelFee">取消费用</div>
          <div class="price">
            <span>总</span>
            <span>{{ (order.cancelCost * 1).toFixed(2) }}</span>
            <span>元</span>
          </div>
        </div>
        <div v-if="!order.cancelCost">
          <img class="tipSign" src="../../../assets/images/trade/tip.png"></img>
          <div class="tip">司机接单后3分钟内免费取消</div>
        </div>
        <div class="rule">
          <span>取消规则</span>
          <i class="iconfont icon-fanhui-copy icon-right-arrow"></i>
        </div>
      </div>
      <div class="customerService">联系客服</div>
    </div>

  </div>
</template>
<script>
import { mapState } from 'vuex';

export default {
  props: {
  },
  data() {
    return {
    };
  },
  methods: {
  },
  computed: {
    // orderTime() {
    //   let time = this.order.order_time;

    // },
    ...mapState({
      car: state => state.travel.car,
      state: state => state.travel.car.state,
      order: state => state.travel.car.order, // (含cancelCost: 0, // 取消扣费（司机接单超过3分钟后取消的扣费）)
    }),
  },
};
</script>
<style lang="less" scoped>
.containerBox {
  .feeIllustrateBox {
    box-shadow: 0 2px 4px 0 #9B9B9B;
    border-radius: 2px;
    .transfer-wrap {
      margin: 0px 12px;
      padding: 15px 12px;
      .transfer {
        display: flex;
        align-items: center;
        box-sizing: border-box;
        font-size: 16px; // color: #666666;
        padding: 5px 0;
        span {
          line-height: 22px;
        }
        .sign {
          display: flex;
          align-items: center;
          justify-content: center;
          margin-right: 15px;
          .dot {
            border-radius: 50%;
            width: 8px;
            height: 8px;
            display: inline-block;
            align-self: center;
          }
          .greySlot {
            background-color: #9E9E9E;
          }
          .greenSlot {
            background-color: #6CC60A;
          }
          .orangeSlot {
            background-color: #FCB23C;
          }
        }
      }
    }
  }
  .fee {
    padding: 20px 0px;
    text-align: center;
    .cancelFee {
      font-size: 12px;
      color: #858585;
      margin-bottom: 8px;
    }
    .price {
      margin-bottom: 12px;
      span:nth-of-type(2) {
        font-size: 30px;
        line-height: 42px;
        color: #FCB23C;
        margin: 0 5px;
      }
    }
    .tipSign {
      width: 48px;
      height: 48px;
    }
    .tip {
      font-size: 14px;
      line-height: 22px;
      color: #000000;
    }
    .rule {
      color: #666666;
      font-size: 12px;
      line-height: 12px;
      margin-top: 10px;
      .icon-right-arrow {
        font-size: 11px;
      }
    }
  }
  .customerService {
    padding: 14px 0;
    color: #666666;
    text-align: center;
  }
}
</style>
