<!--
  describe: card-评价
  created by: panjm
  date: 2017-11-29
-->
<template>
  <div class="containerBox">
    <div class="evaluationBox" v-if="show">
      <div class="score">
        <p>评价</p>
        <rater v-model="score"
          :margin="13.2"
          :active-color="showValid ? '#FCB23C' : '#999'" v-if="showValid"></rater>
      </div>
      <textarea class="evaluation" v-model="evaluation" placeholder="请输入您宝贵的评价！"></textarea>
      <div class="tip">您的评价会让司机做得更好</div>
    </div>
  </div>
</template>
<script>
import { Rater } from 'vux';
import { mapState } from 'vuex';

export default {
  props: {
  },
  components: {
    Rater,
  },
  data() {
    return {
      score: 0,
      evaluation: '',
    };
  },
  watch: {
    score(val) {
      this.$store.commit('CAR', Object.assign({}, this.car, { level: val }));
    },
    evaluation(val) {
      this.$store.commit('CAR', Object.assign({}, this.car, { commentOrComplaint: val }));
    },
  },
  methods: {},
  computed: {
    show() {
      return this.state === 'endTrip' || this.state === 'paying' || this.state === 'paid' || this.state === 'payFail';
    },
    showValid() {
      return this.state === 'endTrip' || this.state === 'paying' || this.state === 'paid';
    },
    ...mapState({
      car: state => state.travel.car,
      state: state => state.travel.car.state,
      level: state => state.travel.car.level,
      commentOrComplaint: state => state.travel.car.commentOrComplaint,
    }),
  },
};
</script>
<style lang="less" scoped>
.containerBox {
  .score{
    width: 100%;
    padding: 17px 0 10px;
    text-align: center;
    p{
      font-size: 14px;
      margin-bottom: 6px;
    }
  }
  .evaluation{
    width:100%;
    height: 77px;
    font-size: 12px;
    line-height: 17px;
    padding: 10px 10px;
    border: 0.5px solid #DFDFDF;
    box-sizing: border-box;
    outline:none;
    resize:none;
  }
  textarea::-webkit-input-placeholder { /* WebKit*/
    color: #DEDEDE;
  }
  .tip{
    padding: 10px 0 10px;
    font-size: 12px;
    color: #858585;
    text-align: center;
    margin-bottom: 10px;
  }
}
</style>
