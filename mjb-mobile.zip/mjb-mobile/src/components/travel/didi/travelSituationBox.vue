<!--
  describe: card-行程概况
  created by: panjm
  date: 2017-11-27
-->
<template>
  <div class="containerBox">
    <transition
      name="custom-classes-transition"
      enter-active-class="animated fadeInUp"
    >
    <div class="travelSituationBox" v-show="detailOrder.id">
      <div class="fee columns is-mobile is-gapless border-bottom">
        <div class="price column">
          <span>总费用</span>
          <span>{{ (detailOrder.price.total_price * 1).toFixed(2) }}</span>
          <span>元</span>
        </div>
        <!-- <div class="rule">
          <span>计费规则</span>
          <i class="iconfont icon-fanhui-copy icon-right-arrow"></i>
        </div> -->
      </div>
      <div class="situation border-bottom">
        <div class="firstLine">
          <div class="car">
            <span v-if="detailOrder.rule==='301'">快车</span>
            <span v-if="detailOrder.rule==='201'">专车</span>
            <!-- <span v-if="detailOrder.reason === '加班'">加班用车</span>
            <span v-else-if="detailOrder.reason === '出差'">出差用车</span>
            <span v-else>{{ detailOrder.reason }}</span> -->
          </div>
          <div class="time">
            <span>{{ timeFormat(detailOrder.order_time) }}</span>
          </div>
        </div>
        <div class="situationItem" v-if="showPassenger">
          <span>乘客：</span>
          <span>{{ detailOrder.passenger_phone }}</span>
        </div>
        <div class="situationItem">
          <span>起点：</span>
          <span>{{ detailOrder.start_name }}</span>
        </div>
        <div class="situationItem">
          <span>终点：</span>
          <span>{{ detailOrder.end_name }}</span>
        </div>
        <div class="situationItem">
          <span>距离：</span>
          <span>{{ detailOrder.normal_distance }}公里</span>
        </div>
        <div class="situationItem">
          <span>耗时：</span>
          <span>{{ detailOrder.normal_time || 0 }}分钟</span>
        </div>
      </div>
      <div class="driverInfo border-bottom" v-if="detailOrder.driver_name">
        <div class="leftItem">
          <img :src="driver">
          <div class="info">
            <div>{{ detailOrder.driver_name }}</div>
            <div>{{ detailOrder.driver_card }}</div>
          </div>
        </div>
        <div class="rightItem">
          <a href="tel:400-000-0999" class="grayFont">
            <div class="complaint">
              <span>投诉司机</span>
              <i class="iconfont icon-fanhui-copy icon-right-arrow"></i>
            </div>
          </a>
        </div>
      </div>
      <div class=" assess border-bottom" v-if="detailOrder.status !== 610">
        <span>您的评价</span>
        <rater v-model="detailOrder.commentOrComplaint.commentType || 0" active-color="#FCB23C" :disabled="true"></rater>
      </div>

    </div>
  </transition>
  </div>
</template>
<script>
import { Rater } from 'vux';
import carFare from './carFare';
import driver from '../../../assets/images/trade/driver.png';

export default {
  components: {
    Rater,
    carFare,
  },
  data() {
    return {
      detailOrder: {
        price: {},
        commentOrComplaint: {}
      },
      driver,
      rate: 0,
    };
  },
  props: {
    orderId: {
      type: String,
      require: true
    }
  },
  methods: {
    // 格式化时间
    timeFormat(time) {
      if (time) {
        const myTime = time.split(' ');  // myTime 格式为 (2) ["2017-11-29", "11:07"]
        const myTimeA = myTime[0].split('-');  // 年月日
        const myTimeB = myTime[1].split(':');   // 时分
        const myYear = parseInt(myTimeA[0], 0);
        const myMonth = parseInt(myTimeA[1], 0);
        const mydate = parseInt(myTimeA[2], 0);
        const myHours = parseInt(myTimeB[0], 0);
        const myMinutes = parseInt(myTimeB[1], 0);
        return `${myYear}年${myMonth}月${mydate}日   ${myHours}:${myMinutes}`;
      }
      return '';
    },
  },
  computed: {
    user() {
      return this.$store.state.travel.car.user;
    },
    showPassenger() {
      if (this.user.phone === this.detailOrder.passenger_phone) {
        return false;
      }
      return true;
    }
  },
  created() {
    this.$store.dispatch('getOrderDetail', {
      order_id: this.orderId
    }).then((response) => {
      this.detailOrder = response.data;
      if (response.data.commentOrComplaint) {
        delete response.data.commentOrComplaint.orderId;
        delete response.data.commentOrComplaint.type;
        delete response.data.commentOrComplaint.id;
        response.data.order.commentOrComplaint = response.data.commentOrComplaint;
        response.data.order.commentOrComplaint.commentType = response.data.commentOrComplaint.commentType * 1;
      }else {
        response.data.order.commentOrComplaint = { commentType: 0 };
      }

      response.data.order.price = response.data.price;
      this.detailOrder = response.data.order;
    })
  }
};
</script>
<style lang="less" scoped>
@import '../../../assets/css/base.less';
.containerBox {
  position: fixed;
  bottom: 0px;
  left: 0px;
  right: 0px;
  z-index: 111;
  width: 100%;
  padding: 15px;
  box-sizing: border-box;
  .travelSituationBox {
    box-shadow: 0 2px 4px 0 #9B9B9B;
    border-radius: 2px;
    background: #FFFFFF;
    padding: 0 15px;
    animation-duration: .65s;
    .fee {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      padding: 14px 0 10px;
      margin: 0;
      .price {
        text-align: center;
        font-size: 12px;
        line-height: 17px;
        color: #000000;
        span:nth-of-type(2) {
          font-size: 30px;
          line-height: 42px;
          color: #FCB23C;
          padding: 0 4px;
        }
      }
      .rule {
        text-align: right;
        color: #666666;
        font-size: 12px;
        margin-left: 40px;
      }
    }
    .situation {
      padding: 13px 0;
      .firstLine {
        display: flex;
        justify-content: space-between;
        padding: 5px 0px;
        margin-bottom: 2px;
        .car {
          span:nth-of-type(1) {
            font-size: 16px;
            line-height: 22px;
            margin-right: 11px;
          }
          span:nth-of-type(2) {
            display: inline-block;
            height: 19px;
            background-color: #3DA5FE;
            color: #ffffff;
            border-radius: 12px;
            padding: 0 8px;
            font-size: 11px;
            line-height: 19px;
          }
        }
        .time {
          color: #858585;
          span:nth-of-type(1) {
            margin-right: 5px;
          }
        }
      }
      .situationItem {
        font-size: 14px;
        line-height: 20px;
        padding: 5px 0px;
        span:nth-of-type(1) {
          color: #858585;
          // margin-right: 20px;
        }
      }
    }
    .assess {
      padding: 15px 0;
      display: flex;
      justify-content: space-between;;
      span:nth-of-type(1) {
        font-size: 14px;
        line-height: 26px;
      }
    }
    .driverInfo {
      padding: 15px 0;
      display: flex;
      justify-content: space-between;
      .leftItem {
        display: flex;
        img {
          width: 40px;
          height: 40px;
          margin-right: 11px;
        }
        .info {
          div:nth-of-type(1) {
            font-size: 16px;
            line-height: 19px;
            color: #000000;
            margin-bottom: 2px;
          }
          div:nth-of-type(2) {
            font-size: 12px;
            line-height: 17px;
            padding: 1px 5px;
            background-color: #ECECEC;
            border-radius: 2px;
            box-sizing: border-box;
          }
        }
      }
      .rightItem {
        display: flex;
        align-items: center;
        .complaint {
          color: #666666;
          font-size: 12px;
        }
      }
    }
    .icon-right-arrow {
      font-size: 12px;
    }
  }
}
</style>
