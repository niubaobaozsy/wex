<!--
  describe：carTab（现在/预约）
  created by：ouql
  date：2017-11-26
-->
<template>
  <div class="my-tabs" v-if="!hide">
    <!-- 有定位 -->
    <div class="tab" v-if="!showIllustrate && state !== 'detail'">
      <img class="location-icon" src="../../../assets/images/trade/local3x.png" alt="" @click="locate()">
      <!-- 选项卡 -->
      <div v-if="showOrderType">
        <div class="tabs-bar">
          <div class="tabs-bar-nav">
            <div class="tabs-tab" :class="{'tabs-active': nowCalling}" @click="changeTab(true)">
              现在
            </div>
            <div class="tabs-tab" :class="{'tabs-active': !nowCalling}" @click="changeTab(false)">
              预约
            </div>
          </div>
        </div>
        <div class="tabs-content">
          <!-- 现在 -->
          <div class="content-item" :class="[showLeftTab ? 'now' : 'book']">
            <position-box :showTime="!showLeftTab" @get-price="getEvaluatePrice"  :currentLocationInfo="$attrs.currentLocationInfo"></position-box>
            <step-two
              v-if="showConfirm2orderCar"
              :showTime="!showLeftTab"></step-two>
          </div>
        </div>
      </div>
      <!-- 非选项卡 卡片式 -->
      <div class="card" v-if="cancelBt||driver">
        <button-box v-if="cancelBt" @end-call="cancelOrder"></button-box>
        <driver v-if="driver" @end-order="cancelOrder"></driver>
      </div>
    </div>
    <!-- 无定位 -->
    <div class="card" v-if="showIllustrate">
      <fee-illustrate></fee-illustrate>
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import driver from './driverBox.vue';
import feeIllustrate from './feeIllustrateBox.vue';
import buttonBox from './buttonBox.vue';
import evaluationBox from './evaluationBox.vue';
import carFare from './carFare';
import positionBox from './positionBox';
import stepTwo from './stepTwo';

export default {
  inheritAttrs: false,
  components: {
    driver,
    feeIllustrate,
    stepTwo,
    buttonBox,
    evaluationBox,
    carFare,
    positionBox,
  },
  data() {
    return {
      showLeftTab: true,
    };
  },
  methods: {
    // 到达目的地 变成支付状态，didi.vue的messageCard组件显示
    arrived() {

    },
    // 上车，行程中
    onTheWay() {
      this.state = 'onTheWay';
    },
    // 司机到达，等待上车
    takeCar() {
      this.state = 'takeCar';
    },
    // 取消叫车 / 取消订单
    cancelOrder() {
      const self = this;
      let titleStr = '是否取消叫车？';
      if (this.state === 'takeOrder') {
        titleStr = '是否取消用车？';
      }
      this.$vux.confirm.show({
        title: titleStr,
        onConfirm() {
          const str = 'cancelling';
          self.$store.commit('CAR', Object.assign({}, self.car, { state: str }));
        },
      });
    },
    // 现在/预约
    changeTab(bool) {
      this.$store.commit('CAR', Object.assign({}, this.car, { departure_time: '' }));
      if (this.state === 'canCall' || this.state === 'nonCall') {
        if (bool) {
          this.showLeftTab = true;
          this.$store.commit('CAR', Object.assign({}, this.car, { nowCalling: true }));
        } else {
          this.showLeftTab = false;
          this.$store.commit('CAR', Object.assign({}, this.car, { nowCalling: false }));
        }
      } else if (this.state === 'toCall' && !this.enableCall) {
        this.showLeftTab = bool;
        this.$store.commit('CAR', Object.assign({}, this.car, { nowCalling: bool }));
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'canCall' }));
      } else if (this.state === 'toCall' && this.enableCall) {
        this.showLeftTab = bool;
        this.$store.commit('CAR', Object.assign({}, this.car, { nowCalling: bool }));
        this.$store.commit('CAR', Object.assign({}, this.car, { state: 'nonCall' }));
      }
    },
    // 定位,触发父组件
    locate() {
      this.$emit('centerLocation')
    },
    // 获取预估价格
    getEvaluatePrice() {
      this.$emit('get-price');
    },
  },
  mounted() {
    console.log(this)
  },
  computed: {
    showConfirm2orderCar() {
      return this.$store.state.travel.car.state === 'toCall' || this.$store.state.travel.car.state === 'calling';
    },
    hide() {
      return this.state === 'endTrip' || this.state === 'paid' || this.state === 'payFail' || this.state === 'evaluating' || this.state === 'evaluated' || this.state === 'notEvaluate' || this.state === 'orderEnd' || this.state === '';
    },
    showIllustrate() {
      return this.state === 'cancelled';
    },
    cancelBt() {
      return this.state === 'waitOrder';
    },
    driver() {
      return this.state === 'takeOrder' || this.state === 'takeCar' || this.state === 'onTheWay';
    },
    nowCalling() {
      return this.$store.state.travel.car.nowCalling;
    },
    showOrderType() {
      return this.state === 'canCall' || this.state === 'nonCall' || this.state === 'toCall';
    },
    ...mapState({
      car: state => state.travel.car,
      state: state => state.travel.car.state,
      enableCall: state => state.travel.car.enableCall,
    }),
  },
};
</script>
<style lang="less" scoped>
@import '../../../assets/css/base.less';
.my-tabs {
  position: absolute;
  bottom: 0;
  left: 0;
  z-index: 111;
  width: 100%;
  padding: 15px;
  box-sizing: border-box;
  .location-icon {
    width: 30px;
  }
  .tabs-bar {
    width: 114px;
    height: 36px;
    background: #fff;
    line-height: 36px;
    box-shadow: 0 2px 4px 0 #9B9B9B;
    border-radius: 100px 100px 100px 0;
    font-size: 14px;
    .tabs-bar-nav {
      display: flex;
      justify-content: center;
      height: 36px;
      line-height: 36px;
      .tabs-tab {
        background: #fff;
        border-radius: 40px;
        border: 1px solid #fff;
        box-sizing: border-box;
        height: 30px;
        width: 54px;
        margin: auto 0;
        text-align: center;
        line-height: 30px;
        color: #C3C3C3;
      }
      .tabs-active {
        border: 1px solid #E8E8E8;
        color: #000;
      }
    }
  }
  .tabs-content {
    background: #fff;
    margin-top: 10px;
    box-shadow: 0 2px 4px 0 #9B9B9B;
    border-radius: 2px;
    .now {
      .secondStep {
        background: #fff;
        .ticket {
          width: 100%;
          height: 78px;
          background-image: url(../../../assets/images/trade/vaildSTicket2x.png);
          background-size: 100% 78px;
          background-repeat: no-repeat;
          padding: 20px 10px;
          box-sizing: border-box;
          .declare {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #666;
            height: 12px;
            line-height: 12px;
          }
          .detail {
            display: flex;
            justify-content: space-between;
            font-size: 16px;
            color: #000;
            height: 16px;
            line-height: 16px;
            margin-top: 10px;
          }
        }
        .moreTicket {
          height: 50px;
          display: flex;
          justify-content: flex-end;
          line-height: 50px;
          font-size: 12px;
          color: #666;
          img {
            width: 8px;
            height: 12px;
            margin: auto 5px;
          }
        }
        .carType {
          position: relative;
          padding: 20px 10px;
          display: flex;
          justify-content: space-between;
          font-size: 12px; // background: #fff;
          color: #666;
          &::after {
            .borderScale;
            bottom: 50%;
            border-bottom: 1px solid #DFDFDF;
            width: 100%;
          }
          .car {
            text-align: center;
            .type {
              height: 40px;
              line-height: 40px;
            }
            .fare {
              height: 40px;
              display: flex;
              align-items: baseline;
              line-height: 47px;
              p {
                font-size: 16px;
              }
            }
          }
          .active {
            color: #000;
            .type {
              font-size: 14px;
            }
            .fare {
              line-height: 35px;
              border-top: 3px solid #3DA5FE;
              p {
                font-size: 24px;
                color: #F59B0B;
              }
            }
          }
        }
      }
    }
    .book {
      .secondStep {
        background: #fff;
        .bookTime {
          height: 50px;
          display: flex;
          line-height: 50px;
          color: #666;
          .dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #9E9E9E;
            margin: auto 15px auto 0;
          }
        }
        .sum {
          display: flex;
          justify-content: center;
          align-items: baseline;
          color: #000;
          padding: 20px 16px;
          height: 76px;
          box-sizing: border-box;
          line-height: 36px;
          p {
            font-size: 36px;
            color: #F59B0B;
          }
        }
        .ticket {
          width: 100%;
          height: 78px;
          background-image: url(../../../assets/images/trade/vaildSTicket2x.png);
          background-size: 100% 78px;
          background-repeat: no-repeat;
          padding: 20px 10px;
          box-sizing: border-box;
          .declare {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #666;
            height: 12px;
            line-height: 12px;
          }
          .detail {
            display: flex;
            justify-content: space-between;
            font-size: 16px;
            color: #000;
            height: 16px;
            line-height: 16px;
            margin-top: 10px;
          }
        }
        .moreTicket {
          height: 50px;
          display: flex;
          justify-content: flex-end;
          line-height: 50px;
          font-size: 12px;
          color: #666;
          img {
            width: 8px;
            height: 12px;
            margin: auto 5px auto 5px;
          }
        }
      }
    }
  }
}

.card {
  background: #fff; // padding: 0 15px;
}

.borderScale {
  content: "";
  position: absolute;
  left: 0px;
  right: 0px;
  transform: scaleY(.5);
  transform-origin: 0 0;
}
</style>
