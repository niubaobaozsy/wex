<template>
	<div class="baseLocationInfo">
		<my-header :titleText="'常驻办公地'">
      <img src="~@/assets/images/common/nav_back.png" width="20" slot="left" @click="close()">
    </my-header>
    <p class="baseCity">您的常驻办公地：{{ userDatas.cityname }}</p>
    <p class="alertFont tips">说明：常驻办公地一经设置，不可自行修改，非常驻办公地用车需要申请EA 方可使用；若您的办公地发生变化，由系统管理员为您重置！</p>
	</div>
</template>

<script>
// 有查询常驻办公地的 api，但查不出数据 @xujian10。暂时使用car.user 的数据

import MyHeader from 'common/newHeader';

export default {
  components: {
    MyHeader
  },
  data() {
    return {
      baseLocation: {}
    };
  },
  created() {
    // this.getBaseLocation();
  },
  computed: {
    userDatas() {
      return this.$store.state.travel.car.user;
    }
  },
  methods: {
    close() {
      this.$emit('close');
    },
    getBaseLocation() {
      this.$store.dispatch('getBaseCity', {
        account: this.$store.state.userInfo.user.userId
      });
    }
  }
};
</script>

<style lang="less">
.baseLocationInfo {
  background-color: #fff;
  font-size: 16px;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 222;
  animation-duration: 0.5s;

  .baseCity {
    line-height: 1;
    padding: 1em;
    border-bottom: 1px solid #ddd;
  }

  .tips {
    font-size: 0.8em;
    padding: 10/8em;
  }
}
</style>
