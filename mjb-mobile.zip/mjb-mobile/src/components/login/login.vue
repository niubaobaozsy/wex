<!--
  文件描述：登录过渡页
  切图人员：庄裕浩
  逻辑联调：庄裕浩
  创建日期：2017年7月6日
-->
<template>
  <div class="login-wrap">
    <!-- 账号密码登录 -->
    <div class='login' v-if='showLogin'>
      <!-- <i class="iconfont icon-meijiebaologo" v-debug="true"></i> -->
      <div class="app-name">
        <div class="main-name">{{ baseConfig.appName }}</div>
        <div class="sub-name" v-if="baseConfig.subName">{{ baseConfig.subName }}</div>
      </div>
      <input v-model='userName' placeholder='请输入账号'>
      <input type='password' v-model='userPasswd' placeholder='请输入密码'>
      <button @click='localLogin'>登录</button>
      <div class="login-option">
        <check-icon :value.sync="rememberPW" type="plain">记住密码</check-icon>
        <check-icon :value.sync="autoLogin" type="plain">自动登录</check-icon>
      </div>
    </div>
    <div class="footer" v-if="hasAdvancedSetting">
      <router-link to="/advancedSetting" class="demo">高级设置 >>></router-link>
    </div>
    <alert v-model='showAlert' :title='alertTitle' :content='alertContent' @on-hide='onAlertHide'></alert>
  </div>
</template>
<script>
import Raven from 'raven-js';
import { getUrlQueryParam } from '@/js/util';
import { platform } from '@/platform';
import { mapState } from 'vuex';
import { Loading, Alert, CheckIcon } from 'vux';

export default {
  components: {
    Loading,
    Alert,
    CheckIcon,
  },
  data() {
    return {
      showAlert: false,
      alertTitle: '登录失败',
      alertContent: '',
      showLogin: false,
      userName: '',
      userPasswd: '',
      rememberPW: false,
      autoLogin: false,
    };
  },
  computed: {
    ...mapState({
      baseConfig: state => state.baseConfig,
      userInfo: state => state.userInfo,
    }),
    hasAdvancedSetting() {
      return this.baseConfig.envConfig[this.baseConfig.envConfig.currentEnv].hasAdvancedSetting || false;
      // return process.env.NODE_ENV === 'development';
    },
  },
  watch: {
    rememberPW(val) {
      if (!val) {
        this.autoLogin = false;
      }
    },
    autoLogin(val) {
      if (val) {
        this.rememberPW = true;
      }
    },
  },
  methods: {
    // 微信JS-SDK使用初始化
    WX_JS_SDK_INIT() {
      console.log('WX_JS_SDK_INIT in login');
      this.$store.dispatch('getWxSign', {
        corpid: this.baseConfig.appid,
        url: location.origin + location.pathname,
      }).then((res) => {
        if (res && res.code === '0000') {
          platform.wxconfig(this.baseConfig.appid, res.data.nonceStr, res.data.signature, res.data.timestamp);
        }
      });
    },
    buildRedirectUrl(redirectUrl) {
      const result = {};
      const urlComponents = redirectUrl.split('#')[1].split('?');
      result.path = urlComponents[0];
      if (urlComponents[1]) {
        const query = {};
        const queryArr = urlComponents[1].split('&');
        queryArr.forEach((v) => {
          query[v.split('=')[0]] = unescape(v.split('=')[1]);
        });
        result.query = query;
      }
      return result;
    },
    wechatLogin() {
      this.showLoading('登录中');
      const self = this;
      const code = getUrlQueryParam('code');
      this.$store.dispatch('getToken', { code }).then((rep) => {
        this.hideLoading();
        if (rep.code === '0000') {
          self.WX_JS_SDK_INIT();
          platform.wxready(() => {
            this.afterLogin();
          });
        } else {
          this.showAlert = true;
          this.alertContent = rep.msg;
        }
      });
    },
    browserLogin() {
      if (localStorage.loginOption) {
        const loginOption = JSON.parse(localStorage.loginOption);
        this.rememberPW = loginOption.rememberPW;
        this.autoLogin = loginOption.autoLogin;
        if (this.rememberPW) {
          this.userName = loginOption.userName;
          this.userPasswd = loginOption.userPasswd;
        }
        if (this.rememberPW && this.autoLogin) {
          this.localLogin();
        } else {
          this.showLogin = true;
        }
      } else {
        this.showLogin = true;
      }
    },
    localLogin() {
      if (!this.userName || !this.userPasswd) {
        this.showAlert = true;
        this.alertContent = '请填写账号及密码';
        return;
      }
      this.ravenCaptureMessage(`userName: ${this.userName}`);
      this.showLoading('登录中');
      const loginType = JSON.parse(localStorage.getItem('advancedSetting') || '{}').loginType || 'customLogin';
      // const loginType = this.baseConfig.platform === 'meixinBase' ? 'customLogin' : 'localLogin';
      this.$store.dispatch('localLogin', { loginType, username: this.userName, password: this.userPasswd, tenant_id: this.baseConfig.tenantId })
        .then((rep) => {
          this.hideLoading();
          if (rep.code === '0000') {
            if (this.baseConfig.multiLogin && this.baseConfig.multiLogin.length) {
              this.showLoading();
              this.$store.dispatch('smartBuyLocalLogin', { username: 'pengyy', password: this.userPasswd, tenant_id: this.baseConfig.smartBuyTenantId })
                .then((sbrep) => {
                  this.hideLoading();
                  if (sbrep.code === '0000') {
                    this.setLoginOption();
                    this.afterLogin();
                  } else {
                    this.showAlert = true;
                    this.alertContent = `商旅登陆异常[${sbrep.msg}]`;
                    this.showLogin = true;
                  }
                }, () => { this.showLogin = true; });
            } else {
              this.setLoginOption();
              this.afterLogin();
            }
          } else {
            this.showAlert = true;
            this.alertContent = `登陆异常[${rep.msg || rep.code}]`;
            this.showLogin = true;
          }
        }, () => { this.showLogin = true; });
    },
    meixinLogin() {
      const self = this;
      this.showLoading('登录中');
      platform.getUser().then((data) => {
        this.$store.commit('SSOTOKEN', data.ssoToken);
        this.$store.dispatch('switchToken', {
          alias: 'mas.token.getSsoToken',
          token: data.ssoToken,
        }).then((resp) => {
          if (resp && !resp.error) {
            this.$store.commit('MIP', resp.msg);
            platform.getDeviceInfo().then((deviceInfo) => {
              this.$store.commit('DEVICEINFO', deviceInfo);
              this.$store.dispatch('deviceLogin', {
                mipAccount: this.$store.state.mipId,
                deviceId: deviceInfo.deviceId,
                tenantId: this.baseConfig.tenantId,
              }).then((rep) => {
                this.hideLoading();
                if (rep.code === '0000') {
                  if (this.baseConfig.multiLogin && this.baseConfig.multiLogin.length) {
                    this.showLoading('登录中');
                    this.$store.dispatch('smartBuyDeviceLogin', {
                      mipAccount: this.$store.state.mipId,
                      deviceId: this.$store.state.deviceInfo.deviceId,
                      tenantId: this.baseConfig.smartBuyTenantId,
                    }).then((sbrep) => {
                      this.hideLoading();
                      if (sbrep.code === '0000') {
                        this.getExtra().then(() => {
                          this.afterLogin();
                        });
                      } else {
                        self.showAlert = true;
                        self.alertContent = `商旅登陆异常[${sbrep.msg}]`;
                      }
                    });
                  } else {
                    this.afterLogin();
                  }
                } else {
                  self.showAlert = true;
                  self.alertContent = `登陆异常[${rep.msg}]`;
                }
              });
            });
          } else {
            self.hideLoading();
            self.showAlert = true;
            self.alertContent = resp.msg;
          }
        }, () => {
          self.hideLoading();
          self.showAlert = true;
          self.alertContent = '获取token失败，请检查网络连接后重试';
        });
      }, () => {
        self.hideLoading();
        self.showAlert = true;
        self.alertContent = '获取用户信息失败，请稍后重试';
      });
    },
    meixinLoginTest() {
      const self = this;
      self.$store.commit('SSOTOKEN', 'T2510184496612352');
      self.$store.dispatch('switchToken', {
        alias: 'mas.token.getSsoToken',
        token: 'T2510184496612352',
      }).then((resp) => {
        if (resp) {
          self.$store.commit('MIP', resp.msg);
          this.$store.dispatch('deviceLogin', {
            mipAccount: this.$store.state.mipId,
            deviceId: 1,
            tenantId: this.baseConfig.tenantId,
          }).then((rep) => {
            if (rep.code === '0000') {
              this.afterLogin();
            } else {
              this.hideLoading();
              this.showAlert = true;
              this.alertContent = rep.msg;
            }
          });
        }
      });
    },
    onAlertHide() {
      if(!this.showLogin) {
        platform.exit();
      }
    },
    // getExtra() {
    //   return new Promise((resolve) => {
    //     platform.getExtra([this.baseConfig.identifier]).then((msg) => {
    //       if (msg && msg.extra) {
    //         this.$store.commit('EXTCALL', true);
    //         let info = msg.extra;
    //         if (msg.extra.showWidgetKey) {
    //           try {
    //             info = JSON.parse(msg.extra.showWidgetKey);
    //           } catch (error) {
    //             info = msg.extra.showWidgetKey;
    //           }
    //         }
    //         if (info.subModuleName) { // 调起应用子模块
    //           if (info.subModuleName === 'footprint') {
    //             this.$router.push({ path: '/activity/footprint' });
    //           }
    //         } else if (info.docUrl || (info.type && info.fdId)) { // 调起待办
    //           const docUrlHash = info.docUrl.split('#')[1];
    //           const type = docUrlHash && docUrlHash.split('/')[4] ? docUrlHash.split('/')[4] : '';
    //           const fdId = docUrlHash && docUrlHash.split('/')[5] ? docUrlHash.split('/')[5] : '';
    //           info.type = info.type || type;
    //           info.fdId = info.fdId || fdId;
    //           const query = {
    //             id: info.fdId,
    //             type: info.type,
    //           };
    //           if (info.type === 'EA') {
    //             this.$router.replace({ path: '/fee/approve/travelReim', query });
    //           } else if (info.type === 'EC') {
    //             this.$router.replace({ path: '/fee/approve/approvalReimburse', query });
    //           } else if (info.type === 'LM') {
    //             this.$router.replace({ path: '/fee/approve/approveLoan', query });
    //           } else if (info.type === 'BM') {
    //             this.$router.replace({ path: '/fee/approve/budgetChange', query });
    //           } else if (info.type === 'PA') {
    //             this.$router.replace({ path: '/fee/approve/feeReim', query });
    //           } else if (info.type === 'CA') {
    //             this.$router.replace({ path: '/fee/approve/adjustAccount', query });
    //           } else {
    //             this.alert({
    //               title: '提示',
    //               content: '单据类型错误',
    //               onHide() {
    //                 platform.exit();
    //               },
    //             });
    //           }
    //         }
    //       } else {
    //         resolve();
    //       }
    //     });
    //     platform.changeColor([72, 71, 89, 1]);
    //   });
    // },
    setLoginOption() {
      const loginOption = {
        rememberPW: this.rememberPW,
        autoLogin: this.autoLogin,
        userName: '',
        userPasswd: '',
      };
      if (this.rememberPW) {
        loginOption.userName = this.userName;
        loginOption.userPasswd = this.userPasswd;
      }
      localStorage.setItem('loginOption', JSON.stringify(loginOption));
    },
    afterLogin() {
      this.registerPushService(this.userInfo.employeeNumber)
      .then(() => {
        this.getPush();
      })
      .finally(() => {
        const redirectUrl = localStorage.getItem('redirectUrl');
        if (redirectUrl) {
          localStorage.removeItem('redirectUrl');
          this.$router.replace(this.buildRedirectUrl(redirectUrl));
        } else {
          this.$router.replace('/index');
        }
      });
    },
  },
  mounted() {
    if (this.$store.state.token) {
      this.$router.replace('/index');
    } else {
      const isInWeChat = this.baseConfig.platform === 'wechat';
      const isInMeiXin = this.baseConfig.platform === 'meixin';
      if (isInWeChat) {
        this.wechatLogin();
      } else if (isInMeiXin) {
        // this.meixinLoginTest();
        document.addEventListener('deviceready', () => {
          this.meixinLogin();
        }, false);
      } else {
        this.browserLogin();
      }
    }
    // this.testLogin();
  },
};
</script>

<style lang='less' scoped>
@import "~@/assets/css/theme.less";

* {
  font-size: 18px;
}

.login-wrap {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 100%;
}

.login {
  position: absolute;
  top: 44%;
  width: 100%;
  box-sizing: border-box;
  transform: translateY(-50%);
  padding: 0 10%;
  text-align: center;
  i {
    font-size: 50px;
    line-height: 150px;
    color: #3aa2eb;
  }
  .app-name {
    margin-bottom: 40px;
    .main-name {
      font-size: 40px;
      color: @color-main;
    }
    .sub-name {
      color: red;
    }
  }
  .login-option {
    display: flex;
    flex-wrap: nowrap;
    justify-content: space-between;
    padding-top: 15px;
  }
}

input {
  box-sizing: border-box;
  width: 100%;
  height: 50px;
  margin: 0 0 36px 0;
  padding: 0 10px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

button {
  width: 100%;
  height: 50px;
  background-color: @color-main;
  border: 0;
  color: #fff;
  border-radius: 4px;
}
.footer {
  position: absolute;
  bottom: 0;
  width: 100%;
  text-align: center;
  padding: 10px;
  box-sizing: border-box;
  .demo {
    font-size: 14px;
  }
}
</style>
