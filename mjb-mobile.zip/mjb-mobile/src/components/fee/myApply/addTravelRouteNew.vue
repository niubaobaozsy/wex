 <!--
  describe：差旅申请（第二步）——“添加行程”
  created by：Yim Lee
  date：2017-11-10
  modify by: zhuangyh
  date: 2017-11-22
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myApply/addTravelRoute.less';
</style>
 <template>
  <div>
    <div class="wrap">
      <div class="travel-route border" v-for="(item,index) in travelRoute" :key="index">
        <div class="travel-title border-bottom columns is-mobile is-gapless">
          <div class="show-travel" @click="showRouteInfo(index)"><img :src="item.isshow ? showTravelImg : hideTravelImg" :alt="item.isshow ? 'up' : 'down'"></div>
          <span class="column">行程{{ item.routeIndex }}</span>
          <button @click="deleteRoute(index)">删除</button>
        </div>
        <div class="travel-info" ref="travelInfo">
          <div class="columns is-mobile is-gapless travel-info-item border-bottom">
            <span class="text">地点</span>
            <input-box :placeholder="'出发地'" :textCenter="true" :isreadOnly="true" :pickValue="item.from_area_name" @select="openArea('start', index)"></input-box>
            <span class="line">—</span>
            <input-box :placeholder="'目的地'" :textCenter="true" :isreadOnly="true" :pickValue="item.to_area_names" @select="openArea('end', index)"></input-box>
          </div>
          <div class="columns is-mobile is-gapless travel-info-item border-bottom">
            <span class="text">日期</span>
            <div class="cal-img" @click="onCellBClick(index)"><img :src="calenderImg" alt="calenderImg"></div>
            <input-box :placeholder="'请选择'" :textCenter="false" :isreadOnly="true" :pickValue="(item.start_date && item.end_date) ? `${formatDate(item.start_date)} - ${formatDate(item.end_date)}` : ''" @select="onCellBClick(index)"></input-box>
            <!-- 右箭头 -->
            <img :src="r_arrow" alt="rightArrow" class="rt-arrow" @click="onCellBClick(index)">
          </div>
        </div>
      </div>
      <div class="add-travle-btn border" @click="addTravelRoute">
        <img :src="addTravelBtn" alt="addTravelBtn">
        <span>添加行程</span>
      </div>
    </div>
    <calendar :show.sync="showCalendarB" :disablePast="true" v-model="date" @pickDate="onPickDateB">
    </calendar>
    <select-city :show="showArea" :headTitle="headTitle" @on-hide="hideArea" @select-city="selecCity" v-if="showArea"></select-city>
  </div>
</template>

<script>
import { mapState } from 'vuex';
import showTravel from '../../../assets/images/fee/myApply/showTravel.png';
import hideTravel from '../../../assets/images/fee/myApply/hideTravel.png';
import add from '../../../assets/images/fee/myApply/addTravelBtn.png';
import InputBox from '../../common/input.vue';
import rArrow from '../../../assets/rt-arrow.png';
import calImg from '../../../assets/calendar.png';
import calendar from '../../common/myCalendar';
import selectCity from '../../common/selectCity';

export default {
  components: {
    InputBox,
    calendar,
    selectCity,
  },
  data() {
    return {
      travelRoute: [],
      r_arrow: rArrow,   // 右箭头图标的路径
      showTravelImg: showTravel,  // 向下箭头图标的路径
      hideTravelImg: hideTravel,  // 向上箭头图标的路径
      addTravelBtn: add,  // 添加的图标路径
      calenderImg: calImg, // 日历小图标的路径
      routeNum: 0,  // 记录添加的行程数
      showCalendarB: false,
      pickValueIndex: 0,
      headTitle: '',
      showArea: false,
      currentIndex: 0, // 当前点击的行程index
      areaType: '',  // 当前正在选择的地点类型（出发地点或目的地点）
      date: [],  // 选择到的日期数组
      isSave: false,
    };
  },
  computed: {
    // 差旅申请的所有参数
    emseaapplyh() {
      return this.$store.state.myApply.emseaapplyh;
    },
    ...mapState({
      applyCreate: state => state.myApply.applyCreate,
    }),
  },
  methods: {
    // 返回 或 上一步
    goBack() {
      const _this = this;
      if (!this.$store.state.myApply.isSave) {
        this.$vux.confirm.show({
          content: '尚未保存，返回将清空当前页面内容，确认返回？',
          // 点击“确定”时触发
          onConfirm() {
            _this.$route.meta.keepAlive = false;
            _this.$router.go(-1);
          },
        });
      } else {
        this.$route.meta.keepAlive = true;
        this.$router.go(-1);
      }
    },
    // 点击流程导航条进行相应的路由跳转
    goRouter(index) {
      if (index > this.currentStep) {
        // this.goNext();
      } else if (index < this.currentStep) {
        this.goBack();
      }
    },
    // 添加行程
    addTravelRoute() {
      const routeObj = {
        routeIndex: this.routeNum + 1,
        isshow: true,
        from_area_name: '',
        from_area_code: '',        // 出发地编码
        to_area_names: '',
        to_area_codes: '',         // 目的地编码
        start_date: '',
        end_date: '',
      };
      this.travelRoute.push(routeObj);
      this.routeNum++;
      this.isSave = false;
      this.$store.commit('IS_SAVE', this.isSave);
      console.log(this.travelRoute);
    },
    // 删除行程
    deleteRoute(index) {
      const _this = this;
      // 在弹窗出现时触发
      this.$vux.confirm.show({
        content: '删除该行程？',
        // 点击“确定”时触发
        onConfirm() {
          _this.travelRoute.splice(index, 1);
          _this.emseaapplyh.emseaapplytravels.splice(index, 1);
          _this.$store.commit('EMSEAAPPLYH', _this.emseaapplyh);
          console.log(_this.travelRoute.length);
          _this.travelRoute.forEach((item) => {
            if (item.routeIndex > (index + 1)) {
              item.routeIndex--;
              _this.$refs.travelInfo[index].hidden = _this.$refs.travelInfo[index + 1].hidden;
            }
          });
          _this.routeNum--;
          _this.isSave = false;
          _this.$store.commit('IS_SAVE', this.isSave);
        },
      });
    },
    // 点击打开选择城市页面
    openArea(type, index) {
      this.showArea = true;
      this.currentIndex = index;
      this.areaType = type;
      if (type === 'start') {
        this.headTitle = '选择出发地点';
      } else if (type === 'end') {
        this.headTitle = '选择目的地点';
      }
    },
    // 点击选择地点
    selecCity(item) {
      if (this.areaType === 'start') {
        if (item.area_name !== this.travelRoute[this.currentIndex].from_area_name) this.isSave = false;
        this.travelRoute[this.currentIndex].from_area_name = item.area_name;
        this.travelRoute[this.currentIndex].from_area_code = item.area_code;
      } else if (this.areaType === 'end') {
        if (item.area_name !== this.travelRoute[this.currentIndex].to_area_names) this.isSave = false;
        this.travelRoute[this.currentIndex].to_area_names = item.area_name;
        this.travelRoute[this.currentIndex].to_area_codes = item.area_code;
      }
      this.$store.commit('IS_SAVE', this.isSave);
      this.showArea = false;
    },
    // 点击隐藏搜索地点
    hideArea() {
      this.showArea = false;
    },
    // 点击选择时间
    onPickDateB() {
      if (this.travelRoute[this.pickValueIndex].start_date !== this.date[0] || this.travelRoute[this.pickValueIndex].end_date !== this.date[1]) this.isSave = false;
      this.travelRoute[this.pickValueIndex].start_date = this.date[0];
      this.travelRoute[this.pickValueIndex].end_date = this.date[1];
      this.$store.commit('IS_SAVE', this.isSave);
    },
    // 点击打开日历组件
    onCellBClick(index) {
      this.pickValueIndex = index;
      this.showCalendarB = true;
    },
    // 将日期格式化成年月日的形式
    formatDate(date) {
      const formatDate = new Date(date);
      // const year = formatDate.getFullYear();
      const month = formatDate.getMonth() + 1;
      const day = formatDate.getDate();
      return `${month}月${day}日`;
    },
    // 点击下拉或折叠行程信息
    showRouteInfo(index) {
      if (this.$refs.travelInfo[index].hidden) {
        this.$refs.travelInfo[index].hidden = false;
        this.travelRoute[index].isshow = true;
      } else {
        this.$refs.travelInfo[index].hidden = true;
        this.travelRoute[index].isshow = false;
      }
    },
    // 计算行程天数
    computeRentDay(startDay, endDay) {
      const start = new Date(Date.parse(startDay)).getTime();
      const end = new Date(Date.parse(endDay)).getTime();
      const rentDays = Math.abs((start - end)) / (24 * 60 * 60 * 1000);
      return rentDays;
    },
    // 更新数据
    updateData() {
      for (let i = 0; i < this.travelRoute.length; i++) {
        const route = {
          // 差旅行程明细主键id，新增时为空，更新时必填
          fee_travel_id: this.emseaapplyh.emseaapplytravels.fee_travel_id || '',
          // 申请单主键id，新增时为空，更新时必填
          fee_apply_id: this.emseaapplyh.emseaapplytravels.fee_apply_id || '',
          travel_persons: this.emseaapplyh.emseaapplytravels.travel_persons,     // 出差人员
          travel_persons_name: this.emseaapplyh.emseaapplytravels.travel_persons_name, // 出差人员名称
          to_area_names: this.travelRoute[i].to_area_names,    // 目的地
          start_date: this.travelRoute[i].start_date,          // 出差开始时间
          end_date: this.travelRoute[i].end_date,              // 出差结束时间
          // 出差天数,根据出差开始结束时间自动计算
          travel_days:
          this.computeRentDay(this.travelRoute[i].start_date, this.travelRoute[i].end_date) + 1,
          // 住宿天数，根据出差开始结束时间自动计算
          rent_days:
          this.computeRentDay(this.travelRoute[i].start_date, this.travelRoute[i].end_date),
          from_area_code: this.travelRoute[i].from_area_code,  // 出发地编码
          from_area_name: this.travelRoute[i].from_area_name,  // 出发地名称
          to_area_codes: this.travelRoute[i].to_area_codes,    // 目的地编码
        };
        this.emseaapplyh.emseaapplytravels[i] = route;
        this.emseaapplyh.fee_apply_id = '';
      }
      this.$store.commit('EMSEAAPPLYH', this.emseaapplyh);
    },
    // 保存草稿
    saveDraft() {
      // console.log(this.emseaapplyh);
      this.updateData();
      const params = {
        emseaapplyh: this.emseaapplyh,
      };
      this.showLoading();
      this.$store.dispatch('saveFeeApply', params)
        .then((rep) => {
          this.hideLoading();
          if (rep.data.code === '0000') {
            this.showToast({ msg: '保存成功', width: '18em', time: 800 });
            this.isSave = true;
            this.$store.commit('IS_SAVE', this.isSave);
            this.emseaapplyh.emseaapplytravels = rep.data.emseaapplyh.emseaapplytravels;
            this.$store.commit('EMSEAAPPLYH', this.emseaapplyh);
          } else {
            this.showToast({ msg: rep.data.msg });
            this.isSave = true;
            this.$store.commit('IS_SAVE', this.isSave);
          }
        }, () => {
          this.hideLoading();
          this.showToast({ msg: '页面开小差，请稍候重试' });
        });
    },
    // 下一步
    beforeNext() {
      let next = true;
      if (this.travelRoute.length === 0) {
        this.showToast({ msg: '请添加行程！' });
        return false;
      }
      for (let i = 0; i < this.travelRoute.length; i++) {
        if (this.travelRoute[i].from_area_name === '') {
          this.showToast({ msg: '出发地不能为空！' });
          next = false;
        }
        if (this.travelRoute[i].to_area_names === '') {
          this.showToast({ msg: '目的地不能为空！' });
          next = false;
        }
        if (this.travelRoute[i].end_date === '') {
          this.showToast({ msg: '行程时间不能为空！' });
          next = false;
        }
        const start = new Date(Date.parse(this.travelRoute[i].start_date)).getTime();
        const end = new Date(Date.parse(this.travelRoute[i].end_date)).getTime();
        if (end < start) {
          this.showToast({ msg: '结束时间不能早于开始时间！' });
          next = false;
        }
        return next;
      }
      this.updateData();
      this.$router.push({ path: 'expenseEstimateIndex' });
      console.log(this.emseaapplyh);
      return true;
    },
  },
  mounted() {
    console.log(this.emseaapplyh);
  },
};
</script>
