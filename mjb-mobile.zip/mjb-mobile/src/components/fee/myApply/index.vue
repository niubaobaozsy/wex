<!--
  describe：我的申请
  created by：欧倩伶
  date：2017-11-07
-->
<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>
