<!--
  describe："差旅申请-已审批"
  created by：panjm
  date：2017-11-9
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div infinite-scroll-immediate-check="true" v-infinite-scroll="loadMoreFun" infinite-scroll-disabled="busy" infinite-scroll-distance="10" infinite-scroll-throttle-delay="500">
    <down-pull-loading @loading="refresh" v-if="orderList.length">
      <swipeout slot='list'>
        <swipeout-item v-for="(data, index) in orderList" :key="index" ref="swip">
          <div slot="content" @click="goDetail(data.loan_info_id, data.order_type, data)">
            <!-- <div class="invoiceBox">
              <div class="invoiceLeft">
                <div :class="['invoiceType',{'blue':data.order_type_name=='差旅'},{'green':data.order_type_name=='其他'},{'pink':data.order_type_name=='借款'}]">
                  {{ data.order_type_name }}
                </div>
                <div class="invoiceSecondCol">
                  <p>{{ data.description}}</p>
                  <p>{{ data.apply_date }}</p>
                </div>
              </div>

              <div class="invoiceThirdCol">
                <p class="invoicePrice">￥{{ data.approve_amount.toFixed(2) }}</p>
                <span class="invoiceStatus" v-if="data.first_node_status=='未查检'">{{ data.first_node_status }}</span>
              </div>
            </div> -->
            <div class="invoiceBox">
              <div class="invoiceLeft">
                <div :class="['invoiceType', data.logo_color]">
                  {{ data.order_type_name }}
                </div>
              </div>
              <div class="invoiceRight">
                <div class="invoiceSecondCol">
                  <p>{{ data.reason_desc}}</p>
                  <p>{{ data.creation_date }}</p>
                  <!-- <p>单号：{{ data.loan_info_code }}</p> -->
                </div>
                <div class="invoiceThirdCol">
                   <p class="invoicePrice" v-if="myMenuCfgCurreny">￥{{ parseFloat(data.amount || 0).toFixed(2) }}</p>
                   <p class="invoicePrice" v-else>{{ data.currenySymbol }} {{ parseFloat(data.amount || 0).toFixed(2) }}</p>
                </div>
              </div>
            </div>
          </div>
        </swipeout-item>
      </swipeout>
    </down-pull-loading>

    <load-more v-if="loadMore" :tip="'加载中...'" style="width: 100%;padding: 22px 0px;box-sizing: border-box;margin:0 auto"></load-more>
    <div v-if="!orderList.length && isloading" class="emptyBox">
      <img class="no_data_img" :src="noDataImg" alt="">
      <p class="no_data_text">暂无数据</p>
    </div>

  </div>
</template>

<script>
import { Swipeout, SwipeoutItem, SwipeoutButton, XButton, Confirm, XSwitch, LoadMore, TransferDomDirective as TransferDom } from 'vux';
import downPullLoading from '../../common/downPullLoading';
import noDataImg from '../../../assets/images/common/no_data.png';
import curreny from '../../../../static/curreny.json';

export default {
  components: {
    Swipeout,
    SwipeoutItem,
    SwipeoutButton,
    XButton,
    Confirm,
    XSwitch,
    LoadMore,
    TransferDom,
    downPullLoading,
  },
  data() {
    return {
      curreny,
      noDataImg,
      isloading: false,
      loadMore: false,
      busy: false,
      hasNextPage: true,
      pageInfo: {
        page_number: 1,
        page_size: 10,
        order_status: 'AUDITED',
        module_types: 'EC',
      },
      orderList: [],
      firstPageFlag: true, // 标记当前页码是否为第一页
    };
  },
  methods: {
    getApplyList(isRefresh) {
      return new Promise((resolve) => {
        this.$store.dispatch('pageApplyList', this.pageInfo).then((res) => {
          this.hideLoading();
          resolve();
          if (res && res.code === '0000') {
            this.isloading = true;
            if (res.data && res.data.info && res.data.info.length) {
              res.data.info.forEach((list) => {
                // if (list.source_system !== 'MOBILE') {
                //   list.apply_type = 'nonsupport';
                //   if (list.order_type === 'HW') {
                //     list.order_type_name = '会务';
                //     list.logo_color = 'grey';
                //   } else if (list.order_type === 'CL') {
                //     list.order_type_name = '差旅';
                //     list.logo_color = 'blue';
                //   } else if (list.order_type === 'TY') {
                //     list.order_type_name = '通用';
                //     list.logo_color = 'green';
                //   } else if (list.order_type === 'CAR') {
                //     list.order_type_name = '用车';
                //     list.logo_color = 'grey';
                //   } else if (list.module_type === 'LM') {
                //     list.order_type_name = '借款';
                //     if (list.order_type === 'PERSONPAY_PUBLIC') {
                //       list.logo_color = 'pink';
                //     } else {
                //       list.logo_color = 'grey';
                //     }
                //   }
                // } else if (list.order_type === 'HW') {
                if (list.order_type === 'HW') {
                  list.order_type_name = '会务';
                  list.logo_color = 'grey';
                  list.apply_type = 'nonsupport';
                } else if (list.order_type === 'CL') {
                  list.order_type_name = '差旅';
                  list.logo_color = 'blue';
                  list.apply_type = 'CL';
                } else if (list.order_type === 'TY') {
                  list.order_type_name = '通用';
                  list.logo_color = 'green';
                  list.apply_type = 'EA';
                } else if (list.order_type === 'CAR') {
                  list.order_type_name = '用车';
                  list.logo_color = 'grey';
                  list.apply_type = 'nonsupport';
                } else if (list.module_type === 'LM') {
                  list.order_type_name = '借款';
                  if (list.order_type === 'PERSONPAY_PUBLIC') {
                    list.logo_color = 'pink';
                    list.apply_type = 'LM';
                  } else {
                    list.logo_color = 'grey';
                    list.apply_type = 'nonsupport';
                  }
                } else if (list.order_type === 'EC_AIR') {
                  list.order_type_name = '机票';
                  list.reimburse_type = 'nonsupport';
                  list.logo_color = 'grey';
                }
                // 币种
                let currenyName = list.currency_name;
                list.currenySymbol = this.curreny[currenyName];
              });
              this.orderList = isRefresh ? res.data.info : this.orderList.concat(res.data.info);
              this.pageInfo.page_number += 1;
            } else if (res.data && !res.data.info) {
              this.hasNextPage = false;
              this.loadMore = false;
            }
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      });
    },
    goDetail(applyId, orderType, data) {
      if (data.apply_type === 'nonsupport') {
        if (data.module_type === 'LM') {
          setTimeout(() => {
            this.$router.push({
              path: '/fee/approve/approveLoan', query: { id: applyId, type: 'LM' },
            });
          }, 500);
        } else if (data.module_type === 'EA') {
          setTimeout(() => {
            this.$router.push({
              path: '/fee/approve/travelReim', query: { id: applyId, type: orderType },
            });
          }, 500);
        } else if (data.module_type === 'PA') {
          setTimeout(() => {
            this.$router.push({
              path: '/fee/approve/feeReim', query: { id: applyId, type: orderType },
            });
          }, 500);
        } else if (data.module_type === 'EC') {
          setTimeout(() => {
            this.$router.push({
              path: '/fee/approve/approvalReimburse', query: { id: applyId, type: orderType },
            });
          }, 500);
        } else if (data.module_type === 'CA') {
          setTimeout(() => {
            this.$router.push({
              path: '/fee/approve/adjustAccount', query: { id: applyId, type: orderType },
            });
          }, 500);
        } else if (data.module_type === 'BM') {
          setTimeout(() => {
            this.$router.push({
              path: '/fee/approve/budgetChange', query: { id: applyId, type: orderType },
            });
          }, 500);
        } else if (data.module_type === 'BA') {
          this.showToast({ msg: '移动端不支持查看该单据，请移步PC端操作' });
        }
      } else if (orderType === 'PERSONPAY_PUBLIC') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/myApply/loanDetail', query: { id: applyId },
          });
        }, 800);
      } else {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/details', query: { id: applyId },
          });
        }, 800);
      }
    },
    loadMoreFun() {
      if (this.hasNextPage) {
        setTimeout(() => {
          this.loadMore = true;
          this.getApplyList();
        }, 500);
      }
    },
    refresh() {
      this.isloading = false;
      this.pageInfo.page_number = 1;
      return new Promise((resolve) => {
        this.getApplyList(true).then(() => {
          setTimeout(() => {
            resolve();
          }, 1000);
        });
      });
    },
  },
  mounted() {
    this.showLoading();
    this.getApplyList();
  },
  computed: {
    myMenuCfgCurreny() {
      return this.$store.state.menuConfig.fee.curreny;
    },
  }
};
</script>

