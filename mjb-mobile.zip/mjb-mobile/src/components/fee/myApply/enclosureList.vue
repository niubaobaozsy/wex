<!--
  describe：审批附件列表页
  created by：黄喆
  date：2017-11-30
-->
<template>
  <div class="enclosure-container">
    <my-header :title='top.type' @previous="goBack"></my-header>
    <div class="content">
      <ul class="data-content border-top">
        <li class="data-list border-bottom" v-for="(item, index) in imgList" :key="index">
          <img class="type-img" :src="'data:'+ item.mime_type +';base64,' + item.content" alt="" @click="showImgFun(index)" @load="setImgSize(index)">
          <div class="list-content">
            <div class="name"> {{ item.source_filename }} </div>
            <div class="time"> {{formatDate(item.creation_date)}}
              <span class="size">{{ (item.file_size / 1024).toFixed(2) }}K</span>
            </div>
          </div>
        </li>
      </ul>
    </div>
    <Gallery :show="showBigImg" :index="showImgIndex" :list="imgList" :hasDel="hasDel" @on-hide="hideImgView"></Gallery>
  </div>
</template>

<script type="text/ecmascript-6">
import MyHeader from '../../common/header';
import address from '../../../assets/images/trade/didi/address.png';
import Gallery from '../../common/gallery';

export default {
  components: {
    MyHeader,
    Gallery,
  },
  data() {
    return {
      showImgIndex: 0,
      showBigImg: false, // 是否显示大图列表
      hasDel: false,
      imgList: [],
      address,
      top: {
        type: '附件',
      },
    };
  },
  mounted() {
    this.imgList = this.$route.query.imgList;
  },
  methods: {
    formatDate(time) {
      let result = '';
      if (time) {
        const num = new Date(time);
        result = `${num.getFullYear()}/${num.getMonth() + 1}/${num.getDate()}`;
      }
      return result;
    },
    setImgSize(index) {
      const el = event.srcElement;
      const showImg = this.imgList[index];
      if (showImg) {
        showImg.el = el;
        showImg.src = el.src;
        showImg.w = el.naturalWidth;
        showImg.h = el.naturalHeight;
      }
    },
    hideImgView() {
      this.showBigImg = false;
    },
    // 点击图片查看大图
    showImgFun(index) {
      this.showBigImg = true;
      this.showImgIndex = index;
    },

    goBack() {
      this.$router.go(-1);
    },
  },
};
</script>
<style lang="less" scoped>
@white: #ffffff;

.content {
  margin-top: 57px;
  .data-content {
    background: #ffffff;
    .data-list {
      display: flex;
      justify-content: flex-start;
      align-items: center;
      padding: 15px;
      .type-img {
        height: 40px;
        width: 40px;
      }
      .list-content {
        margin-left: 12px;
        .name {
          font-size: 16px;
          color: #000000;
        }
        .time {
          font-size: 12px;
          color: #9B9B9B;
          .size {
            margin-left: 20px;
          }
        }
      }
    }
  }
}
</style>
