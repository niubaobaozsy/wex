 <!--
  describe：差旅申请（第二步）——“添加行程”
  created by：Yim Lee
  date：2017-11-10
  modify by: zhuangyh
  date: 2017-11-22
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myApply/addTravelRoute.less';
</style>
 <template>
  <div class="addTravelRoute">
    <div class="wrap">
      <div class="travel-route border" v-for="(item,index) in travelRoute" :key="index">
        <div class="travel-title border-bottom columns is-mobile is-gapless">
          <div class="show-travel" @click="showRouteInfo(index)"><img :src="item.isshow ? showTravelImg : hideTravelImg" :alt="item.isshow ? 'up' : 'down'"></div>
          <span class="column">行程{{ index+1 }}</span>
          <button @click="deleteRoute(index)">删除</button>
        </div>
        <div class="travel-info" ref="travelInfo">
          <div class="columns is-mobile is-gapless travel-info-item border-bottom">
            <span class="text">地点</span>
            <input-box v-edit.feeStdExp.overStd.createAirBdt :data-edit="item.from_area_name || ''" :placeholder="'出发地'" :textCenter="true" :isreadOnly="true" :pickValue="item.from_area_name" @select="openArea('start', index)"></input-box>
            <span class="line">—</span>
            <input-box v-edit.feeStdExp.overStd.createAirBdt :data-edit="item.to_area_name || ''" :placeholder="'目的地'" :textCenter="true" :isreadOnly="true" :pickValue="item.to_area_name" @select="openArea('end', index)"></input-box>
          </div>

          <div class="columns is-mobile is-gapless travel-info-item border-bottom" v-if="!myApplyMenuCfg[applyType].traInfo">
            <span class="text">日期</span>
            <div class="cal-img" @click="showCalendar(index)"><img :src="calenderImg" alt="calenderImg"></div>
            <input-box v-edit.feeStdExp.overStd :data-edit="watchDateStr(item.start_date, item.end_date)" :placeholder="'请选择'" :textCenter="false" :isreadOnly="true" :pickValue="(item.start_date && item.end_date) ? `${formatDate(item.start_date)} - ${formatDate(item.end_date)}` : ''"  @select="showCalendar(index)"></input-box>
            <img :src="r_arrow" alt="rightArrow" class="rt-arrow" @click="showCalendar(index)">
          </div>

          <div class="columns is-mobile is-gapless travel-info-item border-bottom" v-if="applyType === 'CL' && myApplyMenuCfg[applyType].traInfo">
            <span class="text mr-20">出差类型</span>
            <input-box :placeholder="'请选择'" v-edit.feeStdExp.overStd :data-edit="item.attribute1" :value="menus[item.attribute1]" v-model="menus[item.attribute1]"  @select="openTravelType(index)"></input-box>
            <!-- 右箭头 -->
            <img :src="r_arrow" alt="rightArrow" class="rt-arrow" @click="openTravelType(index)">
          </div>

          <div class="columns is-mobile is-gapless travel-info-item border-bottom" v-if="applyType === 'CL' && myApplyMenuCfg[applyType].traInfo">
            <span class="text">起始时间</span>
            <div class="cal-img" @click="openDate('start' ,index)"><img :src="calenderImg" alt="calenderImg"></div>
            <input-box :placeholder="'请选择'" v-edit.feeStdExp.overStd :data-edit="item.start_date" :isreadOnly="true" :pickValue="item.start_date ? item.start_date : ''"  @select="openDate('start' ,index)"></input-box>
            <img :src="r_arrow" alt="rightArrow" class="rt-arrow" @click="openDate('start' ,index)">
          </div>

           <div class="columns is-mobile is-gapless travel-info-item border-bottom" v-if="applyType === 'CL' && myApplyMenuCfg[applyType].traInfo">
            <span class="text">结束时间</span>
            <div class="cal-img" @click="openDate('end' ,index)"><img :src="calenderImg" alt="calenderImg"></div>
            <input-box :placeholder="'请选择'" v-edit.feeStdExp.overStd :data-edit="item.end_date" :isreadOnly="true" :pickValue="item.end_date ? item.end_date : ''"  @select="openDate('end' ,index)"></input-box>
            <img :src="r_arrow" alt="rightArrow" class="rt-arrow" @click="openDate('end' ,index)">
          </div>

          <div class="columns is-mobile is-gapless travel-info-item border-bottom" v-if="applyType === 'CL' && myApplyMenuCfg[applyType].traInfo">
            <span class="text mr-20">加班时长</span>
            <input-box placeholder="必填，一小时为单位" v-model="item.attribute2" :value="item.attribute2" v-edit @on-blur="updateData"></input-box>
          </div>

          <!-- <div class="travel-person" v-if="applyType === 'CL' && myApplyMenuCfg[applyType].compnayPayAir" @click="getTravelPerson(item,index)" v-edit.feeStdExp.overStd.createAirBdt :data-edit="item.travel_persons_name">
            <div class="columns is-mobile is-gapless travel-info-item">
              <span class="text">出行人</span>
              <span class="column num" v-if="item.travel_persons_name && item.travel_persons_name.split(',').length == 1">{{item.travel_persons_name}}</span>
              <span class="column num" v-if="item.travel_persons_name && item.travel_persons_name.split(',').length > 1">{{`共${item.travel_persons_name.split(',').length}人`}}</span>
              <span class="column num" v-if="!item.travel_persons_name || item.travel_persons_name.split(',').length == 0">请选择</span>
              <img :src="r_arrow" alt="rightArrow" class="rt-arrow">
            </div>
            <div class="select-person  border-bottom" v-if="item.travel_persons_name && item.travel_persons_name.split(',').length > 1">{{item.travel_persons_name}}</div>
          </div> -->

        </div>
      </div>
      <div class="add-travle-btn border" @click="addTravelRoute">
        <img :src="addTravelBtn" alt="addTravelBtn">
        <span>添加行程</span>
      </div>
    </div>
    <actionsheet v-model="showAction" :menus="menus" :show-cancel="showCancel" @on-click-menu="selectTravelType"></actionsheet>
    <org v-model="orgnization" :show.sync="showOrg" :multi="multiUser" @confirm="onOrgconfirm" />
    <calendar :show.sync="showCalendarB" :disablePast="disablePast" :start-date="startDate" v-model="date" @pickDate="onPickDate">
    </calendar>
    <datetime v-show="showDateStart" format="YYYY-MM-DD HH:mm" @on-show="openDate" @on-hide="closeDate" @on-confirm="closeDate" @on-change="selectDate" :show="showDateStart"></datetime>
    <datetime v-show="showDateEnd" format="YYYY-MM-DD HH:mm" @on-show="openDate" @on-hide="closeDate" @on-confirm="closeDate" @on-change="selectDate" :show="showDateEnd"></datetime>
    <select-city v-if="showCity" :headTitle="headTitle" :tempType="'travel'" @select-city="selectCity" @close-panel="showCity = false"></select-city>
  </div>
</template>

<script>
import { mapState } from 'vuex';
import { Actionsheet, Datetime } from 'vux';
import showTravel from '../../../assets/images/fee/myApply/showTravel.png';
import hideTravel from '../../../assets/images/fee/myApply/hideTravel.png';
import add from '../../../assets/images/fee/myApply/addTravelBtn.png';
import InputBox from '../../common/input.vue';
import rArrow from '../../../assets/rt-arrow.png';
import calImg from '../../../assets/images/fee/myApply/calendar.png';
import calendar from '../../common/myCalendar';
import selectCity from '../../common/selectCity';
import org from '../../common/org';

export default {
  components: {
    InputBox,
    calendar,
    selectCity,
    org,
    Actionsheet,
    Datetime,
  },
  data() {
    return {
      travelRoute: [],
      r_arrow: rArrow,   // 右箭头图标的路径
      showTravelImg: showTravel,  // 向下箭头图标的路径
      hideTravelImg: hideTravel,  // 向上箭头图标的路径
      addTravelBtn: add,  // 添加的图标路径
      calenderImg: calImg, // 日历小图标的路径
      showCalendarB: false,
      pickValueIndex: 0,
      headTitle: '',
      showCity: false,
      currentIndex: 0, // 当前点击的行程index
      areaType: '',  // 当前正在选择的地点类型（出发地点或目的地点）
      date: [],  // 选择到的日期数组
      startDate: '',
      persons: {
        travel_persons: '',
        travel_persons_name: '',
      },
      disablePast: true,
      orgnization: [],
      showOrg: false,
      multiUser: false,
      selectTravelItem: {},
      selectTravelIndex: 0,
      showAction: false,
      showCancel: true, // 是否显示取消按钮
      // menus: {
      //   0: '三地内出差',
      //   1: '三地外出差',
      // },
      menus: {},
      showDate: false,
      showDateStart: false,
      showDateEnd: false,
      dateType: '',
      minYear: '',
      emseaapplyls: [],
    };
  },
  computed: {
    totalFee() {
      return this.$store.getters.totalFee;
    },
    totalCommonBudget() {
      return this.$store.getters.totalCommonBudget;
    },
    airTicketBudget() {
      return this.$store.getters.airTicketBudget;
    },
    // 差旅申请的所有参数
    emseaapplyh() {
      return this.$store.state.myApply.emseaapplyh;
    },
    ...mapState({
      applyCreate: state => state.myApply.applyCreate,
    }),
    myApplyMenuCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.children;
    },
    applyType() {
      return this.$store.state.myApply.applyCreate.applyType;
    },
    isCreateAirBudget() {
      return this.$store.state.myApply.applyCreate.isCreateAirBudget;
    },
    travelers() {
      const travelPersons = this.selectTravelItem.travel_persons ? this.selectTravelItem.travel_persons.split(',') : [];
      const travelPersonsName = this.selectTravelItem.travel_persons_name ? this.selectTravelItem.travel_persons_name.split(',') : [];
      const users = [];
      travelPersons.forEach((person, index) => {
        const user = {
          user_full_name: travelPersonsName[index],
          user_id: person,
        };
        users.push(user);
      });
      return users;
    },
  },
  methods: {
    //    获取出差人
    getTravelPerson(item, index) {
      this.selectTravelItem = item;
      this.selectTravelIndex = index; // 点击修改第N行的出行人
      this.orgnization = this.travelers; // 修改前获第N行的出行人
      this.showOrg = true;
      this.multiUser = true;
    },

    onOrgconfirm(users) {
      if (this.multiUser) {
        if (users.length > 1) {
          this.showToast({ msg: '多人出差，如行程不一致，请移步PC端，谢谢' });
        }
        const obj = {
          travel_persons: '',
          travel_persons_name: '',
        };
        users.forEach((user) => {
          obj.travel_persons += `${user.user_id},`;
          obj.travel_persons_name += `${user.user_full_name},`;
        });
        obj.travel_persons = obj.travel_persons.substr(0, obj.travel_persons.length - 1);
        obj.travel_persons_name = obj.travel_persons_name.substr(0, obj.travel_persons_name.length - 1);
        this.travelRoute[this.selectTravelIndex] = Object.assign({}, this.travelRoute[this.selectTravelIndex], obj);
        this.updateData();
      }
      this.orgnization = [];
    },

    // 添加行程
    addTravelRoute() {
      const routeNum = this.travelRoute.length;
      const routeObj = {
        attribute1: '',
        attribute2: '',
        isshow: true,
        from_area_name: routeNum ? this.travelRoute[routeNum - 1].to_area_name : '',
        from_area_code: routeNum ? this.travelRoute[routeNum - 1].to_area_code : '', // 出发地编码
        to_area_name: '',
        to_area_code: '',         // 目的地编码
        start_date: '',
        end_date: '',
      };
      this.travelRoute.push(routeObj);
      this.updateData();
    },
    // 删除行程
    deleteRoute(index) {
      const _this = this;
      // 在弹窗出现时触发
      this.$vux.confirm.show({
        content: '删除该行程？',
        // 点击“确定”时触发
        onConfirm() {
          _this.travelRoute.splice(index, 1);
          _this.updateData();
        },
      });
    },
    // 点击打开选择城市页面
    openArea(type, index) {
      this.showCity = true;
      this.currentIndex = index;
      this.areaType = type;
      if (type === 'start') {
        this.headTitle = '选择出发地点';
      } else if (type === 'end') {
        this.headTitle = '选择目的地点';
      }
    },
    closePanel4cities() {
      this.showCity = false;
    },
    // 点击选择地点
    selectCity(item) {
      if (this.areaType === 'start') {
        this.travelRoute[this.currentIndex].from_area_name = item.area_name;
        this.travelRoute[this.currentIndex].from_area_code = item.area_code;
        this.travelRoute[this.currentIndex].from_area_id = item.area_id;
        this.travelRoute[this.currentIndex].from_area = item;
      } else if (this.areaType === 'end') {
        this.travelRoute[this.currentIndex].to_area_name = item.area_name;
        this.travelRoute[this.currentIndex].to_area_code = item.area_code;
        this.travelRoute[this.currentIndex].to_area_id = item.area_id;
        this.travelRoute[this.currentIndex].to_area = item;
      }
      this.updateData();
    },
    // 点击选择时间
    onPickDate() {
      this.travelRoute[this.pickValueIndex].start_date = this.date[0];
      this.travelRoute[this.pickValueIndex].end_date = this.date[1];
      this.date = [];
      this.updateData();
    },
    // 点击打开日历组件
    showCalendar(index) {
      if (index > 0) {
        this.disablePast = false;
        this.startDate = this.travelRoute[index - 1].end_date;
      } else {
        this.disablePast = false;
        this.startDate = '';
      }
      const arr = [
        this.travelRoute[index].start_date ? this.travelRoute[index].start_date.split(' ')[0] : '',
        this.travelRoute[index].end_date ? this.travelRoute[index].end_date.split(' ')[0] : '',
      ];
      this.date = arr;
      this.pickValueIndex = index;
      this.showCalendarB = true;
    },
    // 将日期格式化成年月日的形式
    formatDate(date) {
      const formatDate = new Date(date.split(' ')[0]);
      // const year = formatDate.getFullYear();
      const month = formatDate.getMonth() + 1;
      const day = formatDate.getDate();
      return `${month}月${day}日`;
    },
    // 点击下拉或折叠行程信息
    showRouteInfo(index) {
      if (this.$refs.travelInfo[index].hidden) {
        this.$refs.travelInfo[index].hidden = false;
        this.travelRoute[index].isshow = true;
      } else {
        this.$refs.travelInfo[index].hidden = true;
        this.travelRoute[index].isshow = false;
      }
    },
    // 计算行程天数
    computeRentDay(startDay, endDay) {
      const start = new Date(Date.parse(startDay)).getTime();
      const end = new Date(Date.parse(endDay)).getTime();
      const rentDays = Math.abs((start - end)) / (24 * 60 * 60 * 1000);
      return rentDays;
    },
    // 更新数据
    updateData() {
      const emseaapplytravels = [];
      // const emseatransportdetailsInit = [{ // 交通费用
      //   label: false, // 非接口所有
      //   transport: 'AIRPLANE',
      //   transport_fee: '',
      //   currency_code: 'CNY',
      //   currency_name: '人民币',
      //   conversion_rate: '1',
      // }];
      let emptyFlag = false;
      if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir && this.isCreateAirBudget) {
        //  存在对公飞机票配置,要重新计算
        this.emptyAirEmseaapplyls(); // 清空预算来源里的对公飞机订票预算行
        emptyFlag = true;
      }
      this.travelRoute.forEach((tr) => {
        let startDate =  '';
        let endDate = '';
        if (this.myApplyMenuCfg[this.applyType].travelInfo && tr.start_date && tr.end_date) {
          startDate =  tr.start_date.split(' ')[0];
          endDate = tr.end_date.split(' ')[0];
        }
        const route = {
          attribute1: tr.attribute1,
          attribute2: tr.attribute2,
          attribute_name: tr.attribute_name,
          from_area: tr.from_area,
          from_area_id: tr.from_area_id,
          from_area_name: tr.from_area_name,  // 出发地名称
          from_area_code: tr.from_area_code,  // 出发地编码
          to_area: tr.to_area,
          to_area_id: tr.to_area_id,
          to_area_name: tr.to_area_name,    // 目的地
          to_area_code: tr.to_area_code,    // 目的地编码
          tenant_id: this.emseaapplyh.tenant_id,
          // 差旅行程明细主键id，新增时为空，更新时必填
          fee_travel_id: tr.fee_travel_id || null,
          // 申请单主键id，新增时为空，更新时必填
          fee_apply_id: this.emseaapplyh.fee_apply_id || null,
          travel_persons: this.persons.travel_persons,     // 出差人员
          travel_persons_name: this.persons.travel_persons_name, // 出差人员名称
          start_date: tr.start_date,          // 出差开始时间
          end_date: tr.end_date,              // 出差结束时间
          // 出差天数,根据出差开始结束时间自动计算
          travel_days: this.computeRentDay(startDate, endDate) + 1,
          // 住宿天数，根据出差开始结束时间自动计算
          rent_days: this.computeRentDay(tr.startDate, endDate),
          created_by: '',
          created_name: '',
          creation_date: '',
          last_updated_by: '',
          last_updated_name: '',
          last_update_date: '',
          // isclose: true,
          // emseatransportdetails: tr.emseatransportdetails ? tr.emseatransportdetails : emseatransportdetailsInit,
          emseatransportdetails: tr.emseatransportdetails ? tr.emseatransportdetails : [],
        };

        if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir && this.isCreateAirBudget) {
          //  存在对公飞机票配置,需要重新计算
          route.travel_persons = tr.travel_persons;
          route.travel_persons_name = tr.travel_persons_name;
          this.getAirTicketBudget(route); // 重新计算对公飞机订票预算行
        }
        emseaapplytravels.push(route);
      });
      if (emseaapplytravels.length || emptyFlag) {
        this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, { emseaapplytravels }));
      }

      if (this.isCreateAirBudget) {
        // 重新计算了对公飞机票预算行
        this.$store.commit('APPLY_CREATE', { isCreateAirBudget: false });
      }

    },
    // 重新计算对公飞机订票预算行
    getAirTicketBudget(item) {
      let peopleNameList = item.travel_persons_name ? item.travel_persons_name.split(',') : [];
      let peopleIdList = item.travel_persons ? item.travel_persons.split(',') : [];  // 每个行程的出行人
      item.emseatransportdetails.forEach((tripDetailItem, subIndex) => {
        // 每行的交通
        if (tripDetailItem.transport === 'AIRPLANE') {
          // 每行交通平均到出行人
          let airBudgetRow = tripDetailItem;
          let perFee = (airBudgetRow.transport_fee / peopleIdList.length);
          let perFeeStr = perFee.toString();
          if ((perFeeStr.indexOf('.') > -1 && perFeeStr.split('.')[1].length <= 2) || (perFeeStr.indexOf('.') < 0)) {
            airBudgetRow.perfee = perFee;  // 平均分配的
            airBudgetRow.perlastfee = perFee;
          } else {
            // 获取前面2位小数，最后一个人=总费用-前面人费用
            airBudgetRow.perfee = parseFloat(`${perFeeStr.split('.')[0]}.${perFeeStr.split('.')[1].substring(0, 2)}`);
            // 分多的
            airBudgetRow.perlastfee = airBudgetRow.transport_fee - ((peopleIdList.length - 1) * airBudgetRow.perfee);
          }
          // 对公飞机订票预算行
          peopleIdList.forEach((pel, pelIndex) => {
            let airBudgetItem = {
              attribute1: 'COMPANY', // 预算类型为 飞机票对公司预算  为空表示不为公司预算
              attribute2: pel,		// 出行人姓名Id
              attribute3: peopleNameList[pelIndex],		// 出行人姓名
              attribute4: item.start_date,	// 出行日期
              attribute5: this.emseaapplyh.reason_desc,   	// 业务描述
              attribute6: item.from_area_id || item.from_area.area_id,			// 从哪里来 id
              attribute7: item.from_area_name || item.from_area.area_name,    // name
              attribute8: item.from_area_code || item.from_area.area_code,   // code
              attribute9: item.to_area_id || item.to_area.area_id,		// 去哪里
              attribute10: item.to_area_name || item.to_area.area_name,  // name
              attribute11: item.to_area_code || item.to_area.area_code,    // code
              attribute12: item.end_date, // 回程日期
              attribute13: airBudgetRow.transport, //
              // index: this.emseaapplyh.emseaapplyls.length - 1,
              busi_org_name: '', // ????????
              fee_type_name: '', // ????????
              busi_org_id: '', // ????????
              from_area: item.from_area,
              to_area: item.to_area,
              fee_type: '', // ????????
              budget_name: '',
              project_id: '', // 前端保存值 项目id
              project_name: '', // 前端保存值 项目名称
              source_system: '', // 前端保存值 项目来源系统
              erp_bank_type: '', // 前端保存值 项目erp类型
              erp_bank_type_name: '', // 前端保存值 项目erp类型名称

              fee_apply_l_id: null, // 批文申请单明细ID
              fee_apply_id: null, // ????????
              tenant_id: '', // 租户ID
              eco_type_id: '', // 活动事项ID
              fee_type_id: '', // 预算科目ID
              bill_type_id: '', // 经济事项ID
              apply_amount: peopleIdList.length > 1 && pelIndex > 0 ? airBudgetRow.perfee : airBudgetRow.perlastfee,
              currency: this.emseaapplyh.currency,
              currency_code: this.emseaapplyh.currency_code, // 币种编码(与头币种一致)
              currency_name: this.emseaapplyh.currency_name, // 币种名称(与头币种一致)
              conversion_rate: 1,// 预算行币种兑头币种汇率 // ????????
              approve_conversion_rate: 1, // 预算行币种兑头币种汇率 // ????????
              fee_advance_date: '', // 预计发生日期
              reason_desc: this.emseaapplyh.reason_desc, // 事由/工作任务
              project_code: '', // 项目号
              product_line_id: '', // 产品线ID
              budget_node_id: airBudgetRow.budget_node_id, // 预算单元 // ????????
              budget_node_desc: airBudgetRow.budget_node_desc, // 预算单元描述 // ????????
              budget_headers_id: airBudgetRow.budget_headers_id,  // 预算树ID // ????????
              used_amount: '', // 已用金额
              is_release: '', // 是否释放
              // release_amount: , // 释放金额
              release_by: '', // 释放人
              release_name: '', // 释放人姓名
              release_date: '', // 释放时间
              release_reason: '', // 释放原因
              created_by: '', // 创建人
              created_name: '', // 创建人姓名
              creation_date: '', // 创建日期
              last_updated_by: '', // 修改人
              last_updated_name: '', // 修改人姓名
              last_update_date: '', // 修改日期
              business_code: '', // 项目号对应的事业部code
              business_name: '', // 项目号对应的事业部
              budget_code: '', // 预算项目号
              budget_main_id: airBudgetRow.budget_main_id, // 预算主体id // ????????
              budget_main_name: airBudgetRow.budget_main_name, // 预算主体名称 // ????????
              acc_code: '', // 会计科目编码
              acc_name: '', // 会计科目名称
              lock_biz_type: '', // 锁定业务类型（消费增加）
              lock_return_code: '', // 锁定标识（消费明细主键-订单号）（消费增加）
              lock_status: '',  // 创建锁定状态：0，否-默认值  1，已创建锁定明细（消费增加）
            };
            this.emseaapplyh.emseaapplyls.push(airBudgetItem);
          })
        }
      })
    },
    // 清空预算来源里的对公飞机订票预算行
    emptyAirEmseaapplyls() {
      this.emseaapplyls = this.emseaapplyh.emseaapplyls || [];
      const emseaapplyls = [];
      this.emseaapplyls.forEach(item => {
        if (!item.attribute1 || (item.attribute1 && item.attribute1 !== 'COMPANY')) {
          emseaapplyls.push(item);
        }
      });
      // 不含对公飞机票的预算来源的自动计算带出第一行总额
      if (emseaapplyls.length < 2 && parseFloat(this.totalFee - this.airTicketBudget)) {
        emseaapplyls[0] = Object.assign({}, emseaapplyls[0] || {}, { apply_amount: parseFloat(this.totalFee - this.airTicketBudget) });
      }
      this.emseaapplyh.emseaapplyls = emseaapplyls;
    },
    // 下一步
    beforeNext() {
      let next = true;
      if (!this.travelRoute.length) {
        this.showToast({ msg: '请添加行程！' });
        return false;
      }
      for (let i = 0; i < this.travelRoute.length; i++) {
        if (!this.travelRoute[i].from_area_name) {
          this.showToast({ msg: '出发地不能为空！' });
          next = false;
          break;
        }
        if (!this.travelRoute[i].to_area_name) {
          this.showToast({ msg: '目的地不能为空！' });
          next = false;
          break;
        }
        if (!this.travelRoute[i].end_date) {
          this.showToast({ msg: '行程时间不能为空！' });
          next = false;
          break;
        }
        // if (!this.travelRoute[i].travel_persons && this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir) {
        //   this.showToast({ msg: '行程出行人不能为空！' });
        //   next = false;
        //   break;
        // }
        const start = new Date(Date.parse(this.travelRoute[i].start_date)).getTime();
        const end = new Date(Date.parse(this.travelRoute[i].end_date)).getTime();
        if (end < start) {
          this.showToast({ msg: '结束时间不能早于开始时间！' });
          next = false;
          break;
        }
      }
      this.updateData();
      return next;
    },
    // 上一步
    beforePrevious() {
      this.updateData();
      return true;
    },
    watchDateStr(date1, date2) {
      return `${date1}-${date2}`;
    },
    openTravelType(index) {
      this.showAction = true;
      this.currentIndex = index || this.currentIndex;
    },
    // 点击弹出差旅单类型选择组件
    selectTravelType(key) {
      let travelType = key || 0;
      this.travelRoute[this.currentIndex].attribute1 = travelType;
      this.updateData();
    },
    openDate(type ,index) {
      if (type === 'start') {
        this.showDateStart = true;
      } else if (type === 'end') {
        this.showDateEnd = true;
      }
      // this.showDate = true;
      this.dateType = type || this.dateType;
      this.currentIndex = index || this.currentIndex;
      // let travelDate = '';
      // if (type === 'start') {
      //   if(this.travelRoute[this.currentIndex].start_date) {
      //     travelDate = this.travelRoute[this.currentIndex].start_date.substr(0, 15);
      //   }
      // } else {
      //   if(this.travelRoute[this.currentIndex].end_date) {
      //     travelDate = this.travelRoute[this.currentIndex].start_end.substr(0, 15);
      //   }
      // }
      // this.travelDate = travelDate;
    },
    closeDate() {
      this.showDate = false;
    },
    selectDate (key) {
      key = `${key}:00`;
      if(this.dateType === 'start') {
        this.travelRoute[this.currentIndex].start_date = key;
      } else {
        this.travelRoute[this.currentIndex].end_date = key;
      }
      this.showDateStart = false;
      this.showDateEnd = false;
      this.closeDate();
      this.updateData();
    },
    getTravelType() {
      let params = 'C_EA_AWAY_TYPE';
      this.$store.dispatch('getItemsByCode', params).then((rep) => {
        if (rep.code === '0000') {
          rep.data.forEach((data) => {
            this.menus[data.itemValue] = data.itemName;
          })
        }
      })
    },
    getTime() {
      let date = new Date();
      this.minYear = date.getFullYear() - 1;
    }
  },
  mounted() { },
  activated() {
    this.persons = JSON.parse(JSON.stringify(this.emseaapplyh.emseaapplytravels[0]));
    this.travelRoute = this.emseaapplyh.emseaapplytravels;
    this.travelRoute.forEach((item) => {
      item.isshow = true;
    });
    if (this.myApplyMenuCfg[this.applyType].traInfo) {
      this.getTime();
      this.getTravelType();
    }
    // this.$store.commit('GET_STANDARD_REQ_PARAM', { travels: JSON.parse(JSON.stringify(this.emseaapplyh.emseaapplytravels)) });
  },
};
</script>
