<!--
 describe：差旅申请（第4步）——“审批流程”
 created by：黄喆
 invoice_date：2017-11-18
 modify by: zhuangyh
 modify date: 2017-12-10
-->
<template>
  <div class="requisition-submit">
    <div class="wrap">
      <ul class="information">
        <li v-for="(node, index) in nodeList" :key="index" class="information-list border-bottom" @click="getApprover(index)">
          <div class="list-between">
            <span :class="['options', {'optionsColor': node.fdNodeHandlerNames}]">{{index + 1}}</span>
            <span class="title">{{node.fdNodeName}}</span>
          </div>
          <div class="list-between" :class="{'noNow': node.fdNodeHandlerNames.indexOf(',') !== -1}">
            <span :class="['choice', {'randomly': node.fdNodeHandlerNames}]">{{node.fdNodeHandlerNames || "请选择"}}</span>
            <img :src="r_arrow" alt="" class="r-arrow" :class="{'show': !node.canHandle}">
          </div>
        </li>
      </ul>
    </div>
    <org v-model="orgnization" :show.sync="showOrg" :multi="true" @confirm="onOrgConfirm"/>
  </div>
</template>
<script type="text/ecmascript-6">
  import rArrow from '../../../assets/rt-arrow.png';
  import org from '../../common/org';

  export default {
    components: {
      org,
    },
    data() {
      return {
        r_arrow: rArrow,
        orgnization: [],
        showOrg: false,
        nodeList: [],
        clickIndex: -1,
      };
    },
    computed: {
      emseaapplyh() {
        return this.$store.state.myApply.emseaapplyh;
      },
      applyCreate() {
        return this.$store.state.myApply.applyCreate;
      },
      userInfo() {
        return this.$store.state.userInfo.user;
      },
    },
    methods: {
      getFlowTable() {
        const params = {
//          this.emseaapplyh.formInstanceId
          formInstanceId: this.emseaapplyh.formInstanceId,
//          this.emseaapplyh.form_template_id
          template_form_id: this.emseaapplyh.form_template_id,
          model_id: '001',
        };
        this.showLoading();
        this.$store.dispatch('getFlowTable', params).then((res) => {
          this.hideLoading();
          if (res.code === '0000') {
            if (res.data && res.data.length > 0) {
              const nodes = res.data;
              nodes.forEach((node) => {
                node.canHandle = false;
              });
              this.nodeList = nodes;
              console.log(nodes, 654321);
              this.getCanHandleList();
            }
          } else {
            this.showToast({ msg: res.msg });
          }
        });
      },
      getCanHandleList() {
        const params = {
          formInstanceId: this.emseaapplyh.formInstanceId,
          template_form_id: this.emseaapplyh.form_template_id,
          model_id: '001',
          tenentId: this.userInfo.tenantId,
          handler: this.userInfo.userId,
        };
        this.showLoading();
        this.$store.dispatch('getCanHandleList', params).then((res) => {
          this.hideLoading();
          if (res.code === '0000') {
            if (res.data && res.data.length && res.data[0].operations && res.data[0].operations.length && res.data[0].operations[0].params && res.data[0].operations[0].params.canModifyHandlerNodeList && res.data[0].operations[0].params.canModifyHandlerNodeList.length) {
              const canHandleNodes = res.data[0].operations[0].params.canModifyHandlerNodeList;
              this.nodeList.forEach((node) => {
                canHandleNodes.forEach((canHandleNode) => {
                  if (node.fdNodeId === canHandleNode.id) node.canHandle = true;
                });
              });
            }
            if (res.data && res.data.length && res.data[0].operations && res.data[0].operations.length && res.data[0].operations[0].params && res.data[0].operations[0].params.mustModifyHandlerNodeList && res.data[0].operations[0].params.mustModifyHandlerNodeList.length) {
              this.mustModifyHandlerNodeList = res.data[0].operations[0].params.mustModifyHandlerNodeList;
            } else {
              this.mustModifyHandlerNodeList = [];
            }
          } else {
            this.showToast({ msg: res.msg });
          }
        });
      },
      beforeSubmit() {
        const flowNode = {};
        let sunbmit = true;
        let name = '';
        const newNodeList = [];
        this.nodeList.forEach((node) => {
          flowNode[node.fdNodeId] = node.fdNodeHandlers;
          this.mustModifyHandlerNodeList.forEach((data) => {
            if (node.fdNodeId === data.id && newNodeList.indexOf(node) === -1) {
              newNodeList.push(node);
            }
          });
        });
        newNodeList.forEach((node) => {
          if (!node.fdNodeHandlers) {
            sunbmit = false;
            name = node.fdNodeName;
            console.log(name);
          }
        });
        name = `${name}未选择`;
        this.$store.commit('FLOWNODE', flowNode);
        if (!sunbmit) {
          this.showToast({ msg: name });
        }
        return sunbmit;
      },
      getApprover(index) {
        console.log(index, this.nodeList[index].current);
        if (this.nodeList[index].canHandle) {
          console.log(this.nodeList, 9999);
          this.orgnization = [];
          if (this.nodeList[index].fdNodeHandlerNames) {
            const users = [];
            const nameArr = this.nodeList[index].fdNodeHandlerNames.split(',');
            const idArr = this.nodeList[index].fdNodeHandlers.split(',');
            nameArr.forEach((name, nameIndex) => {
              idArr.forEach((id, idIndex) => {
                if (nameIndex === idIndex) {
                  const user = {
                    user_full_name: name,
                    user_id: id,
                  };
                  users.push(user);
                }
              });
            });
            this.orgnization = [].concat(users);
            console.log(this.orgnization);
          }
          this.showOrg = true;
          this.clickIndex = index;
        }
      },
      onOrgConfirm(users) {
        console.log(users[0]);
        const obj = {
          fdNodeHandlers: '',
          fdNodeHandlerNames: '',
        };
        users.forEach((user) => {
          obj.fdNodeHandlers += `${user.user_id},`;
          obj.fdNodeHandlerNames += `${user.user_full_name},`;
        });
        obj.fdNodeHandlers = obj.fdNodeHandlers.substr(0, obj.fdNodeHandlers.length - 1);
        obj.fdNodeHandlerNames = obj.fdNodeHandlerNames.substr(0, obj.fdNodeHandlerNames.length - 1);
        console.log(obj);
        this.nodeList[this.clickIndex] = Object.assign({}, this.nodeList[this.clickIndex], obj);
        console.log(this.nodeList);
        this.orgnization = [];
      },
    },
    mounted() {
      this.getFlowTable();
    },
  };
</script>
<style lang="less" scoped>
  @import '../../../assets/css/fee/myApply/determinationProcess.less';
</style>
