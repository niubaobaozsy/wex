<!--
  describe：预算部门组件
  created by：欧倩伶
  date：2017-11-10
-->
<template>
  <div class="budget-dept" v-if="show">
    <my-header :title="top.title" :showBack="true" :showRedDot="true" @previous="hide"></my-header>
    <div class="has-header">
      <div class="border content">
        <div class="searchBox">
          <div class="searchInput">
            <img class="icon" :src="search" alt="">
            <p>搜索预算部门</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import MyHeader from '../../common/header';
import search from '../../../assets/images/fee/myApply/search2x.png';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {
      search,
      top: {
        title: '选择预算部门',
      },
    };
  },
  props: {
    show: Boolean,
    id: String,
  },
  methods: {
    hide() {
      this.$emit('on-hide');
    },
  },
};
</script>
<style lang="less" scoped>
.budget-dept {
  position: fixed;
  top: 0;
  z-index: 100;
  width: 100%;
  height: 100%;
  background: #F4F4F4;
}

.content {
  .searchBox {
    background: #FFF;
    height: 50PX;
    padding: 10px;
    box-sizing: border-box;
    .searchInput {
      background: #F4F4F4;
      border-radius: 23px;
      height: 30px;
      line-height: 30px;
      display: flex;
      justify-content: center;
      img {
        width: 12px;
        height: 13px;
        margin: auto 5px;
      }
      p {
        font-size: 13px;
        color: #7F8389;
      }
    }
  }
}
</style>
