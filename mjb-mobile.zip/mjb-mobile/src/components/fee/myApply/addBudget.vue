<!--
  describe：预算来源
  created by：欧倩伶
  date：2017-11-10
  data: 2017-12
  修改：黄喆
-->
<style lang="less" scoped>
@import "../../../assets/css/fee/myApply/addBudget.less";
</style>
<template>
  <div>
    <my-header v-if="EAflag" class="mb10" :title="top.title" :showBack="true" @previous="goBack"></my-header>
    <div :class="{'has-header':EAflag,'mt67':EAflag,'mt10':!EAflag}">
      <div class="detail" v-for="(item,index) in budgetList" :key="index">
        <div class="headline border">
          <div class="flexItem" @click="show(index)">
            <img v-if="!bgIsclose[index]" :src="down" class="down"><img v-if="bgIsclose[index]" :src="up" class="down">
            <div>预算来源{{index+1}}</div>
          </div>
          <div class="del" @click="delItem(index)" v-edit :data-edit="item.busi_org_id">删除</div>
        </div>
        <div v-if="!bgIsclose[index]" class="box border-bottom">
          <div class="amoutItem border-bottom">
            <div>申请金额</div>
            <!-- <label v-if="item.label" class="amount" >{{formatCurrency(item.apply_amount)}}</label>
              <input v-if="!item.label" autofocus placeholder="请输入金额" v-model="item.apply_amount" @blur="noput(index)"> -->
            <currency v-focus class="amount" currency="¥" v-model="item.apply_amount" :precision="2" placeholder="请输入金额" v-edit></currency>
          </div>
          <div class="cell border-bottom">
            <div class="text">预算部门</div>
            <div class="flexItem" @click="showBudgetOrg(index)" v-edit :data-edit="item.busi_org_id">
              <p>{{item.busi_org_name}}</p>
              <img class="rightArrow" :src="rightArrow" alt="">
            </div>
          </div>
          <div class="cell border-bottom">
            <div class="text">经济事项</div>
            <div class="flexItem" @click="economicsEvent(index)" v-edit :data-edit="item.fee_type_id">
              <p>{{item.fee_type_name}}</p>
              <img class="rightArrow" :src="rightArrow" alt="">
            </div>
          </div>
          <div class="cell" :class="{'border-bottom': applyType !== 'CL'}" style="height: auto;">
            <div class="text">预算来源</div>
            <div class="flexItem" @click="budgetSource(index)" v-edit :data-edit="item.budget_node_id">
              <p>{{(autoShow && listIndex === index) ? budgetList[listIndex].budget_node_desc : item.budget_node_desc}}</p>
              <img class="rightArrow" :src="rightArrow" alt="">
            </div>
          </div>
          <div v-if="applyType !== 'CL'" class="cell" style="height: auto;">
            <div class="text">预计发生日期</div>
            <div class="flexItem" @click="onCellClick(index)" v-edit :data-edit="item.fee_advance_date">
              <p class="input_date">
                <img :src="calenderImg" alt="calenderImg" style="width:16px;height:15px;">
                {{item.fee_advance_date || '请设置发生日期'}}
              </p>
              <img class="rightArrow" :src="rightArrow" alt="">
            </div>
          </div>
        </div>
      </div>
      <div class="addItem border" @click="addItem">
        <img :src="add" alt="">
        <p>添加预算</p>
      </div>
      <!-- 底部 -->
      <div v-if="EAflag" class="footer">
        <div class="sum">
          <span>金额总计：</span>
          <currency currency="¥" :value="totalSum" :precision="2" :read-only="true" style="width:30%;"></currency>
        </div>
        <div class="btn" @click="submit">确认</div>
      </div>
    </div>
    <calendar @pickDate="onPickDate" :show.sync="showCalendar" v-model="pick_date"></calendar>
    <bugdet-org :show.sync="showBdOrg" @confirm="setDept" />
    <event :show="showEvent" ref="event" @on-select="selectEvent" @on-hide="hideEvent" :id="budgetList[listIndex]?budgetList[listIndex].busi_org_id:''"></event>
    <sources :show="showSources" @on-select="selectSources" @on-hide="hideSources" :dept-id="budgetList[listIndex]?budgetList[listIndex].busi_org_id:''"
      :sources-id="budgetList[listIndex]?budgetList[listIndex].fee_type_id:''"></sources>
  </div>
</template>

<script>
import MyHeader from '../../common/header';
import bugdetOrg from '../../common/bugdetOrg';
import event from '../../common/economicsEvent';
import sources from '../../common/budgetSourcee';
import down from '../../../assets/images/fee/myApply/triangledown2x.png';
import up from '../../../assets/images/fee/myApply/triangleup2x.png';
import add from '../../../assets/images/fee/myApply/add.png';
import rightArrow from '../../../assets/images/fee/myApply/right2x.png';
import currency from '../../common/currency';
import calendar from '../../common/myCalendar';
import calImg from '../../../assets/images/fee/myApply/calendar.png';

export default {
  components: {
    MyHeader,
    bugdetOrg,
    event,
    sources,
    currency,
    calendar,
  },
  data() {
    return {
      invoice: {},
      pick_date: '',
      showCalendar: false,
      down,
      up,
      add,
      rightArrow,
      showBdOrg: false,
      showEvent: false,
      showSources: false,
      calenderImg: calImg, // 日历小图标的路径
      isSave: false,
      isNext: true,
      EAflag: true,
      listIndex: 0,
      sum: 0,
      top: {
        title: '预算来源',
      },
      bugdet: {},
      budgetList: [],
      airTicketBudgetList: [],
      bgIsclose: [],
      autoShow: false,
    };
  },
  methods: {
    // 点击选择时间
    onPickDate() {
      this.budgetList[this.listIndex].fee_advance_date = this.pick_date;
    },
    onCellClick(index) {
      this.showCalendar = true;
      this.listIndex = index;
      this.pick_date = this.budgetList[this.listIndex].fee_advance_date;
    },
    // formatCurrency(number) {
    //   if (number) {
    //     return `￥${(Math.round(number * 100) / 100).toFixed(2)}`;
    //   }
    //   return 0;
    // },
    formatDate(time) {
      //      if (!time) return null;
      //      if (time.indexOf('-') !== -1) return time;
      if (!time) return null;
      if (time) return time;
      const temp1 = date.getFullYear();
      const temp2 = (date.getMonth() + 1 < 10 ? `0${(date.getMonth() + 1)}` : date.getMonth() + 1);
      const temp3 = (date.getDate() + 1 < 10 ? `0${(date.getDate() + 1)}` : date.getDate() + 1);
      return `${temp1}-${temp2}-${temp3}`;
    },
    goBack() {
      this.$router.go(-1);
    },
    show(index) {
      const arr = [];
      arr[index] = !this.bgIsclose[index];
      this.bgIsclose = Object.assign([], this.bgIsclose, arr);
      // this.budgetList[index].isclose = !this.budgetList[index].isclose;
    },
    addItem() {
      this.budgetList.push({
        apply_amount: '',
        busi_org_name: this.defBusiOrg.busi_org_name,
        busi_org_id: this.defBusiOrg.busi_org_id,
        fee_type_name: '',
        budget_node_desc: '',
        isclose: false,
      });
    },
    delItem(index) {
      this.budgetList.splice(index, 1);
    },
    // 输入金额
    // iput(index) {
    //   this.budgetList[index].label = false;
    // },
    // noput(index) {
    //   const self = this;
    //   self.budgetList[index].label = true;
    // },
    // 选择预算部门
    showBudgetOrg(index) {
      this.showBdOrg = true;
      this.listIndex = index;
      this.budgetList[this.listIndex].fee_type_name = '';
      this.budgetList[this.listIndex].budget_node_desc = '';
    },
    setDept(param) {
      this.budgetList[this.listIndex].busi_org_name = param.busi_org_name;
      this.budgetList[this.listIndex].busi_org_id = param.busi_org_id;
    },
    // 选择经济事项
    economicsEvent(index) {
      // 如果没有选中预算部门，则不能选择经济事项
      if (!this.budgetList[this.listIndex].busi_org_name) {
        this.showToast({ msg: '请先选择预算部门' });
        return false;
      }
      this.listIndex = index;
      this.showEvent = true;
      this.budgetList[this.listIndex].budget_node_desc = '';
      this.$refs.event.getFeeTypeList();
      return null;
    },
    selectEvent(param) {
      this.showEvent = false;
      this.autoShow = false;
      this.budgetList[this.listIndex].fee_type_id = param.fee_type_id;
      this.budgetList[this.listIndex].fee_type_name = param.fee_type_name;
      this.getSourceList(this.listIndex);
    },
    hideEvent() {
      this.showEvent = false;
    },
    // 选择预算来源
    budgetSource(index) {
      if (!this.budgetList[this.listIndex].busi_org_name) {
        this.showToast({ msg: '请先选择预算部门' });
        return false;
      } else if (!this.budgetList[this.listIndex].fee_type_name) {
        this.showToast({ msg: '请先选择经济事项' });
        return false;
      }
      this.listIndex = index;
      this.showSources = true;
      return null;
    },
    selectSources(param) {
      this.showSources = false;
      this.budgetList[this.listIndex].budget_name = param.budget_name;
      this.budgetList[this.listIndex].budget_node_name = param.budget_node_name;
      this.budgetList[this.listIndex].budget_node_id = param.budget_node_id;
      this.budgetList[this.listIndex].budget_node_desc = param.budget_node_desc;
      this.budgetList[this.listIndex].budget_headers_id = param.budget_headers_id;
    },
    hideSources() {
      this.showSources = false;
    },
    // 保存store
    commitStore() {
      this.budgetList.forEach((item) => {
        item.currency_code = this.emseaapplyh.currency_code;
        item.currency_name = this.emseaapplyh.currency_name;
        item.conversion_rate = 1;
        // item.approve_amount = 0;
        item.reason_desc = this.emseaapplyh.reason_desc;
        item.fee_apply_l_id = null;
        item.fee_apply_id = null;
        // if (this.applyType === 'CL') item.fee_advance_date = this.feeAdvanceDate;
      });
    },
    // 确认
    submit() {
       const self = this;
      self.budgetList.forEach((item) => {
        if (!item.apply_amount) {
          self.showToast({ msg: '请填写申请金额', width: '12em' });
          self.isNext = false;
        } else if (!item.busi_org_name) {
          self.showToast({ msg: '请填写预算部门', width: '12em' });
          self.isNext = false;
        } else if (!item.fee_type_name) {
          self.showToast({ msg: '请填写经济事项', width: '12em' });
          self.isNext = false;
        } else if (!item.budget_node_desc) {
          self.showToast({ msg: '请填写预算来源', width: '12em' });
          self.isNext = false;
        } else if (self.applyType !== 'CL' && !item.fee_advance_date) {
          self.showToast({ msg: '请填写预计发生日期', width: '12em' });
          self.isNext = false;
        } else {
          self.isNext = true;
        }
        self.commitStore();
      });
      if (!self.isNext) {
        return false;
      }
      // const emseaapplyh = Object.assign({}, self.emseaapplyh, { emseaapplyls: self.budgetList });
      // self.$store.commit('EMSEAAPPLYH', emseaapplyh);
      let emseaapplyls = [...self.budgetList, ...self.airTicketBudgetList];
      const emseaapplyh = Object.assign({}, self.emseaapplyh, { emseaapplyls: emseaapplyls});
      self.$store.commit('EMSEAAPPLYH', emseaapplyh);
      self.$router.go(-1);
      return null;
    },
    // EA/CLX时的下一步
    beforeNext() {
      const self = this;
      self.isNext = true;
      const obj = { apply_amount: self.totalSum };
      self.budgetList.forEach((item) => {
        if (!item.apply_amount) {
          self.showToast({ msg: '请填写申请金额', width: '12em' });
          self.isNext = false;
        }
        if (!item.busi_org_name) {
          self.showToast({ msg: '请填写预算部门', width: '12em' });
          self.isNext = false;
        }
        if (!item.fee_type_name) {
          self.showToast({ msg: '请填写经济事项', width: '12em' });
          self.isNext = false;
        }
        if (!item.budget_node_desc) {
          self.showToast({ msg: '请填写预算来源', width: '12em' });
          self.isNext = false;
        }
        if (!self.isNext) {
          return false;
        }
        self.commitStore();
        return null;
      });
      // self.emseaapplyh.emseaapplyls = self.budgetList;
      // self.$store.commit('EMSEAAPPLYH', Object.assign({}, self.emseaapplyh, obj));
      let emseaapplyls = [...self.budgetList, ...self.airTicketBudgetList];
      const emseaapplyh = Object.assign({}, self.emseaapplyh, { emseaapplyls: emseaapplyls}, obj);
      self.$store.commit('EMSEAAPPLYH', emseaapplyh);
      return self.isNext;
    },
    // 保存草稿之前
    beforeSaveDraft() {
      const self = this;
      const obj = { apply_amount: self.totalSum };
      self.commitStore();
      // self.emseaapplyh.emseaapplyls = self.budgetList;
      // self.$store.commit('EMSEAAPPLYH', Object.assign({}, self.emseaapplyh, obj));
      let emseaapplyls = [...self.budgetList, ...self.airTicketBudgetList];
      const emseaapplyh = Object.assign({}, self.emseaapplyh, { emseaapplyls: emseaapplyls},obj);
      self.$store.commit('EMSEAAPPLYH', emseaapplyh);
      return true;
    },
    // 初始化
    init() {
       const self = this;
      (self.emseaapplyh.emseaapplyls || []).forEach((budget, index) => {
        self.bgIsclose[index] = false;
      });

      if (self.applyCreate.applyType === 'EA' || self.applyCreate.applyType === 'CLX') {
        self.EAflag = false;
      }
      // 设置初始的部门信息
      self.budgetList = [];  //  不含对公飞机票预算
      self.airTicketBudgetList =[];  // 对公飞机票预算
      if (self.emseaapplyh.emseaapplyls.length) {
        self.emseaapplyh.emseaapplyls.forEach((item, index) => {
          if(self.applyType === 'CL' && self.myApplyMenuCfg[self.applyType].compnayPayAir && item.attribute1 && item.attribute1 === 'COMPANY'){
             const airTicketBudgetList = Object.assign({}, item, {
                busi_org_name: item.busi_org_name ? item.busi_org_name : self.defBusiOrg.busi_org_name,
                busi_org_id: item.busi_org_id ? item.busi_org_id : self.defBusiOrg.busi_org_id,
                fee_advance_date: item.fee_advance_date ? item.fee_advance_date.split(' ')[0] : '',
                amount: 0,
                isclose: false,
              });
              self.$set(self.airTicketBudgetList, self.airTicketBudgetList.length, airTicketBudgetList);
          }else{
            const budgetList = Object.assign({}, item, {
              busi_org_name: item.busi_org_name ? item.busi_org_name : self.defBusiOrg.busi_org_name,
              busi_org_id: item.busi_org_id ? item.busi_org_id : self.defBusiOrg.busi_org_id,
              fee_advance_date: item.fee_advance_date ? item.fee_advance_date.split(' ')[0] : '',
              amount: 0,
              isclose: false,
            });
            self.$set(self.budgetList, self.budgetList.length, budgetList);
          }
          self.listIndex = 0;
          // const emseaapplyl = Object.assign({}, item, {
          //   busi_org_name: item.busi_org_name ? item.busi_org_name : self.defBusiOrg.busi_org_name,
          //   busi_org_id: item.busi_org_id ? item.busi_org_id : self.defBusiOrg.busi_org_id,
          //   fee_advance_date: item.fee_advance_date ? item.fee_advance_date.split(' ')[0] : '',
          //   amount: 0,
          //   isclose: false,
          // });
          // self.$set(self.budgetList, index, emseaapplyl);
          // self.listIndex = 0;
        });
      } else {
        self.addItem();
      }
      let emseaapplyls = [...self.budgetList, ...self.airTicketBudgetList];
      const emseaapplyh = Object.assign({}, self.emseaapplyh, { emseaapplyls: emseaapplyls});
      // const emseaapplyh = Object.assign({}, self.emseaapplyh, { emseaapplyls: self.budgetList});
      self.$store.commit('EMSEAAPPLYH', emseaapplyh);
    },
    // 获取预算来源列表
    getSourceList(index) {
      const pamars = {
        busi_org_id: this.budgetList[this.listIndex] ? this.budgetList[this.listIndex].busi_org_id : '',
        fee_type_id: this.budgetList[this.listIndex] ? this.budgetList[this.listIndex].fee_type_id : '',
        page_number: 1,
        page_size: 2,
      };
      this.$store.dispatch('getBudgetSource', pamars)
        .then((rep) => {
          if (rep.code === '0000') {
            if (rep.data.info.length === 1) {
              this.budgetList[index].budget_name = rep.data.info[0].budget_name;
              this.budgetList[index].budget_node_name = rep.data.info[0].budget_node_name;
              this.budgetList[index].budget_node_id = rep.data.info[0].budget_node_id;
              this.budgetList[index].budget_node_desc = rep.data.info[0].budget_node_desc;
              this.budgetList[index].budget_headers_id = rep.data.info[0].budget_headers_id;
              this.autoShow = true;
            }
          } else {
            this.showToast({ msg: rep.msg });
          }
        });
    },
  },
  computed: {
    applyType() {
      return this.$store.state.myApply.applyCreate.applyType;
    },
     myApplyMenuCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.children;
    },
    totalSum() {
      let sum = 0;
      this.budgetList.forEach((item) => {
        sum += parseFloat(item.apply_amount)
          ? parseFloat(item.apply_amount)
          : 0;
      });
      return sum;
    },
    emseaapplyh() {
      return this.$store.state.myApply.emseaapplyh;
    },
    applyCreate() {
      return this.$store.state.myApply.applyCreate;
    },
    // 获取默认个人配置信息
    defBusiOrg() {
      return this.$store.state.login.defCfg.busiOrg || {};
    },
  },
  mounted() {
    this.init();
  },
};
</script>
