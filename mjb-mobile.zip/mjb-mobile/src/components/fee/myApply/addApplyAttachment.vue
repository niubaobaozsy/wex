<!--
  describe：借款申请-附件
  created by：panjm
  date：2017-11-20
-->
<template>
  <div>
    <div class="attachmentBox">
      <span class="title">附件</span>
      <div class="list-right" @click="showUpload">
        <img :src="addAttachment">
        <span>添加</span>
      </div>
    </div>
    <div class="attachmentList" v-if="showImgList.length > 0">
      <div class="attachmentItem" v-for="(data, index) in showImgList" :key="index">
        <img class="type-img" :src="'data:'+ data.mime_type +';base64,' + data.content" alt="" @click="showBigImgFuc(index)" @load="setImgSize(index)">
        <!-- <img :src="data.thumbnail_content" @click="showBigImgFuc(index)" @load="setImgSize(index)"> -->
        <div class="del" @click="delImg(index, data.file_id)"></div>
      </div>
    </div>

    <actionsheet v-model="showAction" :menus="menus" :show-cancel="showCancel" @on-click-menu="addPhoto"></actionsheet>
    <Gallery :show="showBigImg" :index="bigImgIndex" :list="showImgList" :hasDel="hasDel" @on-hide="hideImgView" @on-del="delImg"></Gallery>
  </div>
</template>
<script>
import { Actionsheet } from 'vux';
import { platform } from '../../../platform';
import Gallery from '../../common/gallery';
import add from '../../../assets/images/fee/myApply/addTravelBtn.png';

export default {
  components: {
    Actionsheet,
    Gallery,
  },
  data() {
    return {
      addAttachment: add,
      showAction: false,
      showCancel: true,
      menus: {
        menu1: '<span style="color: #666666;">拍照</span>',
        menu2: '<span style="color: #666666;">相册</span>',
      },
      bigImgIndex: 0,
      showBigImg: false, // 是否显示大图列表
      hasDel: false,
    };
  },
  computed: {
    // 拍照和相册上传的图片
    imgList() {
      return this.$store.state.myReimburse.enclosureList;
    },
    // 展示图片
    showImgList() {
      const list = this.$store.state.myReimburse.enclosureList;
      return list;
    },
    emseaapplyh() {
      return this.$store.state.myApply.emseaapplyh;
    },
    emslmloan() {
      return this.$store.state.myApply.emslmloan;
    },
  },
  methods: {
    hideImgView() {
      this.showBigImg = false;
    },
    saveDraft() {

    },
    // 点击图片查看大图
    showBigImgFuc(index) {
      this.showLoading();
      this.hasDel = true;
      this.bigImgIndex = index;
      setTimeout(() => {
        this.hideLoading();
        this.showBigImg = true;
      }, 1000);
    },
    // 加载图片时设置图片显示的位置
    setImgSize(index) {
      const el = event.srcElement;
      const showImg = this.imgList[index];
      if (showImg) {
        showImg.el = el;
        showImg.src = el.src;
        showImg.w = el.naturalWidth;
        showImg.h = el.naturalHeight;
      }
      this.imgList[index] = showImg;
    },
    addPhoto(key) {
      switch (key) {
        case 'menu1':
          this.takePicture();
          break;
        case 'menu2':
          this.selectFromAlbum();
          break;
        default:
          this.showAction = false;
      }
    },
    selectFromAlbum() {
      // window.Camera = {
      //   PictureSourceType: {
      //     SAVEDPHOTOALBUM: 0,
      //     CAMERA: 1,
      //   },
      // };
      const self = this;
      platform.getPicture({
        sourceType: Camera.PictureSourceType.SAVEDPHOTOALBUM,
      }).then((data) => {
        self.uploadImg(data);
      });
    },
    takePicture() {
      // window.Camera = {
      //   PictureSourceType: {
      //     SAVEDPHOTOALBUM: 0,
      //     CAMERA: 1,
      //   },
      // };
      const self = this;
      platform.getPicture({
        sourceType: Camera.PictureSourceType.CAMERA,
      }).then((data) => {
        self.uploadImg(data);
      });
    },
    // 附件上传随机生成文件名
    imgRandom() {
      return `${Date.now()}${Math.floor(Math.random() * 10000000)}.png`;
    },
    // 上传图片
    uploadImg(data) {
      const params = {
        source_system: 'Expense',
        source_order_id: this.emslmloan.loan_info_id,
        source_order_type: 'LM',
        seq: 1,
        file: {
          source_filename: this.imgRandom(),
          content: data,
        },
      };
      this.showLoading('附件上传中');
      this.$store.dispatch('attachmentUpload', params).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          const list = res.data;
          this.getBigImg(list.file_id);
        } else {
          this.showToast({ msg: res.msg });
        }
      }, () => {
        this.hideLoading();
        this.showToast({ msg: '页面开小差了' });
      });
    },

    // 获取大图
    getBigImg(id) {
      this.showLoading();
      this.$store.dispatch('getBigImg', id).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          if (res.data) {
            this.imgList.push(res.data);
            this.$store.commit('TR_ENCLOSURE_LIST', this.imgList);
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },

    getAttachment() {
      const params = {
        source_system: 'Expense',
        source_order_id: this.emslmloan.loan_info_id,
        source_order_type: 'LM',
      };
      this.showLoading();
      this.$store.dispatch('getAttachment', params).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          if (res.data && res.data.info) {
            this.$store.commit('TR_ENCLOSURE_LIST', []);
            const list = res.data.info;
            list.forEach((item) => {
              this.getBigImg(item.file_id);
            });
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    delImg(index, fileId) {
      fileId = fileId || this.showImgList[index].file_id;
      const params = {
        file_id: fileId,
        source_system: 'Expense',
        source_order_id: this.emslmloan.loan_info_id,
        source_order_type: 'LM',
      };
      const self = this;
      this.$vux.confirm.show({
        title: '删除',
        content: '确定删除该附件？',
        onConfirm() {
          self.$store.dispatch('attachemntDelete', params).then((res) => {
            if (res && res.code === '0000') {
              self.imgList.splice(index, 1);
              self.$store.commit('TR_ENCLOSURE_LIST', self.imgList);
              self.showToast({ msg: '删除成功', width: '14em', time: 800 });
            } else if (res && res.code) {
              self.showToast({ msg: `请求异常(${res.code})` });
            }
          });
        },
      });
      this.hideImgView();
    },
    showUpload() {
      const that = this;
      if (this.emslmloan.loan_info_id) {
        this.showAction = !this.showAction;
        return false;
      }
      return new Promise((resolve) => {
        that.$parent.saveDraft().then(() => {
          that.showAction = !that.showAction;
          resolve();
        });
      });
    },
  },
  mounted() {
    this.getAttachment();
    this.$store.commit('TR_ENCLOSURE_LIST', []);
  },
};
</script>
<style lang="less" scoped>
.attachmentBox {
  background-color: #ffffff;
  margin-top: 10px;
  display: flex;
  justify-content: space-between;
  font-size: 16px;
  line-height: 22px;
  padding: 15px 15px;
  .list-right {
    flex: 1;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    span {
      color: #858585;
    }
    img {
      width: 12px;
      height: 12px;
      margin-right: 10px;
    }
  }
}

.footer-btn {
  position: fixed;
  bottom: 0;
  width: 100%;
  margin-bottom: 0 !important;
  div {
    box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.10);
    font-size: 18px;
    height: 50px;
    line-height: 48px;
    text-align: center;
    &:first-child {
      background: #FFFFFF;
      color: #666666;
    }
    &:nth-child(2) {
      background: #3DA5FE;
      color: #FFFFFF;
    }
  }
}

.attachmentList {
  display: inline-flex;
  padding: 10px 10px;
  flex-wrap: wrap;
  background-color: #ffffff;
  margin-top: 1px;
  width: 100%;
  box-sizing: border-box;
  border-top: 1px solid #F3F4F6;
  .attachmentItem {
    position: relative;
    img {
      width: 59px;
      height: 59px;
      margin: 5px 5px 0px;
      border: 1px solid #c1bfbf;
    }
    .del {
      position: absolute;
      background: url(../../../assets/images/fee/myInvoice/delete2x.png) no-repeat;
      background-size: 17px 17px;
      top: -17px;
      width: 17px;
      height: 17px;
      top: 0px;
      right: 0px;
    }
  }
}
</style>
