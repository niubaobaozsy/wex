<!--
  describe： Homepage of apply creation
  created by：Zhuangyh
  date：2017-11-22
-->
<template>
  <div>
    <my-header v-show="!childRtFullScreen" :title="top.title" :headerClass="top.headerTop" @previous="goBack" :rightItem="!tplProcess[currentStep].hideSaveBtn?top.rightTitle:''" @on-click="saveDraft(true)"></my-header>
    <process-bar v-show="!childRtFullScreen" class="has-header process-bar border-bottom" :process="process" :currentStep="currentStep" @on-click="goRouter"></process-bar>
    <div :class="{'has-header': !childRtFullScreen, 'has-process-bar': !childRtFullScreen}">
      <keep-alive>
        <router-view ref="childRt"></router-view>
      </keep-alive>
      <div v-show="!childRtFullScreen" class="footer-btn columns is-mobile is-gapless">
        <button class="column" @click="goPrevious" v-if="currentStep">上一步</button>
        <button class="column" @click="goNext" :class="{available: applyCreate.ableNext}" v-if="currentStep<(tplProcess.length-1)">下一步</button>
        <button class="column" @click="submit" :class="{available: applyCreate.ableNext}" v-if="currentStep===(tplProcess.length-1)">提交</button>
      </div>
      <over-standard :show="showOverStand" @on-select="onOverStandSubmit" @on-hide="onOverStandHide"></over-standard>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
import { mapState } from 'vuex';
import store from '@/store';
import myApply from '@/store/myApply';
import myHeader from '../../common/header';
import processBar from '../../common/processBar';
import overStandard from '../../common/overStandReason';

export default {
  components: {
    myHeader,
    processBar,
    overStandard,
  },
  data() {
    return {
      showOverStand: false,
      delOverStdRes: false,
      tplCfg: {
        CL: {
          top: {
            title: '差旅申请',
            rightTitle: '保存草稿',
          },
          process: [
            {
              procName: '差旅申请',
              procRt: 'addTravelApply',
            }, {
              procName: '行程',
              procRt: 'addTravelRoute',
            }, {
              procName: '费用预估',
              procRt: 'expenseEstimateIndex',
            }, {
              procName: '审批流程',
              procRt: 'determinationProcess',
              hideSaveBtn: true,
            },
          ],
          rtWhitelist: ['/fee/myApply/expenseEstimate', '/fee/myApply/addBudget','/fee/myApply/addAirTickerBudget'],
          validateRule: () => {
            console.log('validateRule');
            return true;
          },
        },
        CLX: {
          top: {
            title: '差旅申请',
            rightTitle: '保存草稿',
          },
          process: [
            {
              procName: '差旅申请',
              procRt: 'addTravelApply',
            }, {
              procName: '预算来源',
              procRt: 'addBudget',
            }, {
              procName: '审批流程',
              procRt: 'determinationProcess',
              hideSaveBtn: true,
            },
          ],
          rtWhitelist: [],
          validateRule: () => {
            console.log('validateRule');
            return true;
          },
        },
        EA: {
          top: {
            title: '其他费用申请',
            rightTitle: '保存草稿',
          },
          process: [
            {
              procName: '费用申请',
              procRt: 'addTravelApply',
            }, {
              procName: '预算来源',
              procRt: 'addBudget',
            }, {
              procName: '审批流程',
              procRt: 'determinationProcess',
              hideSaveBtn: true,
            },
          ],
          rtWhitelist: [],
          validateRule: () => {
            console.log('validateRule');
            return true;
          },
        },
        LM: {
          top: {
            title: '借款申请',
            rightTitle: '保存草稿',
          },
          process: [
            {
              procName: '因公个人借款',
              procRt: 'addTravelApply',
            }, {
              procName: '附件',
              procRt: 'applyAttachment',
            }, {
              procName: '审批流程',
              procRt: 'determinationProcess',
              hideSaveBtn: true,
            },
          ],
          rtWhitelist: ['/mine/collectionTitle'],
          validateRule: () => {
            console.log('validateRule');
            return true;
          },
        },
      },
      // isSave: false,
      nativeNav: false,
      childRtFullScreen: false,
    };
  },
  methods: {
    goStep(index) {
      this.$store.commit('APPLY_CREATE', { currentStep: index });
      this.$router.push(this.tplProcess[this.currentStep].procRt);
    },
    goRouter(index) {
      this.nativeNav = true;
      if (this.goRouterValidate()) {
        if (index === this.currentStep) {
          this.nativeNav = false;
          return false;
        }
        if (index === this.currentStep + 1) {
          this.goNext();
        } else if (index === this.currentStep - 1) {
          this.goPrevious();
        } else if ((((index > this.currentStep + 1) && this.goNextValidate()) || ((index < this.currentStep - 1) && this.goPreviousValidate())) && this.validateRuleCheck()) {
          if ((index > this.currentStep + 1) && index === this.tplProcess.length - 1) {
            this.saveAndCheck().then(() => {
              this.goStep(index);
            });
          } else if ((index > this.currentStep + 1) && this.tplProcess[index].saveBeforeIn) {
            if ((this.applyCreate.applyType !== 'LM' && !this.emseaapplyh.fee_apply_id) || (this.applyCreate.applyType === 'LM' && !this.emslmloan.loan_info_id)) {
              this.saveDraft().then(() => {
                this.goStep(index);
              });
            }
          } else {
            this.goStep(index);
          }
        } else {
          this.nativeNav = false;
          return false;
        }
      }
      this.nativeNav = false;
      return true;
    },
    saveDraft(notAuto) {
      if (this.saveDraftValidate()) {
        return new Promise((resolve) => {
          this.showLoading();
          if (this.applyCreate.applyType !== 'LM') {
            //
            const emseaapplyh = Object.assign({}, this.emseaapplyh, {
              apply_amount: this.totalBudget,
              budget_fee: this.totalBudget,
            });
            if (this.applyCreate.applyType === 'CL') {
              emseaapplyh.emseaapplyls.forEach((item) => {
                item.fee_advance_date = this.feeAdvanceDate;
              });
            }
            console.log('this', this);
            this.$store.dispatch('saveFeeApply', { emseaapplyh }).then((res) => {
              this.hideLoading();
              if (res && res.code === '0000') {
                if (res.data && res.data.emseaapplyh && res.data.emseaapplyh.fee_apply_id) {
                  const standardTypeDict = [{
                      label: '市内交通费',
                      value: 'SNJTF',
                    }, {
                      label: '餐费',
                      value: 'CF',
                    }
                  ];
                  res.data.emseaapplyh.emseaassistantdetails.forEach((item) => {
                    if (item.standard_type) {
                      item.standardType = standardTypeDict.filter((i) => i.value === item.standard_type)[0];
                    }
                  });
                  this.$store.commit('APPLY_CREATE', { isSave: true });
                  this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, res.data.emseaapplyh));
                  if (notAuto) {
                    this.showToast({ msg: '保存成功' });
                  }
                  resolve(res.data.emseaapplyh.fee_apply_id);
                }
              } else {
                this.showToast({ msg: `保存失败(${res.code}):${res.msg}` });
              }
            });
          } else {
            this.$store.dispatch('saveLoan', { emslmloan: this.emslmloan }).then((res) => {
              this.hideLoading();
              if (res && res.code === '0000') {
                if (res.data && res.data.emslmloan) {
                  // this.isSave = true;
                  this.$store.commit('APPLY_CREATE', { isSave: true });
                  this.$store.commit('EMSLMLOAN', Object.assign({}, this.emslmloan, res.data.emslmloan));
                  this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emslmloan, res.data.emslmloan));
                  if (notAuto) {
                    this.showToast({ msg: '保存成功' });
                  }
                  resolve(res.data.emslmloan.loan_info_id);
                }
              } else {
                this.showToast({ msg: `保存失败(${res.code}):${res.msg}` });
              }
            });
          }
        });
      }
      return null;
    },
    check(id) {
      return new Promise((resolve) => {
        const self = this;
        self.showLoading();
        if (this.applyCreate.applyType !== 'LM') {
          self.$store.dispatch('CheckmyApply', { fee_apply_id: id })
            .then((rep) => {
              self.hideLoading();
              if (rep.code === '0000') {
                // 超标后用户返回修改成不超标情况时，需要把之前传过的超标理由清除
                if (this.emseaapplyh.over_standard_reason) {
                  const overStdParams = {
                    over_standard_reason: '',
                    is_over_standard: 'N',
                  }
                  this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, overStdParams));
                  this.delOverStdRes = true;
                }
                resolve();
              } else if (rep.code === '9999') {
                if (rep.data && rep.data.checkHLResult && rep.data.checkHLResult.msgNodeList && rep.data.checkHLResult.msgNodeList.length) {
                  const msgList = rep.data.checkHLResult.msgNodeList;
                  const msg = [];
                  msgList.map((list) => {
                    msg.push(list.msg);
                    return null;
                  });
                  self.alert({ content: msg.join(',') });
                } else if (rep.data && rep.data.budgetCheckResult) {
                  const code = rep.data.budgetCheckResult.code;
                  const msg = rep.data.budgetCheckResult.msg;
                  if (code === '0') { // 后台异常
                    self.alert({ content: msg });
                  } else if (code === '1') { // 成功
                    resolve();
                  } else if (code === '2') { // 超预算，严控
                    self.alert({ content: msg });
                  } else if (code === '3') { // 提醒，可通过
                    self.alert({
                      content: msg,
                      onHide() {
                        resolve();
                      },
                    });
                  }
                } else if (rep.data && rep.data.loanCheckResult) {
                  const msg = rep.data.loanCheckResult.msg;
                  self.alert({ content: msg });
                } else if (rep.data && rep.data.hextCheckResult) {
                  const msg = rep.data.hextCheckResult.msg;
                  self.alert({ content: msg });
                } else {
                  self.alert({ content: rep.msg });
                }
              } else if (rep.code === '1100') {
                self.alert({
                  content: rep.msg,
                  onHide() {
                    if (!self.emseaapplyh.over_standard_reason) {
                      self.showOverStand = true;
                      self.$store.commit('OVER_STD_EXP', true);
                      resolve();
                    } else {
                      if (!self.overStdExp) {
                        self.showOverStand = true;
                        self.$store.commit('OVER_STD_EXP', true);
                        resolve();
                      } else {
                        self.showOverStand = false;
                        resolve();
                      }
                    }
                  },
                });
              } else if (rep && rep.code) {
                self.alert({ content: `请求异常[${rep.code}]: ${rep.msg}` });
              }
            });
        } else {
          self.$store.dispatch('checkLoan', { loan_info_id: id })
            .then((rep) => {
              self.hideLoading();
              if (rep.code === '0000') {
                resolve();
              } else if (rep.code === '9999') {
                const msgList = rep.data.checkHLResult.msgNodeList;
                const msg = [];
                msgList.map((list) => {
                  msg.push(list.msg);
                  return null;
                });
                self.alert({ content: msg.join(',') });
              } else if (rep.code === '1100') {
                const msgList = rep.data.checkHLResult.msgNodeList;
                const msg = [];
                msgList.map((list) => {
                  msg.push(list.msg);
                  return null;
                });
                self.alert({
                  content: msg.join(','),
                  onHide() {
                    resolve();
                  },
                });
              } else if (rep.data.budgetCheckResult) {
                if (rep.data.budgetCheckResult.code === '0') {
                  self.alert({ content: msg.join(',') });
                }
              } else {
                const msgList = rep.data.checkHLResult.msgNodeList[0].msg;
                self.alert({ content: msgList });
              }
            });
        }
      });
    },
    saveAndCheck() {
      return new Promise((resolve) => {
        this.saveDraft().then((id) => {
          this.check(id).then(() => {
            // 如果超标理由在校验后被删除，需要再保存一次
            if (this.delOverStdRes) {
              this.saveDraft().then(() => {
                resolve();
              })
            } else {
              resolve();
            }
          });
        });
      });
    },
    submitValidate() {
      const beforeSubmit = this.$refs.childRt.beforeSubmit;
      const result = (beforeSubmit && typeof (beforeSubmit) === 'function' && beforeSubmit()) || beforeSubmit === undefined;
      return result;
    },
    submit() {
      if (this.submitValidate()) {
        const params = {
          auditNote: '',
          formInstanceId: this.emseaapplyh.formInstanceId,
          template_form_id: this.emseaapplyh.form_template_id,
          model_id: '001',
          mustModifyHandler: this.flowNode,
        };
        this.showLoading();
        this.$store.dispatch('submitFeeApply', params).then((rep) => {
          this.hideLoading();
          if (rep.code === '0000') {
            this.showToast({ msg: '提交成功' });
            setTimeout(() => {
              this.$router.push({
                path: '/fee/myApply/applyHome/beingApproved',
              });
            }, 875);
          } else {
            this.showToast({ msg: rep.msg });
          }
        });
      }
    },
    goBack() {
      this.$router.push('/fee/myApply');
    },
    validateRuleCheck() {
      const validateRule = this.tpl.validateRule;
      const result = (validateRule && typeof (validateRule) === 'function' && validateRule()) || validateRule === undefined;
      return result;
    },
    goRouterValidate() {
      const beforeGoRouter = this.$refs.childRt.beforeGoRouter;
      const result = (beforeGoRouter && typeof (beforeGoRouter) === 'function' && beforeGoRouter(index)) || beforeGoRouter === undefined;
      return result;
    },
    goPreviousValidate() {
      const beforePrevious = this.$refs.childRt.beforePrevious;
      const result = (beforePrevious && typeof (beforePrevious) === 'function' && beforePrevious()) || beforePrevious === undefined;
      return result;
    },
    goNextValidate() {
      const beforeNext = this.$refs.childRt.beforeNext;
      const result = (beforeNext && typeof (beforeNext) === 'function' && beforeNext()) || beforeNext === undefined;
      return result;
    },
    saveDraftValidate() {
      const beforeSaveDraft = this.$refs.childRt.beforeSaveDraft;
      const result = (beforeSaveDraft && typeof (beforeSaveDraft) === 'function' && beforeSaveDraft()) || beforeSaveDraft === undefined;
      return result;
    },
    goPrevious() {
      this.nativeNav = true;
      if (this.goPreviousValidate()) {
        this.$store.commit('APPLY_CREATE', { currentStep: this.currentStep - 1 });
        this.$router.push(this.tplProcess[this.currentStep].procRt);
      }
      this.nativeNav = false;
    },
    nextStep() {
      this.$store.commit('APPLY_CREATE', { currentStep: this.currentStep + 1 });
      this.$router.push(this.tplProcess[this.currentStep].procRt);
    },
    goNext() {
      this.nativeNav = true;
      if (this.goNextValidate()) {
        if (this.currentStep === this.tplProcess.length - 2) {
          this.saveAndCheck().then(() => {
            this.nextStep();
          });
        } else if (this.tplProcess[this.currentStep + 1].saveBeforeIn) {
          if ((this.applyCreate.applyType !== 'LM' && !this.emseaapplyh.fee_apply_id) || (this.applyCreate.applyType === 'LM' && !this.emslmloan.loan_info_id)) {
            this.saveDraft().then(() => {
              this.nextStep();
            });
          } else {
            this.nextStep();
          }
        } else {
          this.nextStep();
        }
      }
      this.nativeNav = false;
    },
    onOverStandSubmit(reason) {
      const emseaapplyh = {
        is_over_standard: 'Y',
        over_standard_reason: reason,
      };
      this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, emseaapplyh));
      this.saveDraft().then(() => {
        this.showOverStand = false;
      });
    },
    onOverStandHide() {
      this.showOverStand = false;
    },
  },
  computed: {
    ...mapState({
      applyCreate: state => state.myApply.applyCreate,
      currentStep: state => state.myApply.applyCreate.currentStep,
      overStdExp: state => state.myApply.overStdExp,
      tpl(state) {
        return this.tplCfg[state.myApply.applyCreate.applyType || 'CL'];
      },
      tplProcess(state) {
        return this.tplCfg[state.myApply.applyCreate.applyType || 'CL'].process;
      },
      top(state) {
        return this.tplCfg[state.myApply.applyCreate.applyType || 'CL'].top;
      },
      rtWhitelist(state) {
        return this.tplCfg[state.myApply.applyCreate.applyType || 'CL'].rtWhitelist || [];
      },
      process(state) {
        const process = [];
        this.tplCfg[state.myApply.applyCreate.applyType || 'CL'].process.forEach((item) => {
          process.push(item.procName);
        });
        return process;
      },
    }),
    ...mapState({
      emseaapplyh: state => state.myApply.emseaapplyh,
      emslmloan: state => state.myApply.emslmloan,
      flowNode: state => state.myApply.flowNode,
    }),
    totalFee() {
      return this.$store.getters.totalFee;
    },
    totalBudget() {
      return this.$store.getters.totalBudget;
    },
    feeAdvanceDate() {
      return this.$store.getters.autoFillAdvanceDate;
    },
  },
  mounted() {
    if (!this.applyCreate.applyType) {
      this.$router.push('/fee/myApply/create/');
    }
  },
  beforeRouteEnter(to, from, next) {
    store.dispatch('getDefaultConfig').then((rep) => {
      if (rep) next();
    });
  },
  beforeRouteUpdate(to, from, next) {
    if (to.path === '/fee/myApply/create/viewApplyDetail') {
      this.childRtFullScreen = true;
    } else {
      this.childRtFullScreen = false;
    }
    if (this.nativeNav) {
      next();
    } else {
      if (this.tplProcess[this.currentStep - 1] && to.path === `/fee/myApply/create/${this.tplProcess[this.currentStep - 1].procRt}`) {
        this.$store.commit('APPLY_CREATE', { currentStep: this.currentStep - 1 });
      } else if (this.tplProcess[this.currentStep + 1] && to.path === `/fee/myApply/create/${this.tplProcess[this.currentStep + 1].procRt}`) {
        this.$store.commit('APPLY_CREATE', { currentStep: this.currentStep + 1 });
      }
      next();
    }
  },
  beforeRouteLeave(to, from, next) {
    const _this = this;
    if (!this.applyCreate.isSave && (this.rtWhitelist.indexOf(to.path) === -1) && (to.path !== '/')) {
      this.$vux.confirm.show({
        content: '尚未保存，退出将清空当前页面内容，确认退出？',
        onConfirm() {
          _this.$store.commit('MY_APPLY', JSON.parse(JSON.stringify(myApply.stateInit)));
          next();
        },
        onCancel() {
          next(false);
        },
      });
    } else if (this.rtWhitelist.indexOf(to.path) !== -1) {
      next();
    } else {
      _this.$store.commit('MY_APPLY', JSON.parse(JSON.stringify(myApply.stateInit)));
      next();
    }
  },
};
</script>
<style lang="less" scoped>
.process-bar {
  position: fixed;
  z-index: 99;
  width: 100%;
  top: 0;
  left: 0;
}

.has-process-bar {
  padding: 70px 0 0;
}

button {
  border: none;
  outline: none;
  background: none;
}

.footer-btn {
  position: fixed;
  bottom: 0;
  width: 100%;
  button {
    height: 50px;
    font-size: 18px;
    box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.10);
    &:first-child {
      background: #FFFFFF;
      color: #666666;
    }
    &:last-child {
      color: #FFFFFF;
      background: #C1C1C1;
      &.available {
        background: #3DA5FE;
      }
    }
  }
}
</style>
