<!--
  describe："差旅申请-草稿"
  created by：panjm
  date：2017-11-9
  data: 2017-12
  修改：黄喆
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div infinite-scroll-immediate-check="true" v-infinite-scroll="loadMoreFun" infinite-scroll-disabled="busy" infinite-scroll-distance="10" infinite-scroll-throttle-delay="500" ref="scoller">
    <down-pull-loading @loading="refresh" v-if="orderList.length">
      <!-- <swipeout slot='list'>
        <swipeout-item v-for="(data, index) in orderList" :key="index" ref="swip">
          <div slot="right-menu">
            <swipeout-button @click.native="becomeTop(index)" style="font-size:17px;background:#A8ABB2;width: 66px;border-top:1px solid #DEDFE0;border-bottom:1px solid #DEDFE0;">置顶</swipeout-button>
            <swipeout-button @click.native="showPlugin(data.loan_info_id, data.apply_type, index)" style="font-size:17px;background:#FC4B4B;width: 66px;border-top:1px solid #DEDFE0;border-bottom:1px solid #DEDFE0;">作废</swipeout-button>
          </div>
          <div slot="content" @click="goDetail(data.loan_info_id, data.apply_type)">
            <div class="invoiceBox">
              <div class="invoiceLeft">
                <div :class="['invoiceType', data.logo_color]">
                  {{ data.order_type_name }}
                </div>
              </div>
              <div class="invoiceRight">
                <div class="invoiceSecondCol">
                  <p :class="{placeholder: !data.reason_desc}">{{ data.reason_desc||'暂未填写' }}</p>
                  <p>{{ data.creation_date }}</p>
                  <p>单号：{{ data.loan_info_code }}</p>
                </div>
                <div class="invoiceThirdCol">
                  <p class="invoicePrice">￥{{ parseFloat(data.amount || 0).toFixed(2) }}</p>
                </div>
              </div>
            </div>
          </div>
        </swipeout-item>
      </swipeout> -->
      <div slot="list" v-for="(data, index) in orderList" :key="index"  @click="operation(data)">
        <div class="invoiceBox">
          <div v-if="checkboxStatus">
            <span class="check-box" :class="{checked: data.checked}"></span>
          </div>
          <div class="invoiceLeft">
            <div :class="['invoiceType', data.logo_color]">
              {{ data.order_type_name }}
            </div>
          </div>
          <div class="invoiceRight">
            <div class="invoiceSecondCol">
              <p :class="{placeholder: !data.reason_desc}">{{ data.reason_desc||'暂未填写' }}</p>
              <p>{{ data.creation_date }}</p>
              <!-- <p>单号：{{ data.loan_info_code }}</p> -->
            </div>
            <div class="invoiceThirdCol">
              <p class="invoicePrice" v-if="myMenuCfgCurreny">￥{{ parseFloat(data.amount || 0).toFixed(2) }}</p>
              <p class="invoicePrice" v-else>{{ data.currenySymbol }} {{ parseFloat(data.amount || 0).toFixed(2) }}</p>
            </div>
          </div>
        </div>
      </div>
    </down-pull-loading>

    <load-more v-if="loadMore" :tip="'加载中...'" style="width: 100%;padding: 22px 0px;box-sizing: border-box;margin:0 auto"></load-more>
    <div v-if="!orderList.length && isloading" class="emptyBox">
      <img class="no_data_img" src="../../../assets/images/common/no_data.png" alt="" />
      <p class="no_data_text">暂无数据</p>
      <div class="createOrderBtn" @click="goDetail()">创建申请单</div>
    </div>
    <div v-if="orderList.length" class="footer" @click="goDetail()" @touchmove.prevent.stop>
      <div class="btn" v-if="!checkboxStatus">
        <p>
          <img src="../../../assets/images/fee/Combined3x.png" />
          创建申请单
        </p>
      </div>
      <div class="footerBtn" v-if="checkboxStatus">
        <div class="item manualInput" @click.stop="showPlugin">删除</div>
        <div class="item scanInput" @click.stop="cancel">取消</div>
      </div>
    </div>
  </div>
</template>

<script>
import { Swipeout, SwipeoutItem, SwipeoutButton, XButton, Confirm, XSwitch, LoadMore, TransferDomDirective as TransferDom } from 'vux';
import downPullLoading from '../../common/downPullLoading';
import curreny from '../../../../static/curreny.json';

export default {
  components: {
    Swipeout,
    SwipeoutItem,
    SwipeoutButton,
    XButton,
    Confirm,
    XSwitch,
    TransferDom,
    LoadMore,
    downPullLoading,
  },
  data() {
    return {
      curreny,
      isloading: false,
      loadMore: false,
      busy: false,
      hasNextPage: true,
      pageInfo: {
        page_number: 1,
        page_size: 10,
        order_status: 'DRAFT',
      },
      orderList: [],
    };
  },
  methods: {
    getApplyList(isRefresh) {
      return new Promise((resolve) => {
        this.$store.dispatch('pageApplyList', this.pageInfo).then((res) => {
          this.hideLoading();
          resolve();
          if (res && res.code === '0000') {
            this.isloading = true;
            if (res.data && res.data.info && res.data.info.length) {
              console.log('11111', res.data.info);
              res.data.info.forEach((list) => {
                list.checked = false;
                if (list.source_system !== 'MOBILE') {
                  list.logo_color = 'grey';
                  list.apply_type = 'nonsupport';
                  if (list.order_type === 'HW') {
                    list.order_type_name = '会务';
                  } else if (list.order_type === 'CL') {
                    list.order_type_name = '差旅';
                  } else if (list.order_type === 'TY') {
                    list.order_type_name = '通用';
                  } else if (list.order_type === 'CAR') {
                    list.order_type_name = '用车';
                  } else if (list.module_type === 'LM') {
                    list.order_type_name = '借款';
                  } else if (list.order_type === 'EC_AIR') {
                    list.order_type_name = '机票';
                  }
                } else if (list.order_type === 'HW') {
                  list.order_type_name = '会务';
                } else if (list.order_type === 'CL') {
                  list.order_type_name = '差旅';
                  list.logo_color = 'blue';
                  list.apply_type = 'CL';
                } else if (list.order_type === 'TY') {
                  list.order_type_name = '通用';
                  list.logo_color = 'green';
                  list.apply_type = 'EA';
                } else if (list.order_type === 'CAR') {
                  list.order_type_name = '用车';
                } else if (list.module_type === 'LM') {
                  list.order_type_name = '借款';
                  if (list.order_type === 'PERSONPAY_PUBLIC') {
                    list.logo_color = 'pink';
                    list.apply_type = 'LM';
                  }
                }
                 // 币种
                let currenyName = list.currency_name;
                list.currenySymbol = this.curreny[currenyName];
              });
              this.orderList = isRefresh ? res.data.info : this.orderList.concat(res.data.info);
              this.pageInfo.page_number += 1;
              this.$nextTick(() => {
                this.vuxChangeWidth();
              });
            } else if (res.data && !res.data.info) {
              this.hasNextPage = false;
              this.loadMore = false;
            }
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      });
    },
    loadMoreFun() {
      console.log('loadMoreFun');
      if (this.hasNextPage) {
        setTimeout(() => {
          this.loadMore = true;
          this.getApplyList();
        }, 500);
      }
    },
    // 置顶
    becomeTop(index) {
      const toTop = this.orderList.splice(index, 1);
      this.orderList.unshift(toTop[0]);
    },
    // 删除
    deleteFeeApply(applyId, orderType, index) {
      return new Promise((resolve, reject) => {
        if (orderType === 'LM') {
          this.$store.dispatch('deleteLoan', { loan_info_id: applyId }).then((res) => {
            if (res.code === '0000') {
              this.orderList.splice(index, 1);
              resolve();
            } else if (res && res.code) {
              reject();
            }
          });
        } else {
          this.$store.dispatch('deleteFeeApply', { fee_apply_id: applyId }).then((res) => {
            if (res.code === '0000') {
              // this.orderList.splice(index, 1);
              resolve();
            } else if (res && res.code) {
              reject();
            }
          });
        }
      });
    },
    goDetail(applyId, applyType) {
      if (applyType === 'nonsupport') {
        this.showToast({ msg: '移动端暂不支持该类型单据的编辑，请移步PC端' });
      } else if (applyId && applyType) {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/myApply/create/addTravelApply', query: { id: applyId, type: applyType },
          });
        }, 500);
      } else {
        setTimeout(() => {
          this.$router.push({ path: '/fee/myApply/create/addTravelApply' });
        }, 500);
      }
    },
    showPlugin() {
      const self = this;
      let checkedCnt = 0;
      let successCnt = 0;
      let failCnt = 0;
      this.$vux.confirm.show({
        title: '作废',
        content: '确定作废已选中申请单吗？',
        onConfirm() {
          self.showLoading('删除中');
          self.orderList.forEach((item, index) => {
            if (item.checked) {
              checkedCnt ++;
              self.deleteFeeApply(item.loan_info_id, item.order_type, index).then(() => {
                successCnt ++;
                if (successCnt + failCnt === checkedCnt) {
                  self.hideLoading();
                  self.showToast({ msg: `操作完成,${successCnt}条成功，${failCnt}条失败` });
                  setTimeout(() => {
                    self.cancel();
                    self.pageInfo.page_number = 1;
                    self.getApplyList(true);
                  }, 800);
                }
              }, () => {
                failCnt ++;
                if (successCnt + failCnt === checkedCnt) {
                  self.hideLoading();
                  self.showToast({ msg: `操作完成,${successCnt}条成功，${failCnt}条失败` });
                  setTimeout(() => {
                    self.cancel();
                    self.pageInfo.page_number = 1;
                    self.getApplyList(true);
                  }, 800);
                }
              });
            }
          })
        },
      });
    },
    vuxChangeWidth() {
      // 修改vux-swiper-item距离content的宽
      if (this.$refs.swip) {
        this.$refs.swip.forEach((swip) => {
          const list = swip.$slots['right-menu'][0].children.filter(one => one.tag);
          list.forEach((one) => {
            one.componentOptions.propsData.width = 66;
          });
        });
      }
    },
    refresh() {
      this.isloading = false;
      this.pageInfo.page_number = 1;
      return new Promise((resolve) => {
        this.getApplyList(true).then(() => {
          setTimeout(() => {
            resolve();
          }, 1000);
        });
      });
    },
    pickBill(data){
      this.orderList.forEach((item,index) =>{
        // item.checked = false;
        if(item.loan_info_id === data.loan_info_id){
          item.checked = !item.checked;
        }
      })
    },
    operation(data){
      if(this.checkboxStatus){
        this.pickBill(data)
      } else {
        this.goDetail(data.loan_info_id, data.apply_type)
      }

    },
    cancel(){
      this.$store.commit('REC_CHECKBOXSTATUS')
    }
  },
  computed:{
    checkboxStatus(){
      return this.$store.state.myApply.checkboxStatus;
    },
    myMenuCfgCurreny() {
      return this.$store.state.menuConfig.fee.curreny;
    },
  },
  mounted() {
    this.showLoading();
    this.getApplyList();
  },
};
</script>
<style lang='less' scoped>
.footer {
  position: fixed;
  width: 100%;
  height: 50px;
  bottom: 0;
  left: 0;
  background: #fff;
  .btn {
    background: #3DA5FE;
    height: 50px;
    display: flex;
    p {
      margin: auto;
      font-size: 18px;
      color: #fff;
      img {
        width: 18px;
        height: 18px;
        vertical-align: middle;
      }
    }
  }
}
.check-box {
  display: block;
  box-sizing: border-box;
  width: 18px;
  height: 18px;
  margin:24px 20px;
  border-radius: 9px;
  border: 1px #ADADAD solid;
}

.checked {
  border: 0px;
  background-image: url(../../../assets/images/common/checked.png);
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
}
</style>

