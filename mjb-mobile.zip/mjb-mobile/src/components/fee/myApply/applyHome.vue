<!--
  describe："我的申请主页"
  created by：panjm
  date：2017-11-6
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div>
    <my-header title="我的申请" :rightItem='rightTitle' @previous="goBack" @on-click="edit"></my-header>
    <Tab :tabList="tabList"></Tab>
    <div class="has-header has-tab has-footer">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
import MyHeader from '../../common/header';
import Tab from '../../common/Tab';

export default {
  components: {
    MyHeader,
    Tab,
  },
  data() {
    return {
      tabList: [
        {
          name: '草稿',
          linkTo: 'draft',
        },
        {
          name: '审批中',
          linkTo: 'beingApproved',
        },
        {
          name: '已审批',
          linkTo: 'approved',
        },
      ],
    };
  },
  computed:{
    location(){
      return this.$route.path;
    },
    rightTitle() {
      return this.location.split('/').indexOf('draft') === -1 ? '' : '编辑';
    },
  },
  methods: {
    goBack() {
      this.$router.push('/fee');
      this.$store.commit('REC_CHECKBOXSTATUS')
    },
    edit(){
      this.$store.commit('CHANGE_CHECKBOXSTATUS')
    }
  },
  watch:{
    location (newValue,oldValue) {
      if (newValue.split('/').indexOf('draft') === -1) {
        this.$store.commit('CHANGE_CHECKBOXSTATUS');
      } else {
        this.$store.commit('REC_CHECKBOXSTATUS');
      }
    },
  }
};
</script>
