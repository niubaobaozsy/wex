<!--
  describe:国内差旅申请 - 费用预估
  created by：欧倩伶
  date：2017-11-07
-->
<style lang="less" scoped>
@import "../../../assets/css/fee/myApply/expenseEstimateIndex.less";
</style>
<template>
  <div class="expenseEstimateIndex">
    <div>
      <div class="row border" @click="goRoute('/fee/myApply/expenseEstimate')">
        <div class="title">费用预估</div>
        <div class="flexItem">
          <div v-if="applyType === 'CL' && myApplyMenuCfg[applyType].compnayPayAir">
             <div v-if="totalFee" class="amount" >¥ {{totalFee}}<span> (含飞机票 ¥ {{airTicketBudget}})</span></div>
            <div v-else class="text"><span> 暂无，请添加</span></div>
          </div>
          <div v-else>
            <currency currency="¥" :value="totalFee" :precision="2" placeholder="暂无，请添加" :read-only="true"></currency>
          </div>
          <!-- <currency currency="¥" :value="totalFee" :precision="2" placeholder="暂无，请添加" :read-only="true"></currency> -->
          <span class="rightArrow"> <img :src="rightArrow" alt=""></span>
        </div>
      </div>

      <div class="row border" @click="goRoute('/fee/myApply/addAirTickerBudget')" v-if="applyType === 'CL' && myApplyMenuCfg[applyType].compnayPayAir && airTicketBudget">
        <div class="title">公司订票预算来源</div>
        <div class="flexItem">
          <currency currency="¥" :value="totalAirFee" :precision="2" placeholder="暂无，请添加" :read-only="true"></currency>
          <span class="rightArrow"><img :src="rightArrow" alt=""></span>
        </div>
      </div>

      <div class="row border" @click="goRoute('/fee/myApply/addBudget')" v-if="applyType === 'CL' && myApplyMenuCfg[applyType].compnayPayAir">
        <div class="title">预算来源(不含公司订票)</div>
        <div class="flexItem">
          <!-- <div :class="applyh.budget_fee === '暂无，请添加' ? 'text' : 'amount'">{{applyh.budget_fee}}</div> -->
          <currency currency="¥" :value="totalCommonBudget" :precision="2" placeholder="暂无，请添加" :read-only="true"></currency>
          <span class="rightArrow"><img :src="rightArrow" alt=""></span>
        </div>
      </div>

      <div class="row border" @click="goRoute('/fee/myApply/addBudget')" v-else>
        <div class="title">预算来源</div>
        <div class="flexItem">
          <!-- <div :class="applyh.budget_fee === '暂无，请添加' ? 'text' : 'amount'">{{applyh.budget_fee}}</div> -->
          <currency currency="¥" :value="totalCommonBudget" :precision="2" placeholder="暂无，请添加" :read-only="true"></currency>
          <span class="rightArrow"><img :src="rightArrow" alt=""></span>
        </div>
      </div>

      <div class="tip" v-if="applyType === 'CL' && myApplyMenuCfg[applyType].compnayPayAir">
        <p>温馨提示：</p>
        <p>1、公司订票预算来源是指机票结算方式为公司结算的预算；</p>
        <p>2、公司订票预算来源与预算来源（不含公司订票）之和等于费用预估总额。</p>
      </div>
      <div class="tip" v-else>温馨提示：预算来源总额必须等于费用预估总额。</div>

    </div>
    <over-standard :show="showReason" @on-select="selectReason" @on-hide="hideReason"></over-standard>
  </div>
</template>

<script>
import MyHeader from '../../common/header';
import overStandard from '../../common/overStandReason';
import processBar from '../../common/processBar';
import rightArrow from '../../../assets/images/fee/myApply/right.png';
import currency from '../../common/currency';

export default {
  components: {
    MyHeader,
    overStandard,
    processBar,
    currency,
  },
  data() {
    return {
      rightArrow,
      budgetAmount: 0,
      currentStep: 3,
      isGo: false,
      showReason: false,
      stand_hotel: '',
      stand_assistant: '',
      over_standard_reason: '',
      is_over_standard: 'N',
      queryMsg: [],
      applyh: {},
      zsfFee: [{ rent_fee: '' }],
      bzfFee: [{ assistant_fee: '' }],
      airApplys: [],
    };
  },
  methods: {
    // 页面路由
    goRoute(router) {
      this.$router.push({ path: router });
    },
    selectReason(param) {
      this.showReason = false;
      this.over_standard_reason = param;
      this.applyh.emseaapplyls.reason_desc = this.over_standard_reason;
      this.isGo = true;
    },
    hideReason() {
      this.showReason = false;
    },
    arraySum(arr) {
      let sum = 0;
      arr.forEach((item) => {
        sum += parseFloat(item);
      });
      return sum;
    },
    getBudgetData() {
    },

    autoFirstBudget() {
      if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir) {
        // 有对公飞机票配置,根据行程拆分 公司订票预算来源  预算来源(不含公司订票)
        this.getBudgetData(); // 对公飞机票不在此页面获取数据
      } else {
        if (this.emseaapplyh.emseaapplyls.length < 2 && this.totalFee) {
          this.applyh.emseaapplyls[0] = Object.assign({}, this.applyh.emseaapplyls[0] || {}, { apply_amount: this.totalFee });
          this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, this.applyh));
        }
      }
    },
    // 获取申请的住宿费和补助费标准,并自动带出
    getStand() {
      const commObj = {
        index: 0,
        to_area: '',
        date: null,
        fee_apply_id: '',
        tenant_id: '',
        currency_code: 'CNY',
        currency_name: '人民币',
        conversion_rate: '1',
        approve_conversion_rate: '1',
        reason_desc: '',
        seq_no: '',
        created_by: '',
        created_name: '',
        creation_date: '',
        last_updated_by: '',
        last_updated_name: '',
        last_update_date: '',
        travel_days: 0,
      };
      const param = this.emseaapplyh.emseaapplytravels;
      // this.$store.commit('GET_STANDARD_REQ_PARAM', {
      //   travels: JSON.parse(JSON.stringify(param)),
      //   travel_persons: param[0].travel_persons,
      // });
      this.$store.commit('FEE_STD_EXP', true);
      this.showLoading();
      this.$store.dispatch('getStand', param).then(
        (rep) => {
          this.hideLoading();
          if (rep && rep.code === '0000') {
            const rentList = [];
            const assistantList = [];
            if (rep.data && rep.data.zsList) {
              rep.data.zsList.forEach((item) => {
                let rentObj = {
                  rent_fee: item.rent_fee,
                  to_area_name: item.to_area_name || '',
                  to_area_id: item.to_area_id || '',
                  attribute2: item.to_area_code || '',
                  end_date: item.end_date || '',
                  start_date: item.start_date || '',
                  travel_persons_name: item.travel_persons_name,
                  travel_persons: item.travel_persons,
                  to_area_code: item.to_area_code,
                  approve_rent_fee: '',
                  is_peer: '',
                  lodging_days: '',
                  rent_id: '',
                };
                rentObj = Object.assign({}, rentObj, commObj);
                rentList.push(rentObj);
              });
            }
            if (rep.data && rep.data.bzList) {
              const standardTypeDict = [{
                  label: '市内交通费',
                  value: 'SNJTF',
                }, {
                  label: '餐费',
                  value: 'CF',
                }
              ];
              rep.data.bzList.forEach((item) => {
                if (item.standard_type) {
                  item.standardType = standardTypeDict.filter((i) => i.value === item.standard_type)[0];
                }
                let assistantObj = {
                  assistant_fee: item.assistant_fee,
                  to_area_name: item.to_area_name || '',
                  to_area_id: item.to_area_id || '',
                  attribute2: item.to_area_code || '',
                  end_date: item.end_date || '',
                  start_date: item.start_date || '',
                  assistant_persons_name: item.travel_persons_name,
                  assistant_persons: item.travel_persons,
                  to_area_code: item.to_area_code,
                  approve_assistant_fee: '',
                  assistant_day: '',
                  id: '',
                };
                if (this.hasAssistantFeeType) {
                  assistantObj.standard_type = item.standard_type;
                  assistantObj.standardType = item.standardType;
                }
                assistantObj = Object.assign({}, assistantObj, commObj);
                assistantList.push(assistantObj);
              });
            }
            this.applyh.emsearentdetails = rentList;
            this.applyh.emseaassistantdetails = assistantList;
            this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, this.applyh));
            this.autoFirstBudget();
          } else if (rep && rep.code) {
            this.showToast({ msg: rep.msg || '获取住宿费和补助费失败' });
          }
        });
    },
    // 下一步
    beforeNext() {
      let next = true;
      const _this = this;
      if (this.emseaapplyh.emseaapplytravels.length) {
        this.emseaapplyh.emseaapplytravels.forEach((item) => {
          item.emseatransportdetails.forEach((feeItem) => {
            if (!feeItem.transport || !feeItem.transport_fee) {
              next = false;
            }
          });
        });
        if (!next) {
          this.$vux.confirm.show({
            title: '提示',
            content: '费用预估未填写完整，去填写？',
            confirmText: '好',
            onConfirm() {
              _this.goRoute('/fee/myApply/expenseEstimate');
            },
          });
          return false;
        }
      }
      if (this.emseaapplyh.emseaapplyls.length) {
        let airbdgFlag = false;
        this.emseaapplyh.emseaapplyls.forEach((item) => {
          if (!item.apply_amount || !item.busi_org_name || !item.fee_type_name || !item.budget_node_desc || (this.applyType !== 'CL' && !item.fee_advance_date)) {
            next = false;
            airbdgFlag = item.attribute13 === 'AIRPLANE' && item.attribute1 === 'COMPANY';
          }
        });
        if (!next) {
          let tip = '预算来源未填写完整，去填写？';
          let goBudgetRoute = '/fee/myApply/addBudget';

          if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir) {
            tip = airbdgFlag ? '公司订票预算来源未填写完整，去填写？' : '预算来源(不含公司订票)未填写完整，去填写？';
            goBudgetRoute = airbdgFlag ? '/fee/myApply/addAirTickerBudget' : '/fee/myApply/addBudget';
          }

          this.$vux.confirm.show({
            title: '提示',
            content: tip,
            confirmText: '好',
            onConfirm() {
              _this.goRoute(goBudgetRoute);
            },
          });
          return false;
        }
      }
      if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir) {
        if (this.totalFee !== parseFloat(this.totalCommonBudget + this.totalAirFee)) {
          next = false;
           // 金额校验 预算=公司订票预算+不含公司订票预算
          this.showToast({ msg: '公司订票预算来源与预算来源（不含公司订票）总额之和要等于费用预估总额' });
        }else if(this.airTicketBudget !== this.totalAirFee){
           next = false;
            // 公司订票合计 = 行程上的飞机票合计
          this.showToast({ msg: '公司订票预算来源总额要等于费用预估飞机票总额' });
        }
      } else {
        if (this.totalFee !== this.totalCommonBudget) {
          next = false;
          this.showToast({ msg: '费用预估总额和预算总额不相等' });
        }
      }

      return next;
    },
    // 初始化
    init() {
      this.applyh = this.emseaapplyh;
      this.autoFirstBudget();
    },
    // 上一步
    beforePrevious() {
      this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, this.applyh));
      return true;
    },
  },
  computed: {
    applyType() {
      return this.$store.state.myApply.applyCreate.applyType;
    },
    myApplyMenuCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.children;
    },
    emseaapplyh() {
      return this.$store.state.myApply.emseaapplyh;
    },
    totalFee() {
      return this.$store.getters.totalFee;
    },
    totalBudget() {
      return this.$store.getters.totalBudget;
    },
    totalCommonBudget() {
      return this.$store.getters.totalCommonBudget;
    },
    // 行程上的对公飞机票预算来源
    airTicketBudget() {
      return this.$store.getters.airTicketBudget;
    },
    // 预算上的对公飞机票预算行金额总和
    totalAirFee() {
      return this.$store.getters.totalAirFee;
    },
    // getStandardReqParam() {
    //   return this.$store.state.myApply.getStandardReqParam;
    // },
    feeStdExp() {
      return this.$store.state.myApply.feeStdExp;
    },
    hasAssistantFeeType() {
      return this.$store.state.menuConfig.fee.hasAssistantFeeType || false;
    },
  },
  activated() {
    this.init();
    const emseaapplytravels = this.emseaapplyh.emseaapplytravels;
    if (!this.emseaapplyh.emseaassistantdetails.length && !this.emseaapplyh.emsearentdetails.length) {
      // this.getStand(); // 不自动「自动生成」住宿/补助标准
      this.$store.commit('FEE_STD_EXP', true);
    } else {
      const _this = this;
      if (!this.feeStdExp) {
        this.$store.commit('FEE_STD_EXP', true);
        this.$vux.confirm.show({
          title: '提示',
          content: '检测到行程发生变化，是否重新生成住宿及补助费用？',
          onConfirm() {
            _this.getStand();
          },
        });
      }
    }
  },
};
</script>
