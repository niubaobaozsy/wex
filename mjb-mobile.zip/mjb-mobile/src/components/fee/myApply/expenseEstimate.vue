<!--
  describe：费用预估
  created by：欧倩伶
  date：2017-11-08
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myApply/expenseEstimate.less';
</style>
<template>
  <div>
    <my-header @on-click="getStand" title="费用预估" :showBack="true" rightItem="自动生成" @previous="goBack"></my-header>
    <div class="has-header has-footer">
      <!-- 交通 -->
      <div style="margin-top:59px;">
        <div class="detail" v-for="(item,index) in expenseList.emseaapplytravels" :key="index">
          <div class="headline border" @click="show('transport', index)">
            <div class="flexItem">
              <img v-show="!travelIsclose[index]" :src="down" class="down"><img v-show="travelIsclose[index]" :src="up" class="down">
              <div>交通
                <span v-if="item.from_area_name">({{item.from_area_name}} <img :src="to" class="to"> {{item.to_area_name}})</span>
              </div>
            </div>
            <!-- <div>合计：{{travelFee[index]}}</div> -->
            <currency currency="合计：¥" :value="travelFee[index]" :precision="2" :read-only="true" style="width:40%;"></currency>
          </div>
          <div v-show="!travelIsclose[index]">
            <div class="feeItem border-bottom" v-for="(feeItem,feeIndex) in item.emseatransportdetails" :key="feeIndex">
              <!-- <div v-if="item.emseatransportdetails.length && item.emseatransportdetails.length !== 1 " class="delItem borderBottom"> -->
              <div v-if="item.emseatransportdetails.length" class="delItem">
                <img :src="deleteBtn" alt="" @click="delFeeItem('transport', index, feeIndex)">
              </div>
              <div class="flex1">
                <div class="vehicle border-bottom">
                  <div class="text">工具</div>
                  <div class="flexItem" @click="showSheet(index,feeIndex)" v-edit.createAirBdt :data-edit="feeItem.transport">
                    <div class="trsp" v-if="feeItem.transport==='AIRPLANE'"><img class="icon" :src="plane">飞机</div>
                    <div class="trsp" v-if="feeItem.transport==='TRAIN'"><img class="icon" :src="train">火车</div>
                    <div class="trsp" v-if="feeItem.transport==='BUS'"><img class="icon" :src="car">汽车</div>
                    <div class="trsp" v-if="feeItem.transport==='SHIP'"><img class="icon" :src="ship">轮船</div>
                    <div class="trsp" v-if="feeItem.transport==='TAIX' &&　applyType === 'CL' && myApplyMenuCfg[applyType].compnayPayAir">
                      <img class="icon" :src="car">出租车</div>
                    <div class="trsp" v-if="feeItem.transport==='DIDI' && applyType === 'CL' && myApplyMenuCfg[applyType].compnayPayAir">
                      <img class="icon" :src="car">滴滴</div>
                    <img class="rightArrow" :src="rightArrow" alt="">
                  </div>
                </div>
                <div class="amoutItem">
                  <div>金额</div>
                  <!-- <label v-if="feeItem.label" class="amount" @click="iput('transport', index, feeIndex)">{{formatCurrency(feeItem.transport_fee) }}</label> -->
                  <!-- <input type="number" v-if="!feeItem.label" autofocus placeholder="请输入金额" v-model="feeItem.transport_fee" @blur="noput('transport', index, feeIndex)"> -->
                  <currency class="amount" currency="¥" v-model="feeItem.transport_fee" :precision="2" placeholder="请输入金额" v-edit.createAirBdt></currency>
                </div>
              </div>
            </div>
            <div class="addItem border-bottom" @click="addFeeItem('transport', index)">
              <img :src="add" alt="">
              <p>交通工具</p>
            </div>
          </div>
        </div>
      </div>
      <!-- 住宿 -->
      <div class="detail">
        <div class="headline border" @click="show('rent')">
          <div class="flexItem">
            <img v-if="!rentIsclose" :src="down" class="down"><img v-if="rentIsclose" :src="up" class="down">
            <div>住宿</div>
          </div>
          <!-- <div>合计：{{hotelFee}}</div> -->
          <currency currency="合计：¥" :value="hotelFee" :precision="2" :read-only="true" style="width:45%;"></currency>
        </div>
        <div v-if="!rentIsclose">
          <div class="feeItem border-bottom" v-for="(item,index) in expenseList.emsearentdetails" :key="index">
            <div class="delItem ">
              <img :src="deleteBtn" alt="" @click="delFeeItem('rent', index)">
            </div>
            <div class=" flex1">
              <div class="vehicle border-bottom">
                <div class="text">住宿人</div>
                <div class="flexItem">
                  <p>{{item.travel_persons_name}}</p>
                </div>
              </div>
              <div class="vehicle border-bottom" @click="openArea('rent', index)" v-edit.createAirBdt :data-edit="item.to_area_name">
                <div class="text">住宿城市</div>
                <div class="flexItem">
                  <p>{{item.to_area_name}}</p>
                  <img class="rightArrow" :src="rightArrow" alt="">
                </div>
              </div>
              <div class="vehicle border-bottom" @click="selectCalendar('rent',index)" v-edit.createAirBdt :data-edit="watchDateStr(item.start_date, item.end_date)">
                <div class="text">住宿时间</div>
                <div class="flexItem">
                  <img class="calendarIcon" :src="calendarIcon" alt="">
                  <p v-if="item.start_date">{{formatDate(item.start_date)}}-{{formatDate(item.end_date)}}</p>
                  <img class="rightArrow" :src="rightArrow" alt="">
                </div>
              </div>
              <div class="amoutItem">
                <div>住宿费用</div>
                <!-- <label v-if="item.label" class="amount" @click="iput('rent', index)">{{formatCurrency(item.rent_fee)}}</label> -->
                <!-- <input v-if="!item.label" type="number" autofocus placeholder="请输入金额" v-model="item.rent_fee" @blur="noput('rent', index)"> -->
                <currency class="amount" currency="¥" v-edit.overStd.createAirBdt :data-edit="item.rent_fee" v-model="item.rent_fee" :precision="2" placeholder="请输入金额" style="width:70%" v-edit.createAirBdt></currency>
              </div>
            </div>
          </div>
          <div class="addItem border-bottom" @click="addFeeItem('rent')">
            <img :src="add" alt="">
            <p>住宿费用</p>
          </div>
        </div>
      </div>
      <!-- 补助 -->
      <div class="detail">
        <div class="headline border" @click="show('assistant')">
          <div class="flexItem">
            <img v-if="!assIsclose" :src="down" class="down"><img v-if="assIsclose" :src="up" class="down">
            <div>补助</div>
          </div>
          <!-- <div>合计：{{subsidyFee}}</div> -->
          <currency currency="合计：¥" :value="subsidyFee" :precision="2" :read-only="true" style="width:40%;"></currency>
        </div>
        <div v-if="!assIsclose">
          <div class="feeItem border-bottom" v-for="(item,index) in expenseList.emseaassistantdetails" :key="index">
            <div class="delItem ">
              <img :src="deleteBtn" alt="" @click="delFeeItem('assistant', index)">
            </div>
            <div class=" flex1">
              <div class="vehicle border-bottom">
                <div class="text">补助人</div>
                <div class="flexItem">
                  <p>{{item.assistant_persons_name}}</p>
                </div>
              </div>
              <div class="vehicle border-bottom" @click="openArea('assistant',index)" v-edit.createAirBdt :data-edit="item.to_area_name">
                <div class="text">城市</div>
                <div class="flexItem">
                  <p>{{item.to_area_name}}</p>
                  <img class="rightArrow" :src="rightArrow" alt="">
                </div>
              </div>
              <div class="vehicle border-bottom" @click="selectCalendar('assistant',index)" v-edit.createAirBdt :data-edit="watchDateStr(item.start_date, item.end_date)">
                <div class="text">时间</div>
                <div class="flexItem">
                  <img class="calendarIcon" :src="calendarIcon" alt="">
                  <p v-if="item.start_date">{{formatDate(item.start_date)}}-{{formatDate(item.end_date)}}</p>
                  <img class="rightArrow" :src="rightArrow" alt="">
                </div>
              </div>
              <div v-if="hasAssistantFeeType" class="vehicle border-bottom" @click="showSetStandardType(index)" v-edit :data-edit="item.standard_type">
                <div class="text">补助类型</div>
                <div class="flexItem">
                  <p>{{item.standardType.label}}</p>
                  <img class="rightArrow" :src="rightArrow" alt="">
                </div>
              </div>
              <div class="amoutItem">
                <div>补助费用</div>
                <!-- <label v-if="item.label" class="amount" @click="iput('assistant', index)">{{formatCurrency(item.assistant_fee)}}</label> -->
                <!-- <input v-if="!item.label" type="number" autofocus placeholder="请输入金额" v-model="item.assistant_fee" @blur="noput('assistant', index)"> -->
                <currency class="amount" currency="¥" v-edit.overStd.createAirBdt :data-edit="item.assistant_fee" v-model="item.assistant_fee" :precision="2" placeholder="请输入金额" style="width:70%;"></currency>
              </div>
            </div>
          </div>
          <div class="addItem border-bottom" @click="addFeeItem('assistant')">
            <img :src="add" alt="">
            <p>补助费用</p>
          </div>
        </div>
      </div>
      <!-- 其他 -->
      <div class="detail last">
        <div class="headline border" @click="show('other')">
          <div class="flexItem">
            <img v-if="!othIsclose" :src="down" class="down"><img v-if="othIsclose" :src="up" class="down">
            <div>其他</div>
          </div>
          <!-- <div>合计：{{otherFee}}</div> -->
          <currency currency="合计：¥" :value="otherFee" :precision="2" :read-only="true"></currency>
        </div>
        <div v-if="!othIsclose">
          <div class="feeItem border-bottom" v-for="(item,index) in expenseList.emseaotherfeedetails" :key="index">
            <div class="delItem ">
              <img :src="deleteBtn" alt="" @click="delFeeItem('other', index)">
            </div>
            <div class=" flex1">
              <div class="amoutItem border-bottom">
                <div>费用金额</div>
                <!-- <label v-if="item.label" class="amount" @click="iput('other', index)">{{formatCurrency(item.other_fee)}}</label> -->
                <!-- <input v-if="!item.label" type="amount" autofocus placeholder="请输入金额" v-model="item.other_fee" @blur="noput('other', index)"> -->
                <currency class="amount" currency="¥" v-model="item.other_fee" :precision="2" placeholder="请输入金额" style="width:70%;" v-edit.createAirBdt></currency>
              </div>
              <div class="amoutReason">
                <div>消费事由</div>
                <div class="ERTextarea" style="width:70%;">
                  <x-textarea :max="40" v-model="item.reason_desc"></x-textarea>
                </div>
              </div>
            </div>
          </div>
          <div class="addItem border-bottom" @click="addFeeItem('other')">
            <img :src="add" alt="">
            <p>其他费用</p>
          </div>
        </div>
      </div>
      <!-- 底部 -->
      <div class="footer">
        <div class="sum">
          <span>金额总计：</span>
          <!-- <p>{{totalSum}}</p> -->
          <currency currency="¥" :value="totalSum" :precision="2" :read-only="true" style="width:30%;"></currency>
        </div>
        <div class="btn" @click="submit">确认</div>
      </div>
    </div>
    <Actionsheet class="traveToolsAction" v-model="showAction" :menus="menus" @on-click-menu="selectTool" :show-cancel="showCancel"></Actionsheet>
    <Actionsheet v-model="showStandardType" :menus="standardTypeMenus" @on-click-menu="selectStandardType" :show-cancel="true"></Actionsheet>
    <calendar v-model="date" :show.sync="showCalendar" @pickDate="pickDate" />
    <select-city v-if="showArea" :headTitle="headTitle" @select-city="selecCity" :tempType="'travel'" @close-panel="closePanel4cities()"></select-city>
  </div>
</template>

<script type="text/ecmascript-6">
import { XTextarea, Actionsheet } from 'vux';
import MyHeader from '../../common/header';
import calendar from '../../common/myCalendar';
import selectCity from '../../common/selectCity';
import to from '../../../assets/images/fee/myApply/to.png';
import add from '../../../assets/images/fee/myApply/add2x.png';
import deleteBtn from '../../../assets/images/fee/myApply/delete2x.png';
import rightArrow from '../../../assets/images/fee/myApply/right2x.png';
import plane from '../../../assets/images/fee/myApply/aircraft2x.png';
import train from '../../../assets/images/fee/myApply/train2x.png';
import car from '../../../assets/images/fee/myApply/car2x.png';
import ship from '../../../assets/images/fee/myApply/ship2x.png';
import down from '../../../assets/images/fee/myApply/triangledown2x.png';
import up from '../../../assets/images/fee/myApply/triangleup2x.png';
import calendarIcon from '../../../assets/images/fee/myApply/calendar.png';
import currency from '../../common/currency';

export default {
  components: {
    MyHeader,
    Actionsheet,
    XTextarea,
    calendar,
    selectCity,
    currency,
  },
  data() {
    return {
      to,
      down,
      up,
      rightArrow,
      plane,
      train,
      car,
      ship,
      calendarIcon,
      add,
      deleteBtn,
      showAction: false,
      showStandardType: false,
      showCancel: true,
      showCalendar: false,
      showArea: false,
      rentIsclose: true,
      assIsclose: true,
      othIsclose: true,
      travelIndex: '',
      costIndex: '',
      dateIndex: '',
      dateType: '',
      areaType: '',
      areaIndex: '',
      headTitle: '选择城市',
      date: [],
      menus: {
        menu1: `<img class="icon" src="${plane}" alt=""><p>飞机</p>`,
        menu2: `<img class="icon" src="${train}" alt=""><p>火车</p>`,
        menu3: `<img class="icon" src="${car}" alt=""><p>汽车</p>`,
        menu4: `<img class="icon" src="${ship}" alt=""><p>轮船</p>`,
      },
      standardTypeMenus: [{
          label: '市内交通费',
          value: 'SNJTF',
        }, {
          label: '餐费',
          value: 'CF',
        }
      ],
      standardTypeEditIndex: 0,
      expenseList: {},
      travelIsclose: [],
      airBudget: [],
    };
  },
  mounted() {
    this.init();
  },
  methods: {
    getStand() {
      const commObj = {
        index: 0,
        to_area: '',
        date: null,
        fee_apply_id: '',
        tenant_id: '',
        currency_code: 'CNY',
        currency_name: '人民币',
        conversion_rate: '1',
        approve_conversion_rate: '1',
        reason_desc: '',
        seq_no: '',
        created_by: '',
        created_name: '',
        creation_date: '',
        last_updated_by: '',
        last_updated_name: '',
        last_update_date: '',
        travel_days: 0,
      };
      const param = this.emseaapplyh.emseaapplytravels;
      // this.$store.commit('GET_STANDARD_REQ_PARAM', {
      //   travels: JSON.parse(JSON.stringify(param)),
      //   travel_persons: param[0].travel_persons,
      // });
      this.$store.commit('FEE_STD_EXP', true);
      this.showLoading();
      this.$store.dispatch('getStand', param).then(
        (rep) => {
          this.hideLoading();
          if (rep.code === '0000') {
            const rentList = [];
            const assistantList = [];
            if (rep.data && rep.data.zsList) {
              rep.data.zsList.forEach((item) => {
                let rentObj = {
                  rent_fee: item.rent_fee,
                  to_area_name: item.to_area_name || '',
                  to_area_id: item.to_area_id || '',
                  attribute2: item.to_area_code || '',
                  end_date: item.end_date || '',
                  start_date: item.start_date || '',
                  travel_persons_name: item.travel_persons_name,
                  travel_persons: item.travel_persons,
                  to_area_code: item.to_area_code,
                  approve_rent_fee: '',
                  is_peer: '',
                  lodging_days: '',
                  rent_id: '',
                };
                rentObj = Object.assign({}, rentObj, commObj);
                rentList.push(rentObj);
              });
            }
            if (rep.data && rep.data.bzList) {
              const standardTypeDict = [{
                  label: '市内交通费',
                  value: 'SNJTF',
                }, {
                  label: '餐费',
                  value: 'CF',
                }
              ];
              rep.data.bzList.forEach((item) => {
                if (item.standard_type) {
                  item.standardType = standardTypeDict.filter((i) => i.value === item.standard_type)[0];
                }
                let assistantObj = {
                  assistant_fee: item.assistant_fee,
                  to_area_name: item.to_area_name || '',
                  to_area_id: item.to_area_id || '',
                  attribute2: item.to_area_code || '',
                  end_date: item.end_date || '',
                  start_date: item.start_date || '',
                  assistant_persons_name: item.travel_persons_name,
                  assistant_persons: item.travel_persons,
                  to_area_code: item.to_area_code,
                  approve_assistant_fee: '',
                  assistant_day: '',
                  id: '',
                };
                if (this.hasAssistantFeeType) {
                  assistantObj.standard_type = item.standard_type;
                  assistantObj.standardType = item.standardType;
                }
                assistantObj = Object.assign({}, assistantObj, commObj);
                assistantList.push(assistantObj);
              });
            }
            const expenseList = {
              emsearentdetails: rentList,
              emseaassistantdetails: assistantList,
            };
            this.expenseList = Object.assign({}, this.expenseList, expenseList);
          } else if (rep && rep.code) {
            this.showToast({ msg: rep.msg || '获取住宿费和补助费失败' });
          }
        },
      );
    },
    showSetStandardType(index) {
      this.showStandardType = true;
      this.standardTypeEditIndex = index;
    },
    selectStandardType(value) {
      if (value === 'cancel') return false;
      let editItem = this.expenseList.emseaassistantdetails[this.standardTypeEditIndex];
      editItem.standard_type = value;
      editItem.standardType = this.standardTypeMenus.filter((item) => item.value === value)[0];
    },
    // formatCurrency(number) {
    //   return `￥${(Math.round(number * 100) / 100).toFixed(2)}`;
    // },
    formatDate(time) {
      if (!time) return null;
      if (time.indexOf('/') !== -1) {
        const temp1 = time.substr(0, 4);
        const temp2 = time.substr(5, 2);
        const temp3 = time.substr(8, 2);
        return `${temp1}-${temp2}-${temp3}`;
      }
      if (time.indexOf('月') !== -1) return time;
      const temp4 = time.substr(5, 2);
      const temp5 = time.substr(8, 2);
      return `${temp4}月${temp5}日`;
    },
    goBack() {
      this.$router.go(-1);
    },
    // 初始化
    init() {
      this.expenseList = JSON.parse(JSON.stringify(this.emseaapplyh));
      (this.emseaapplyh.emseaapplytravels || []).forEach((travel, index) => {
        this.travelIsclose[index] = true;
      });
      this.emseaapplyh.emseaotherfeedetails.forEach((item, index) => {
        item.happend_date = this.emseaapplyh.emseaapplytravels[0].start_date || null;
        if (!item.approve_other_fee) {
          this.emseaapplyh.emseaotherfeedetails.splice(index, 1);
        }
      });
      if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir) {
        this.menus.menu5 = `<img class="icon" src="${car}" alt=""><p>出租车</p>`;
        this.menus.menu6 = `<img class="icon" src="${car}" alt=""><p>滴滴</p>`;
      }
    },
    // 清空预算来源里的对公飞机订票预算行
    emptyAirEmseaapplyls() {
      let applyls = this.expenseList.emseaapplyls || [];
      const emseaapplyls = [];
      applyls.forEach(item => {
        if (!item.attribute1 || (item.attribute1 && item.attribute1 !== 'COMPANY')) {
          emseaapplyls.push(item);
        }
      });
      this.expenseList.emseaapplyls = emseaapplyls;
      // 自动带出第一行不含飞机票预算来源的总金额
      if (emseaapplyls.length < 2 && parseFloat(this.totalSum - this.airTicketFee)) {
        emseaapplyls[0] = Object.assign({}, emseaapplyls[0] || {}, { apply_amount: parseFloat(this.totalSum - this.airTicketFee) });
      }
      this.$store.commit('EMSEAAPPLYH', this.expenseList);
    },

    // 确认
    submit() {
      let close = true;
      // 交通消费校验
      this.expenseList.emseaapplytravels.forEach((item) => {
        let peopleNameList = item.travel_persons_name ? item.travel_persons_name.split(',') : []; // 每个行程的出行人
        let peopleIdList = item.travel_persons ? item.travel_persons.split(',') : [];  // 每个行程的出行人

        item.emseatransportdetails.forEach((feeItem) => {
          feeItem.attribute2 = item.to_area_code;
          if (!feeItem.transport) {
            this.showToast({ msg: '交通：交通工具不能为空!', width: '12em' });
            close = false;
          } else if (!feeItem.transport_fee) {
            this.showToast({ msg: '交通：交通费用不能为空!', width: '12em' });
            close = false;
          }
          // 对公飞机订票的结算方式
          if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir && feeItem.transport !== 'AIRPLANE' && this.isCreateAirBudget) {
            // 非对公飞机票
            this.$set(feeItem, 'attribute1', 'PERONAL');
          } else if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir && feeItem.transport === 'AIRPLANE' && this.isCreateAirBudget) {
            // 每行交通平均到出行人
            let airBudgetRow = feeItem;
            let perFee = (feeItem.transport_fee / peopleIdList.length);
            let perFeeStr = perFee.toString();
            if ((perFeeStr.indexOf('.') > -1 && perFeeStr.split('.')[1].length <= 2) || (perFeeStr.indexOf('.') < 0)) {
              airBudgetRow.perfee = perFee;  // 平均分配的
              airBudgetRow.perlastfee = perFee;
            } else {
              // 获取前面2位小数，最后一个人=总费用-前面人费用
              airBudgetRow.perfee = parseFloat(`${perFeeStr.split('.')[0]}.${perFeeStr.split('.')[1].substring(0, 2)}`);
              // 分多的
              airBudgetRow.perlastfee = feeItem.transport_fee - ((peopleIdList.length - 1) * airBudgetRow.perfee);
            }
            // 根据行程重新计算对公飞机票预算行
            peopleIdList.forEach((pel, pelIndex) => {
              let airBudgetItem = {
                attribute1: 'COMPANY', // 预算类型为 飞机票对公司预算  为空表示不为公司预算
                attribute2: pel,		// 出行人姓名Id
                attribute3: peopleNameList[pelIndex],		// 出行人姓名
                attribute4: item.start_date,	// 出行日期
                attribute5: this.expenseList.reason_desc,   	// 业务描述
                attribute6: item.from_area_id || item.from_area.area_id,			// 从哪里来 id
                attribute7: item.from_area_name || item.from_area.area_name,    // name
                attribute8: item.from_area_code || item.from_area.area_code,   // code
                attribute9: item.to_area_id || item.to_area.area_id,		// 去哪里
                attribute10: item.to_area_name || item.to_area.area_name,  // name
                attribute11: item.to_area_code || item.to_area.area_code,    // code
                attribute12: item.end_date, // 回程日期
                attribute13: airBudgetRow.transport, //
                index: this.expenseList.emseaapplyls.length - 1,
                busi_org_name: '', // ????????
                fee_type_name: '', // ????????
                busi_org_id: '', // ????????
                from_area: item.from_area,
                to_area: item.to_area,
                fee_type: '', // ????????
                budget_name: '',
                project_id: '', // 前端保存值 项目id
                project_name: '', // 前端保存值 项目名称
                source_system: '', // 前端保存值 项目来源系统
                erp_bank_type: '', // 前端保存值 项目erp类型
                erp_bank_type_name: '', // 前端保存值 项目erp类型名称

                fee_apply_l_id: null, // 批文申请单明细ID
                fee_apply_id: null, // ????????
                tenant_id: '', // 租户ID
                eco_type_id: '', // 活动事项ID
                fee_type_id: '', // 预算科目ID
                bill_type_id: '', // 经济事项ID
                apply_amount: peopleIdList.length > 1 && pelIndex > 0 ? airBudgetRow.perfee : airBudgetRow.perlastfee,
                currency: this.expenseList.currency,
                currency_code: this.expenseList.currency_code, // 币种编码(与头币种一致)
                currency_name: this.expenseList.currency_name, // 币种名称(与头币种一致)
                conversion_rate: 1,// 预算行币种兑头币种汇率 // ????????
                approve_conversion_rate: 1, // 预算行币种兑头币种汇率 // ????????
                fee_advance_date: '', // 预计发生日期
                reason_desc: this.expenseList.reason_desc, // 事由/工作任务
                project_code: '', // 项目号
                product_line_id: '', // 产品线ID
                budget_node_id: airBudgetRow.budget_node_id, // 预算单元 // ????????
                budget_node_desc: airBudgetRow.budget_node_desc, // 预算单元描述 // ????????
                budget_headers_id: airBudgetRow.budget_headers_id,  // 预算树ID // ????????
                used_amount: '', // 已用金额
                is_release: '', // 是否释放
                // release_amount: , // 释放金额
                release_by: '', // 释放人
                release_name: '', // 释放人姓名
                release_date: '', // 释放时间
                release_reason: '', // 释放原因
                created_by: '', // 创建人
                created_name: '', // 创建人姓名
                creation_date: '', // 创建日期
                last_updated_by: '', // 修改人
                last_updated_name: '', // 修改人姓名
                last_update_date: '', // 修改日期
                business_code: '', // 项目号对应的事业部code
                business_name: '', // 项目号对应的事业部
                budget_code: '', // 预算项目号
                budget_main_id: airBudgetRow.budget_main_id, // 预算主体id // ????????
                budget_main_name: airBudgetRow.budget_main_name, // 预算主体名称 // ????????
                acc_code: '', // 会计科目编码
                acc_name: '', // 会计科目名称
                lock_biz_type: '', // 锁定业务类型（消费增加）
                lock_return_code: '', // 锁定标识（消费明细主键-订单号）（消费增加）
                lock_status: '',  // 创建锁定状态：0，否-默认值  1，已创建锁定明细（消费增加）
              };
              this.airBudget.push(airBudgetItem); // 重新计算获取对公飞机票预算行
            })
            this.$set(feeItem, 'attribute1', 'COMPANY');
          }
        });
      });

      if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir && this.isCreateAirBudget) {
        this.emptyAirEmseaapplyls(); // 清空对公飞机票
        // 重新合并对公飞机票预算行，不含飞机票预算行
        let emseaapplyls = [...this.airBudget, ...this.expenseList.emseaapplyls];
        this.expenseList.emseaapplyls = emseaapplyls;
      }

      // 住宿消费校验
      this.expenseList.emsearentdetails.forEach((item) => {
        item.attribute2 = item.to_area_code;
        if (!item.to_area_id) {
          this.showToast({ msg: '住宿：住宿城市不能为空!', width: '12em' });
          close = false;
        } else if (!item.start_date && !item.end_date) {
          this.showToast({ msg: '住宿：住宿日期不能为空!', width: '12em' });
          close = false;
        } else if (!item.rent_fee) {
          this.showToast({ msg: '住宿：住宿费用不能为空!', width: '12em' });
          close = false;
        }
      });
      // 补助费校验
      this.expenseList.emseaassistantdetails.forEach((item) => {
        // item.attribute2 = this.expenseList.emsearentdetails[index].attribute2;
        item.attribute2 = item.to_area_code;
        if (!item.to_area_name) {
          this.showToast({ msg: '补助：住宿城市不能为空!', width: '12em' });
          close = false;
        } else if (!item.start_date && !item.end_date) {
          this.showToast({ msg: '补助：住宿日期不能为空!', width: '12em' });
          close = false;
        } else if (!item.assistant_fee) {
          this.showToast({ msg: '补助：补助费用不能为空!', width: '12em' });
          close = false;
        }
      });
      // 其他消费校验
      this.expenseList.emseaotherfeedetails.forEach((item) => {
        if (!item.reason_desc) {
          this.showToast({ msg: '其他：消费事由不能为空!', width: '12em' });
          close = false;
        }
        if (item.other_fee) {
          if (!item.reason_desc) {
            this.showToast({ msg: '其他：消费事由不能为空!', width: '12em' });
            close = false;
          }
        }
        if (item.reason_desc) {
          if (!item.other_fee) {
            this.showToast({ msg: '其他：费用金额不能为空!', width: '12em' });
            close = false;
          }
        }
      });
      if (close) {
        this.expenseList.apply_amount = this.totalSum;
        const emseaapplyh = this.expenseList;
        this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, emseaapplyh));
        this.$router.go(-1);
      }

      if (this.isCreateAirBudget) {
        // 重新计算了对公飞机票预算行
        this.$store.commit('APPLY_CREATE', { isCreateAirBudget: false });
      }
      return close;
    },
    // 日期选择
    selectCalendar(type, timeIndex) {
      // this.date = [];
      if (type === 'rent') {
        if (this.expenseList.emsearentdetails[timeIndex].start_date) {
          const startTime = this.expenseList.emsearentdetails[timeIndex].start_date.split(' ');
          const endTime = this.expenseList.emsearentdetails[timeIndex].end_date.split(' ');
          this.date.push(startTime[0]);
          this.date.push(endTime[0]);
        }
      } else if (type === 'assistant') {
        if (this.expenseList.emseaassistantdetails[timeIndex].start_date) {
          const startTime = this.expenseList.emseaassistantdetails[timeIndex].start_date.split(' ');
          const endTime = this.expenseList.emseaassistantdetails[timeIndex].end_date.split(' ');
          if (startTime[0] === endTime[0]) {
            const time = endTime[0].split('-');
            const newDay = parseInt(time[2], 10) + 1;
            endTime[0] = `${time[0]}-${time[1]}-${newDay}`;
          }
          this.date.push(startTime[0]);
          this.date.push(endTime[0]);
        }
      }
      this.showCalendar = true;
      this.dateIndex = timeIndex;
      this.dateType = type;
    },
    pickDate() {
      if (this.dateType === 'rent') {
        this.expenseList.emsearentdetails[this.dateIndex].start_date = this.date[0];
        this.expenseList.emsearentdetails[this.dateIndex].end_date = this.date[1];
      } else if (this.dateType === 'assistant') {
        this.expenseList.emseaassistantdetails[this.dateIndex].start_date = this.date[0];
        this.expenseList.emseaassistantdetails[this.dateIndex].end_date = this.date[1];
      }
      this.date = [];
    },
    // 选择城市
    openArea(type, index) {
      this.showArea = true;
      this.areaType = type;
      this.areaIndex = index;
    },
    closePanel4cities() {
      this.showArea = false;
    },
    selecCity(item) {
      if (this.areaType === 'rent') {
        this.expenseList.emsearentdetails[this.areaIndex].to_area_name = item.area_name;
        this.expenseList.emsearentdetails[this.areaIndex].to_area_id = item.area_id;
        this.expenseList.emsearentdetails[this.areaIndex].to_area_code = item.area_code;
        this.expenseList.emsearentdetails[this.areaIndex].to_area = item.area_name;
      } else if (this.areaType === 'assistant') {
        this.expenseList.emseaassistantdetails[this.areaIndex].to_area_name = item.area_name;
        this.expenseList.emseaassistantdetails[this.areaIndex].to_area_id = item.area_id;
        this.expenseList.emseaassistantdetails[this.areaIndex].to_area_code = item.area_code;
        this.expenseList.emseaassistantdetails[this.areaIndex].to_area = item.area_name;
      }
    },
    // 选择交通工具
    showSheet(index, feeIndex) {
      this.showAction = true;
      this.travelIndex = index;
      this.costIndex = feeIndex;
    },
    selectTool(key) {
      const self = this;
      if (key === 'menu1') {
        self.expenseList.emseaapplytravels[self.travelIndex].emseatransportdetails[self.costIndex].transport = 'AIRPLANE';
      } else if (key === 'menu2') {
        self.expenseList.emseaapplytravels[self.travelIndex].emseatransportdetails[self.costIndex].transport = 'TRAIN';
      } else if (key === 'menu3') {
        self.expenseList.emseaapplytravels[self.travelIndex].emseatransportdetails[self.costIndex].transport = 'BUS';
      } else if (key === 'menu4') {
        self.expenseList.emseaapplytravels[self.travelIndex].emseatransportdetails[self.costIndex].transport = 'SHIP';
      } else if (key === 'menu5' && this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir) {
        self.expenseList.emseaapplytravels[self.travelIndex].emseatransportdetails[self.costIndex].transport = 'TAIX';
      } else if (key === 'menu6' && this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir) {
        self.expenseList.emseaapplytravels[self.travelIndex].emseatransportdetails[self.costIndex].transport = 'DIDI';
      }
    },
    // 输入金额
    // iput(feeTypeName, index, feeIndex) {
    //   if (feeTypeName === 'transport') {
    //     this.expenseList.emseaapplytravels[index].emseatransportdetails[feeIndex].label = false;
    //   } else if (feeTypeName === 'rent') {
    //     this.expenseList.emsearentdetails[index].label = false;
    //   } else if (feeTypeName === 'assistant') {
    //     this.expenseList.emseaassistantdetails[index].label = false;
    //   } else if (feeTypeName === 'other') {
    //     this.expenseList.emseaotherfeedetails[index].label = false;
    //   }
    // },
    // noput(feeTypeName, index, feeIndex) {
    //   const self = this;
    //   if (feeTypeName === 'transport') {
    //     self.expenseList.emseaapplytravels[index].emseatransportdetails[feeIndex].label = true;
    //   } else if (feeTypeName === 'rent') {
    //     self.expenseList.emsearentdetails[index].label = true;
    //   } else if (feeTypeName === 'assistant') {
    //     self.expenseList.emseaassistantdetails[index].label = true;
    //   } else if (feeTypeName === 'other') {
    //     self.expenseList.emseaotherfeedetails[index].label = true;
    //   }
    // },
    // 展开详细信息、删除、添加
    show(feeTypeName, index) {
      if (feeTypeName === 'transport') {
        const arr = [];
        arr[index] = !this.travelIsclose[index];
        this.travelIsclose = Object.assign([], this.travelIsclose, arr);
      } else if (feeTypeName === 'rent') {
        this.rentIsclose = !this.rentIsclose;
      } else if (feeTypeName === 'assistant') {
        this.assIsclose = !this.assIsclose;
      } else if (feeTypeName === 'other') {
        this.othIsclose = !this.othIsclose;
      }
    },
    delFeeItem(feeTypeName, index, feeIndex) {
      if (feeTypeName === 'transport') {
        this.expenseList.emseaapplytravels[index].emseatransportdetails.splice(feeIndex, 1);
      } else if (feeTypeName === 'rent') {
        this.expenseList.emsearentdetails.splice(index, 1);
      } else if (feeTypeName === 'assistant') {
        this.expenseList.emseaassistantdetails.splice(index, 1);
      } else if (feeTypeName === 'other') {
        this.expenseList.emseaotherfeedetails.splice(index, 1);
      }
    },
    addFeeItem(feeTypeName, index) {
      const commonObj = {
        fee_apply_id: '',
        tenant_id: this.emseaapplyh.tenant_id,
        is_peer: '',
        lodging_days: '',
        currency_code: 'CNY',
        currency_name: '人民币',
        conversion_rate: '1',
        approve_conversion_rate: '1',
        seq_no: '',
        created_by: '',
        created_name: '',
        creation_date: '',
        last_updated_by: '',
        last_updated_name: '',
        last_update_date: '',
        // label: false,    // 非接口所有
      };
      if (feeTypeName === 'transport') {
        this.expenseList.emseaapplytravels[index].emseatransportdetails.push({ transport: 'AIRPLANE', transport_fee: '', currency_code: 'CNY', currency_name: '人民币', conversion_rate: '1', approve_conversion_rate: '1' });
      } else if (feeTypeName === 'rent') {
        commonObj.rent_id = '';
        commonObj.travel_persons = this.expenseList.emseaapplytravels[0].travel_persons;
        commonObj.travel_persons_name = this.expenseList.emseaapplytravels[0].travel_persons_name;
        this.expenseList.emsearentdetails.push(commonObj);
      } else if (feeTypeName === 'assistant') {
        commonObj.assistant_id = '';
        commonObj.assistant_persons = this.expenseList.emseaapplytravels[0].travel_persons;
        commonObj.assistant_persons_name = this.expenseList.emseaapplytravels[0].travel_persons_name;
        if (this.hasAssistantFeeType) {
          commonObj.standardType = this.standardTypeMenus[0];
          commonObj.standard_type = this.standardTypeMenus[0].value;
        }
        this.expenseList.emseaassistantdetails.push(commonObj);
      } else if (feeTypeName === 'other') {
        commonObj.other_id = '';
        commonObj.happend_date = this.expenseList.emseaapplytravels[0].start_date;
        this.expenseList.emseaotherfeedetails.push(commonObj);
      }
    },
    arraySum(arr) {
      let sum = 0;
      arr.forEach((item) => {
        sum += parseFloat(item);
      });
      return sum;
    },
    watchDateStr(date1, date2) {
      return `${date1}-${date2}`;
    },
  },
  computed: {
    applyType() {
      return this.$store.state.myApply.applyCreate.applyType;
    },
    myApplyMenuCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.children;
    },
    isCreateAirBudget() {
      return this.$store.state.myApply.applyCreate.isCreateAirBudget;
    },
    airTicketFee() {
      let airTicketFee = 0;
      if (this.expenseList.emseaapplytravels) {
        this.expenseList.emseaapplytravels.forEach((item) => {
          if (item.emseatransportdetails) {
            item.emseatransportdetails.forEach((feeItem) => {
              feeItem.approve_conversion_rate = '1';
              if (feeItem.transport === 'AIRPLANE' && feeItem.attribute1 === 'COMPANY') {
                airTicketFee += parseFloat(feeItem.transport_fee) ? parseFloat(feeItem.transport_fee) : 0;
              }
            });
          }
        });
      }
      return airTicketFee;
    },
    travelFee() {
      const travelSum = [];
      if (this.expenseList.emseaapplytravels) {
        this.expenseList.emseaapplytravels.forEach((item) => {
          if (item.emseatransportdetails) {
            let travelItem = 0;
            item.emseatransportdetails.forEach((feeItem) => {
              feeItem.approve_conversion_rate = '1';
              travelItem += parseFloat(feeItem.transport_fee) ? parseFloat(feeItem.transport_fee) : 0;
            });
            travelSum.push(travelItem);
          }
        });
      }
      return travelSum;
    },
    hotelFee() {
      let hotelSum = 0;
      if (this.expenseList.emsearentdetails) {
        this.expenseList.emsearentdetails.forEach((item) => {
          hotelSum += parseFloat(item.rent_fee) ? parseFloat(item.rent_fee) : 0;
        });
      }
      return hotelSum;
    },
    subsidyFee() {
      let subsidySum = 0;
      if (this.expenseList.emseaassistantdetails) {
        this.expenseList.emseaassistantdetails.forEach((item) => {
          subsidySum += parseFloat(item.assistant_fee) ? parseFloat(item.assistant_fee) : 0;
        });
      }
      return subsidySum;
    },
    otherFee() {
      let otherSum = 0;
      if (this.expenseList.emseaotherfeedetails) {
        this.expenseList.emseaotherfeedetails.forEach((item) => {
          item.happend_date = this.emseaapplyh.emseaapplytravels[0].start_date || null;
          otherSum += parseFloat(item.other_fee) ? parseFloat(item.other_fee) : 0;
        });
      }
      return otherSum;
    },
    totalSum() {
      return parseFloat(this.arraySum(this.travelFee) + this.hotelFee
        + this.subsidyFee + this.otherFee);
    },
    // 获取数据
    emseaapplyh() {
      return this.$store.state.myApply.emseaapplyh;
    },
    applyDate() {
      const date = new Date().toLocaleDateString();// 获取日期："2017/11/15"
      return this.formatDate(date);
    },
    hasAssistantFeeType() {
      return this.$store.state.menuConfig.fee.hasAssistantFeeType || false;
    },
  },
  filters: {
    filterA(value) {
      return `￥${(Math.round(value * 100) / 100).toFixed(2)}`;
    },
  },
};
</script>
