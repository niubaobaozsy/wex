<!--
  describe：差旅申请（第一步）——“添加行程”
  created by：黄喆
  invoice_date：2017-11-17
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myApply/addTravelApply.less';
</style>
<template>
  <div class="add-travel-apply">
    <div class="wrap">
      <ul class="information border-top">
        <li class="information-list border-bottom" @click="showSetTpl">
          <div class="list-between">
            <span class="type">类型</span>
          </div>
          <div class="list-between">
            <span class="choice randomly">{{applyTypeStr}}</span>
            <img v-if="tplCanModify" :src="r_arrow" alt="" class="r-arrow">
          </div>
        </li>
        <li class="information-list border-bottom" v-if="applyType === 'LM'" @click="relation" v-edit :data-edit="relatedApplyIdStr">
          <div class="list-between">
            <span class="type">关联申请单</span>
          </div>
          <div class="list-between">
            <currency currency="¥" :value="relatedApplyStr" :precision="2" placeholder="请选择" :read-only="true"></currency>
            <!-- <span :class="['choice', {'randomly': relatedApplyStr}]">{{relatedApplyStr || '请选择'}}</span> -->
            <img :src="r_arrow" alt="" class="r-arrow">
          </div>
        </li>
        <li class="information-list border-bottom" @click="getApplyer" v-edit :data-edit="applyer[0]?applyer[0].user_full_name:''">
          <div class="list-between">
            <span class="type">申请人</span>
          </div>
          <div class="list-between">
            <span :class="['choice', {'randomly': applyer[0]}]">{{applyer[0]?applyer[0].user_full_name:'请选择'}}</span>
            <img :src="r_arrow" alt="" class="r-arrow">
          </div>
        </li>

        <li class="information-list border-bottom" :class="{'notice': notice && !selectTravle}"
         v-if="applyType === 'CL'&& myApplyMenuCfg[applyType].hasTravelType" @click="showSetTravelType">
          <div class="list-between">
            <span class="type">出差类型</span>
          </div>
          <div class="list-between">
            <span class="choice randomly">{{selectTravle}}</span>
            <img :src="r_arrow" alt="" class="r-arrow">
          </div>
        </li>

         <li class="international" v-if="isUrgentCfg">
          <group class="set-international">
            <x-switch title="是否加急" v-model="is_urgent" :value-map="['N','Y']"></x-switch>
          </group>
        </li>

        <li class="information-list border-bottom" @click="getTravellerpp" v-if="applyType === 'CL'" v-edit.feeStdExp.overStd :data-edit="emseaapplyh.emseaapplytravels[0].travel_persons_name" >
          <div class="list-between">
            <span class="type" v-if="myApplyMenuCfg[applyType].compnayPayAir">出行人</span>
            <span class="type" v-else>出差人</span>
          </div>
          <div class='travel-persons'>
            <div class="list-right">
              <span v-if="togetherNumber > 0" class="randomly">
                {{togetherNumber === 1 ? emseaapplyh.emseaapplytravels[0].travel_persons_name : `共${togetherNumber}人`}}
              </span>
              <span class="message" v-if="togetherNumber == 0">请选择</span>
              <img :src="r_arrow" alt="" class="r-arrow">
            </div>
            <div class="batch" v-if="togetherNumber > 1">
              {{emseaapplyh.emseaapplytravels[0].travel_persons_name}}
            </div>
          </div>
        </li>

        <li class="international" v-if="applyType === 'CL'&& myApplyMenuCfg[applyType].ableINT">
          <group class="set-international">
            <x-switch title="国外差旅" v-model="isINT" :value-map="['GN', 'GW']"></x-switch>
          </group>
        </li>
        <li class="information-list border-bottom describe" :class="{'notice': notice && !reasonDescs}">
          <div class="list-between no-center">
            <span class="type">业务描述</span>
          </div>
          <div class="textarea-text">
            <div class="text">{{reasonDesc}}</div>
            <textarea class="textarea" v-edit :class="{'notice': notice && !reasonDescs}" placeholder="请填写 (必填)" maxlength="40" v-model="reasonDesc"></textarea>
          </div>
          <span class="wordlimit" :class="{'red': reasonDesc.length === 40 }">{{reasonDesc?`${reasonDescs}/40`: "0/40"}}</span>
        </li>
        <li class="information-list border-bottom" v-if="applyType === 'LM'" @click="getMoney" v-edit :data-edit="receiverStr">
          <div class="list-between">
            <span class="type">收款方</span>
          </div>
          <div class="list-between">
            <span :class="['choice', {'randomly': receiverStr}]">{{ receiverStr || '请选择'}}</span>
            <img :src="r_arrow" alt="" class="r-arrow">
          </div>
        </li>
        <li class="information-list border-bottom" v-if="applyType === 'LM'" @click="getMoneyCompany" v-edit :data-edit="coStr">
          <div class="list-between">
            <span class="type">入账单位</span>
          </div>
          <div class="list-between">
            <span :class="['choice', {'randomly': coStr}]">{{ coStr || '请选择'}}</span>
            <img :src="r_arrow" alt="" class="r-arrow">
          </div>
        </li>
        <li class="information-list border-bottom" v-if="applyType === 'LM'">
          <div class="list-between">
            <span class="type">借款金额</span>
          </div>
          <currency class="amount" currency="¥" v-model="loanAmount" :precision="2" placeholder="请输入金额" v-edit></currency>
        </li>
        <li class="information-list border-bottom" v-if="applyType === 'LM'" v-edit :data-edit="emslmloan.expected_repay_date">
          <div class="list-between">
            <span class="type">预计还款日期</span>
          </div>
          <div class="list-between" @click="openCal">
            <span :class="['choice', {'randomly': emslmloan.expected_repay_date}]">{{ emslmloan.expected_repay_date ? emslmloan.expected_repay_date.split(' ')[0] : '请选择'}}</span>
            <img :src="r_arrow" alt="" class="r-arrow">
          </div>
        </li>
      </ul>
      <div class="hint" v-if="applyType === 'LM'">
        温馨提示：如果需要录入税额，请移步PC端操作。
      </div>
      <div class="hint" v-else>
        温馨提示：如果关联项目号，请移步至PC端操作。
      </div>
    </div>
    <actionsheet v-model="showAction" :menus="menus" :show-cancel="showCancel" @on-click-menu="setTpl"></actionsheet>
    <org v-model="orgnization" :show.sync="showOrg" :multi="multiUser" @confirm="onOrgconfirm" />
    <receiver v-model="receiver" :show.sync="showReceiver" :coId="coId" />
    <co :show.sync="showCo" :defCo="defaultConfig.companys" @confirm="onSelectCo" />
    <association-apply v-model="requisition" :show.sync="showRelated" />
    <calendar :show.sync="showCalendar" :disablePast="true" v-model="date"></calendar>
    <actionsheet v-model="showTravelType" :menus="travelTypeListData" :show-cancel="showCancel" @on-click-menu="setTravelType"></actionsheet>
  </div>
</template>
<script>
import { Actionsheet, Group, XSwitch } from 'vux';
import rArrow from '../../../assets/rt-arrow.png';
import org from '../../common/org';
import relatedApply from '../../common/relatedApply';
import co from '../../common/company';
import receiver from '../../common/receiver';
import calendar from '../../common/myCalendar';
import currency from '../../common/currency';
import associationApply from '../../common/associationApply';

export default {
  components: {
    Actionsheet,
    Group,
    XSwitch,
    org,
    relatedApply,
    co,
    receiver,
    calendar,
    currency,
    associationApply,
  },
  data() {
    return {
      lengths: 0,
      orderTypeCode: '',
      r_arrow: rArrow, // huang向左图标路径
      orgnization: [],
      persons_name: '',
      showOrg: false,
      multiUser: false,
      emseaapplytravels: [],
      showAction: false, // 是否显示弹出差旅单类型选择组件
      showCancel: true, // 是否显示取消按钮
      showRelated: false,
      dataList: [],
      myNext: false, // 是否可以下一步
      // 弹出差旅单类型选择组件数据
      menus: {
        // CL: '差旅申请（国内）',
        // CLX: '差旅申请（不定行程）',
        // EA: '其他费用申请（个人）',
        // LM: '个人因公借款', // 美的暂时屏蔽借款
      },
      // lym***借款申请的信息
      showCo: false,
      company: {},
      showReceiver: false,
      showCalendar: false,
      companys: '',
      notice: false,
      applyaList: [],
      getList: [],
      storeData: {},
      canModify: true,
      allTravelTypes: [], // 所有的出差类型
      showTravelType: false, // 是否显示出差类型组件
      travelTypeListData: {    // 出差类型的下拉数据
      },
    };
  },
  computed: {
    selectTravle() {
      if(this.emseaapplyh.attribute15){
        return this.travelTypeListData[this.emseaapplyh.attribute15];
      }
    },
    tplCanModify() {
      if (!this.canModify) {
        return this.canModify;
      }
      return !this.emseaapplyh.fee_apply_id && !this.emslmloan.loan_info_id;
    },
    requisition: {
      get() {
        const feeApplyid = this.emslmloan.fee_apply_id;
        const applyAmount = this.emslmloan.apply_amount || '已关联';
        const result = feeApplyid ? [{ fee_apply_id: feeApplyid, approve_amount: applyAmount }] : [];
        return result;
      },
      set(value) {
        const emslmloan = { fee_apply_id: '', apply_amount: '' };
        if (value[0]) {
          emslmloan.fee_apply_id = value[0].fee_apply_id;
          emslmloan.apply_amount = value[0].approve_amount;
        }
        this.$store.commit('EMSLMLOAN', Object.assign({}, this.emslmloan, emslmloan));
      },
    },
    relatedApplyIdStr() {
      let result = '';
      if (this.requisition.length) {
        this.requisition.forEach((apply) => {
          result += `/${apply.fee_apply_id}`;
        });
      }
      return result;
    },
    relatedApplyStr() {
      const apply = this.requisition[0];
      return apply && apply.approve_amount ? `¥${apply.approve_amount}` : '';
    },
    emslmloan() {
      return this.$store.state.myApply.emslmloan;
    },
    emseaapplyh() {
      return this.$store.state.myApply.emseaapplyh;
    },
    applyCreate() {
      return this.$store.state.myApply.applyCreate;
    },
    applyType() {
      return this.$store.state.myApply.applyCreate.applyType;
    },
    applyTypeStr() {
      switch (this.applyType) {
        case 'CL':
          this.orderTypeCode = 'EA_CL';
          return this.myApplyMenuCfg[this.applyType].name;
        case 'CLX':
          this.orderTypeCode = 'EA_CL';
          return this.myApplyMenuCfg[this.applyType].name;
        case 'EA':
          this.orderTypeCode = 'EA_TY';
          return this.myApplyMenuCfg[this.applyType].name;
        case 'LM':
          this.orderTypeCode = 'LM_PERSONPAY_PUBLIC';
          return this.myApplyMenuCfg[this.applyType].name;
        default:
          return '';
      }
    },
    defaultConfig() {
      return this.$store.state.login.defCfg;
    },
    // 申请人
    applyer() {
      if (this.applyType === 'LM') {
        return this.emslmloan.apply_name ? [{ user_full_name: this.emslmloan.apply_name, user_id: this.emslmloan.apply_by }] : [];
      }
      return this.emseaapplyh.apply_name ? [{ user_full_name: this.emseaapplyh.apply_name, user_id: this.emseaapplyh.apply_by }] : [];
    },
    travelers() {
      const emseaapplytravels = this.$store.state.myApply.emseaapplyh.emseaapplytravels[0];
      const travelPersons = emseaapplytravels.travel_persons ? emseaapplytravels.travel_persons.split(',') : [];
      const travelPersonsName = emseaapplytravels.travel_persons_name ? emseaapplytravels.travel_persons_name.split(',') : [];
      const users = [];
      travelPersons.forEach((person, index) => {
        const user = {
          user_full_name: travelPersonsName[index],
          user_id: person,
        };
        users.push(user);
      });
      return users;
    },
    togetherNumber() {
      const travels = this.emseaapplyh.emseaapplytravels;
      return (travels.length && travels[0].travel_persons_name) ? travels[0].travel_persons_name.split(',').length : 0;
    },
    reasonDescs() {
      return this.reasonDesc ? this.reasonDesc.length : 0;
    },
    reasonDesc: {
      get() {
        if (this.applyType === 'LM') {
          return this.emslmloan.sensitive_info || ''; // YimLee: 借款单和EC单的事由是由sensitive_info字段保存的
        }
        if (this.applyType !== 'LM') {
          return this.emseaapplyh.reason_desc || '';
        }
        return '';
      },
      set(value) {
        if (this.applyType !== 'LM') {
          const emseaapplyh = Object.assign({}, this.emseaapplyh, { reason_desc: value });
          this.$store.commit('EMSEAAPPLYH', emseaapplyh);
        }
        if (this.applyType === 'LM') {
          const emslmloan = Object.assign({}, this.emslmloan, { sensitive_info: value });
          this.$store.commit('EMSLMLOAN', emslmloan);
        }
      },
    },
    date: {
      get() {
        return this.emslmloan.expected_repay_date;
      },
      set(value) {
        const emslmloan = Object.assign({}, this.emslmloan, { expected_repay_date: value });
        this.$store.commit('EMSLMLOAN', emslmloan);
      },
    },
    coId() {
      return this.$store.state.myApply.emslmloan.company_id || '';
    },
    // lym***借款申请信息
    coStr() {  // 选择入账单位
      let company = this.$store.state.myApply.emslmloan.company_name;
      if (!company) {
        company = this.defaultConfig.company || {};
        this.onSelectCo(company);
        return company.company_name;
      }
      return company;
    },
    receiver: {
      get() {
        const obj = {};
        if (this.emslmloan.receiver) {
          obj.receiver = this.emslmloan.receiver;
          obj.receiver_en = this.emslmloan.receiver_en;
          obj.bank_name = this.emslmloan.bank_name;
          obj.bank_code = this.emslmloan.bank_code;
          obj.bank_account = this.emslmloan.bank_account;
          obj.bank_adress = this.emslmloan.bank_adress;
        } else if (this.defaultConfig.cmEmsEmpReceiver) {
          const defaultReceiver = this.defaultConfig.cmEmsEmpReceiver;
          obj.receiver = defaultReceiver.receiver;
          obj.receiver_en = defaultReceiver.receiver_en;
          obj.bank_name = defaultReceiver.bank_name;
          obj.bank_code = defaultReceiver.bank_code;
          obj.bank_account = defaultReceiver.bank_account;
          obj.bank_adress = defaultReceiver.bank_adress;
          this.$store.commit('EMSLMLOAN', Object.assign({}, this.emslmloan, obj));
        }
        return obj;
      },
      set(value) {
        this.$store.commit('EMSLMLOAN', Object.assign({}, this.emslmloan, {
          receiver: value.receiver,
          receiver_en: value.receiver_en,
          bank_name: value.bank_name,
          bank_code: value.bank_code,
          bank_account: value.bank_account,
          bank_adress: value.bank_adress,
        }));
      },
    },
    receiverStr() { // 选择收款方
      if (Object.keys(this.receiver).length) {
        return `${this.receiver.receiver}[尾号${this.receiver.bank_account.slice(-4)}]`;
      }
      return '';
    },
    loanAmount: {
      get() {
        return this.$store.state.myApply.emslmloan.amount;
      },
      set(value) {
        this.$store.commit('EMSLMLOAN', Object.assign({}, this.emslmloan, { amount: value }));
      },
    },
    myApplyMenuCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.children;
    },
    isUrgentCfg(){
       return this.$store.state.menuConfig.fee.children.myApply.isUrgent
    },
    is_urgent:{
      get() {
        if (this.isUrgentCfg) {
          return this.$store.state.myApply.emseaapplyh.is_urgent || 'N';
        }
      },
      set(value) {
        if (this.isUrgentCfg) {
          this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, { is_urgent: value }));
        }
      },
    },
    isINT: {
      get() {
        return this.$store.state.myApply.emseaapplyh.attribute21 || 'GN';
      },
      set(value) {
        if (this.myApplyMenuCfg[this.applyType].ableINT) {
          this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, { attribute21: value }));
        }
      },
    },
  },
  watch: {
    'emseaapplyh.apply_by'(newVal, oldVal) {
      if (newVal && newVal !== oldVal) {
        this.getTravelTypeById(this.emseaapplyh.apply_by);
      }
    },
  },
  mounted() {
    // 判断是否要显示可选类型
    if (this.$route.query.addType && (this.$route.query.addType === 'CL' || this.$route.query.addType === 'CLX')) {
      Object.keys(this.myApplyMenuCfg).filter(item => ['CL', 'CLX'].indexOf(item) > -1).forEach((item) => {
        this.menus[item] = this.myApplyMenuCfg[item].name;
      });
      // this.canModify = true;
    } else if (this.$route.query.addType && (this.$route.query.addType === 'LM' || this.$route.query.addType === 'EA')) {
      // this.showAction = false;
      this.canModify = false;
    } else {
      Object.keys(this.myApplyMenuCfg).forEach((item) => {
        this.menus[item] = this.myApplyMenuCfg[item].name;
      });
    }
    // 保存原始的store数据
    this.storeData = this.emseaapplyh;
    const billId = this.$route.query.id;
    const applyType = this.$route.query.type;
    if (billId && applyType && !this.applyType) {
       // state存myApplyMenuCfg
        this.$store.commit('APPLY_CREATE', { applyType: applyType, myApplyMenuCfg: this.myApplyMenuCfg});
      // this.$store.commit('APPLY_CREATE', { applyType });
      this.getBillDetail();
    } else if (!billId && !applyType && !this.applyType) {
      this.showAction = true;
      // state存myApplyMenuCfg
      this.$store.commit('APPLY_CREATE', { applyType: 'CL', myApplyMenuCfg: this.myApplyMenuCfg});
      // this.$store.commit('APPLY_CREATE', { applyType: 'CL' });
      this.$nextTick(() => {
        this.initNewApply();
        this.getFormTemplates();
      });
    } else if (!billId && !applyType && this.applyType) {
      this.initNewApply();
      this.getFormTemplates();
    }
    this.getDictData(); // 获取下拉数据
  },
  methods: {
    // 出差类型的选择,显示中文
    setTravelType(key) {
      if(key !=='cancel'){
        this.emseaapplyh.attribute15 = key;
        this.$store.commit('EMSEAAPPLYH', this.emseaapplyh);
      }
    },

    // 弹出出差类型的选择框
    showSetTravelType() {
      this.showTravelType = true;
    },

    // 根据申请人，获取申请人所在入账单位对应报销标准的出差类型
    getTravelTypeById(id) {
      if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].hasTravelType) {
        this.$store.dispatch('getTravelTypeById', { query_param: { apply_by: id } }).then((res) => {
          if (res.code === '0000') {
            let travalTypData = res.data.info || [];
            this.travelTypeListData = {};
            travalTypData.forEach(item => {
              item.value = item.attribute1;
              item.name = this.$method.getValueInArray(item.value, this.allTravelTypes, 'itemValue', 'itemName'); // 根据value 获取 name
              this.travelTypeListData[item.value] = item.name;
            })
          }
        });
      }
    },

    // 批量获取业务字典编码对应的数据
    async getDictData() {
      if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].hasTravelType) {
        this.allTravelTypes = await this.$method.getDataFromDict('TRAVEL_TYPE'); // 获取所有出差类型数据
      }
    },
    getRelatedlist(list) {
      this.applyaList = list;
      this.lengths = this.applyaList.length;
      let feeApplyid = '';
      let messagesApply = '';
      if (this.lengths) {
        let messages = 0;
        this.applyaList.forEach((item) => {
          messages += item.approve_amount - 0;
          feeApplyid += `${item.fee_apply_id},`;
        });
        messagesApply = `共${this.lengths}张，可借款￥${messages.toFixed(2)}`;
      }
      feeApplyid = feeApplyid.substr(0, feeApplyid.length - 1);
      const emslmloan = Object.assign({}, this.emslmloan, { fee_apply_id: feeApplyid, messages_apply: messagesApply });
      this.$store.commit('EMSLMLOAN', emslmloan);
    },
    initNewApply() {
      const userInfo = this.$store.state.userInfo.user;
      const orgId = Object.keys(userInfo.org)[0];
      const orgName = userInfo.org[orgId];
      if (this.applyType !== 'LM') {
        const emseaapplyh = {
          tenant_id: userInfo.tenantId,
          created_by: userInfo.userId,
          created_name: userInfo.userName,
          apply_by: this.emseaapplyh.apply_by ? this.emseaapplyh.apply_by : userInfo.userId,
          apply_name: this.emseaapplyh.apply_name ? this.emseaapplyh.apply_name : userInfo.userName,
          org_id: orgId,
          org_name: orgName,
          apply_date: this.getCurTimeStr(),
          creation_date: this.getCurTimeStr(),
          is_travel_sure: this.applyType === 'CLX' ? 'N' : 'Y'
        };
        if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].hasTravelType) {
          emseaapplyh.attribute15 = this.emseaapplyh.attribute15 ? this.emseaapplyh.attribute15 : null;
        }
        if (!this.emseaapplyh.emseaapplytravels[0] || !this.emseaapplyh.emseaapplytravels[0].travel_persons) {
          emseaapplyh.emseaapplytravels = [{
            travel_persons: userInfo.userId,
            travel_persons_name: userInfo.userName,
          }];
        }
        const travelsPersons = this.emseaapplyh.emseaapplytravels[0].travel_persons_name ? this.emseaapplyh.emseaapplytravels[0].travel_persons_name.split(',') : [];
        if (travelsPersons.length === 0) {
          const travelsObj = {
            travel_persons_name: userInfo.userName,
            travel_person_count: 1,
          };
          const emseaapplytravels = [];
          if (this.emseaapplyh.emseaapplytravels.length) {
            this.emseaapplyh.emseaapplytravels.forEach((travel) => {
              emseaapplytravels.push(Object.assign({}, travel, travelsObj));
            });
          } else {
            emseaapplytravels.push(obj);
          }
          const emseaapplyhList = Object.assign({}, this.emseaapplyh, { emseaapplytravels });
          this.$store.commit('EMSEAAPPLYH', emseaapplyhList);
        }
        this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, emseaapplyh));
      } else {
        const emslmloan = {
          apply_by: userInfo.userId,
          apply_name: this.emseaapplyh.apply_name ? this.emseaapplyh.apply_name : userInfo.userName,
          org_id: orgId,
          org_name: orgName,
          apply_date: this.getCurTimeStr(),
        };
        this.$store.commit('EMSLMLOAN', Object.assign({}, this.emslmloan, emslmloan));
      }
    },
    getCurTimeStr() {
      const time = new Date();
      return `${time.getFullYear()}-${time.getMonth() < 9 ? '0' : ''}${time.getMonth() + 1}-${time.getDate() <= 9 ? '0' : ''}${time.getDate()} ${time.getHours <= 9 ? '0' : ''}${time.getHours()}:${time.getMinutes() <= 9 ? '0' : ''}${time.getMinutes()}:${time.getSeconds() <= 9 ? '0' : ''}${time.getSeconds()}`;
    },
    // 打开日历
    openCal() {
      this.showCalendar = true;
    },
    //      有id的时候获取数据
    getBillDetail() {
      this.showAction = false;
      if (this.applyType === 'LM') {
        this.showLoading();
        this.$store.dispatch('getLoan', { loan_info_id: this.$route.query.id }).then((res) => {
          this.hideLoading();
          if (res.code === '0000') {
            const emslmloan = res.data.emslmloan;
            this.$store.commit('EMSLMLOAN', emslmloan); // 获取详情数据
            if (emslmloan.fee_apply_id) {
              this.selectAvaliableFeeApply(emslmloan.fee_apply_code);
            }
          } else {
            this.showToast({ msg: res.msg });
          }
        });
      } else {
        const params = {
          fee_apply_id: this.$route.query.id,
          is_myrun: 'N',
        };
        this.showLoading();
        this.$store.dispatch('myFeeReQuest', params)
          .then((rep) => {
            this.hideLoading();
            if (rep.code === '0000') {
              const emseaapplyh = rep.data.emseaapplyh;
              const standardTypeDict = [{
                  label: '市内交通费',
                  value: 'SNJTF',
                }, {
                  label: '餐费',
                  value: 'CF',
                }
              ];
              emseaapplyh.emseaassistantdetails.forEach((item) => {
                if (item.standard_type) {
                  item.standardType = standardTypeDict.filter((i) => i.value === item.standard_type)[0];
                }
              });
              if (emseaapplyh.order_type === 'CL' && emseaapplyh.is_travel_sure === 'N') {
                // state存myApplyMenuCfg
                // this.$store.commit('APPLY_CREATE', { applyType: 'CLX' });
                 this.$store.commit('APPLY_CREATE', { applyType: 'CLX', myApplyMenuCfg: this.myApplyMenuCfg});
              }
              this.$store.commit('EMSEAAPPLYH', emseaapplyh);
            } else {
              this.showToast({ msg: rep.msg });
            }
          });
      }
    },
    //    获取差旅类型
    showSetTpl() {
      if (this.tplCanModify) {
        this.showAction = true;
      } else if (!this.canModify) {
        this.showToast({ msg: '该单据不能修改类型', width: '9em' });
      } else {
        this.showToast({ msg: '单据已保存草稿，不能修改类型', width: '9em' });
      }
    },
    //    关联单
    relation() {
      this.showRelated = true;
    },
    //    获取申请人
    getApplyer() {
      this.orgnization = this.applyer;
      this.showOrg = true;
      this.multiUser = false;
    },
    //    获取出差人
    getTravellerpp() {
      this.orgnization = this.travelers;
      this.showOrg = true;
      this.multiUser = true;
    },
    //    收款方
    getMoney() {
      this.showReceiver = true;
    },
    //    入账单位
    getMoneyCompany() {
      this.showCo = true;
    },
    // 获取必须属性
    getFormTemplates() {
      const params = {
        order_type: this.orderTypeCode,
      };
      this.showLoading();
      this.$store.dispatch('getFormTemplates', params)
        .then((rep) => {
          this.hideLoading();
          if (rep && rep.code === '0000') {
            const info = rep.data.info[0];
            const formTemplate = {
              order_type: info.order_type,
              form_template_id: info.form_template_id,
              form_template_name: info.form_template_name,
              order_template_id: info.order_template_id,
              order_template_name: info.order_template_name,
            };
            if (this.applyType !== 'LM') {
              this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, formTemplate));
            } else {
              this.$store.commit('EMSLMLOAN', Object.assign({}, this.emslmloan, formTemplate));
            }
          } else if (rep && rep.code) {
            this.showToast({ msg: `请求异常(${rep.code})` });
          }
        });
    },
    setTpl(key) { // 点击弹出差旅单类型选择组件
      let applyType = '';
      if (key === 'CLX') {
        applyType = 'CLX';
      } else if (key === 'EA') {
        applyType = 'EA';
      } else if (key === 'LM') {
        applyType = 'LM';
      } else if (key === 'CL') {
        applyType = 'CL';
      } else if (!this.applyType) {
        applyType = 'CL';
      }
      if (applyType && applyType !== this.applyType) {
        // state存myApplyMenuCfg
        // this.$store.commit('APPLY_CREATE', { applyType });
         this.$store.commit('APPLY_CREATE', { applyType: applyType, myApplyMenuCfg: this.myApplyMenuCfg});
        this.$store.commit('EMSEAAPPLYH', this.storeData);
        this.$nextTick(() => {
          this.initNewApply();
          this.getDictData(); // 获取下拉数据
          this.getFormTemplates();
        });
      }
    },
    onOrgconfirm(users) {
      if (this.multiUser) {
        if (users.length > 1) {
          this.showToast({ msg: '多人出差，如行程不一致，请移步PC端，谢谢' });
        }
        const obj = {
          travel_persons: '',
          travel_persons_name: '',
        };
        users.forEach((user) => {
          obj.travel_persons += `${user.user_id},`;
          obj.travel_persons_name += `${user.user_full_name},`;
        });
        obj.travel_persons = obj.travel_persons.substr(0, obj.travel_persons.length - 1);
        obj.travel_persons_name = obj.travel_persons_name.substr(0, obj.travel_persons_name.length - 1);
        const emseaapplytravels = [];
        if (this.emseaapplyh.emseaapplytravels.length) {
          this.emseaapplyh.emseaapplytravels.forEach((travel) => {
            emseaapplytravels.push(Object.assign({}, travel, obj));
          });
        } else {
          emseaapplytravels.push(obj);
        }
        // 如果出差人数量为1，申请人也需跟着出差人改变
        if (users.length === 1 && this.emseaapplyh.apply_name !== users[0].user_full_name) {
          const applyer = {
            apply_by: users[0].user_id,
            apply_name: users[0].user_full_name,
          };
          this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, applyer));
        }
        const emseaapplyh = Object.assign({}, this.emseaapplyh, { emseaapplytravels });
        this.$store.commit('EMSEAAPPLYH', emseaapplyh);
      } else {
        const obj = {
          apply_by: users[0] ? users[0].user_id : '',
          apply_name: users[0] ? users[0].user_full_name : '',
        };
        if (this.applyType === 'LM') {
          this.$store.commit('EMSLMLOAN', Object.assign({}, this.emslmloan, obj));
        } else {
          this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, obj));
        }
        // 如果出差人为1个时，改变申请人，出差人也需跟着改变
        const applytravelsNum = (this.emseaapplyh.emseaapplytravels[0].travel_persons_name.split(',')).length;
        if (this.applyType !== 'LM' && applytravelsNum === 1 && this.emseaapplyh.apply_name !== this.emseaapplyh.emseaapplytravels[0].travel_persons_name) {
          const traveler = {
            travel_persons: users[0] ? users[0].user_id : '',
            travel_persons_name: users[0] ? users[0].user_full_name : '',
          };
          const emseaapplytravels = [];
          if (this.emseaapplyh.emseaapplytravels.length) {
            this.emseaapplyh.emseaapplytravels.forEach((travel) => {
              emseaapplytravels.push(Object.assign({}, travel, traveler));
            });
          }
          this.$store.commit('EMSEAAPPLYH', Object.assign({}, this.emseaapplyh, { emseaapplytravels }));
        }
      }
      this.orgnization = [];
    },
    // 下一步
    beforeNext() {
      let next = true;
      if (!this.applyer[0]) {
        this.showToast({ msg: '请填写：申请人' });
        next = false;
      } else if (this.applyType === 'CL' && !this.emseaapplyh.emseaapplytravels[0]) {
        this.showToast({ msg: '请填写：出差人' });
        next = false;
      } else if (this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].hasTravelType && !this.emseaapplyh.attribute15) {
        this.showToast({ msg: '请填写：出差类型' });
        this.notice = true;
        next = false;
      } else if (!this.reasonDesc) {
        this.showToast({ msg: '请填写：业务描述' });
        this.notice = true;
        next = false;
      } else if (this.applyType === 'LM' && this.emslmloan.apply_amount && this.emslmloan.amount && this.emslmloan.apply_amount < this.emslmloan.amount) {
        this.showToast({ msg: '借款金额不能大于关联申请单的批准金额' });
        next = false;
      } else if (this.applyType === 'LM' && !this.receiverStr) {
        this.showToast({ msg: '请填写：收款方' });
        next = false;
      } else if (this.applyType === 'LM' && !this.coStr) {
        this.showToast({ msg: '请填写：入账单位' });
        next = false;
      } else if (this.applyType === 'LM' && !this.emslmloan.amount) {
        this.showToast({ msg: '请填写：借款金额' });
        next = false;
      } else if (this.applyType === 'LM' && !this.emslmloan.expected_repay_date) {
        this.showToast({ msg: '请填写：还款日期' });
        next = false;
      } else if (!this.emseaapplyh.emseaapplytravels[0].travel_persons_name && this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir) {
        this.showToast({ msg: '行程出行人不能为空！' });
        next = false;
      } else {
        next = true;
      }
        // if (!this.travelRoute[i].travel_persons && this.applyType === 'CL' && this.myApplyMenuCfg[this.applyType].compnayPayAir) {
        //   this.showToast({ msg: '行程出行人不能为空！' });
        //   next = false;
        //   break;
        // }
      return next;
    },
    onSelectCo(selCo) {
      const obj = {
        company_id: selCo.company_id || '',
        ou_id: selCo.ou_id || '',
        proxy_user: selCo.proxy_user || '',
        company_name: selCo.company_name || '',
      };
      const emslmloan = Object.assign({}, this.emslmloan, obj);
      this.$store.commit('EMSLMLOAN', emslmloan);
    },
    selectAvaliableFeeApply(feeApplyCode) {
      const params = {
        page_size: 100,
        page_number: 1,
        query_param: {
          biz_flag: '0',
          fee_apply_code: feeApplyCode,
          reason_desc: '',
        },
      };
      this.showLoading();
      this.$store.dispatch('selectAvaliableFeeApply', params)
        .then((rep) => {
          this.hideLoading();
          if (rep && rep.code === '0000' && rep.data && rep.data.info) {
            this.$store.commit('EMSLMLOAN', Object.assign({}, this.emslmloan, { apply_amount: rep.data.info[0].approve_amount }));
          } else if (rep && rep.code) {
            this.showToast({ msg: `请求异常(${rep.code})` });
          }
        });
    },
  },
};
</script>
