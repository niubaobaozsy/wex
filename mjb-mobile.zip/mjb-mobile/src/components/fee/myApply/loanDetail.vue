
<!--
  describe：查看借款申请单
  created by：黄喆
  date：2017-12-2
-->
<template>
  <div>
    <my-header :title='top.type' @previous='goBack' @on-click="saveDraft"></my-header>
    <div class='wrap has-footer' v-if="emslmloan">
      <ul class="data">
        <li class="data-list border-bottom">
          <div class="type-name">
            类型
            <!-- <i class="state" :class="{'pass': emslmloan.order_status !== 'SUBMITED'}">{{ emslmloan.order_status == 'SUBMITED' ? "审批中" : "已通过" }}</i> -->
          </div>
          <div class="info">
            <div>{{emslmloan.order_template_name}}</div>
            <div class="number">单号:{{emslmloan.loan_info_code}}</div>
          </div>
        </li>
        <li class="data-list border-bottom">
          <div class="type-name">
            申请人
          </div>
          <div class="info">
            {{emslmloan.apply_name}}
          </div>
        </li>
        <li class="data-list border-bottom">
          <div class="type-name">
            业务描述
          </div>
          <div class="info">
            {{emslmloan.sensitive_info}}
          </div>
        </li>
        <li class="data-list border-bottom">
          <div class="type-name">
            收款方
          </div>
          <div class="info">
            {{emslmloan.receiver}}
          </div>
        </li>
        <li class="data-list border-bottom">
          <div class="type-name">
            入账单位
          </div>
          <div class="info">
            {{emslmloan.company_name}}
          </div>
        </li>
        <li class="data-list border-bottom">
          <div class="type-name">
            借款金额
          </div>
          <div class="info">
            {{emslmloan.approve_amount}}
          </div>
        </li>
        <li class="data-list">
          <div class="type-name">
            预计还款日期
          </div>
          <div class="info">
            {{emslmloan.expected_repay_date?emslmloan.expected_repay_date.substring(0, 10): ''}}
          </div>
        </li>
      </ul>
      <!-- 查看附件 -->
      <div class="border-bottom margin" @click="checkInvioce">
        <div class="type-name">附件</div>
        <div class="sum">{{`共${this.imgList.length}份`}}</div>
        <div class="info">
          <img :src="top.arrow" alt="" class="arrow">
        </div>
      </div>
      <!-- 查看关联申请单 -->
      <!-- <div class="border-bottom margin" @click="showApply = true">
        <div class="type-name">关联申请单</div>
        <div class="sum">共1张</div>
        <div class="info">
          <img :src="top.arrow" alt="" class="arrow">
        </div>
      </div> -->
      <div class="border-bottom margin">
        <div class="type-name">
          审核记录
        </div>
        <p class='remind' :class='{"disable": !canRemind}' @click='reminders' v-if="emslmloan.order_status === 'SUBMITED'">催办</p>
      </div>
      <my-progress :title='log' :list="listNew" class="my-progress"></my-progress>
      <pro :title="auditing"></pro>
      <alert v-model='remindersShow' :content='prompt'></alert>
      <relevance-apply :loanList="emslmloan" :show="showApply" @on-hide="hideArea"></relevance-apply>
      <confirm v-model='show1' :title='title3' @on-confirm='onConfirm()'></confirm>
      <div class='bottom' @click='withdraw()' v-if="emslmloan.order_status === 'SUBMITED'">撤回</div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import { Confirm, Alert } from 'vux';
import MyHeader from '../../common/header';
import pro from '../../common/budGetsee';
import rtarrow from '../../../assets/rt-arrow.png';
import myProgress from '../../common/proGress';
import RelevanceApply from '../../common/relevanceApply';

export default {
  components: {
    MyHeader,
    Confirm,
    Alert,
    pro,
    myProgress,
    RelevanceApply,
  },
  data() {
    return {
      top: {
        type: '查看借款单',
        arrow: rtarrow,
      },
      emslmloan: {},
      auditing: [],
      listNew: [],
      log: [],
      show1: false,
      remindersShow: false,
      prompt: '',
      title3: '撤回该报销单',
      canRemind: true,
      imgList: [],
      showApply: false,
    };
  },
  created() {
    this.getLoanForApp();
  },
  computed: {
    loanObj() {
      console.log('111', this.$store.state.myApply.loanObj);
      return this.$store.state.myApply.loanObj;
    },
    applyaList() {
      console.log('222', this.$store.state.myApply.applyaList);
      return this.$store.state.myApply.applyaList;
    },
  },
  methods: {
    // 点击组件显示隐藏
    hideArea() {
      this.showApply = false;
    },
    // 获取大图
    getBigImg(id) {
      this.showLoading();
      this.$store.dispatch('getBigImg', id).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          if (res.data) {
            this.imgList.push(res.data);
            this.$store.commit('TR_ENCLOSURE_LIST', this.imgList);
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    // 获取附件
    getAttachment() {
      const params = {
        source_system: 'Expense',
        source_order_id: this.$route.query.id,
        source_order_type: 'LM',
      };
      this.showLoading();
      this.$store.dispatch('getAttachment', params).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          if (res.data && res.data.info) {
            this.$store.commit('TR_ENCLOSURE_LIST', []);
            const list = res.data.info;
            list.forEach((item) => {
              this.getBigImg(item.file_id);
            });
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    // 数据获取
    getLoanForApp() {
      this.showLoading();
      const obj = {
        loan_info_id: this.$route.query.id,
      };
      this.$store.dispatch('getLoanForApp', obj).then((res) => {
        this.hideLoading();
        if (res.code === '0000') {
          this.emslmloan = res.data.order_msg.emslmloan;
          this.auditing = res.data.process_log;
          this.getlog().then(() => {
            this.getAttachment();
            if (this.emslmloan.order_status === 'SUBMITED') {
              this.grtFlowt();
            }
          });
        } else if (res) {
          this.showToast({ msg: `请求异常[${res.code}]: ${res.msg}` });
          this.$router.push({ path: '/fee/myApply/applyHome/draft' });
        }
      });
    },
    //      审批节点未审批
    grtFlowt() {
      return new Promise((resolve) => {
        this.$store.dispatch('grtFlowt', {
          formInstanceId: this.emslmloan.formInstanceId, // this.$route.query.id,
          model_id: '001',
          template_form_id: this.emslmloan.form_template_id,
        }).then((res) => {
          if (res && res.code === '0000') {
            let curIndex = 0;
            res.data.forEach((flowt, index) => {
              if (flowt.current) {
                curIndex = index;
              }
            });
            this.listNew = res.data.slice(curIndex);
            resolve(res.data);
          } else if (res) {
            this.showToast({ msg: `请求异常[${res.code}]: ${res.msg}` });
          }
        });
      });
    },
    // 获取审批流程
    getlog() {
      return new Promise((resolve) => {
        this.$store.dispatch('getlog', {
          formInstanceId: this.emslmloan.formInstanceId, // this.order.formInstanceId,
          model_id: '001',
          template_form_id: this.emslmloan.form_template_id,
        }).then((res) => {
          if (res && res.code === '0000') {
            let latelyRemind = '';
            this.log = res.data.filter(log => log.fdActionKey.indexOf('走分支') === -1);
            res.data.forEach((log) => {
              if (log.fdActionKey === '催办') {
                latelyRemind = log.fdHandleDate.split(' ')[0];
              }
            });
            if (latelyRemind) {
              this.canRemind = Date.now() - Date.parse(new Date(latelyRemind)) > 86400000;
            }
            resolve(res.data);
          } else if (res) {
            this.showToast({ msg: `请求异常[${res.code}]: ${res.msg}` });
          }
        });
      });
    },
    // 催办
    reminders() {
      if (this.canRemind) {
        this.showLoading();
        this.$store.dispatch('myReminDers', {
          auditNote: '请审批',   //  审批意见
          formInstanceId: this.emslmloan.formInstanceId,  //  EA单
          model_id: '001',
          template_form_id: this.emslmloan.form_template_id,  // 表单模板id
        }).then((res) => {
          this.hideLoading();
          if (res.code === '0000') {
            this.showToast({ msg: '催办成功', time: 500 });
            setTimeout(() => {
              this.getLoanForApp();
            }, 500);
          } else if (res) {
            this.showToast({ msg: `催办失败[${res.code}]: ${res.msg}` });
          }
        });
      } else {
        this.prompt = '今天已经成功提醒审批人,明天再来催办吧';
        this.remindersShow = true;
      }
    },
    onConfirm() {
      this.showLoading();
      this.$store.dispatch('myBillBack', {
        auditNote: '测试撤回',   //  this.list.fdAuditNote审批意见
        formInstanceId: this.emslmloan.formInstanceId,
        model_id: '001',
        template_form_id: this.emslmloan.form_template_id,  // 表单模板id
      }).then((res) => {
        if (res.code === '0000') {
          this.hideLoading();
          this.$router.push({ path: '/fee/myApply/applyHome/draft' });
        } else {
          this.hideLoading();
          this.showToast({ msg: '操作错误，请重试' });
          console.log(res);
        }
      });
    },
    goBack() {
      this.$router.go(-1);
    },
    checkInvioce() {
      this.$router.push({ path: '/fee/myApply/invoiceList', query: { imgList: this.imgList } });
    },
    withdraw() {
      // console.log(this.order.order_status);
      this.show1 = !this.show1;
    },
    saveDraft() {
      console.log('选择中');
      const obj = {
        data: this.$route.query.id,
        show: true,
      };
      const loanObj = Object.assign({}, this.loanObj, obj);
      this.$store.commit('LOANOBJ', loanObj);
      console.log(this.loanObj);
      this.$router.go(-1);
    },
  },
};
</script>

<style lang='less' scoped>
@white: #ffffff;

.wrap {
  margin-top: 57px;
  .data {
    background: @white;
    padding-left: 15px;
    .data-list {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 16px;
      padding: 12px 0;
      padding-right: 15px;
      .type-name {
        display: flex;
        align-items: center;
        width: 106px;
        color: #858585;
        .state {
          font-style: normal;
          background: #fcb23c;
          width: 52px;
          height: 19px;
          border-radius: 12px;
          font-size: 11px;
          color: #ffffff;
          line-height: 19px;
          text-align: center;
          margin-left: 10px;
          &.pass {
            background: #3da5fe;
          }
        }
      }
    }
    .info {
      text-align: end;
      .number {
        font-size: 14px;
        color: #9B9B9B;
      }
      &.reson {
        text-align: start;
        width: 250px;
      }
    }
  }
  .margin {
    background: @white;
    margin-top: 10px;
    padding: 12px 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .type-name {
      color: #858585;
    }
    .sum {
      flex: 1;
      font-size: 16px;
      color: #000000;
      text-align: right;
      margin-right: 12.5px;
    }
    .remind {
      width: 70px;
      height: 30px;
      background: #3DA5FE;
      color: #FFFFFF;
      text-align: center;
      line-height: 30px;
      border-radius: 40px;
      &.disable {
        background-color: #c1c1c1;
      }
    }
    .arrow {
      display: block;
      width: 9px;
      height: 16px;
    }
  }
  .bottom {
    width: 100%;
    height: 50px;
    text-align: center;
    line-height: 50px;
    margin-bottom: 0;
    background: #ffffff;
    box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
    position: fixed;
    bottom: 0;
  }
}
</style>
