<!--
  describe：预算来源组件
  created by：欧倩伶
  date：2017-11-10
-->
<template>
  <div class="budget-source" v-if="show">
    <my-header :title="top.title" :showBack="true" :showRedDot="true" @previous="hide"></my-header>
    <div class="has-header" :style="style" >
      <div class="border content">
        <div v-for="(item, index) in sourceList" :key="index" @click="onSelected(item)">
          <div class="row border-top">{{item.budget_node_desc}}</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import MyHeader from '../../common/header';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {
      style: '',
      top: {
        title: '选择预算来源',
      },
      sourceList: [],
    };
  },
  props: {
    show: Boolean,
    deptId: String,
    sourcesId: String,
  },
  watch: {
    show(val) {
      if (val) {
        this.getSourceList();
      }
    },
  },
  methods: {
    // 获取预算来源列表
    getSourceList() {
      this.showLoading();
      const pamars = {
        busi_org_id: this.deptId,
        fee_type_id: this.sourcesId,
        page_number: 1,
        page_size: 1000,
      };
      this.$store.dispatch('getBudgetSource', pamars)
        .then((rep) => {
          this.hideLoading();
          if (rep.code === '0000') {
            this.sourceList = rep.data.info;
          } else {
            this.showToast({ msg: rep.msg });
          }
        }, () => {
          this.hideLoading();
          this.showToast({ msg: '页面开小差，请重试' });
        });
    },
    hide() {
      this.$emit('on-hide');
    },
    // 选择预算来源
    onSelected(item) {
      this.$emit('on-select', item);
    },
    init() {
      this.style = `height: ${window.screen.height - 50}px; overflow: auto;`;
    },
  },
  mounted() {
    this.init();
  },
};
</script>
<style lang="less" scoped>
.budget-source{
  position: fixed;
  top: 0;
  z-index: 100;
  width: 100%;
  height: 100%;
  background: #F4F4F4;
}
.content {
  background: #fff;
  .row {
    // height: 50px;
    padding: 14px 15px;
    box-sizing: border-box;
    line-height: 22px;
  }
}
</style>
