<style lang="less" scoped>
@import "../../../assets/css/fee/myApply/addAirTickerBudget.less";
</style>
<template>
  <div>
    <my-header v-if="EAflag" class="mb10" :title="top.title" :showBack="true" @previous="goBack"></my-header>
    <div :class="{'has-header':EAflag,'mt67':EAflag,'mt10':!EAflag}">
      <div class="detail" v-for="(item,index) in airTicketBudgetList" :key="index">
        <div class="headline border">
          <div class="flexItem" @click="show(index)">
            <img v-if="!bgIsclose[index]" :src="down" class="down"><img v-if="bgIsclose[index]" :src="up" class="down">
            <div>预算来源{{index+1}}</div>
          </div>
          <div class="del" @click="delItem(index)" v-edit :data-edit="item.busi_org_id">删除</div>
        </div>
        <div v-if="!bgIsclose[index]" class="box border-bottom">
          <div class="amoutItem border-bottom">
            <div>申请金额</div>
            <currency v-focus class="amount" currency="¥" v-model="item.apply_amount" :precision="2" placeholder="请输入金额" v-edit></currency>
          </div>
          <div class="cell border-bottom">
            <div class="text">预算部门</div>
            <div class="flexItem" @click="showBudgetOrg(index)" v-edit :data-edit="item.busi_org_id">
              <p>{{item.busi_org_name}}</p>
              <img class="rightArrow" :src="rightArrow" alt="">
            </div>
          </div>
          <div class="cell border-bottom">
            <div class="text">经济事项</div>
            <div class="flexItem" @click="economicsEvent(index)" v-edit :data-edit="item.fee_type_id">
              <p>{{item.fee_type_name}}</p>
              <img class="rightArrow" :src="rightArrow" alt="">
            </div>
          </div>
          <div class="cell border-bottom" style="height: auto;">
            <div class="text">预算来源</div>
            <div class="flexItem" @click="budgetSource(index)" v-edit :data-edit="item.budget_node_id">
              <p>{{(autoShow && listIndex === index) ? airTicketBudgetList[listIndex].budget_node_desc : item.budget_node_desc}}</p>
              <img class="rightArrow" :src="rightArrow" alt="">
            </div>
          </div>

          <div class="cell border-bottom" style="height: auto;">
            <div class="text">出行人</div>
            <div class="flexItem" @click="getTraveler(item,index)" v-edit :data-edit="item.attribute3">
              <p>{{item.attribute3?item.attribute3:'请选择'}}</p>
              <img class="rightArrow" :src="rightArrow" alt="">
            </div>
          </div>

          <div class="cell area border-bottom" style="height: auto;">
            <div class="text">地点</div>
            <div class="flexItem">
              <input-box v-edit.feeStdExp.overStd :data-edit="item.attribute7 || ''" :placeholder="'出发地'" :textCenter="true" :isreadOnly="true" :pickValue="item.attribute7" @select="openArea('start', index)"></input-box>
              <span class="line">—</span>
              <input-box v-edit.feeStdExp.overStd :data-edit="item.attribute10 || ''" :placeholder="'目的地'" :textCenter="true" :isreadOnly="true" :pickValue="item.attribute10" @select="openArea('end', index)"></input-box>
            </div>
          </div>
          <div class="cell columns travel-date-item border-bottom" style="height: auto;">
            <span class="text">日期</span>
            <div class="cal-img" @click="showCalendar(index)"><img :src="calenderImg" alt="calenderImg"></div>
            <div class="flexItem">
              <input-box v-edit.feeStdExp.overStd :data-edit="watchDateStr(item.attribute4, item.attribute12)" :placeholder="'请选择'" :textCenter="false" :isreadOnly="true" :pickValue="(item.attribute4 && item.attribute12) ? `${formatDate(item.attribute4)} - ${formatDate(item.attribute12)}` : ''" @select="showCalendar(index)"></input-box>
              <!-- 右箭头 -->
              <img class="rightArrow" :src="rightArrow" alt="" @click="showCalendar(index)">
            </div>
          </div>
          <div class="information-list border-bottom describe">
            <div class="list-between no-center">
              <span class="type">业务描述</span>
            </div>
            <div class="textarea-text">
              <div class="text">{{item.attribute5}}</div>
              <textarea class="textarea" v-edit placeholder="请填写 (必填)" maxlength="40" v-model="item.attribute5"></textarea>
            </div>
            <!-- <span class="wordlimit" :class="{'red': item.attribute5.length === 40 }">{{item.attribute5?`${item.attribute5s}/40`: "0/40"}}</span> -->
            <span class="wordlimit" :class="{'red': item.attribute5.length === 40 }">{{item.attribute5?`${reasonDescs[index]}/40`: "0/40"}}</span>
          </div>

        </div>
      </div>
      <div class="addItem border" @click="addItem">
        <img :src="add" alt="">
        <p>添加预算</p>
      </div>
      <!-- 底部 -->
      <div v-if="EAflag" class="footer">
        <div class="sum">
          <span>金额总计：</span>
          <currency currency="¥" :value="totalSum" :precision="2" :read-only="true" style="width:30%;"></currency>
        </div>
        <div class="btn" @click="submit">确认</div>
      </div>
    </div>
    <!-- <calendar @pickDate="onPickDate" :show.sync="showCalendar" v-model="pick_date"></calendar> -->

    <calendar :show.sync="showCalendarB" :disablePast="disablePast" :start-date="startDate" v-model="date" @pickDate="onPickDate"></calendar>

    <bugdet-org :show.sync="showBdOrg" @confirm="setDept" />
    <event :show="showEvent" ref="event" @on-select="selectEvent" @on-hide="hideEvent" :id="airTicketBudgetList[listIndex]?airTicketBudgetList[listIndex].busi_org_id:''"></event>
    <sources :show="showSources" @on-select="selectSources" @on-hide="hideSources" :dept-id="airTicketBudgetList[listIndex]?airTicketBudgetList[listIndex].busi_org_id:''" :sources-id="airTicketBudgetList[listIndex]?airTicketBudgetList[listIndex].fee_type_id:''"></sources>
    <!--  单独选人 -->
    <org v-model="orgnization" :show.sync="showOrg" :multi="multiUser" @confirm="onOrgconfirm" />
    <select-city v-if="showCity" :headTitle="headTitle" :tempType="'travel'" @select-city="selectCity" @close-panel="closePanel4cities()"></select-city>

  </div>
</template>

<script>
import MyHeader from '../../common/header';
import bugdetOrg from '../../common/bugdetOrg';
import event from '../../common/economicsEvent';
import sources from '../../common/budgetSourcee';
import down from '../../../assets/images/fee/myApply/triangledown2x.png';
import up from '../../../assets/images/fee/myApply/triangleup2x.png';
import add from '../../../assets/images/fee/myApply/add.png';
import rightArrow from '../../../assets/images/fee/myApply/right2x.png';
import currency from '../../common/currency';
import calendar from '../../common/myCalendar';
import calImg from '../../../assets/images/fee/myApply/calendar.png';
// 单独选人
import org from '../../common/org';
import selectCity from '../../common/selectCity';
import InputBox from '../../common/input.vue';

export default {
  components: {
    MyHeader,
    bugdetOrg,
    event,
    sources,
    currency,
    calendar,
    org,
    selectCity,
    InputBox,
  },
  data() {
    return {
      date: [],  // 选择到的日期数组
      startDate: '',
      disablePast: true,
      pickValueIndex: true,
      showCalendarB: false,
      calenderImg: calImg, // 日历小图标的路径

      invoice: {},
      pick_date: '',
      down,
      up,
      add,
      rightArrow,
      showBdOrg: false,
      showEvent: false,
      showSources: false,
      isSave: false,
      isNext: true,
      EAflag: true,
      listIndex: 0,
      sum: 0,
      top: {
        title: '预算来源',
      },
      bugdet: {},
      budgetList: [], // 不含对公飞机票预算来源
      airTicketBudgetList: [], // 含对公飞机票预算来源
      bgIsclose: [],
      autoShow: false,
      // 对公飞机票预算行
      orgnization: [],
      showOrg: false,
      multiUser: false,
      traveler: [],
      showCity: false,
      travelIndex: 0,
      areaType: '',  // 当前正在选择的地点类型（出发地点或目的地点）
      headTitle: '',
    };
  },
  computed: {
    airTicketBudget() {
      return this.$store.getters.airTicketBudget;
    },
    // 计算业务描述的个数
    reasonDescs() {
      let arr = [];
      this.airTicketBudgetList.forEach(item => {
        item.attribute5 = item.attribute5 || '';
        item.attribute5s = item.attribute5 ? item.attribute5.length : 0;
        arr.push(item.attribute5s);
      });
      return arr;
    },
    applyType() {
      return this.$store.state.myApply.applyCreate.applyType;
    },
    myApplyMenuCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.children;
    },
    totalSum() {
      let sum = 0;
      this.airTicketBudgetList.forEach((item) => {
        sum += parseFloat(item.apply_amount)
          ? parseFloat(item.apply_amount)
          : 0;
      });
      return sum;
    },
    emseaapplyh() {
      return this.$store.state.myApply.emseaapplyh;
    },
    applyCreate() {
      return this.$store.state.myApply.applyCreate;
    },
    // 获取默认个人配置信息
    defBusiOrg() {
      return this.$store.state.login.defCfg && this.$store.state.login.defCfg.busiOrg ? this.$store.state.login.defCfg.busiOrg : {};
    },
  },
  methods: {
    //    获取出行人
    getTraveler(item, index) {
      let user = {
        user_full_name: item.attribute3,
        user_id: item.attribute2
      }
      this.traveler = [];
      this.traveler.push(user);
      this.orgnization = this.traveler;
      this.showOrg = true;
      this.multiUser = false;
      this.travelIndex = index;
    },
    // 出行人修改
    onOrgconfirm(users) {
      const obj = {
        attribute2: users[0] ? users[0].user_id : '',
        attribute3: users[0] ? users[0].user_full_name : '',
      };
      this.airTicketBudgetList[this.travelIndex] = Object.assign({}, this.airTicketBudgetList[this.travelIndex], obj);
      this.orgnization = [];
    },

    // 点击打开选择城市页面
    openArea(type, index) {
      this.showCity = true;
      this.travelIndex = index;
      this.areaType = type;
      if (type === 'start') {
        this.headTitle = '选择出发地点';
      } else if (type === 'end') {
        this.headTitle = '选择目的地点';
      }
    },
    closePanel4cities() {
      this.showCity = false;
    },
    // 点击选择地点
    selectCity(item) {
      if (this.areaType === 'start') {
        this.airTicketBudgetList[this.travelIndex].attribute7 = item.area_name;
        this.airTicketBudgetList[this.travelIndex].attribute8 = item.area_code;
        this.airTicketBudgetList[this.travelIndex].attribute6 = item.area_id;
        this.airTicketBudgetList[this.travelIndex].from_area = item;
      } else if (this.areaType === 'end') {
        this.airTicketBudgetList[this.travelIndex].attribute10 = item.area_name;
        this.airTicketBudgetList[this.travelIndex].attribute11 = item.area_code;
        this.airTicketBudgetList[this.travelIndex].attribute9 = item.area_id;
        this.airTicketBudgetList[this.travelIndex].to_area = item;
      }
    },
    watchDateStr(date1, date2) {
      return `${date1}-${date2}`;
    },

    // 点击选择时间
    onPickDate() {
      this.airTicketBudgetList[this.pickValueIndex].attribute4 = this.date[0];
      this.airTicketBudgetList[this.pickValueIndex].attribute12 = this.date[1];
      this.date = [];
      // this.updateData();
    },
    // 点击打开日历组件
    showCalendar(index) {
      if (index > 0) {
        this.disablePast = false;
        this.startDate = this.airTicketBudgetList[index - 1].attribute12;
      } else {
        this.disablePast = false;
        this.startDate = '';
      }
      const arr = [
        this.airTicketBudgetList[index].attribute4 ? this.airTicketBudgetList[index].attribute4.split(' ')[0] : '',
        this.airTicketBudgetList[index].attribute12 ? this.airTicketBudgetList[index].attribute12.split(' ')[0] : '',
      ];
      this.date = arr;
      this.pickValueIndex = index;
      this.showCalendarB = true;
    },
    // 将日期格式化成年月日的形式
    formatDate(date) {
      const formatDate = new Date(date.split(' ')[0]);
      // const year = formatDate.getFullYear();
      const month = formatDate.getMonth() + 1;
      const day = formatDate.getDate();
      return `${month}月${day}日`;
    },

    goBack() {
      this.$router.go(-1);
    },
    show(index) {
      const arr = [];
      arr[index] = !this.bgIsclose[index];
      this.bgIsclose = Object.assign([], this.bgIsclose, arr);
    },
    addItem() {
      let airBudgetItem = {
        attribute1: 'COMPANY', // 预算类型为 飞机票对公司预算  为空表示不为公司预算
        attribute2: null,		// 出行人姓名Id
        attribute3: null,			// 出行人姓名
        attribute4: null,	// 出行日期
        attribute5: this.emseaapplyh.reason_desc,   	// 业务描述
        attribute6: null,				// 从哪里来 id
        attribute7: null,	    // name
        attribute8: null,   // code
        attribute9: null,			// 去哪里
        attribute10: null,	 // name
        attribute11: null,	    // code
        attribute12: null,	 // 回程日期
        attribute13: null,	 //
        // index: this.emseaapplyh.emseaapplyls.length - 1,
        busi_org_name: '', // ????????
        fee_type_name: '', // ????????
        busi_org_id: '', // ????????
        from_area: null,
        to_area: null,
        fee_type: '', // ????????
        budget_name: '',
        project_id: '', // 前端保存值 项目id
        project_name: '', // 前端保存值 项目名称
        source_system: '', // 前端保存值 项目来源系统
        erp_bank_type: '', // 前端保存值 项目erp类型
        erp_bank_type_name: '', // 前端保存值 项目erp类型名称

        fee_apply_l_id: null, // 批文申请单明细ID
        fee_apply_id: null, // ????????
        tenant_id: '', // 租户ID
        eco_type_id: '', // 活动事项ID
        fee_type_id: '', // 预算科目ID
        bill_type_id: '', // 经济事项ID
        apply_amount: null,
        currency: this.emseaapplyh.currency,
        currency_code: this.emseaapplyh.currency_code, // 币种编码(与头币种一致)
        currency_name: this.emseaapplyh.currency_name, // 币种名称(与头币种一致)
        conversion_rate: 1,// 预算行币种兑头币种汇率 // ????????
        approve_conversion_rate: 1, // 预算行币种兑头币种汇率 // ????????
        fee_advance_date: '', // 预计发生日期
        reason_desc: this.emseaapplyh.reason_desc, // 事由/工作任务
        project_code: '', // 项目号
        product_line_id: '', // 产品线ID
        budget_node_id: '', // 预算单元 // ????????
        budget_node_desc: '',  // 预算单元描述 // ????????
        budget_headers_id: '',   // 预算树ID // ????????
        used_amount: '', // 已用金额
        is_release: '', // 是否释放
        // release_amount: , // 释放金额
        release_by: '', // 释放人
        release_name: '', // 释放人姓名
        release_date: '', // 释放时间
        release_reason: '', // 释放原因
        created_by: '', // 创建人
        created_name: '', // 创建人姓名
        creation_date: '', // 创建日期
        last_updated_by: '', // 修改人
        last_updated_name: '', // 修改人姓名
        last_update_date: '', // 修改日期
        business_code: '', // 项目号对应的事业部code
        business_name: '', // 项目号对应的事业部
        budget_code: '', // 预算项目号
        budget_main_id: '',  // 预算主体id // ????????
        budget_main_name: '',  // 预算主体名称 // ????????
        acc_code: '', // 会计科目编码
        acc_name: '', // 会计科目名称
        lock_biz_type: '', // 锁定业务类型（消费增加）
        lock_return_code: '', // 锁定标识（消费明细主键-订单号）（消费增加）
        lock_status: '',  // 创建锁定状态：0，否-默认值  1，已创建锁定明细（消费增加）
      };
      this.airTicketBudgetList.push(airBudgetItem);
    },
    delItem(index) {
      this.airTicketBudgetList.splice(index, 1);
    },
    // 选择预算部门
    showBudgetOrg(index) {
      this.showBdOrg = true;
      this.listIndex = index;
      this.airTicketBudgetList[this.listIndex].fee_type_name = '';
      this.airTicketBudgetList[this.listIndex].budget_node_desc = '';
    },
    setDept(param) {
      this.airTicketBudgetList[this.listIndex].busi_org_name = param.busi_org_name;
      this.airTicketBudgetList[this.listIndex].busi_org_id = param.busi_org_id;
    },
    // 选择经济事项
    economicsEvent(index) {
      // 如果没有选中预算部门，则不能选择经济事项
      if (!this.airTicketBudgetList[this.listIndex].busi_org_name) {
        this.showToast({ msg: '请先选择预算部门' });
        return false;
      }
      this.listIndex = index;
      this.showEvent = true;
      this.airTicketBudgetList[this.listIndex].budget_node_desc = '';
      this.$refs.event.getFeeTypeList();
      return null;
    },
    selectEvent(param) {
      this.showEvent = false;
      this.autoShow = false;
      this.airTicketBudgetList[this.listIndex].fee_type_id = param.fee_type_id;
      this.airTicketBudgetList[this.listIndex].fee_type_name = param.fee_type_name;
      this.getSourceList(this.listIndex);
    },
    hideEvent() {
      this.showEvent = false;
    },
    // 选择预算来源
    budgetSource(index) {
      if (!this.airTicketBudgetList[this.listIndex].busi_org_name) {
        this.showToast({ msg: '请先选择预算部门' });
        return false;
      } else if (!this.airTicketBudgetList[this.listIndex].fee_type_name) {
        this.showToast({ msg: '请先选择经济事项' });
        return false;
      }
      this.listIndex = index;
      this.showSources = true;
      return null;
    },
    selectSources(param) {
      this.showSources = false;
      this.airTicketBudgetList[this.listIndex].budget_name = param.budget_name;
      this.airTicketBudgetList[this.listIndex].budget_node_name = param.budget_node_name;
      this.airTicketBudgetList[this.listIndex].budget_node_id = param.budget_node_id;
      this.airTicketBudgetList[this.listIndex].budget_node_desc = param.budget_node_desc;
      this.airTicketBudgetList[this.listIndex].budget_headers_id = param.budget_headers_id;
    },
    hideSources() {
      this.showSources = false;
    },
    // 确认
    submit() {
      const self = this;
      for (let i = 0; i < self.airTicketBudgetList.length; i++) {
        let item = self.airTicketBudgetList[i];
        if (!item.apply_amount) {
          self.showToast({ msg: '请填写申请金额', width: '12em' });
          self.isNext = false;
          break;
        } else if (!item.busi_org_name) {
          self.showToast({ msg: '请填写预算部门', width: '12em' });
          self.isNext = false;
          break;
        } else if (!item.fee_type_name) {
          self.showToast({ msg: '请填写经济事项', width: '12em' });
          self.isNext = false;
          break;
        } else if (!item.budget_node_desc) {
          self.showToast({ msg: '请填写预算来源', width: '12em' });
          self.isNext = false;
          break;
        } else if (self.applyType !== 'CL' && !item.fee_advance_date) {
          self.showToast({ msg: '请填写预计发生日期', width: '12em' });
          self.isNext = false;
          break;
        } else {
          self.isNext = true;
        }
      }
      if (!self.isNext) {
        return false;
      }
      let emseaapplyls = [...self.budgetList, ...self.airTicketBudgetList];
      const emseaapplyh = Object.assign({}, self.emseaapplyh, { emseaapplyls: emseaapplyls });
      self.$store.commit('EMSEAAPPLYH', emseaapplyh);
      self.$router.go(-1);
      return null;
    },
    // EA/CLX时的下一步
    beforeNext() {
      const self = this;
      self.isNext = true;
      const obj = { apply_amount: self.totalSum };
      self.airTicketBudgetList.forEach((item) => {
        if (!item.apply_amount) {
          self.showToast({ msg: '请填写申请金额', width: '12em' });
          self.isNext = false;
        }
        if (!item.busi_org_name) {
          self.showToast({ msg: '请填写预算部门', width: '12em' });
          self.isNext = false;
        }
        if (!item.fee_type_name) {
          self.showToast({ msg: '请填写经济事项', width: '12em' });
          self.isNext = false;
        }
        if (!item.budget_node_desc) {
          self.showToast({ msg: '请填写预算来源', width: '12em' });
          self.isNext = false;
        }
        if (!self.isNext) {
          return false;
        }
        return null;
      });
      let emseaapplyls = [...self.budgetList, ...self.airTicketBudgetList];
      const emseaapplyh = Object.assign({}, self.emseaapplyh, { emseaapplyls: emseaapplyls }, obj);
      self.$store.commit('EMSEAAPPLYH', emseaapplyh);
      return self.isNext;
    },
    // 保存草稿之前
    beforeSaveDraft() {
      const self = this;
      const obj = { apply_amount: self.totalSum };
      let emseaapplyls = [...self.budgetList, ...self.airTicketBudgetList];
      const emseaapplyh = Object.assign({}, self.emseaapplyh, { emseaapplyls: emseaapplyls }, obj);
      self.$store.commit('EMSEAAPPLYH', emseaapplyh);

      return true;
    },
    // 初始化
    init() {
      const self = this;
      (self.emseaapplyh.emseaapplyls || []).forEach((budget, index) => {
        self.bgIsclose[index] = false;
      });

      if (self.applyCreate.applyType === 'EA' || self.applyCreate.applyType === 'CLX') {
        self.EAflag = false;
      }
      // 设置初始的部门信息
      self.budgetList = [];  //  不含对公飞机票预算
      self.airTicketBudgetList = [];  // 对公飞机票预算
      if (self.emseaapplyh.emseaapplyls.length) {
        self.emseaapplyh.emseaapplyls.forEach((item, index) => {
          if (self.applyType === 'CL' && self.myApplyMenuCfg[self.applyType].compnayPayAir && item.attribute1 && item.attribute1 === 'COMPANY') {
            const airTicketBudgetList = Object.assign({}, item, {
              busi_org_name: item.busi_org_name ? item.busi_org_name : self.defBusiOrg.busi_org_name,
              busi_org_id: item.busi_org_id ? item.busi_org_id : self.defBusiOrg.busi_org_id,
              fee_advance_date: item.fee_advance_date ? item.fee_advance_date.split(' ')[0] : '',
              amount: 0,
              isclose: false,
            });
            self.$set(self.airTicketBudgetList, self.airTicketBudgetList.length, airTicketBudgetList);
          } else {
            const budgetList = Object.assign({}, item, {
              busi_org_name: item.busi_org_name ? item.busi_org_name : self.defBusiOrg.busi_org_name,
              busi_org_id: item.busi_org_id ? item.busi_org_id : self.defBusiOrg.busi_org_id,
              fee_advance_date: item.fee_advance_date ? item.fee_advance_date.split(' ')[0] : '',
              amount: 0,
              isclose: false,
            });
            self.$set(self.budgetList, self.budgetList.length, budgetList);
          }
          self.listIndex = 0;
        });
      } else {
        self.addItem();
      }
      let emseaapplyls = [...self.budgetList, ...self.airTicketBudgetList];
      const emseaapplyh = Object.assign({}, self.emseaapplyh, { emseaapplyls: emseaapplyls });
      self.$store.commit('EMSEAAPPLYH', emseaapplyh);
    },
    // 获取预算来源列表
    getSourceList(index) {
      const pamars = {
        busi_org_id: this.airTicketBudgetList[this.listIndex] ? this.airTicketBudgetList[this.listIndex].busi_org_id : '',
        fee_type_id: this.airTicketBudgetList[this.listIndex] ? this.airTicketBudgetList[this.listIndex].fee_type_id : '',
        page_number: 1,
        page_size: 2,
      };
      this.$store.dispatch('getBudgetSource', pamars)
        .then((rep) => {
          if (rep.code === '0000') {
            if (rep.data.info.length === 1) {
              this.airTicketBudgetList[index].budget_name = rep.data.info[0].budget_name;
              this.airTicketBudgetList[index].budget_node_name = rep.data.info[0].budget_node_name;
              this.airTicketBudgetList[index].budget_node_id = rep.data.info[0].budget_node_id;
              this.airTicketBudgetList[index].budget_node_desc = rep.data.info[0].budget_node_desc;
              this.airTicketBudgetList[index].budget_headers_id = rep.data.info[0].budget_headers_id;
              this.autoShow = true;
            }
          } else {
            this.showToast({ msg: rep.msg });
          }
        });
    },
  },
  mounted() {
    this.init();
  },
};
</script>

