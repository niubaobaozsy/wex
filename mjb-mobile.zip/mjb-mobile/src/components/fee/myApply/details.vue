<!--
  describe：查看申请单
  created by：张绍武
  date：2017-11-17
-->
<template>
  <div>
    <my-header title="查看申请单" :showBack="true" @previous='goBack' :rightItem="rightTitle" @on-click="saveDraft"></my-header>
    <div class='has-footer'>
      <ul class='has-header top border-bottom'>
        <li class='border-bottom one'>
          <p>
            <span>类型</span>
            <!-- <i :class="['status',{'yellow' : order.order_status == 'SUBMITED'},{'blue': order.order_status == 'AUDITED'}]">{{ order.order_status == 'SUBMITED' ? "审批中" : "已通过" }}</i> -->
          </p>
          <div class="top-div">
            <section>{{order.order_template_name}}</section>
            <span>单号: {{order.fee_apply_code}}</span>
          </div>
        </li>
        <li class='border-bottom'>
          <p>申请人</p>
          <div>
            {{order.created_name}}
          </div>
        </li>
        <li class='border-bottom' v-if="order.order_type === 'CL'&& myApplyMenuCfg[order.order_type].hasTravelType">
          <p>出差类型</p>
          <div>
            {{order.attribute15_name}}
          </div>
        </li>
        <li class='border-bottom' v-if="isUrgentCfg">
          <p>是否加急</p>
          <div>
            {{order.is_urgent === 'Y' ? '是' : '否' }}
          </div>
        </li>
        <li class='border-bottom'>
          <p>业务描述</p>
          <div style='word-break:break-all'>
            {{order.reason_desc}}
          </div>
        </li>
        <li class='border-bottom' v-if="order.is_over_standard !== 'N'">
          <p>超标原因</p>
          <div>
            {{order.over_standard_reason}}
          </div>
        </li>
        <li class='border-bottom two' v-if="CLtag && !myApplyMenuCfg[order.order_type].compnayPayAir">
          <p>出差人</p>
          <div>
            <section style="">共{{persons}}人</section>
            <!--{{this.order.order_type == 'CL' ? this.travels[0].assistant_persons_name.split(',').length || this.travel[0].assistant_persons_name.length : '' }}-->
            <section style="">{{persons_name}}</section>
          </div>
        </li>
        <li @click="getTravellerpp">
          <p>授权使用</p>
          <p class="top-right" :class="{'placeholder': !accredit}">{{accredit || '请选择(选填)' }}<img :src='rtarrow' class='img'></p>
        </li>
      </ul>
      <div class='logs border'>
        <div class='top border-bottom'>
          <span>审批记录</span>
          <!--点击催办-->
          <p class="remind" @click='reminders' v-if="order.order_status === 'SUBMITED'" :class='{"disable": !canRemind}'>催办</p>
        </div>
        <my-progress :title='log' :list="listNew" :current="current" class="my-progress"></my-progress>
      </div>
      <div class='has-bottom more border'>
        <div v-if="order.emseaapplytravels &&　order.emseaapplytravels.length && order.emseaapplytravels[0].from_area_name" class='router border-bottom' @click=" showTravels = true ">
          <div class="text">行程信息</div>
          <div class='detaileds'>共{{travel}}条<img :src='rtarrow' class='img'></div>
        </div>
        <div v-if="arr.length && order.order_type === 'CL' " class='router border-bottom' @click=" showExpenses = true ">
          <div class="text">费用预估</div>
          <div class='detailed' v-if="airFee">￥{{(cost * 1).toFixed(2)}}
            <span> (含飞机票 ￥{{airFee.toFixed(2)}})</span>
            <img :src='rtarrow' class='img'>
          </div>
          <div class='detailed' v-else>￥{{(cost * 1).toFixed(2)}} <img :src='rtarrow' class='img'></div>
          <!-- <div class='detailed'>
              <currency currency="¥" :value="cost" :precision="2" :read-only="true"></currency>
              <img :src='rtarrow' class='img'>
            </div> -->
        </div>
        <!-- 公司订票预算来源 -->
        <div class='router border-bottom' v-if="order.order_type === 'CL' && myApplyMenuCfg[order.order_type].compnayPayAir && airBdgArr.length > 0" @click="goBudgetsee('airBdgArr')">
          <div>公司订票预算来源</div>
          <div class='detailed'>￥{{airBdgFee.toFixed(2)}} <img :src='rtarrow' class='img'></div>
        </div>

        <div class='router border-bottom' v-if="order.order_type === 'CL' && myApplyMenuCfg[order.order_type].compnayPayAir && noAirBdgArr.length > 0" @click=" goBudgetsee('noAirBdgArr')">
          <div>预算来源(不含公司订票)</div>
          <div class='detailed'>￥{{noAirBdgFee.toFixed(2)}} <img :src='rtarrow' class='img'></div>
        </div>

         <div class='router border-bottom'  v-else @click="goBudgetsee()">
          <div>预算来源</div>
          <div class='detailed'>￥{{applyAmount.toFixed(2)}} <img :src='rtarrow' class='img'></div>
        </div>
        <!-- <div class='router  border-bottom' v-else @click="goBudgetsee">
          <div class="text">预算来源</div>
          <div class='detailed'>
            <currency currency="¥" :value="applyAmount" :precision="2" :read-only="true"></currency>
            <img :src='rtarrow' class='img'>
          </div>
        </div> -->
        <div class='router'>
          <div class="text">剩余可用金额</div>
          <div class='detailed amount-mr'>
            <currency currency="¥" :value="order.avail_amount" :precision="2" :read-only="true"></currency>
          </div>
        </div>
      </div>
      <confirm v-model='showConfirm' :content='popup' @on-confirm='onConfirm'></confirm>
      <alert v-model='show' :content='prompt'></alert>
      <my-journeySee :title='order.emseaapplytravels' :show="showTravels" @on-hide="hideTravel"></my-journeysee>
      <my-expenseSee :order='arr' :show="showExpenses" @on-hide="hideExpense"></my-expenseSee>
      <my-budgetSee :title='budgetseeArr' :show.sync="showBudgets" @on-hide="hideBudget"></my-budgetSee>
      <org v-model="orgnization" :show.sync="showOrg" :multi="multiUser" @confirm="onOrgconfirm" />
      <div class='bottom' @click='withdraw()' v-if="order.order_status === 'SUBMITED'">撤回</div>
      <div class='bottom' :class="{'disable': order.biz_status === 'RELEASED'}" @click='withdraw()' v-if="order.order_status == 'AUDITED'">{{order.biz_status==='RELEASED'?'预算已释放':'释放预算'}}</div>
    </div>
  </div>
</template>

<script>
import { Confirm, Group, XSwitch, XButton, Alert } from 'vux';
import myProgress from '../../common/proGress';
import myJourneySee from '../../common/jourNeysee';  // 行程
import myExpenseSee from '../../common/expenseSee';  // 消费
import myBudgetSee from '../../common/budGetsee';    // 预算
import myHeader from '../../common/header';
import org from '../../common/org'; // 选择授权
import currency from '../../common/currency';
import rtarrow from '../../../assets/rt-arrow.png';

export default {
  components: {
    myProgress,
    myExpenseSee,
    myJourneySee,
    myBudgetSee,
    myHeader,
    Group,
    XSwitch,
    Confirm,
    XButton,
    Alert,
    org,
    currency,
  },
  data() {
    return {
      noAirBdgFee: 0,
      noAirBdgArr: [],
      airBdgFee: 0,
      airBdgArr: [],
      budgetseeArr: [],
      cost: 0,
      airFee: 0, // 对公飞机票金额合计

      prompt: '',
      popup: '',
      show: false, // 催办
      showConfirm: false, // 撤回
      showTravels: false,  // 行程
      showExpenses: false, // 消费
      showBudgets: false,  // 预算
      CLtag: false,    // 是否差旅申请单
      showOrg: false,
      multiUser: false,
      rtarrow,
      persons: 0,
      persons_name: '',
      list: [],   // process_log
      order: {},
      arr: [],
      accreditArr: [],
      orgnization: [],
      emseaapplyrefs: [],
      log: [],
      listNew: [],
      current: '',
      applyAmount: 0,
      rightTitle: '',
      canRemind: true,
      allTravelTypes: [],
    };
  },

  methods: {
    saveDraft() {
      this.$router.go(-1);
      if (this.applyArr.length) {
        this.applyArr.forEach((item) => {
          if ((this.$route.query.id !== this.$route.query.id) && (item.fdHandleDate.indexOf('走分支') !== -1)) {
            this.applyArr.push(item);
          }
        });
      } else {
        this.applyArr.push(this.$route.query.id);
      }
    },
    // budgetDetail() {
    //   this.showBudgets = true;
    // },
    // 查看预算
    goBudgetsee(type) {
      this.budgetseeArr = type ? this[type] : this.order.emseaapplyls;
      this.showBudgets = true;
    },
    //    获取授权人
    getTravellerpp() {
      this.orgnization = this.newArr;
      this.showOrg = true;
      this.multiUser = true;
    },
    // 组件行程关闭
    hideTravel() {
      this.showTravels = false;
    },
    // 组件消费关闭
    hideExpense() {
      this.showExpenses = false;
    },
    // 组件预算关闭
    hideBudget() {
      this.showBudgets = false;
    },
    onOrgconfirm(users) {
      if (this.multiUser) {
        this.emseaapplyrefs = [];
        users.forEach((user) => {
          const obj = {
            id: '',
            fee_apply_id: '',
            tenant_id: this.userInfo.user.tenantId,
            ref_by: user.user_id,
            ref_name: user.user_full_name,
          };
          this.emseaapplyrefs.push(obj);
        });
        const data = Object.assign({}, this.order, { emseaapplyrefs: this.emseaapplyrefs });
        this.refer(data);
      }
      this.orgnization = [];
    },
    // 提交授权人
    refer(data) {
      const params = {
        emseaapplyh: data,
      };
      this.$store.dispatch('saveFeeApply', params)
        .then((rep) => {
          if (rep.code === '0000') {
            this.getDetail();
          }
        });
    },
    // 数据获取
    async getDetail() {
      this.allTravelTypes = await this.$method.getDataFromDict('TRAVEL_TYPE'); // 获取所有出差类型数据
      const standardTypeDict = [{
          label: '市内交通费',
          value: 'SNJTF',
        }, {
          label: '餐费',
          value: 'CF',
        }];
      this.$store.dispatch('myFeeReQuest', {
        fee_apply_id: this.$route.query.id,
      }).then((res) => {
        if (res.code === '0000') {
          this.list = res.data.process_log;     // res里没有这一个的
          this.order = res.data.emseaapplyh;
          // 出差类型code转name
          if (this.order.order_type === 'CL' && this.myApplyMenuCfg[this.order.order_type].hasTravelType) {
            this.$set(this.order, 'attribute15_name', this.$method.getValueInArray(this.order.attribute15, this.allTravelTypes, 'itemValue', 'itemName'));
          }
          if (this.order.emseaapplyrefs) {
            this.accreditArr = this.order.emseaapplyrefs;
            this.emseaapplyrefs = this.accreditArr;
          }

          this.airBdgArr = [];
          this.airBdgFee = 0;
          this.noAirBdgArr = [];
          this.noAirBdgFee = 0;

          this.order.emseaapplyls.forEach(item => {
            this.applyAmount += item.approve_amount;
            // this.applyAmount = this.applyAmount + item.approve_amount;
            if (item.attribute1 === 'COMPANY' && item.attribute13 === 'AIRPLANE') {
              this.airBdgArr.push(item);
              this.airBdgFee += item.approve_amount;
            } else {
              this.noAirBdgArr.push(item);
              this.noAirBdgFee += item.approve_amount;
            }
          });

          this.airBdgFee = parseFloat(this.airBdgFee);
          this.noAirBdgFee = parseFloat(this.noAirBdgFee);

          let moneyCat = 0;
          this.arr[0] = this.order.emseaapplytravels;// 行程
          if (this.arr[0]) {
            this.arr[0].forEach((data) => {
              if (data.emseatransportdetails) {
                data.trans = data.emseatransportdetails; // 交通工具
              }
              data.trans.forEach((moneyData) => {
                if (moneyData.approve_transport_fee) {
                  moneyCat += moneyData.approve_transport_fee;
                }
              });
            });
          }
          this.arr[2] = this.order.emsearentdetails;// 住宿
          let moneyHotel = 0;
          if (this.arr[2]) {
            this.arr[2].forEach((hotelData) => {
              if (hotelData.approve_rent_fee) {
                moneyHotel += hotelData.approve_rent_fee;
              }
            });
          }
          this.arr[3] = this.order.emseaassistantdetails; // 补助
          let subsidy = 0;
          if (this.arr[3]) {
            this.arr[3].forEach((subsidyData) => {
              if (subsidyData.standard_type) {
                subsidyData.standard_type_name = this.$method.getValueInArray(subsidyData.standard_type, standardTypeDict, 'value', 'label');
              }
              if (subsidyData.approve_assistant_fee) {
                subsidy += subsidyData.approve_assistant_fee;
              }
            });
          }
          this.arr[4] = this.order.emseaotherfeedetails; // 其他
          let other = 0;
          if (this.arr[4]) {
            this.arr[4].forEach((otherData) => {
              if (otherData.approve_other_fee) {
                other += otherData.approve_other_fee;
              }
            });
          }
          this.cost = other + subsidy + moneyHotel + moneyCat;
          if (this.order.order_type === 'CL') {
            this.CLtag = true;
            if (this.order.emseaapplytravels) {
              this.order.emseaapplytravels.forEach((item) => {
                if (item.travel_persons_name) {
                  const travelPersons = item.travel_persons_name.split(',');
                  this.persons = travelPersons.length;
                  this.persons_name = item.travel_persons_name;
                } else {
                  this.CLtag = false;
                }
              });
            } else if (!this.order.emseaapplytravels[0]) {
              this.CLtag = false;
            }
          }
          this.getlog().then(() => {
            if (this.order.order_status === 'SUBMITED') {
              this.getCurent().then(() => {
                this.grtFlowt();
              });
            }
          });
        } else {
          this.showToast({ msg: res.msg });
          this.$router.push({ path: '/fee/myApply/applyHome/beingApproved' });
        }
      });
    },
    //      审批节点未审批
    grtFlowt() {
      return new Promise((resolve) => {
        this.$store.dispatch('grtFlowt', {
          formInstanceId: this.order.formInstanceId,
          model_id: '001',
          template_form_id: this.order.form_template_id,
        }).then((res) => {
          if (res && res.code === '0000') {
            let curIndex = 0;
            res.data.forEach((flowt, index) => {
              if (flowt.current) {
                curIndex = index;
              }
            });
            this.listNew = res.data.slice(curIndex);
            resolve(res.data);
          } else if (res) {
            this.showToast({ msg: `请求异常[${res.code}]: ${res.msg}` });
          }
        });
      });
    },
    // 获取审批中的流程
    getCurent() {
      return new Promise((resolve) => {
        this.$store.dispatch('getCur', {
          formInstanceId: this.order.formInstanceId,
          model_id: '001',
          template_form_id: this.order.form_template_id,
        }).then((res) => {
          if (res && res.code === '0000') {
            this.current = res.data.actionUidName;
            resolve(res.data);
          } else if (res) {
            this.showToast({ msg: `请求异常[${res.code}]: ${res.msg}` });
          }
        });
      });
    },
    // 获取审批流程
    getlog() {
      return new Promise((resolve) => {
        this.$store.dispatch('getlog', {
          formInstanceId: this.order.formInstanceId,
          model_id: '001',
          template_form_id: this.order.form_template_id,
        }).then((res) => {
          if (res && res.code === '0000') {
            let latelyRemind = '';
            this.log = res.data.filter(log => log.fdActionKey.indexOf('走分支') === -1);
            res.data.forEach((log) => {
              if (log.fdActionKey === '催办') {
                latelyRemind = log.fdHandleDate.split(' ')[0];
              }
            });
            if (latelyRemind) {
              this.canRemind = Date.now() - Date.parse(new Date(latelyRemind)) > 86400000;
            }
            resolve(res.data);
          } else if (res) {
            this.showToast({ msg: res.msg });
          }
        });
      });
    },
    // 撤回申请单按钮
    withdraw() {
      if (this.order.order_status === 'SUBMITED') {
        this.showConfirm = !this.showConfirm;
        this.popup = '撤回该申请单';
      } else if (this.order.order_status === 'AUDITED') {
        if (this.order.biz_status !== 'RELEASED') {
          this.showConfirm = !this.showConfirm;
          this.popup = '是否释放预算';
        } else {
          this.showToast({ msg: '预算已释放' });
        }
      }
    },
    // 确定撤回申请单
    onConfirm() {
      if (this.order.order_status === 'SUBMITED') {
        this.showLoading();
        this.$store.dispatch('myBillBack', {
          auditNote: '请求撤回',   // 审批意见
          formInstanceId: this.order.formInstanceId,  // EA单
          model_id: '001',
          template_form_id: this.order.form_template_id,  // 表单模板id
        }).then((res) => {
          this.hideLoading();
          if (res.code === '0000') {
            this.showToast({ msg: '单据撤回成功', time: 500 });
            setTimeout(() => {
              this.$router.push({ path: '/fee/myApply/applyHome/draft' });
            }, 800);
          } else {
            this.showToast({ msg: res.msg });
          }
        });
      } else if (this.order.order_status === 'AUDITED') {
        this.showLoading();
        this.$store.dispatch('releaseBudget', {
          fee_apply_id: this.$route.query.id,
        }).then((res) => {
          this.hideLoading();
          if (res.code === '0000') {
            this.showToast({ msg: '释放预算成功' });
            this.getDetail();
            // this.$router.push({ path: '/fee/myApply/applyHome/draft' });
          } else {
            this.showToast({ msg: res.msg });
          }
        });
      }
    },
    // 催办
    reminders() {
      if (this.canRemind) {
        this.showLoading();
        this.$store.dispatch('myReminDers', {
          auditNote: '请审批',   //  审批意见
          formInstanceId: this.order.formInstanceId,  //  EA单
          model_id: '001',
          template_form_id: this.order.form_template_id,  // 表单模板id
        }).then((res) => {
          this.hideLoading();
          if (res.code === '0000') {
            this.showToast({ msg: '催办成功', time: 500 });
            this.getDetail();
          } else if (res) {
            this.showToast({ msg: `催办失败[${res.code}]: ${res.msg}` });
          }
        });
      } else {
        this.prompt = '今天已经成功提醒审批人,明天再来催办吧';
        this.show = true;
      }
    },
    goBack() {
      this.$router.go(-1);
    },
  },
  computed: {
    myApplyMenuCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.children;
    },
    isUrgentCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.isUrgent
    },
    travel() {
      if (this.order.emseaapplytravels) {
        return this.order.emseaapplytravels.length;
      }
      return 0;
    },
    accredit() {
      let str = '';
      this.accreditArr.forEach((data) => {
        str += `${data.ref_name},`;
      });
      return str.slice(0, -1);
    },
    applyArr() {
      return this.$store.state.common.applyArr;
    },
    userInfo() {
      return this.$store.state.userInfo;
    },
    newArr() {
      const arrlist = [];
      this.emseaapplyrefs.forEach((item) => {
        const obj = {
          user_id: item.ref_by,
          user_full_name: item.ref_name,
        };
        arrlist.push(obj);
      });
      return arrlist;
    },
  },
  created() {
    this.getDetail();
    if (this.$route.query.type === 'true') {
      this.rightTitle = '选择';
    }
  },
};
</script>

<style lang='less' scoped>
.top {
  background: #ffffff;
  font-size: 16px;
  list-style: none;
  li {
    padding: 14px 0;
    margin: 0 15px;
    line-height: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 16px;
    p {
      min-width: 64px;
      color: #858585;
    }
    .top-right {
      text-align: right;
      color: #000000;
      &.placeholder {
        color: #C3C3C3;
      }
    }
    div {
      flex-grow: 1;
      text-align: right;
    }
    .top-div {
      text-align: right;
    }
    section {
      font-size: 16px;
      text-align: right;
      color: #000000;
    }
    .status {
      font-style: normal;
      display: inline-block;
      padding: 0 10px;
      margin: 0 10px;
      border-radius: 12px;
      font-size: 11px;
      color: #ffffff;
      text-align: center;
    }
    .blue {
      background: #3da5fe;
    }
    .yellow {
      background: #FCB23C;
    }
  }
  .one {
    padding: 14px 0 10px 0;
    span {
      font-size: 14px;
      line-height: 22px;
      color: #9b9b9b;
    }
    P {
      display: flex;
      align-items: center;
      span {
        font-size: 16px;
        color: #858585;
      }
    }
  }
}

.logs {
  margin-top: 10px;
  background: #ffffff;
  .top {
    padding: 9px 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .remind {
      width: 70px;
      height: 30px;
      background: #3DA5FE;
      color: #FFFFFF;
      text-align: center;
      line-height: 30px;
      border-radius: 40px;
      &.disable {
        background-color: #c1c1c1;
      }
    }
  }
}

.has-bottom {
  margin: 10px 0 100px 0;
  padding: 0 13px;
  background: #ffffff;
  .router {
    // display: flex;
    // height: 50px;
    // flex-wrap: nowrap;
    // color: #858585;
    height: 50px;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: #858585;
    .text {
      flex: 1;
      display: flex;
      align-items: center;
    }
    .detailed {
      // display: flex;
      // flex: 1;
      // justify-content: center;
      // align-items: center; // flex: 1;
      // color: #3DA5FE; // padding-right: 13px;
      color: #3DA5FE;
      padding-right: 3px;
      line-height: 50px;
      &.amount-mr {
        padding-right: 18px;
      }
      input {
        width: 100%;
        border: 0;
        outline: none;
        color: #3DA5FE;
        font-size: 16px;
        text-align: right;
      }
      img {
        width: 7px;
        height: 13px;
        margin-left: 10px;
      }
    }
    .detaileds {
      display: flex;
      flex: 1;
      justify-content: flex-end;
      align-items: center;
      color: #000000;
      text-align: right;
      img {
        width: 7px;
        height: 13px;
        margin-left: 10px;
      }
    }
  }
  .router:nth-of-type(7) {
    display: none;
  }
}

.img {
  width: 7px;
  height: 13px;
  margin-left: 10px;
}

.has-footer {
  .bottom {
    width: 100%;
    height: 50px;
    color: #666;
    text-align: center;
    line-height: 50px;
    margin-bottom: 0;
    background: #ffffff;
    box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
    position: fixed;
    bottom: 0;
    &.disable {
      color: #fff;
      background-color: #C1C1C1;
    }
  }
}
</style>
