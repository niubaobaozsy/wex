<!--
  describe："审批主页"
  created by：panjm
  date：2017-12-1
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div class="mine-wrap">
    <div class="mine-content">
      <my-header :title="top.title"  @previous="goBack"></my-header>
      <div class="has-header has-tab">
        <Tab :tabList="tabList"></Tab>
      </div>
      <div>
        <router-view></router-view>
      </div>

    </div>
  </div>
</template>

<script>
import MyHeader from '../../common/header';
import Tab from '../../common/Tab';

export default {
  components: {
    MyHeader,
    Tab,
  },
  data() {
    return {
      top: {
        title: '审批',
      },
      tabList: [
        {
          name: '未审批',
          linkTo: 'unApproved',
        },
        {
          name: '已审批',
          linkTo: 'approved',
        },
      ],
    };
  },
  methods: {
    goBack() {
      this.$router.push('/fee');
    }
  }
};
</script>
