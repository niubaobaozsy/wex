<!--
  describe：关联申请单组件
  created by：黄喆
  date：2017-11-30
-->
<template>
  <div class="related-container" v-if="show">
    <my-header :title="top.title" :headerClass="top.headerTop" @previous="goBack" ></my-header>
    <div class="wrap">
      <div class="data-content">
        <div v-for="(item, index) in list" :key="index" class="data-list border-bottom">
          <div class="left">
            <div class="type">{{types}}</div>
            <div>
              <div class="reason">{{item.sensitive_info}}</div>
              <div class="date">{{item.apply_date}}</div>
            </div>
          </div>
          <div class='right'>
            ￥{{ item.apply_reim_amount.toFixed(2) }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import myHeader from '../../common/header';
  import selectActive from '../../../assets/images/fee/myReimburse/select_active.png';

  export default {
    components: {
      myHeader,
    },
    data() {
      return {
        top: {
          title: '差旅申请',
        },
        types: '差旅',
        select_active: selectActive,
      };
    },
    props: {
      show: {
        type: Boolean,
        required: true,
        default: false,
      },
      list: {
        type: Array,
      },
    },
    methods: {
      goBack() { // 返回
        this.$emit('on-hide');
      },
      details(applyId) {
        console.log(this.$route.matched[this.$route.matched.length - 1].path);
        setTimeout(() => {
          this.$router.push({
            path: '/fee/details', query: { id: applyId },
          });
        }, 800);
      },
    },
  };
</script>
<style lang="less" scoped>
  @white:#ffffff;
  .related-container {
    position: fixed;
    top: 0;
    z-index: 9999;
    width: 100%;
    height: 100%;
    background-color: #F4F4F4;
    .wrap {
      margin-top: 57px;
      background: @white;
      .data-content {
        .data-list {
          display: flex;
          justify-content: space-between;
          padding: 11px 15px 11px 11px;
          .left {
            display: flex;
            justify-content: flex-start;
            .nochoices {
              width: 18px;
              height: 18px;
              margin: -14px 0px -14px -15px;
              padding: 26px 20px 23px 24px;
            }
            .type{
              width: 40px;
              height: 40px;
              border-radius: 50%;
              color: @white;
              font-size: 12px;
              text-align: center;
              align-items: center;
              line-height: 40px;
              margin-right: 14px;
              flex: none;
              background-color: #6CC60A;
            }
            .reason {
              padding-top: 10px;
              line-height: 20px;
            }
            .date {
              padding-top: 10px;
              font-size: 14px;
              line-height: 20px;
              color: #9B9B9B;
            }
          }
          .right {
            font-size: 16px;
            color: #000000;
            padding-top: 10px;
            line-height: 20px;
          }
        }
      }
    }
  }
</style>
