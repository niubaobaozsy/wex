<!--
  describe：沟通组件
  Author: 欧倩伶
	Create: 2017-12-01
-->
<template>
  <div class="linkUp" v-if="infor.show">
    <!-- 发送 -->
    <div class="send"  v-if="!this.check">
      <my-header :title="top.title" :rightItem="'发送'" :showBack="true" @previous="hide" @on-click="sumbit"></my-header>
      <div class="has-header container" v-if="!reply">
        <div class="addressee border-bottom"  @click="selectReceiver">
          <div class="receiver">
            <p class="p1">收件人: </p>
            <p class="p2">{{addressee}}</p>
          </div>
          <img src="../../../assets/images/fee/approve/right2x.png" alt="">
        </div>
        <!-- <div class="message border-bottom" v-if="reply">
          <p>Re: </p> {{content}}
        </div> -->
        <div class="communication border-bottom">
          <x-textarea :max="40" v-model="words" placeholder="请填写沟通内容"></x-textarea>
        </div>
      </div>
      <div class="has-header container" v-if="reply">
        <div class="addressee border-bottom">
          <div class="receiver">
            <p class="p1">收件人: </p>
            <p class="p2">{{receivers}}</p>
          </div>
        </div>
        <div class="message border-bottom">
          <p>Re: </p> {{content}}
        </div>
        <div class="communication border-bottom">
          <x-textarea :max="40" v-model="words" placeholder="请填写沟通内容"></x-textarea>
        </div>
      </div>
    </div>
    <!-- 查看 -->
    <div class="check" v-if="this.check">
      <my-header :title="top.title" :showBack="true" @previous="hide"></my-header>
      <div class="has-header container">
        <div class="sender border-bottom">
          <p>发件人: </p>{{sender}}
        </div>
        <div class="addressee border-bottom">
          <p>收件人: </p>{{addressee}}
        </div>
        <div class="message border-bottom">
          {{content}}
        </div>
      </div>
      <div class="footer">
        <div class="checkBt" @click="checkOrd">查看表单</div>
        <div class="replyBt" @click="replyMsg">回复</div>
      </div>
    </div>
    <org v-model="orgnization" :show.sync="showOrg" :multi="true" @confirm="getReceiver" />
  </div>
</template>
<script>
import { XTextarea } from 'vux';
import MyHeader from '../../common/header';
import org from '../../common/org';

export default {
  components: {
    MyHeader,
    XTextarea,
    org,
  },
  props: {
    infor: {},
  },
  data() {
    return {
      words: '',
      content: '',
      sender: '',
      orgnization: [],
      showOrg: false,
      top: {
        title: '沟通',
      },
      linker: '',
      sendPerson: '',
      message: '',
      receivers: '',
    };
  },
  methods: {
    // 初始化
    init() {
      if (this.infor.linkContant) {
        const len = this.infor.linkContant.length;
        const data = this.infor.linkContant[len - 1];
        if (data.fdActionKey.indexOf('回复') || data.fdActionKey.indexOf('沟通')) {
          const name = data.fdActionKey.substr(4, 2);
          this.receivers = data.fdActionKey.match(/"(\S*)"/)[1];
          console.log(name);
          this.linker = name;
          this.sendPerson = data.fdHandlerName;
          this.message = data.fdAuditNote;
        }
      }
      // 发送状态
      if (!this.check) {
        if (!this.reply) {
          this.addressee = this.addressee || '';
        } else if (this.reply) {    // 回复状态
          this.addressee = this.linker;
          this.content = this.message;
        }
      } else {      // 查看状态
        this.sender = this.sendPerson;
        this.addressee = this.linker;
        this.content = this.message;
      }
    },
    // 发送
    sumbit() {
      this.showLoading();
      if (!this.check) {
        console.log('回复', this.reply);
        console.log('信息', this.infor);
        if (this.reply) {    // 单据回复沟通
          const param = {
            auditNote: this.words,
            formInstanceId: this.infor.formInstanceId,
            template_form_id: this.infor.template_form_id,
            model_id: '001',
          };
          if (this.words) {
            this.$store.dispatch('reCommunicate', param).then((res) => {
              if (res && res.code === '0000') {
                this.hideLoading();
                this.showToast({ msg: '提交成功' });
                setTimeout(() => {
                  this.$emit('hide');
                  this.$emit('successs');
                }, 2000);
              } else if (res && res.code) {
                this.hideLoading();
                this.showToast({ msg: `请求异常(${res.code})` });
              }
            });
          } else {
            this.hideLoading();
            this.showToast({ msg: '沟通内容不可为空！' });
          }

        } else if (this.addressee === '') {     // 单据沟通
          this.hideLoading();
          this.showToast({ msg: '请选择收件人' });
        } else {
          const param = {
            auditNote: this.words,
            formInstanceId: this.infor.formInstanceId,
            template_form_id: this.infor.template_form_id,
            model_id: '001',
            isHiddenNote: true,
            isMutiCommunicate: false,
            toOtherHandlerIds: this.toOtherHandlerIds,
          };
          if (this.words) {
            this.$store.dispatch('getCommunicate', param).then((res) => {
              if (res && res.code === '0000') {
                this.hideLoading();
                this.showToast({ msg: '提交成功' });
                setTimeout(() => {
                  this.$emit('successs');
                  this.$emit('hide');
                }, 2000);
              } else if (res && res.code) {
                this.hideLoading();
                this.showToast({ msg: `请求异常(${res.code})` });
              }
            });
          } else {
             this.hideLoading();
             this.showToast({ msg: '沟通内容不可为空！' });
          }

        }
      }
    },
    hide() {
      this.$emit('hide');
    },
    // 查看表单
    checkOrd() {
      this.$emit('hide');
    },
    // 回复
    replyMsg() {
      this.infor.status = 'reply';
    },
    // 选择收件人
    selectReceiver() {
      console.log(this.showOrg);
      this.showOrg = true;
    },
    getReceiver(users) {
      console.log(users);
      this.orgnization = users;
    },
  },
  computed: {
    check() {
      return this.infor.status === 'check';
    },
    reply() {
      console.log(this.infor, 121212345678);
      return this.infor.status === 'reply';
    },
    addressee: {
      get() {
        let users = '';
        this.orgnization.forEach((user) => {
          users += `${user.user_full_name},`;
        });
        users = users.substr(0, users.length - 1);
        return users;
      },
      set(value) {
        console.log(value);
      },
    },
    toOtherHandlerIds() {
      let usersId = '';
      this.orgnization.forEach((user) => {
        usersId += `${user.user_id},`;
      });
      usersId = usersId.substr(0, usersId.length - 1);
      return usersId;
    },
  },
  mounted() {
    this.init();
  },
};
</script>
<style lang="less" scoped>
@import '../../../assets/css/base.less';
.send {
  position: fixed;
  top: 0;
  bottom: 0;
  width: 100%;
  background-color: #F4F4F4;
  z-index: 99;
}
.container {
  background: #fff;
  .addressee {
    padding: 15px;
    display: flex;
    .receiver {
      width: -webkit-fill-available;
      display: flex;
      .p1 {
        width: 68px;
      }
      .p2 {
        width: -webkit-fill-available;
      }
    }
    img {
      height: 13px;
      margin: auto 0 auto 5px;
    }
    p {
      margin-right: 10px;
      width: 20%
    }
  }
  .sender {
    padding: 15px;
    display: flex;
    p {
      margin-right: 10px;
      width: 20%
    }
  }
  .message {
    padding: 15px;
    display: flex;
    p {
      margin-right: 10px;
      width: 20%
    }
  }
}

.footer {
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 50px;
  display: flex;
  background: #fff;
  .checkBt {
    text-align: center;
    width: 50%;
    line-height: 50px;
    color: #666666;
  }
  .replyBt {
    text-align: center;
    width: 50%;
    line-height: 50px;
    color: #FFF;
    background: #3DA5FE;
  }
}
</style>
