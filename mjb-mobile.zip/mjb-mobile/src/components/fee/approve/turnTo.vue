<!--
  describe：转办组件
  Author: 欧倩伶
	Create: 2017-12-02
-->
<template>
  <div class="turnTo" v-if="infor.show">
    <my-header :title="top.title" :rightItem="'发送'" :showBack="true" @previous="hide" @on-click="sumbit"></my-header>
    <div class="has-header container">
      <div class="addressee border-bottom" @click="selectReceiver">
        <div class="receiver">
          <p class="p1">收件人: </p>
          <p class="p2">{{receiver}}</p>
        </div>
        <img src="../../../assets/images/fee/approve/right2x.png" alt="">
      </div>
      <div class="communication border-bottom">
        <x-textarea :max="40" v-model="words" placeholder="请填写转办内容"></x-textarea>
      </div>
    </div>
    <org v-model="orgnization" :show.sync="showOrg" :multi="true" @confirm="getReceiver" />
  </div>
</template>
<script>
import { XTextarea } from 'vux';
import MyHeader from '../../common/header';
import org from '../../common/org';

export default {
  components: {
    MyHeader,
    XTextarea,
    org,
  },
  props: {
    infor: {
      show: Boolean,
      formInstanceId: String,  // 表单实例id
      form_template_id: String,  // 表单模板id
    },
  },
  data() {
    return {
      words: '',
      orgnization: [],
      showOrg: false,
      top: {
        title: '转办',
      },
    };
  },
  methods: {
    sumbit() {
      this.showLoading();
      const param = {
        auditNote: this.words,
        formInstanceId: this.infor.formInstanceId,
        template_form_id: this.infor.form_template_id,
        model_id: '001',
        toOtherHandlerIds: this.toOtherHandlerIds,
      };
      this.$store.dispatch('commiss', param).then((res) => {
        if (res && res.code === '0000') {
          this.hideLoading();
          this.showToast({ msg: '提交成功' });
          setTimeout(() => {
            this.$emit('hide');
            this.$emit('successs');
          }, 2000);
        } else if (res && res.code) {
          this.hideLoading();
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    selectReceiver() {
      console.log(this.showOrg);
      this.showOrg = true;
    },
    getReceiver(users) {
      console.log(users);
      this.orgnization = users;
    },
    hide() {
      this.$emit('hide');
    },
  },
  computed: {
    receiver() {
      let users = '';
      this.orgnization.forEach((user) => {
        users += `${user.user_full_name},`;
      });
      return users;
    },
    toOtherHandlerIds() {
      let usersId = '';
      this.orgnization.forEach((user) => {
        usersId += `${user.user_id},`;
      });
      return usersId;
    },
  },
};
</script>
<style lang="less" scoped>
  .turnTo {
    position: fixed;
    top: 0;
    bottom: 0;
    width: 100%;
    background-color: #F4F4F4;
    z-index: 99;
  }
.container {
  background: #fff;
  .addressee {
    padding: 15px;
    display: flex;
    .receiver {
      width: -webkit-fill-available;
      display: flex;
      .p1 {
        width: 68px;
      }
      .p2 {
        width: -webkit-fill-available;
      }
    }
    img {
      height: 13px;
      margin: auto 0 auto 5px;
    }
  }
}
</style>
