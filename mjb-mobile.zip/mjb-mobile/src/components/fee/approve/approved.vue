<!--
  describe："审批-已审批"
  created by：panjm
  date：2017-12-1
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div infinite-scroll-immediate-check="true" v-infinite-scroll="loadMoreFun" infinite-scroll-disabled="busy" infinite-scroll-distance="10" infinite-scroll-throttle-delay="500" ref="scoller">
    <down-pull-loading @loading="refresh" v-if="orderList.length">
      <div class="invoiceBox" v-for="(data, index) in orderList" :key="index" slot='list' @click="goDetail(data.orderId, data.orderType)">
        <div class="invoiceLeft">
          <div :class="['invoiceType', {'blue':data.sign=='申请'},{'green':data.sign=='报销'},{'pink':data.sign=='借款'}]">
            {{ data.sign }}
          </div>
        </div>
        <div class="invoiceRight">
          <div class="invoiceSecondCol">
            <!-- <p>{{ data.description}}</p>
            <p>{{ data.order_type_name }}</p>
            <p>{{ data.last_update_date }}</p> -->
            <p>{{ data.description}}</p>
            <p>{{ data.templateType }}-{{ data.name }}</p>
            <p>{{ data.date }}</p>
            <p>{{ data.orderCode }}</p>
          </div>
          <div class="invoiceThirdCol">
            <p class="invoicePrice" v-if="myMenuCfgCurreny">￥{{ data.price }}</p>
            <p class="invoicePrice" v-else>{{ data.currenySymbol }} {{ data.price }}</p>
          </div>
        </div>
      </div>
    </down-pull-loading>

    <load-more v-if="loadMore" :tip="'加载中...'" style="width: 100%;padding: 22px 0px;box-sizing: border-box;margin:0 auto"></load-more>
    <div v-if="!orderList.length && isloading" class="emptyBox">
      <img class="no_data_img" src="../../../assets/images/common/no_data.png" alt="">
      <p class="no_data_text">暂无数据</p>
    </div>
  </div>
</template>

<script>
import { LoadMore } from 'vux';
import downPullLoading from '../../common/downPullLoading';
import curreny from '../../../../static/curreny.json';

export default {
  components: {
    LoadMore,
    downPullLoading,
  },
  data() {
    return {
      curreny,
      isloading: false,
      loadingFlag: 0,
      loadMore: false,
      busy: false,
      hasNextPage: true,
      pageInfo: {
        // is_history: 'Y',
        pageNumber: 1,
        pageSize: 15,
      },
      orderList: [],
      orderData: [],
      description: '无单据描述',
    };
  },
  methods: {
    // getApproveList(refresh) {
    //   return new Promise((resolve) => {
    //     this.$store.dispatch('myHistoryOrder', this.pageInfo).then((res) => {
    //       this.hideLoading();
    //       resolve();
    //       if (res && res.code === '0000') {
    //         this.isloading = true;
    //         if (res.data && res.data.datalist && res.data.datalist.length) {
    //           this.orderList = refresh ? res.data.datalist : this.orderList.concat(res.data.datalist);
    //           this.orderList.forEach((item) => {
    //             if (item.module_type === 'LM') {
    //               item.type = '借款';
    //               item.logo_color = 'pink';
    //             } else if (item.module_type === 'EC') {
    //               item.type = '报销';
    //               item.logo_color = 'green';
    //             } else {
    //               item.type = '申请';
    //               item.logo_color = 'blue';
    //             }
    //           });
    //           this.pageInfo.page_number += 1;
    //         } else if (res.data && res.data.datalist && !res.data.datalist.length) {
    //           this.hasNextPage = false;
    //           this.loadMore = false;
    //         }
    //       } else if (res && res.code) {
    //         this.showToast({ msg: `请求异常(${res.code})` });
    //       }
    //     });
    //   });
    // },
    getApproveList(refresh) {
      return new Promise((resolve) => {
        this.$store.dispatch('myHistoryOrder', this.pageInfo).then((res) => {
          this.hideLoading();
          resolve();
          if (res && res.code === '0000') {
            this.isloading = true;
            const self = this;
            if (res.data && res.data.data && res.data.data.length) {
              // 下拉刷新（refresh）时，数据获取第一页的数据
              this.orderData = refresh ? res.data.data : this.orderData.concat(res.data.data);
              this.orderList = [];
              this.orderData.forEach((item) => {
                const obj = {
                  sign: '',
                  description: '',
                  templateType: '', // 模板类型
                  name: '',
                  date: item.fdStartDate,
                  price: '',
                  orderId: '',
                  orderType: '', // 单据类型
                };
                const docSubject = item.docSubject.split('/');
                const formInstanceIdComponent = item.formInstanceId.split('_');
                let currenyName = docSubject[4];
                obj.currenySymbol = this.curreny[currenyName];
                obj.orderCode = docSubject[0];
                obj.name = docSubject[1];
                obj.sign = docSubject[2];
                obj.templateType = docSubject[2];
                obj.price = docSubject[3];
                obj.description = docSubject[5];
                obj.orderId = formInstanceIdComponent[0];
                obj.orderType = formInstanceIdComponent[1]; // 单据类型

                if (obj.orderType.indexOf('LM') >= 0) {
                  obj.sign = '借款';
                } else if (obj.orderType.indexOf('EC') >= 0) {
                  obj.sign = '报销';
                } else {
                  obj.sign = '申请';
                }
                self.orderList.push(obj);
              });
              this.pageInfo.pageNumber += 1;
            } else if (res.data && !res.data.data) {
              this.hasNextPage = false;
              this.loadMore = false;
            }
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      });
    },
    loadMoreFun() {
      if (this.hasNextPage) {
        setTimeout(() => {
          this.loadMore = true;
          this.getApproveList();
        }, 500);
      }
    },
    goDetail(approvalId, orderType) {
      if (orderType === 'EA') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/travelReim', query: { id: approvalId, type: orderType, isApproved: true },
          });
        }, 500);
      } else if (orderType === 'PA') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/feeReim', query: { id: approvalId, type: orderType, isApproved: true },
          });
        }, 500);
      } else if (orderType === 'EC') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/approvalReimburse', query: { id: approvalId, type: orderType, isApproved: true },
          });
        }, 500);
      } else if (orderType === 'LM') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/approveLoan', query: { id: approvalId, type: orderType, isApproved: true },
          });
        }, 500);
      } else if (orderType === 'CA') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/adjustAccount', query: { id: approvalId, type: orderType, isApproved: true },
          });
        }, 500);
      } else if (orderType === 'BM') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/budgetChange', query: { id: approvalId, type: orderType, isApproved: true },
          });
        }, 500);
      } else if (orderType === 'BA') {
        this.showToast({ msg: '移动端不支持查看该单据，请移步PC端操作' });
      }
    },
    refresh() {
      this.isloading = false;
      this.pageInfo.pageNumber = 1;
      return new Promise((resolve) => {
        this.getApproveList(true).then(() => {
          setTimeout(() => {
            resolve();
          }, 1000);
        });
      });
    },
  },
  mounted() {
    this.showLoading();
    this.getApproveList();
  },
  computed: {
    myMenuCfgCurreny() {
      return this.$store.state.menuConfig.fee.curreny;
    },
  }
};
</script>

