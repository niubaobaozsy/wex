<!--
  describe：审批附件列表页
  created by：黄喆
  date：2017-11-30
-->
<template>
  <div class="enclosure-container">
    <my-header title='附件' @previous="goBack"></my-header>
    <div class="content">
      <ul class="data-content">
        <li class="data-list border-bottom" @click="showBigImgFuc(index)">
          <img class="type-img" :src="address" alt="">
          <div class="list-content">
            <div class="name">发票323232</div>
            <div class="time">23232 <span class="size">22K</span></div>
          </div>
        </li>
        <li class="data-list border-bottom">
          <img class="type-img" :src="address" alt="">
          <div class="list-content">
            <div class="name">发票323232</div>
            <div class="time">23232 <span class="size">22K</span></div>
          </div>
        </li>
        <li class="data-list border-bottom">
          <img class="type-img" :src="address" alt="">
          <div class="list-content">
            <div class="name">发票323232</div>
            <div class="time">23232 <span class="size">22K</span></div>
          </div>
        </li>
      </ul>
    </div>
    <Gallery :show="showBigImg" :index="bigImgIndex" :list="showImgList" :hasDel="hasDel" @on-hide="hideImgView"></Gallery>
  </div>
</template>

<script type="text/ecmascript-6">
  import MyHeader from '../../common/header';
  import address from '../../../assets/images/trade/didi/address.png';
  import Gallery from '../../common/gallery';

  export default {
    components: {
      MyHeader,
      Gallery,
    },
    data() {
      return {
        bigImgIndex: 0,
        showBigImg: false, // 是否显示大图列表
        hasDel: false,
        showImgList: [],
        address,
      };
    },
    created() {
//      this.getFileByOrderMsg();
    },
    methods: {
      hideImgView() {
        this.showBigImg = false;
      },
      // 点击图片查看大图
      showBigImgFuc(index) {
        this.hasDel = true;
        this.bigImgIndex = index;
        setTimeout(() => {
          this.hideLoading();
          this.showBigImg = true;
        }, 1000);
      },
      getFileByOrderMsg() {
        const params = {
          source_system: 'Expense',
          source_order_id: '111920435091734528',
          source_order_type: 'EA',
        };
        this.$store.dispatch('getFileByOrderMsg', params)
          .then((rep) => {
            if (rep.code === '0000') {
              console.log(rep);
            }
          });
      },
      goBack() {
        this.$router.go(-1);
      },
    },
  };
</script>
<style lang="less" scoped>
  @white:#ffffff;

  .content {
    margin-top: 57px;
    .data-content {
      background: #ffffff;
      .data-list {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        .type-img {
          height: 40px;
          widthl: 40px;
          padding: 15px 12px 15px 15px;
        }
        .list-content {
          .time {
            font-size: 12px;
            color: #9B9B9B;
            .name {
              color: red;
            }
            .size {
              margin-left: 20px;
            }
          }
        }
      }
    }
  }
</style>
