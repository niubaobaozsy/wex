<!--
  describe：付款申请单审批
  created by：张绍武
  date：2017-11-28
-->
<template>
  <div class="approval has-footer">
    <my-header :title='top.type' @previous="goBack"></my-header>
    <div class="top has-header">
      <div>
        <p class="applyer" v-if="emspareqh.apply_name">{{emspareqh.apply_name}} | {{emspareqh.org_name}}</p>
        <i>{{emspareqh.order_template_name}} {{emspareqh.loan_info_code}}</i>
      </div>
      <div v-if="emspareqh.approve_amount">
        <p>￥{{ emspareqh.approve_amount.toFixed(2) }}</p>
        <section>{{ emspareqh.currency_code === 'CNY' ? ' | RMB' : '' }}</section>
      </div>
      <section>{{ emspareqh.sensitive_info }}</section>
    </div>
    <div class="main-top">
      <ul>
        <li v-if="emspareqh.vendor_name" class="border-bottom">
          <p class="type">开支主体</p>
          <div class="section-content">{{emspareqh.company_name}}</div>
        </li>
        <li>
          <p class="type">收款方</p>
          <div class="section-content">{{emspareqh.receiver}}/{{emspareqh.bank_name}}/{{emspareqh.bank_account}}</div>
        </li>
      </ul>
    </div>
    <div class="main">
      <ul>
        <li v-for='(item,index) in emspareqh.emspareqls' :key="index">
          <div class="border-bottom border-top" @click="addclass(index)">
            <div>
              <!--<img :src='top.showbottom' v-show="hide" class="img-show">-->
              <!--<img :src='top.hidetop' v-show="show" class="img-show">-->
              <section>预算明细{{index+1}}</section>
            </div>
          </div>
          <div class='border-bottom'>
            <span>发票号码</span>
            <section>{{item.invoice_code}}</section>
          </div>
          <div class='border-bottom'>
            <span>发票日期</span>
            <div>
              <section>{{item.invoice_date.slice(0, 10)}}</section>
            </div>
          </div>
          <div>
            <span>发票金额</span>
            <section class="amount">￥{{item.residue_amount.toFixed(2)}}</section>
          </div>
          <div>
            <span>本次付款金额</span>
            <section class="amount">￥{{item.payment_amount.toFixed(2)}}</section>
          </div>
        </li>
      </ul>
    </div>
    <attachment :formInstanceId="formInstanceId"></attachment>
    <div class='examine'>
      <div class='examine-top'>
        <span>审批记录</span>
      </div>
      <my-progress :title='list' :list="listNew" :current="current"></my-progress>
    </div>
    <div class="footerBtn" v-if="fdStatus">
      <div class="item scanInput" @click="operation">编辑</div>
      <div class="item manualInput" @click="operation">删除</div>
    </div>
    <div class="bottom-list" v-if="showBottomList">
      <div class="flet">
        <div class="more" @click="more(oplist[2])" v-if="oplist.length > 2 && showoplist.indexOf(oplist[2].operationType) !== -1">{{Object.keys(menus).length> 1 ? "更多": oplist[2].operationName}}
        </div>
        <div class="reject" @click="change(oplist[1])"
             v-if="oplist.length > 1 && showoplist.indexOf(oplist[1].operationType) !== -1">
          {{oplist[1].operationName}}
        </div>
      </div>
      <div class="pass" @click="change(oplist[0])"
           v-if="oplist.length && showoplist.indexOf(oplist[0].operationType) !== -1">
        {{oplist[0].operationName}}
      </div>
    </div>
    <actionsheet v-model="showAction" :menus="menus" :show-cancel="showCancel" @on-click-menu="jump"></actionsheet>
    <reject :rejectInfo="operateDeta" v-if="showReject" @hide="showReject=false" @successs="state"></reject>
    <pass :rejectInfo="operateDeta" v-if="showPass" @hide="showPass=false" @successs="state"></pass>
    <communication :infor="operateDeta" v-if="operateDeta.show" @hide="operateDeta.show=false" @successs="state"></communication>
    <turn-to :infor="inforTurn" v-if="inforTurn.show" @hide="inforTurn.show=false" @successs="state"></turn-to>
  </div>
</template>

<script type="text/ecmascript-6">
import { Actionsheet, Confirm } from 'vux';
import { platform } from '@/platform';
import MyHeader from '../../common/header';
import rtarrow from '../../../assets/rt-arrow.png';
import hideTravel from '../../../assets/images/fee/approve/hideTravel.png';
import showTravel from '../../../assets/images/fee/approve/showTravel.png';
import MyProgress from '../../common/proGress';
import reject from './approveReject.vue';
import pass from './approvePass.vue';
import communication from './communication.vue';
import turnTo from './turnTo.vue';
import attachment from '../../common/attachment';

export default {
  components: {
    MyHeader,
    MyProgress,
    Actionsheet,
    Confirm,
    reject,
    pass,
    communication,
    turnTo,
    attachment,
  },
  data() {
    return {
      showAction: false, // 是否显示更多组件
      showCancel: true,  // 是否显示取消按钮
      showReject: false,
      showPass: false,
      popup: '撤回该沟通消息',
      show: false,
      showoplist: ['handler_communicate', 'handler_returnCommunicate', 'handler_refuse', 'handler_cancelCommunicate', 'handler_commission', 'handler_pass'],
      top: {
        type: '付款申请单审批',
        arrow: rtarrow,
        hidetop: hideTravel,
        showbottom: showTravel,
      },
      menus: {},
      emspareqh: {},
      process: [],
      list: [],
      listNew: [],
      current:'',
      oplist: [],
      formInstanceId: '',
      operateDeta: {
        jumpToNodeId: '',
        formInstanceId: '',
        model_id: '001',
        template_form_id: '',
        show: false,
        status: '',  // 状态：check/reply
        linkContant: [],
      },
      inforTurn: {
        show: false,
        formInstanceId: '',  // 表单实例id
        form_template_id: '',  // 表单模板id
      },
      showBottomList: true, // 是否显示底部操作项
    };
  },
  created() {
    this.getEmspareqh();
  },
  computed:{
    fdStatus(){
      return this.$store.state.approve.fdStatus
    }
  },
  methods: {
    state() {
      setTimeout(() => {
        if (this.$store.state.extCall) {
          platform.exit();
        } else {
          this.$router.push({
            path: '/fee/approve/',
          });
        }
      }, 500);
    },
    //     或者展示信息的接口
    getEmspareqh() {
      this.showLoading();
      this.$store.dispatch('getEmspareqh', this.$route.query.id).then((res) => {
        this.hideLoading();
        if (res.code === '0000') {
          this.emspareqh = res.data.emspareqh;
          this.formInstanceId = res.data.emspareqh.formInstanceId;
          this.operateDeta.formInstanceId = this.formInstanceId;
          this.operateDeta.template_form_id = this.emspareqh.form_template_id;
          //            this.emscaapportionh = res.data.emscaapportionh;
          //            const star = this.emscaapportionh.form_template_name.indexOf('_');
          //            const last = this.emscaapportionh.form_template_name.lastIndexOf('_');
          //            this.emscaapportionh.form_template_name = this.emscaapportionh.form_template_name.substring(star + 1, last);
          this.grtFlowt();
          this.getLog();
          this.getOplist();
        } else {
          this.showToast({ msg: '找不到申请单' });
          //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    grtFlowt() {
      this.$store.dispatch('grtFlowt', {
        formInstanceId: this.formInstanceId, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.emspareqh.form_template_id,
      }).then((res) => {
        if (res.code === '0000') {
          this.listNew = res.data;
          this.listNew.forEach(item =>{
            if(item.current){
              this.current = item.fdNodeHandlerNames;
            }
          })
        }
      });
    },
    //      获取操作按钮节点
    getOplist() {
      this.$store.dispatch('getOplist', {
        formInstanceId: this.formInstanceId,
        model_id: '001',
        template_form_id: this.emspareqh.form_template_id,
      })
        .then((res) => {
          if (res.code === '0000') {
            let list = [];
            if (res.data.length) {
              res.data.forEach((item) => {
                list = list.concat(item.operations);
              });
              const newList = [];
              list.forEach((item, index) => {
                if (item.operationType === 'handler_refuse') {
                  console.log(item);
                  list.splice(index, 1);
                  list.splice(1, 0, item);
                  console.log(list);
                } else if (item.operationType === 'handler_pass') {
                  list.splice(index, 1);
                  list.splice(0, 0, item);
                }
                if (newList.indexOf(item.operationType) === -1) {
                  newList.push(item.operationType);
                } else {
                  list.splice(index, 1);
                }
              });
              this.oplist = list;
              this.oplist.forEach((item, index) => {
                if (index > 1 && this.showoplist.indexOf(item.operationType) !== -1) {
                  const obj = {
                    [item.operationType]: `<span style="color: #666666;">${item.operationName}</span>`,
                  };
                  this.menus = Object.assign({}, this.menus, obj);
                }
              });
            } else {
              list = [];
            }
          } else {
            this.showToast({ msg: res.msg });
          }
        }, () => {
          this.showToast({ msg: '页面开小差，请稍候重试' });
        });
    },
    //      获取已经审批过得节点信息
    getLog() {
      this.$store.dispatch('getLog', {
        formInstanceId: this.formInstanceId, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.emspareqh.form_template_id,
      }).then((res) => {
        if (res.code === '0000') {
          this.list = res.data.filter(log => log.fdActionKey.indexOf('走分支') === -1);
        } else {
          this.showToast({ msg: '找不到待审批节点信息' });
          //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    //      获取取消沟通节点
    cancelOpparam() {
      this.showLoading();
      this.$store.dispatch('cancelOpparam', {
        approveType: 'handler_cancelCommunicate',
        formInstanceId: this.formInstanceId, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.emspareqh.form_template_id,
      }).then((res) => {
        if (res.code === '0000') {
          const communicateWorkitemList = res.data.handler_cancelCommunicate.communicateWorkitemList;
          let communicateArr = '';
          communicateWorkitemList.forEach((item) => {
            communicateArr += `${item.id};`;
          });
          this.celcommunicate(communicateArr);
        } else {
          this.showToast({ msg: '找不到待审批节点信息' });
          //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    //      取消沟通
    celcommunicate(value) {
      this.$store.dispatch('celcommunicate', {
        cancelHandlerIds: value,
        formInstanceId: this.formInstanceId, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.emspareqh.form_template_id,
      }).then((res) => {
        if (res.code === '0000') {
          this.showToast({ msg: '成功取消沟通' });
          setTimeout(() => {
            if (this.$store.state.extCall) {
              platform.exit();
            } else {
              this.$router.push({
                path: '/fee/approve/',
              });
            }
          }, 500);
        } else {
          this.showToast({ msg: '找不到待审批节点信息' });
          //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    // 更多
    more(obj) {
      if (Object.keys(this.menus).length > 1) {
        this.showAction = !this.showAction;
      } else {
        switch (obj.operationType) {
          case 'handler_communicate':
            this.operateDeta.show = true;
            this.operateDeta.status = '';
            this.operateDeta.linkContant = this.list;
            break;
          case 'handler_cancelCommunicate':
            this.cancelOpparam();
            break;
          case 'handler_commission':
            this.inforTurn.show = true;
            this.inforTurn.formInstanceId = this.formInstanceId;
            this.inforTurn.form_template_id = this.emspareqh.form_template_id;
            break;
          case 'handler_returnCommunicate':
            this.operateDeta.show = true;
            this.operateDeta.status = 'reply';
            this.operateDeta.linkContant = this.list;
            break;
          case 'handler_pass':
            this.showPass = true;
            break;
          default:
        }
      }
    },
    // 点击更多的时候的沟通/转办
    jump(ket) {
      switch (ket) {
        case 'handler_communicate':
          this.operateDeta.status = '';
          this.operateDeta.linkContant = this.list;
          this.operateDeta.show = true;
          break;
        case 'handler_commission':
          this.inforTurn.show = true;
          this.inforTurn.formInstanceId = this.formInstanceId;
          this.inforTurn.form_template_id = this.emspareqh.form_template_id;
          break;
        case 'handler_refuse':
          this.operateDeta.jumpToNodeId = this.listNew[0].fdNodeId;
          this.showReject = true;
          break;
        default:
      }
    },
    change(obj) {
      switch (obj.operationType) {
        case 'handler_communicate':
          this.operateDeta.show = true;
          this.operateDeta.status = '';
          this.operateDeta.linkContant = this.list;
          break;
        case 'handler_cancelCommunicate':
          this.cancelOpparam();
          break;
        case 'handler_refuse':
          this.operateDeta.jumpToNodeId = this.listNew[0].fdNodeId;
          this.showReject = true;
          break;
        case 'handler_commission':
          this.inforTurn.show = true;
          this.inforTurn.formInstanceId = this.formInstanceId;
          this.inforTurn.form_template_id = this.form_template_id;
          break;
        case 'handler_returnCommunicate':
          this.operateDeta.show = true;
          this.operateDeta.status = 'reply';
          this.operateDeta.linkContant = this.list;
          break;
        case 'handler_pass':
          this.showPass = true;
          break;
        case 'drafter_press':
          this.showPass = true;
          break;
        default:
      }
    },
    goBack() {
      this.$store.commit('REC_FDSTATUS')
      if (this.$store.state.extCall) {
        platform.exit();
      } else {
        this.$router.go(-1);
      }
    },
    addclass(index) {
      const newIndex = this.Listshow.indexOf(index);
      if (newIndex === -1) {
        this.Listshow.push(index);
      } else {
        this.Listshow.splice(newIndex, 1);
      }
    },
    operation(){
      this.showToast({ msg: '移动端暂不支持该类型操作，请移步PC端' });
    }
  },
  mounted() {
    if (this.$route.query.isApproved) {
      this.showBottomList = false;
    }
  },
};
</script>

<style lang='less' scoped>
.approval {
  font-family: PingFangSC-Regular;
  font-size: 16px;
  color: #000000;
  line-height: 16px;
}

.top {
  background: #484759;
  width: 92%;
  padding: 0 4%;
  position: relative;
  color: #ffffff;

  div {
    display: flex;
    align-items: center;
    .applyer {
      width: 50%;
    }
    i {
      position: absolute;
      right: 0;
      display: inline-block;
      font-style: normal;
      font-size: 12px;
      padding: 0 15px;
      height: 20px;
      background: #6F6E82;
      border-radius: 10px 0 0 10px;
      text-align: center;
      line-height: 18px;
    }
  }
  div:nth-of-type(1) {
    padding: 11px 0 15px 0;
    justify-content: space-between;
    align-items: center;
  }

  div:nth-of-type(2) {
    padding-bottom: 15px;

    p {
      margin-right: 5px;
      color: #3DA5FE;
    }

    section {
      padding-bottom: 0 !important;
    }
  }
  section {
    padding-bottom: 19px;
    opacity: 0.6;
  }
}

.main-top {
  width: 92%;
  padding: 0 4%;
  background: #FFFFFF;
  color: #000000;
  .type {
    width: 108px;
    color: #858585;
  }
  .section-content {
    text-align: end;
    word-break: break-all;
    line-height: 1.5;
  }

  ul {
    list-style-type: none;
    margin-bottom: 10px;

    li {
      display: flex;
      padding: 10px 0;
      justify-content: space-between;
      align-items: center;
      position: relative;
    }

    div {
      & .stop {
        position: absolute;
        top: 0;
      }
    }
  }
}

.main {
  width: 92%;
  padding: 0 4%;
  background: #FFFFFF;
  color: #000000;

  ul {
    list-style-type: none;

    li {

      div {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 50px;
      }
      span {
        color: #858585;
      }
      .amount {
        color: #3DA5FE;
      }
      div:nth-of-type(1) {

        span {
          display: inline-block;
          width: 0;
          height: 0;
          border-left: 6px solid transparent;
          border-right: 6px solid transparent;
          border-top: 7px solid #AFAFAF;
          margin-right: 6px;
        }
      }
    }
  }
}

.has-bottom {
  margin-top: 10px;
  padding-left: 13px;
  background: #ffffff;
  box-shadow: 0 0 0 0 #DEDFE0, 0 0 0 0 #DEDFE0;

  .router {
    height: 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #858585;

    .detailed {
      color: #3DA5FE;
      padding-right: 13px;
    }
  }
}

.img {
  width: 7px;
  height: 13px;
  padding-left: 10px;
}

.examine {
  margin: 10px 0 100px 0;
  background: #ffffff;

  .examine-top {
    height: 48px;
    padding: 0 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #858585;
    border-bottom: 1px solid #cbcfd6;
    p {
      width: 70px;
      height: 30px;
      background: #3da5fe;
      text-align: center;
      line-height: 30px;
      border-radius: 40px;
    }
  }
}

.bottom-list {
  width: 100%;
  text-align: center;
  line-height: 50px;
  margin-bottom: 0;
  background: #ffffff;
  box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
  position: fixed;
  bottom: 0;
  display: flex;
  justify-content: space-between;
  color: #666666;
  font-size: 18px;
  .flet {
    flex: 1;
    display: flex;
    .more {
      flex: 1;
    }
    .reject {
      flex: 1;
    }
  }
  .pass {
    flex: 1;
    background: #3DA5FE;
    color: #ffffff;
  }
}

.enclosure {
  margin-top: 10px;
  padding-left: 13px;
  background: #ffffff;
  height: 50px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #858585;

  .detailed {
    color: #3DA5FE;
    padding-right: 13px;
  }
}
  .footerBtn{
  line-height: 1.6;
  width: 100%;
  position: fixed;
  bottom: 0;
  display: flex;
  justify-content: space-between;
  border-top: #DEDFE0 1px solid;
  .item{
    width: 50%;
    text-align: center;
    padding:11px 0;
    font-size: 18px;
  }
  .manualInput{
    color: #666666;
    background-color: #ffffff;
  }
  .scanInput{
    background-color: #3DA5FE;
    color:#ffffff !important;
  }
}
</style>
