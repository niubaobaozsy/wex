<!--
  describe：getApproveList
  created by：DKZ
  date：2018-3-13
-->
<template>
  <div infinite-scroll-immediate-check="true" v-infinite-scroll="loadMoreFun" infinite-scroll-disabled="busy" infinite-scroll-distance="10" infinite-scroll-throttle-delay="500" ref="scoller">
      <div class="data-list">
          <down-pull-loading @loading="refresh">
            <div slot="list">
              <div class="Title-box border" @click="showApproving()">
                <div class="title" v-show="!isshow"> ▾ 我的在审批单</div>
                <div class="title" v-show="isshow"> ▴ 我的在审批单</div>
              </div>
              <div v-for="(data, index) in orderList" :key="index" @click="goDetail(data)" v-show="isshow" v-if="orderList.length">
                    <div class="invoiceBox">
                        <div class="invoiceLeft">
                            <div :class="['invoiceType',{'blue':data.sign=='申请'},{'green':data.sign=='报销'},{'pink':data.sign=='借款'}]">
                                {{ data.sign }}
                            </div>
                        </div>
                        <div class="invoiceRight">
                            <div class="invoiceSecondCol">
                                <p>{{ data.description||'未填写' }}</p>
                                <p class="cur-msg">当前审批人<span class="improtant-msg">{{ data.currentHandler || '无' }}</span></p>
                                <p>{{ data.applyDate }}</p>
                            </div>
                            <div class="invoiceThirdCol">
                                <p class="invoicePrice" v-if="myMenuCfgCurreny">￥{{ data.approveAmount }}</p>
                                <p class="invoicePrice" v-else>{{ data.currenySymbol }} {{ data.approveAmount }}</p>
                                <p class="cur-msg">审批进度
                                  <span class="improtant-msg" v-if="data.currentIndex&&data.totalStep" v-text="data.currentIndex===data.totalStep?'已完成':`${data.currentIndex}/${data.totalStep}`"></span>
                                  <span class="improtant-msg" v-else>无</span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <load-more v-if="(loadMore||isloading)&&isshow" :tip="'加载中...'" style="width: 100%;padding: 22px 0px;box-sizing: border-box;margin:0 auto;background-color: #fff;"></load-more>
                <div v-if="(!orderList.length && !isloading)&&isshow" class="emptyBox">
                  <!-- <img class="no_data_img" src="../../../assets/images/common/no_data.png" alt=""> -->
                  <p class="empty-tip">暂无在审单据</p>
                </div>
            </div>
          </down-pull-loading>
    </div>
  </div>
</template>
<script>
import {
    Swipeout,
    SwipeoutItem,
    SwipeoutButton,
    XButton,
    XSwitch,
    LoadMore,
    TransferDomDirective as TransferDom
} from 'vux';
import {
    throws
} from 'assert';
import downPullLoading from '../../common/downPullLoading';
import curreny from '../../../../static/curreny.json';

export default {
    components: {
        Swipeout,
        SwipeoutItem,
        SwipeoutButton,
        XButton,
        XSwitch,
        TransferDom,
        LoadMore,
        downPullLoading,
    },
    data() {
        return {
            curreny,
            isloading: false,
            loadingFlag: 0,
            loadMore: false,
            busy: false,
            hasNextPage: true,
            pageInfo: {
                page_number: 0,
                page_size: 15,
            },
            isshow: true,
        };
    },

    computed: {
      orderList() {
        return this.$store.state.approve.approveMsgFeed;
      },
      myMenuCfgCurreny() {
        return this.$store.state.menuConfig.fee.curreny;
      },
    },
    methods: {
        showApproving(){
            this.isshow=!this.isshow;
        },
        getApproveList(refresh) {
          if (this.isloading) return false;
          if (refresh) {
            this.pageInfo.page_number = 1;
          } else {
            this.pageInfo.page_number += 1;
          }
            return new Promise((resolve) => {
              const param = Object.assign({}, this.pageInfo, { module_types: 'EC,LM,EA,PA,CA,BM' });
              this.isloading = true;
              this.$store.dispatch('queryFeeOrderFlowStepForApp', param).then((res) => {
                    resolve();
                    if (res && res.code === '0000') {
                        this.isloading = false;
                        const self = this;
                        if (res.data && res.data.datalist && res.data.datalist.length) {
                            // 下拉刷新（refresh）时，数据获取第一页的数据
                            this.orderData = refresh ? res.data.datalist : this.orderData.concat(res.data.datalist);
                            const orderList = [];
                            this.orderData.forEach((item) => {
                                const obj = {
                                    sign: '',
                                    description: item.description,
                                    currentHandler: item.currentHandler,
                                    applyDate: item.apply_date,
                                    approveAmount: item.approve_amount,
                                    id: item.id,
                                    orderType: item.module_type, // 单据类型
                                    currentIndex: item.currentIndex,
                                    totalStep: item.totalStep,
                                };
                                if (obj.orderType.indexOf('LM') >= 0) {
                                    obj.sign = '借款';
                                } else if (obj.orderType.indexOf('EC') >= 0) {
                                    obj.sign = '报销';
                                } else {
                                    obj.sign = '申请';
                                }
                                // 币种
                                let currenyName = item.currency_name;
                                obj.currenySymbol = this.curreny[currenyName];
                                orderList.push(obj);
                            });
                            this.$store.commit('APPROVEMSGFEED', orderList);
                            this.$nextTick(() => {
                                self.vuxChangeWidth();
                            });
                        } else if (res.data && !res.data.datalist) {
                            this.hasNextPage = false;
                            this.loadMore = false;
                        }
                    } else if (res && res.msg) {
                        this.showToast({
                            msg: `请求异常[${res.msg}]`
                        });
                    }
                });
            });
        },
        goDetail(apply) {
          const orderType = apply.orderType;
          const approvalId = apply.id;
            if (orderType === 'EA') {
                setTimeout(() => {
                    this.$router.push({
                        path: '/fee/approve/travelReim',
                        query: {
                            id: approvalId,
                            type: orderType,
                            isApproved: false
                        },
                    });
                }, 500);
            } else if (orderType === 'PA') {
                setTimeout(() => {
                    this.$router.push({
                        path: '/fee/approve/feeReim',
                        query: {
                            id: approvalId,
                            type: orderType,
                            isApproved: false
                        },
                    });
                }, 500);
            } else if (orderType === 'EC') {
                setTimeout(() => {
                    this.$router.push({
                        path: '/fee/approve/approvalReimburse',
                        query: {
                            id: approvalId,
                            type: orderType,
                            isApproved: false
                        },
                    });
                }, 500);
            } else if (orderType === 'LM') {
                setTimeout(() => {
                    this.$router.push({
                        path: '/fee/approve/approveLoan',
                        query: {
                            id: approvalId,
                            type: orderType,
                            isApproved: false
                        },
                    });
                }, 500);
            } else if (orderType === 'CA') {
                setTimeout(() => {
                    this.$router.push({
                        path: '/fee/approve/adjustAccount',
                        query: {
                            id: approvalId,
                            type: orderType,
                            isApproved: false
                        },
                    });
                }, 500);
            } else if (orderType === 'BM') {
                setTimeout(() => {
                    this.$router.push({
                        path: '/fee/approve/budgetChange',
                        query: {
                            id: approvalId,
                            type: orderType,
                            isApproved: false
                        },
                    });
                }, 500);
            } else if (orderType === 'BA') {
              this.showToast({ msg: '移动端不支持查看该单据，请移步PC端操作' });
            }
        },
        loadMoreFun() {
            if (this.hasNextPage) {
                setTimeout(() => {
                    this.loadMore = true;
                    this.getApproveList();
                }, 500);
            }
        },
        refresh() {
            this.getApproveList(true);
        },
        vuxChangeWidth() {
            // 修改vux-swiper-item距离content的宽
            if (this.$refs.swip) {
                this.$refs.swip.forEach((swip) => {
                    const list = swip.$slots['right-menu'][0].children.filter(one => one.tag);
                    list.forEach((one) => {
                        one.componentOptions.propsData.width = 66;
                    });
                });
            }
        },
    },
  mounted() {
    this.orderData = [];
    this.getApproveList();
  },
};
</script>


<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
.Title-box {
    padding-left: 15px;
    padding-top: 10px;
    padding-bottom: 10px;
    width: 100%;
    box-sizing: border-box;
    background-color: white;
}
.data-list {
  margin-top: 1px;
}
.cur-msg {
  font-size: 14px;
  line-height: 20px;
  color: #9B9B9B;
  white-space: nowrap;
  .improtant-msg {
    color: rgb(240, 139, 15);
    margin-left: 5px;
  }
}
.empty-tip {
  text-align: center;
  color: #858585;
  font-size: 12px;
  padding: 20px 0;
  background-color: #fff;
}
</style>
