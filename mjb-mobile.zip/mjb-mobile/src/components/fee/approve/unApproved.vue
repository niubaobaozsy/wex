<!--getApproveList
  describe："审批-未审批"
  created by：panjm
  date：2017-12-1
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div infinite-scroll-immediate-check="true" v-infinite-scroll="loadMoreFun" infinite-scroll-disabled="busy" infinite-scroll-distance="10" infinite-scroll-throttle-delay="500" ref="scoller">
    <down-pull-loading @loading="refresh" v-if="orderList.length">
      <!-- <swipeout slot='list'>
        <swipeout-item v-for="(data, index) in orderList" :key="index" ref="swip">
          <div slot="right-menu">
            <swipeout-button @click.native="operate(index, 'reject')" style="font-size:17px;background:#A8ABB2;width: 66px;">驳回</swipeout-button>
            <swipeout-button @click.native="operate(index, 'pass')" style="font-size:17px;background:#6CC60A;width: 66px;">通过</swipeout-button>
          </div>
          <div slot="content" @click="goDetail(data.orderId, data.orderType)">
            <div class="invoiceBox">
              <div class="invoiceLeft">
                <div :class="['invoiceType',{'blue':data.sign=='申请'},{'green':data.sign=='报销'},{'pink':data.sign=='借款'}]">
                  {{ data.sign }}
                </div>
              </div>
              <div class="invoiceRight">
                <div class="invoiceSecondCol">
                  <p>{{ data.description}}</p>
                  <p>{{ data.templateType }}-{{ data.name }}</p>
                  <p>{{ data.date }}</p>
                </div>
                <div class="invoiceThirdCol">
                  <p class="invoicePrice">￥{{ data.price }}</p>
                  <span class="invoiceStatus tipRed" v-if="data.first_node_status=='需沟通'">{{ data.first_node_status }}</span>需要注释
                </div>
              </div>
            </div>
          </div>
        </swipeout-item>
      </swipeout> -->
      <!-- @click="goDetail(data.orderId, data.orderType) -->
      <div slot="list" v-for="(data, index) in orderList" :key="index" @click="operation(data)">
        <div class="invoiceBox">
          <!-- <div v-if="checkboxStatus">
            <span class="check-box" :class="{unchecked:data.unchecked,checked:data.checked}"></span>
          </div> -->
          <div class="invoiceLeft">
            <div :class="['invoiceType',{'blue':data.sign=='申请'},{'green':data.sign=='报销'},{'pink':data.sign=='借款'}]">
              {{ data.sign }}
            </div>
          </div>
          <div class="invoiceRight">
            <div class="invoiceSecondCol">
              <p>{{ data.description}}</p>
              <p>{{ data.templateType }}-{{ data.name }}</p>
              <p>{{ data.date }}</p>
              <p>{{ data.orderCode }}</p>
            </div>
            <div class="invoiceThirdCol">
              <p class="invoicePrice" v-if="myMenuCfgCurreny">￥{{ data.price }}</p>
              <p class="invoicePrice" v-else>{{ data.currenySymbol }} {{ data.price }}</p>
              <!-- <span class="invoiceStatus tipRed" v-if="data.first_node_status=='需沟通'">{{ data.first_node_status }}</span> -->
            </div>
          </div>
        </div>
      </div>
    </down-pull-loading>

    <load-more v-if="loadMore" :tip="'加载中...'" style="width: 100%;padding: 22px 0px;box-sizing: border-box;margin:0 auto"></load-more>
    <div v-if="!orderList.length && isloading" class="emptyBox">
      <img class="no_data_img" src="../../../assets/images/common/no_data.png" alt="">
      <p class="no_data_text">暂无数据</p>
    </div>
    <!-- <div class="footerBtn" v-if="checkboxStatus">
      <div class="item manualInput">删除</div>
      <div class="item scanInput" @click="cancel">取消</div>
    </div> -->
    <reject :rejectInfo="rejectParams" v-if="showReject" @hide="showReject=false"></reject>
    <pass :rejectInfo="PassParams" v-if="showPass" @hide="showPass=false"></pass>
  </div>
</template>

<script>
import { Swipeout, SwipeoutItem, SwipeoutButton, XButton, XSwitch, LoadMore, TransferDomDirective as TransferDom } from 'vux';
import { throws } from 'assert';
import downPullLoading from '../../common/downPullLoading';
import reject from './approveReject.vue';
import pass from './approvePass.vue';
import curreny from '../../../../static/curreny.json';

export default {
  components: {
    Swipeout,
    SwipeoutItem,
    SwipeoutButton,
    XButton,
    XSwitch,
    TransferDom,
    LoadMore,
    downPullLoading,
    reject,
    pass,
  },
  data() {
    return {
      curreny,
      isloading: false,
      loadingFlag: 0,
      loadMore: false,
      busy: false,
      hasNextPage: true,
      showReject: false,
      showPass: false,
      pageInfo: {
        pageNumber: 1,
        pageSize: 15,
      },
      orderList: [],
      orderData: [],
      rejectParams: {
        jumpToNodeId: '',
        formInstanceId: '',
        model_id: '',
        template_form_id: '',
      },
      PassParams: {
        formInstanceId: '',
        model_id: '',
        template_form_id: '',
      },
    };
  },
  methods: {
    getApproveList(refresh) {
      return new Promise((resolve) => {
        this.$store.dispatch('myGetMessage', this.pageInfo).then((res) => {
          this.hideLoading();
          resolve();
          if (res && res.code === '0000') {
            this.isloading = true;
            const self = this;
            if (res.data && res.data.data && res.data.data.length) {
              // 下拉刷新（refresh）时，数据获取第一页的数据
              this.orderData = refresh ? res.data.data : this.orderData.concat(res.data.data);
              this.orderList = [];
              this.orderData.forEach((item) => {
                const obj = {
                  checked:false,
                  unchecked:true,
                  sign: '',
                  description: '',
                  templateType: '', // 模板类型
                  name: '',
                  date: item.fdStartDate,
                  fdStatus:item.fdStatus,
                  price: '',
                  orderId: '',
                  orderType: '', // 单据类型
                };
                const docSubject = item.docSubject.split('/');
                const formInstanceIdComponent = item.formInstanceId.split('_');
                let currenyName = docSubject[4];
                obj.currenySymbol = this.curreny[currenyName];
                obj.orderCode = docSubject[0];
                obj.name = docSubject[1];
                obj.sign = docSubject[2];
                obj.templateType = docSubject[2];
                obj.price = docSubject[3];
                obj.description = docSubject[5];
                obj.orderId = formInstanceIdComponent[0];
                obj.orderType = formInstanceIdComponent[1]; // 单据类型

                if (obj.orderType.indexOf('LM') >= 0) {
                  obj.sign = '借款';
                } else if (obj.orderType.indexOf('EC') >= 0) {
                  obj.sign = '报销';
                } else {
                  obj.sign = '申请';
                }
                self.orderList.push(obj);
              });
              this.pageInfo.pageNumber += 1;
              this.$nextTick(() => {
                self.vuxChangeWidth();
              });
            } else if (res.data && !res.data.data) {
              this.hasNextPage = false;
              this.loadMore = false;
            }
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      });
    },
    goDetail(approvalId, orderType) {
      if (orderType === 'EA') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/travelReim', query: { id: approvalId, type: orderType, isApproved: false },
          });
        }, 500);
      } else if (orderType === 'PA') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/feeReim', query: { id: approvalId, type: orderType, isApproved: false },
          });
        }, 500);
      } else if (orderType === 'EC') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/approvalReimburse', query: { id: approvalId, type: orderType, isApproved: false },
          });
        }, 500);
      } else if (orderType === 'LM') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/approveLoan', query: { id: approvalId, type: orderType, isApproved: false },
          });
        }, 500);
      } else if (orderType === 'CA') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/adjustAccount', query: { id: approvalId, type: orderType, isApproved: false },
          });
        }, 500);
      } else if (orderType === 'BM') {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/approve/budgetChange', query: { id: approvalId, type: orderType, isApproved: false },
          });
        }, 500);
      } else if (orderType === 'BA') {
        this.showToast({ msg: '移动端不支持审批该类型单据，请移步PC端操作' });
      }
    },
    operate(index, operation) {
      if (operation === 'reject') {
        this.rejectParams.jumpToNodeId = this.orderData[index].fdNodeId;
        this.rejectParams.formInstanceId = this.orderData[index].formInstanceId;
        this.rejectParams.model_id = this.orderData[index].modelId;
        this.rejectParams.template_form_id = this.orderData[index].templateFormId;
        this.showReject = true;
      } else {
        this.PassParams.formInstanceId = this.orderData[index].formInstanceId;
        this.PassParams.model_id = this.orderData[index].modelId;
        this.PassParams.template_form_id = this.orderData[index].templateFormId;
        this.showPass = true;
      }
    },
    operation(data){
      if(data.fdStatus === '11'){
        this.$store.commit('CHANGE_FDSTATUS');
      }
      this.goDetail(data.orderId,data.orderType)
    },
    loadMoreFun() {
      if (this.hasNextPage) {
        setTimeout(() => {
          this.loadMore = true;
          this.getApproveList();
        }, 500);
      }
    },
    refresh() {
      this.isloading = false;
      this.pageInfo.pageNumber = 1;
      return new Promise((resolve) => {
        this.getApproveList(true).then(() => {
          setTimeout(() => {
            resolve();
          }, 1000);
        });
      });
    },
    vuxChangeWidth() {
      // 修改vux-swiper-item距离content的宽
      if (this.$refs.swip) {
        this.$refs.swip.forEach((swip) => {
          const list = swip.$slots['right-menu'][0].children.filter(one => one.tag);
          list.forEach((one) => {
            one.componentOptions.propsData.width = 66;
          });
        });
      }
    },
    filterBill(){
      // alert('1111111')
      this.orderList.forEach((item,index)=>{
        if(item.fdStatus === '11'){
          item.unchecked = false;
        }
      })
    },
    pickBill(data){
      this.orderList.forEach(item =>{
        item.checked  = false;
        if(item.orderId === data.orderId && item.fdStatus === '11'){
          item.checked = true;
        }
      })
    },
    cancel(){
      this.$store.commit('APP_REC_CBSTATUS')
    }
  },
  // computed:{
  //   checkboxStatus(){
  //     return this.$store.state.approve.appCbStatus
  //   },
  //   orderListLength(){
  //     return this.orderList.length
  //   }
  // },
  // watch:{
  //   checkboxStatus:function(newValue,oldValue){
  //     if(newValue){
  //       this.filterBill()
  //     }
  //   },
  //   orderListLength:function(newValue,oldValue){
  //     // alert(newValue,oldValue)
  //     if(newValue !== oldValue && this.checkboxStatus){
  //       // alert('11111111')
  //       this.filterBill();
  //     }
  //   }
  // },
  mounted() {
    this.showLoading();
    this.getApproveList();
  },
  computed: {
    myMenuCfgCurreny() {
      return this.$store.state.menuConfig.fee.curreny;
    },
  }
};
</script>

<style lang="less" scoped>
.check-box {
  display: block;
  box-sizing: border-box;
  width: 18px;
  height: 18px;
  margin:24px 20px;
  border-radius: 9px;
  border: 1px #ADADAD solid;
}

.unchecked{
  background:#f6f6f6;
}


.checked {
  border: 0px;
  background-image: url(../../../assets/images/common/checked.png);
  background-repeat: no-repeat;
  background-position: center;
  background-size: contain;
}
</style>

