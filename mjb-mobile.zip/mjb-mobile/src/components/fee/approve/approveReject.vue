<!--
  describe："审批-驳回"
  created by：panjm
  date：2017-12-1
-->
<template>
  <div class="mine-wrap">
    <div class="mine-content">
      <my-header :title="top.title" @previous="goBack" :rightItem="'提交'" @on-click="submit"></my-header>
      <div class="has-header">
        <textarea class="content" v-model="auditNote" placeholder="请填写驳回原因" autofocus="autofocus" maxlength="40"></textarea>
        <div class="wordLimit">{{ wordNum }}/40</div>
      </div>
    </div>
  </div>
</template>

<script>
import MyHeader from '../../common/header';

export default {
  props: {
    show: Boolean,
    rejectInfo: {
      jumpToNodeId: String,
      formInstanceId: String,
      model_id: String,
      template_form_id: String,
    },
  },
  components: {
    MyHeader,
  },
  data() {
    return {
      top: {
        title: '驳回',
      },
      wordNum: 0,
      auditNote: '',
      refusePassedToThisNode: false,
    };
  },
  methods: {
    goBack() {
      this.$emit('hide');
    },
    submit() {
      this.showLoading();
      const params = {
        jumpToNodeId: this.rejectInfo.jumpToNodeId,
        formInstanceId: this.rejectInfo.formInstanceId,
        model_id: this.rejectInfo.model_id,
        template_form_id: this.rejectInfo.template_form_id,
        auditNote: this.auditNote,
        refusePassedToThisNode: this.falrefusePassedToThisNodese,
      };
      if (this.auditNote) {
        this.$store.dispatch('myRefuse', params).then((res) => {
          if (res && res.code === '0000') {
            this.hideLoading();
            this.showToast({ msg: '提交成功' });
            setTimeout(() => {
              this.$emit('successs');
              this.$emit('hide');
            }, 1000);
          } else if (res && res.code) {
            this.hideLoading();
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      } else {
        this.hideLoading();
        this.showToast({ msg: '驳回原因不可为空！' });
      }

    },
  },
  watch: {
    auditNote(newVal) {
      this.wordNum = 40 - newVal.length; // 字体限制为40个
    },
  },
};
</script>
<style lang="less" scoped>
textarea {
  outline: none;
  resize: none;
  border: none;
}

textarea::-webkit-input-placeholder {
  /* WebKit*/
  color: #CECECE;
}
.mine-content{
  position: fixed;
  top: 0;
  bottom: 0;
  width: 100%;
  background-color: #F4F4F4;
  z-index: 99;
}
.content {
  width: 100%;
  height: 122px;
  padding: 16px 16px;
  font-size: 16px;
  line-height: 22px;
  box-sizing: border-box;
  background-color: #ffffff;
}
.wordLimit {
  width: 100%;
  font-size: 16px;
  line-height: 22px;
  padding: 8px 16px;
  margin-top: -7px;
  text-align: right;
  box-sizing: border-box;
  color: #CECECE;
  background-color: #ffffff;
  border-bottom: 0.3px solid #DEDFE0;
}
</style>

