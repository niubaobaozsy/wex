<!--
  describe：审批调账申请
  created by：黄喆
  date：2017-12-16
-->
<template>
  <div class="approval has-footer">
    <my-header :title='top.type' @previous="goBack"></my-header>
    <div class="top has-header">
      <div class="top-list">
        <p class="applyer">{{emscaapportionh.apply_name}}
          <span v-if="emscaapportionh.org_name">|</span> {{emscaapportionh.org_name}}</p>
        <i>{{emscaapportionh.form_template_name}} {{emscaapportionh.apportion_code}}</i>
      </div>
      <div class="top-currency" v-if="typeof(emscaapportionh.approve_amount)==='number'">
        <p>
          <span>￥</span>{{ emscaapportionh.approve_amount.toFixed(2) }}</p>
        <section>{{ emscaapportionh.currency_name === '人民币' ? ' | RMB' : '' }}</section>
      </div>
      <p class="reason">{{ emscaapportionh.sensitive_info }}</p>
    </div>
    <div>
      <div class='border-bottom margin-top no-top'>
        <div class="type">经办人</div>
        <div class='detailed'>{{emscaapportionh.apply_name}}</div>
      </div>
      <div class='border-bottom margin-top no-top'>
        <div class="type">部门 </div>
        <div class='detailed'>{{emscaapportionh.company_name}}</div>
      </div>
      <div class='border-bottom margin-top no-top'>
        <div class="type">类型</div>
        <div class='detailed'>
          {{emscaapportionh.order_template_name}}
        </div>
      </div>
      <div class='border-bottom margin-top no-top'>
        <div class="type">申请日期</div>
        <div class='detailed' v-if="emscaapportionh.creation_date">
          {{emscaapportionh.creation_date.substring(0,10)}}
        </div>
      </div>
      <div class='border-bottom margin-top no-top'>
        <div class="type">来源系统</div>
        <div class='detailed'>
          <img :src='top.arrow' class='img'>
        </div>
      </div>
      <div class='border-bottom margin-top no-top'>
        <div class="type">来源单据</div>
        <div class='detailed'>
          <img :src='top.arrow' class='img'>
        </div>
      </div>
      <div class='border-bottom margin-top' @click="showTrip= !showTrip">
        <div class="type data-type">调账明细</div>
        <div class='detailed'>
          <div class='detailed'><img :src='top.arrow' :class="['img', {'arrow_top': showTrip}]"></div>
        </div>
      </div>
      <div v-if="showTrip" :class="{'m-t10': data.debit_credit_type !== 'CR'}" :key="index" v-for="(data, index) in emscaapportionh.emscaapportionls">
        <div class='border-bottom margin-top no-top'>
          <div class="type">预算来源</div>
          <div class='detailed'>
            {{data.budget_node_desc}}
          </div>
        </div>
        <div class='border-bottom margin-top no-top'>
          <div class="type">预算部门</div>
          <div class='detailed'>
            {{data.busi_org_name}}
          </div>
        </div>
        <div class='border-bottom margin-top no-top'>
          <div class="type">费用类别</div>
          <div class='detailed'>
            {{data.budget_name}}
          </div>
        </div>
        <div class='border-bottom margin-top no-top'>
          <div class="type">调账金额</div>
          <div class='detailed'>
            {{data.approve_amount}}
          </div>
        </div>
      </div>
    </div>
    <attachment :formInstanceId="emscaapportionh.formInstanceId"></attachment>
    <div class='border-bottom margin-top'>
      <div class="type">审批记录</div>
      <div class='detailed'></div>
    </div>
    <my-progress :title='list' :list="listNew" :current="current"></my-progress>
    <div class="footerBtn" v-if="fdStatus">
      <div class="item scanInput" @click="operation">编辑</div>
      <div class="item manualInput" @click="operation">删除</div>
    </div>
    <div class="bottom-list" v-if="showBottomList">
      <div class="flet">
        <div class="more" @click="more(oplist[2])" v-if="oplist.length > 2 && showoplist.indexOf(oplist[2].operationType) !== -1">{{Object.keys(menus).length > 1 ? "更多": oplist[2].operationName}}</div>
        <div class="reject" @click="change(oplist[1])" v-if="oplist.length > 1 && showoplist.indexOf(oplist[1].operationType) !== -1">{{this.oplist[1].operationName}}</div>
      </div>
      <div class="pass" @click="change(oplist[0])" v-if="this.oplist.length && showoplist.indexOf(oplist[0].operationType) !== -1">{{this.oplist[0].operationName}}</div>
    </div>
    <actionsheet v-model="showAction" :menus="menus" :show-cancel="showCancel" @on-click-menu="jump"></actionsheet>
    <reject :rejectInfo="operateDeta" v-if="showReject" @hide="showReject=false" @successs="state"></reject>
    <pass :rejectInfo="operateDeta" v-if="showPass" @hide="showPass=false" @successs="state"></pass>
    <communication :infor="operateDeta" v-if="operateDeta.show" @hide="operateDeta.show=false" @successs="state"></communication>
    <turn-to :infor="inforTurn" v-if="inforTurn.show" @hide="inforTurn.show=false" @successs="state"></turn-to>
    <approve-relatedapply :list="emscaapportionh.emsecfeebudgets" :show.sync="showRelated" @on-hide="hideRelate" />
  </div>
</template>

<script type="text/ecmascript-6">
import { Actionsheet } from 'vux';
import { platform } from '@/platform';
import myHeader from '../../common/header';
import rtarrow from '../../../assets/rt-arrow.png';
//  审批进度
import myProgress from '../../common/proGress';
import hideTravel from '../../../assets/images/fee/approve/hideTravel.png';
import showTravel from '../../../assets/images/fee/approve/showTravel.png';
import reject from './approveReject.vue';
import pass from './approvePass.vue';
import communication from './communication.vue';
import approveRelatedapply from './approveRelatedapply.vue';
import turnTo from './turnTo.vue';
//  预算明细
import myBudgetsee from '../../common/budGetsee';
import attachment from '../../common/attachment';

export default {
  components: {
    myHeader,
    Actionsheet,
    myProgress,
    reject,
    pass,
    communication,
    turnTo,
    myBudgetsee,
    approveRelatedapply,
    attachment,
  },
  data() {
    return {
      messagesApply: '',
      showRelated: false,
      showAction: false, // 是否显示更多组件
      showCancel: true,  // 是否显示取消按钮
      top: {
        type: '调账申请',
        arrow: rtarrow,
        hidetop: hideTravel,
        showbottom: showTravel,
      },
      menus: {},
      applyaList: [],
      list: [],
      listNew: [],
      current: '',
      oplist: [],
      showoplist: ['handler_communicate', 'handler_returnCommunicate', 'handler_refuse', 'handler_cancelCommunicate', 'handler_commission', 'handler_pass'],
      emscaapportionh: {},
      showReject: false,
      showPass: false,
      showTrip: true,
      operateDeta: {
        jumpToNodeId: '',
        formInstanceId: '',
        model_id: '001',
        template_form_id: '',
        show: false,
        status: '',  // 状态：check/reply
        linkContant: [], // 流程节点的process-log[]  借款
      },
      inforTurn: {
        show: false,
        formInstanceId: '',  // 表单实例id
        form_template_id: '',  // 表单模板id2222222
      },
      type: 'ty-bx',
      applyBack: false,  // 报销审批预算来源显示隐藏
      travelShow: false,  // 报销审批费用预估显示隐藏
      showBottomList: true, // 是否显示底部操作项
    };
  },
  mounted() {
    if (this.$route.query.isApproved) {
      this.showBottomList = false;
    }
    this.adjustAccount();
  },
  computed: {
    fdStatus() {
      return this.$store.state.approve.fdStatus;
    },
  },
  methods: {
    state() {
      setTimeout(() => {
        if (this.$store.state.extCall) {
          platform.exit();
        } else {
          this.$router.push({
            path: '/fee/approve/',
          });
        }
      }, 500);
    },
    goBack() {
      this.$store.commit('REC_FDSTATUS');
      if (this.$store.state.extCall) {
        platform.exit();
      } else {
        this.$router.go(-1);
      }
    },
    //     或者展示信息的接口
    adjustAccount() {
      this.showLoading();
      this.$store.dispatch('adjustAccount', this.$route.query.id).then((res) => {
        this.hideLoading();
        if (res.code === '0000') {
          console.log(res);
          this.emscaapportionh = res.data.emscaapportionh;
          this.operateDeta.formInstanceId = this.emscaapportionh.formInstanceId;
          this.operateDeta.template_form_id = this.emscaapportionh.form_template_id;
          const star = this.emscaapportionh.form_template_name.indexOf('_');
          const last = this.emscaapportionh.form_template_name.lastIndexOf('_');
          this.emscaapportionh.form_template_name = this.emscaapportionh.form_template_name.substring(star + 1, last);
          this.grtFlowt();
          this.getLog();
          this.getOplist();
        } else {
          this.showToast({ msg: '找不到申请单' });
          //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    //      审批节点未审批
    grtFlowt() {
      this.$store.dispatch('grtFlowt', {
        formInstanceId: this.emscaapportionh.formInstanceId, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.emscaapportionh.form_template_id,
      }).then((res) => {
        if (res.code === '0000') {
          this.listNew = res.data;
          this.listNew.forEach((item) => {
            if (item.current) {
              this.current = item.fdNodeHandlerNames;
            }
          });
        }
      });
    },
    //      获取已经审批过得节点信息
    getLog() {
      this.$store.dispatch('getLog', {
        formInstanceId: this.emscaapportionh.formInstanceId, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.emscaapportionh.form_template_id,
      }).then((res) => {
        if (res.code === '0000') {
          this.list = res.data;
        } else {
          this.showToast({ msg: '找不到待审批节点信息' });
          //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    //      获取操作按钮节点
    getOplist() {
      this.$store.dispatch('getOplist', {
        formInstanceId: this.emscaapportionh.formInstanceId, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.emscaapportionh.form_template_id,
      })
        .then((res) => {
          if (res.code === '0000') {
            let list = [];
            if (res.data.length) {
              res.data.forEach((item) => {
                list = list.concat(item.operations);
              });
              const newList = [];
              list.forEach((item, index) => {
                if (item.operationType === 'handler_refuse') {
                  list.splice(index, 1);
                  list.splice(1, 0, item);
                }
                if (newList.indexOf(item.operationType) === -1) {
                  newList.push(item.operationType);
                } else {
                  list.splice(index, 1);
                }
              });
              this.oplist = list;
              this.oplist.forEach((item, index) => {
                if (index > 1 && this.showoplist.indexOf(item.operationType) !== -1) {
                  const obj = {
                    [item.operationType]: `<span style="color: #666666;">${item.operationName}</span>`,
                  };
                  this.menus = Object.assign({}, this.menus, obj);
                }
              });
            } else {
              list = [];
            }
          } else {
            this.showToast({ msg: res.msg });
          }
        }, () => {
          this.showToast({ msg: '页面开小差，请稍候重试' });
        });
    },
    // 点击更多的时候的沟通/转办
    jump(ket) {
      switch (ket) {
        case 'handler_communicate':
          this.operateDeta.status = '';
          this.operateDeta.linkContant = this.list;
          this.operateDeta.show = true;
          break;
        case 'handler_commission':
          this.inforTurn.show = true;
          this.inforTurn.formInstanceId = this.emscaapportionh.formInstanceId;
          this.inforTurn.form_template_id = this.emscaapportionh.form_template_id;
          break;
        default:
      }
    },
    //      获取取消沟通节点
    cancelOpparam() {
      this.$store.dispatch('cancelOpparam', {
        approveType: 'handler_cancelCommunicate',
        formInstanceId: this.emscaapportionh.formInstanceId, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.emscaapportionh.form_template_id,
      }).then((res) => {
        if (res.code === '0000') {
          const communicateWorkitemList = res.data.handler_cancelCommunicate.communicateWorkitemList;
          let communicateArr = '';
          communicateWorkitemList.forEach((item) => {
            communicateArr += `${item.id};`;
          });
          this.celcommunicate(communicateArr);
        } else {
          this.showToast({ msg: '找不到待审批节点信息' });
          //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    //      取消沟通
    celcommunicate(value) {
      this.showLoading();
      this.$store.dispatch('celcommunicate', {
        cancelHandlerIds: value,
        formInstanceId: this.emscaapportionh.formInstanceId, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.emscaapportionh.form_template_id,
      }).then((res) => {
        if (res.code === '0000') {
          this.hideLoading();
          this.showToast({ msg: '成功取消沟通' });
          setTimeout(() => {
            if (this.$store.state.extCall) {
              platform.exit();
            } else {
              this.$router.push({
                path: '/fee/approve/',
              });
            }
          }, 500);
        } else {
          this.hideLoading();
          this.showToast({ msg: '找不到待审批节点信息' });
          //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    //     关闭关联申请单
    hideRelate() {
      this.showRelated = false;
    },
    // 更多
    more(obj) {
      if (Object.keys(this.menus).length > 1) {
        this.showAction = !this.showAction;
      } else {
        const mewThis = this;
        switch (obj.operationType) {
          case 'handler_communicate':
            this.operateDeta.show = true;
            this.operateDeta.status = '';
            this.operateDeta.linkContant = this.list;
            break;
          case 'handler_cancelCommunicate':
            mewThis.cancelOpparam();
            break;
          case 'handler_commission':
            this.inforTurn.show = true;
            this.inforTurn.formInstanceId = this.emscaapportionh.formInstanceId;
            this.inforTurn.form_template_id = this.emscaapportionh.form_template_id;
            break;
          case 'handler_returnCommunicate':
            this.operateDeta.show = true;
            this.operateDeta.status = 'reply';
            this.operateDeta.linkContant = this.list;
            break;
          case 'handler_pass':
            this.showPass = true;
            break;
          default:
        }
      }
    },
    change(obj) {
      const newthis = this;
      switch (obj.operationType) {
        case 'handler_communicate':
          this.operateDeta.show = true;
          this.operateDeta.status = '';
          this.operateDeta.linkContant = this.list;
          break;
        case 'handler_cancelCommunicate':
          newthis.cancelOpparam();
          break;
        case 'handler_refuse':
          this.operateDeta.jumpToNodeId = this.listNew[0].fdNodeId;
          this.showReject = true;
          break;
        case 'handler_commission':
          this.inforTurn.show = true;
          this.inforTurn.formInstanceId = this.emscaapportionh.formInstanceId;
          this.inforTurn.form_template_id = this.emscaapportionh.form_template_id;
          break;
        case 'handler_returnCommunicate':
          this.operateDeta.show = true;
          this.operateDeta.status = 'reply';
          this.operateDeta.linkContant = this.list;
          break;
        case 'handler_pass':
          this.showPass = true;
          break;
        case 'drafter_press':
          this.showPass = true;
          break;
        default:
      }
    },
    //      来源
    selectArea() {
      console.log(99999999);
    },
    //      关闭预算来源
    hideArea() {
      this.applyBack = false;
    },
    //      费用明细返回；
    hideBudgetsee() {
      this.travelShow = false;
    },
    operation() {
      this.showToast({ msg: '移动端暂不支持该类型操作，请移步PC端' });
    },
  },
};
</script>

<style lang='less' scoped>
.approval {
  font-size: 16px;
  color: #000000;
  line-height: 16px;
  .top {
    background: #484759;
    width: 92%;
    padding: 0 4%;
    position: relative;
    color: #ffffff;
    .top-list {
      display: flex;
      padding: 11px 0 15px 0;
      justify-content: space-between;
      align-items: center;
      .applyer {
        width: 50%;
      }
      i {
        position: absolute;
        right: 0;
        display: inline-block;
        font-style: normal;
        font-size: 12px;
        padding: 0 6px 0 8px;
        height: 20px;
        background: #6F6E82;
        border-radius: 10px 0 0 10px;
        text-align: center;
        line-height: 18px;
      }
    }
    .top-currency {
      display: flex;
      align-items: center;
      padding-bottom: 15px;
      p {
        margin-right: 5px;
        color: #3DA5FE;
      }
    }
    .reason {
      padding-bottom: 19px;
      opacity: 0.6;
    }
  }
  .margin-top {
    display: flex;
    justify-content: space-between;
    background: #ffffff;
    padding: 13px;
    margin-top: 10px;
    line-height: 24px;
    &.no-top {
      margin-top: 0px;
    }

    .type {
      width: 105px;
      color: #858585;
      &.data-type {
        color: #000000;
      }
    }
    .detailed {
      width: 100%;
      text-align: end;
      &.blue {
        color: #3DA5FE;
      }
      .img {
        width: 9.5px;
        &.arrow_top {
          transform: rotate(-90deg);
        }
      }
    }
  }
  .bottom-list {
    width: 100%;
    text-align: center;
    line-height: 50px;
    margin-bottom: 0;
    background: #ffffff;
    box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
    position: fixed;
    bottom: 0;
    display: flex;
    justify-content: space-between;
    color: #666666;
    font-size: 18px;
    .flet {
      flex: 1;
      display: flex;
      .more {
        flex: 1;
      }
      .reject {
        flex: 1;
      }
    }
    .pass {
      flex: 1;
      background: #3DA5FE;
      color: #ffffff;
    }
  }
  .m-t10 {
    margin-top: 10px;
  }
  .footerBtn{
    line-height: 1.6;
    width: 100%;
    position: fixed;
    bottom: 0;
    display: flex;
    justify-content: space-between;
    border-top: #DEDFE0 1px solid;
    .item{
      width: 50%;
      text-align: center;
      padding:11px 0;
      font-size: 18px;
    }
    .manualInput{
      color: #666666;
      background-color: #ffffff;
    }
    .scanInput{
      background-color: #3DA5FE;
      color:#ffffff !important;
    }
  }
}
</style>
