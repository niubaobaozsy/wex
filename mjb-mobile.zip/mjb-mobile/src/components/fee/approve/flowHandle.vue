<!--
  describe: flow handle button
  created by: zhuangyh
  date: 2018-01-05
-->

<template>
  <div class="flow-handle-btn">
    <div class="btn-wrap" v-if="moreBtn.operationType||secondaryBtn.operationType">
      <div v-if="moreBtn.operationType" class="more" @click="flowHdl(moreBtn.operationType)">{{moreBtn.operationName}}</div>
      <div class="split-line">|</div>
      <div v-if="secondaryBtn.operationType" class="secondary" @click="flowHdl(secondaryBtn.operationType)">{{secondaryBtn.operationName}}</div>
    </div>
    <div v-if="mainBtn.operationType" class="main" @click="flowHdl(mainBtn.operationType)">{{mainBtn.operationName}}</div>
    <actionsheet class="show-more" v-model="showMore" :menus="menus" :show-cancel="true" @on-click-menu="menuHdl"></actionsheet>
  </div>
</template>
<script>
import { Actionsheet } from 'vux';

export default {
  components: {
    Actionsheet,
  },
  props: {
    formInstanceId: {
      type: String,
      required: true,
      default: '',
    },
    formTemplateId: {
      type: String,
      required: true,
      default: '',
    },
  },
  data() {
    return {
      positiveHdl: ['handler_communicate', 'handler_returnCommunicate', 'handler_commission', 'handler_pass'],
      negativeHdl: ['handler_refuse', 'handler_cancelCommunicate'],
      mainBtn: {
        operationType: '',
        operationName: '',
      },
      secondaryBtn: {
        operationType: '',
        operationName: '',
      },
      moreBtn: {
        operationType: '',
        operationName: '',
      },
      showMore: false,
      menus: [],
    };
  },
  methods: {
    getOplist() {
      this.$store.dispatch('getOplist', {
        formInstanceId: this.formInstanceId,
        model_id: '001',
        template_form_id: this.formTemplateId,
      }).then((res) => {
        if (res.code === '0000') {
          let list = [];
          if (res.data.length) {
            res.data.forEach((item) => {
              list = list.concat(item.operations);
            });
            const allHdl = this.positiveHdl.concat(this.negativeHdl);
            list = list.filter(item => allHdl.indexOf(item.operationType) >= 0);
            list.forEach((item) => {
              if (item.operationType === 'handler_pass') {
                this.mainBtn = item;
              } else if (item.operationType === 'handler_refuse') {
                this.secondaryBtn = item;
              } else if (this.positiveHdl.indexOf(item.operationType) >= 0) {
                this.mainBtn = item;
              } else if (this.negativeHdl.indexOf(item.operationType) >= 0) {
                this.secondaryBtn = item;
              }
            });
            list = list.filter(item => (item.operationType !== this.mainBtn.operationType) && (item.operationType !== this.secondaryBtn.operationType));
            if (list.length > 1) {
              this.moreBtn = {
                operationType: 'showMore',
                operationName: '更多',
              };
              this.menus = list.map((item) => {
                const menu = {
                  label: item.operationName,
                  type: 'primary',
                  value: item.operationType,
                };
                return menu;
              });
            } else if (list.length === 1) {
              this.moreBtn = list[0];
            }
          }
        } else if (res && res.msg) {
          this.showToast({ msg: res.msg });
        }
      });
    },
    flowHdl(hdlType) {
      switch (hdlType) {
        case 'handler_pass':
          break;
        case 'handler_communicate':
          break;
        case 'handler_returnCommunicate':
          break;
        case 'handler_commission':
          break;
        case 'handler_refuse':
          break;
        case 'handler_cancelCommunicate':
          break;
        case 'showMore':
          this.showMore = true;
          break;
        default:
      }
    },
    menuHdl(key, item) {
      console.log(key, item);
    },
  },
  computed: {
    flowForm() {
      return `${this.formInstanceId}/${this.formTemplateId}`;
    },
  },
  watch: {
    flowForm() {
      if (this.formInstanceId && this.formTemplateId) {
        this.getOplist();
      }
    },
  },
};
</script>
<style lang="less" scoped>
.flow-handle-btn {
  display: flex;
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  font-size: 18px;
  line-height: 50px;
  text-align: center;
  box-shadow: 0 0 5px #DEDFE0;
  .btn-wrap {
    width: 50%;
    flex-grow: 1;
    display: flex;
    color: #666666;
    background-color: #fff;
    .more {
      flex-grow: 1;
    }
    .split-line {
      color: #CBCFD6;
      font-weight: 100;
    }
    .secondary {
      flex-grow: 1;
    }
  }
  .main {
    width: 50%;
    flex-grow: 1;
    color: #fff;
    background-color: #3DA5FE;
  }
  .show-more {
    line-height: 30px;
  }
}
</style>
