<!--
  describe：借款申请审批
  created by：黄喆
  date：2017-11-27
-->
<template>
  <div class="approval has-footer">
    <my-header :title='top.type' @previous="goBack"></my-header>
    <div class="top">
      <div class="top-list">
        <p class="applyer">{{emslmloan.apply_name}}
          <span v-if="emslmloan.org_name">|</span> {{emslmloan.org_name}}</p>
        <i> {{order_type_name}} {{emslmloan.loan_info_code}}</i>
      </div>
      <div class="top-currency" v-if="typeof(emslmloan.approve_amount)==='number'">
        <p>
          <span>￥</span>{{ (emslmloan.approve_amount * 1).toFixed(2) }}</p>
        <section>| {{ emslmloan.currency_code }}</section>
      </div>
      <p class="reason">{{ emslmloan.sensitive_info }}</p>
    </div>
    <div class='has-bottom'>
      <div class='router border-bottom'>
        <div class="type">单据类型</div>
        <div class='detailed'>{{emslmloan.order_template_name}}</div>
      </div>
      <div class='router border-bottom'>
        <div class="type">开支主体</div>
        <div class='detailed'>{{emslmloan.company_name}}</div>
      </div>
      <div class='router border-bottom'>
        <div class="type">收款方</div>
        <div class='detailed'>{{emslmloan.receiver}}/{{emslmloan.bank_name}}/{{emslmloan.bank_account}}</div>
      </div>
    </div>
    <attachment :formInstanceId="emslmloan.formInstanceId"></attachment>
    <div class='border-bottom margin-top'>
      <div class="type">审批记录</div>
      <div class='detailed'></div>
    </div>
    <my-progress :title='list' :list="listNew" :current="current"></my-progress>
    <div class="footerBtn" v-if="fdStatus">
      <div class="item scanInput" @click="operation">编辑</div>
      <div class="item manualInput" @click="operation">删除</div>
    </div>
    <div class="bottom-list" v-if="showBottomList">
      <div class="flet">
        <div class="more" @click="more(oplist[2])" v-if="oplist.length > 2 && showoplist.indexOf(oplist[2].operationType) !== -1">{{Object.keys(menus).length > 1 ? "更多": oplist[2].operationName}}</div>
        <div class="reject" @click="change(oplist[1])" v-if="oplist.length > 1 && showoplist.indexOf(oplist[1].operationType) !== -1">{{this.oplist[1].operationName}}</div>
      </div>
      <div class="pass" @click="change(oplist[0])" v-if="this.oplist.length && showoplist.indexOf(oplist[0].operationType) !== -1">{{this.oplist[0].operationName}}</div>
    </div>
    <actionsheet v-model="showAction" :menus="menus" :show-cancel="showCancel" @on-click-menu="jump"></actionsheet>
    <reject :rejectInfo="operateDeta" v-if="showReject" @hide="showReject=false" @successs="state"></reject>
    <pass :rejectInfo="operateDeta" v-if="showPass" @hide="showPass=false" @successs="state"></pass>
    <communication :infor="operateDeta" v-if="operateDeta.show" @hide="operateDeta.show=false" @successs="state"></communication>
    <turn-to :infor="inforTurn" v-if="inforTurn.show" @hide="inforTurn.show=false" @successs="state"></turn-to>
  </div>
</template>

<script type="text/ecmascript-6">
import { Actionsheet } from 'vux';
import { platform } from '@/platform';
import myHeader from '../../common/header';
import rtarrow from '../../../assets/rt-arrow.png';
import myProgress from '../../common/proGress';
import reject from './approveReject.vue';
import pass from './approvePass.vue';
import communication from './communication.vue';
import turnTo from './turnTo.vue';
import attachment from '../../common/attachment';

export default {
  components: {
    myHeader,
    Actionsheet,
    myProgress,
    reject,
    pass,
    communication,
    turnTo,
    attachment,
  },
  data() {
    return {
      showAction: false, // 是否显示更多组件
      showCancel: true,  // 是否显示取消按钮
      top: {
        type: '借款申请单审批',
        arrow: rtarrow,
      },
      menus: {},
      list: [],
      listNew: [],
      current:'',
      showoplist: ['handler_communicate', 'handler_returnCommunicate', 'handler_refuse', 'handler_cancelCommunicate', 'handler_commission', 'handler_pass'],
      oplist: [],
      emslmloan: {},
      showReject: false,
      showPass: false,
      operateDeta: {
        jumpToNodeId: '',
        formInstanceId: '',
        model_id: '001',
        template_form_id: '',
        show: false,
        status: '',  // 状态：check/reply
        linkContant: [], // 流程节点的process-log[]  借款
      },
      inforTurn: {
        show: false,
        formInstanceId: '',  // 表单实例id
        form_template_id: '',  // 表单模板id
      },
      order_type_name: '',
      showBottomList: true, // 是否显示底部操作项
    };
  },
  created() {
    this.getLoan();
  },
  methods: {
    state() {
      setTimeout(() => {
        if (this.$store.state.extCall) {
          platform.exit();
        } else {
          this.$router.push({
            path: '/fee/approve/',
          });
        }
      }, 500);
    },
    goBack() {
      this.$store.commit('REC_FDSTATUS')
      if (this.$store.state.extCall) {
        platform.exit();
      } else {
        this.$router.go(-1);
      }
    },
    // 借款单审批展示信息
    getLoan() {
      const params = {
        loan_info_id: this.$route.query.id,
      };
      this.showLoading();
      this.$store.dispatch('getLoan', params)
        .then((res) => {
          if (res.code === '0000') {
            this.hideLoading();
            this.emslmloan = res.data.emslmloan;
            this.operateDeta.formInstanceId = `${this.$route.query.id}_LM`;
            this.operateDeta.template_form_id = this.emslmloan.form_template_id;
            const star = this.emslmloan.org_name.indexOf('_');
            this.emslmloan.org_name = this.emslmloan.org_name.substring(star + 1, star + 5);
            this.order_type_name = this.emslmloan.order_template_name.substring(star + 4);
            if (this.emslmloan.have_process === 'Y' && this.emslmloan.order_status !== 'DISABLED') {
              this.getLog().then(() => {
                this.grtFlowt();
              });
              this.getOplist();
            }

          } else {
            this.hideLoading();
            this.showToast({ msg: res.msg });
          }
        });
    },
    //      已经通过了的节点
    getLog() {
      return new Promise((resolve) => {
        const params = {
          formInstanceId: `${this.$route.query.id}_LM`,
          model_id: '001',
          template_form_id: this.emslmloan.form_template_id,
        };
        this.$store.dispatch('getLog', params)
          .then((res) => {
            if (res && res.code === '0000') {
              this.list = res.data.filter(log => log.fdActionKey.indexOf('走分支') === -1);
              resolve(res.data);
            } else if (res) {
              this.showToast({ msg: res.msg });
            }
          });
      });
    },
    grtFlowt() {
      return new Promise((resolve) => {
        const params = {
          formInstanceId: `${this.$route.query.id}_LM`,
          model_id: '001',
          template_form_id: this.emslmloan.form_template_id,
        };
        this.$store.dispatch('grtFlowt', params)
          .then((res) => {
            if (res && res.code === '0000') {
              let curIndex = 0;
              res.data.forEach((flowt, index) => {
                if (flowt.current) {
                  curIndex = index;
                }
              });
              this.refuseJumpToNodeId = res.data[0].fdNodeId;
              this.listNew = res.data.slice(curIndex);
              this.listNew.forEach(item =>{
              if(item.current){
                this.current = item.fdNodeHandlerNames;
              }
            })
              resolve(res.data);
            } else {
              this.showToast({ msg: `请求异常[${res.code}]: ${res.msg}` });
            }
          });
      });
    },
    getOplist() {
      const params = {
        formInstanceId: `${this.$route.query.id}_LM`,
        model_id: '001',
        template_form_id: this.emslmloan.form_template_id,
      };
      this.$store.dispatch('getOplist', params)
        .then((res) => {
          if (res.code === '0000') {
            console.log(res.data);
            let list = [];
            if (res.data.length) {
              res.data.forEach((item) => {
                list = list.concat(item.operations);
              });
              const newList = [];
              list.forEach((item, index) => {
                if (item.operationType === 'handler_refuse') {
                  list.splice(index, 1);
                  list.splice(1, 0, item);
                }
                if (newList.indexOf(item.operationType) === -1) {
                  newList.push(item.operationType);
                } else {
                  list.splice(index, 1);
                }
              });
              this.oplist = list;
              this.oplist.forEach((item, index) => {
                if (index > 1 && this.showoplist.indexOf(item.operationType) !== -1) {
                  const obj = {
                    [item.operationType]: `<span style="color: #666666;">${item.operationName}</span>`,
                  };
                  this.menus = Object.assign({}, this.menus, obj);
                }
              });
            } else {
              list = [];
            }
          } else {
            this.showToast({ msg: res.msg });
          }
        });
    },
    // 沟通/转办
    //      获取取消沟通节点
    cancelOpparam() {
      this.$store.dispatch('cancelOpparam', {
        approveType: 'handler_cancelCommunicate',
        formInstanceId: `${this.$route.query.id}_LM`, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.emslmloan.form_template_id,
      }).then((res) => {
        console.log(res);
        if (res.code === '0000') {
          console.log(res.data.handler_cancelCommunicate.communicateWorkitemList, 99887766);
          const communicateWorkitemList = res.data.handler_cancelCommunicate.communicateWorkitemList;
          let communicateArr = '';
          communicateWorkitemList.forEach((item) => {
            communicateArr += `${item.id};`;
          });
          this.celcommunicate(communicateArr);
          console.log(communicateArr, 123456789123);
        } else {
          this.showToast({ msg: '找不到待审批节点信息' });
          //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    //      取消沟通
    celcommunicate(value) {
      this.showLoading();
      this.$store.dispatch('celcommunicate', {
        cancelHandlerIds: value,
        formInstanceId: `${this.$route.query.id}_LM`, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.emslmloan.form_template_id,
      }).then((res) => {
        console.log(res);
        if (res.code === '0000') {
          this.hideLoading();
          this.showToast({ msg: '成功取消沟通' });
          setTimeout(() => {
            if (this.$store.state.extCall) {
              platform.exit();
            } else {
              this.$router.push({
                path: '/fee/approve/',
              });
            }
          }, 500);
        } else {
          this.hideLoading();
          this.showToast({ msg: res.msg });
        }
      });
    },
    jump(ket) {
      console.log(ket);
      switch (ket) {
        case 'handler_communicate':
          console.log('沟通');
          this.operateDeta.status = '';
          this.operateDeta.linkContant = this.list;
          this.operateDeta.show = true;
          console.log(ket);
          break;
        case 'handler_commission':
          console.log('转办');
          this.inforTurn.show = true;
          this.inforTurn.formInstanceId = `${this.$route.query.id}_LM`;
          this.inforTurn.form_template_id = this.emslmloan.form_template_id;
          break;
        default:
      }
    },
    // 撤回沟通
    withdraw() {
      console.log('撤回沟通');
    },
    // 更多位置按钮
    more(obj) {
      console.log(obj);
      if (Object.keys(this.menus).length > 1) {
        this.showAction = !this.showAction;
      } else {
        switch (obj.operationType) {
          case 'handler_communicate':
            this.operateDeta.show = true;
            this.operateDeta.status = '';
            this.operateDeta.linkContant = this.list;
            break;
          case 'handler_cancelCommunicate':
            console.log('取消沟通');
            this.cancelOpparam();
            break;
          case 'handler_commission':
            console.log('转办');
            this.inforTurn.show = true;
            this.inforTurn.formInstanceId = `${this.$route.query.id}_LM`;
            this.inforTurn.form_template_id = this.emslmloan.form_template_id;
            break;
          case 'handler_returnCommunicate':
            console.log('回复');
            this.operateDeta.show = true;
            this.operateDeta.status = 'reply';
            this.operateDeta.linkContant = this.list;
            break;
          case 'handler_pass':
            this.showPass = true;
            break;
          default:
        }
      }
    },
    // 驳回,通过或者固定显示在右边按钮
    change(obj) {
      console.log(obj.operationType);
      switch (obj.operationType) {
        case 'handler_communicate':
          console.log('沟通');
          this.operateDeta.show = true;
          this.operateDeta.status = '';
          this.operateDeta.linkContant = this.list;
          break;
        case 'handler_cancelCommunicate':
          console.log('取消沟通');
          this.cancelOpparam();
          break;
        case 'handler_refuse':
          this.operateDeta.jumpToNodeId = this.refuseJumpToNodeId;
          this.showReject = true;
          console.log('驳回');
          break;
        case 'handler_commission':
          console.log('转办');
          this.inforTurn.show = true;
          this.inforTurn.formInstanceId = `${this.$route.query.id}_LM`;
          this.inforTurn.form_template_id = this.emslmloan.form_template_id;
          break;
        case 'handler_returnCommunicate':
          console.log('回复');
          this.operateDeta.show = true;
          this.operateDeta.status = 'reply';
          this.operateDeta.linkContant = this.list;
          break;
        case 'handler_pass':
          this.showPass = true;
          break;
        case 'drafter_press':
          this.showPass = true;
          console.log('通过');
          break;
        default:
      }
    },
    operation(){
      this.showToast({ msg: '移动端暂不支持该类型操作，请移步PC端' });
    }
  },
  computed:{
    fdStatus(){
      return this.$store.state.approve.fdStatus
    }
  },
  mounted() {
    if (this.$route.query.isApproved) {
      this.showBottomList = false;
    }
  },
};
</script>

<style lang="less" rel="stylesheet/less" scoped>
.approval {
  font-size: 16px;
  color: #000000;
  line-height: 16px;
  .top {
    background: #484759;
    padding: 0 15px;
    position: relative;
    color: #ffffff;
    margin-top: 45px;
    .top-list {
      display: flex;
      padding: 11px 0 15px 0;
      justify-content: space-between;
      align-items: center;
      .applyer {
        width: 50%;
      }
      i {
        position: absolute;
        right: 0;
        display: inline-block;
        font-style: normal;
        font-size: 12px;
        padding: 0 6px 0 8px;
        height: 20px;
        background: #6F6E82;
        border-radius: 10px 0 0 10px;
        text-align: center;
        line-height: 18px;
      }
    }
    .top-currency {
      display: flex;
      align-items: center;
      padding-bottom: 15px;
      p {
        margin-right: 5px;
        color: #3DA5FE;
      }
    }
    .reason {
      padding-bottom: 19px;
      opacity: 0.6;
    }
  }
  .margin-top {
    display: flex;
    justify-content: space-between;
    background: #ffffff;
    color: #858585;
    padding: 13px;
    margin-top: 10px;
    line-height: 24px;
    .type {
      width: 105px;
      &.data-type {
        color: #000000;
      }
    }
    .detailed {
      width: 100%;
      text-align: end;
    }
  }
  .has-bottom {
    margin-top: 10px;
    background: #ffffff;
    box-shadow: 0 0 0 0 #DEDFE0, 0 0 0 0 #DEDFE0;
    .router {
      padding: 13px 13px 13px 0;
      margin-left: 13px;
      display: flex;
      justify-content: space-between;
      line-height: 24px;
      .type {
        width: 105px;
        color: #858585;
        &.data-type {
          color: #000000;
        }
      }
      .detailed {
        width: 100%;
        text-align: end;
        word-break: break-all;
      }
    }
  }
  .bottom-list {
    width: 100%;
    text-align: center;
    line-height: 50px;
    margin-bottom: 0;
    background: #ffffff;
    box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
    position: fixed;
    bottom: 0;
    display: flex;
    justify-content: space-between;
    color: #666666;
    font-size: 18px;
    .flet {
      flex: 1;
      display: flex;
      .more {
        flex: 1;
      }
      .reject {
        flex: 1;
      }
    }
    .pass {
      flex: 1;
      background: #3DA5FE;
      color: #ffffff;
    }
  }

  .footerBtn{
    line-height: 1.6;
    width: 100%;
    position: fixed;
    bottom: 0;
    display: flex;
    justify-content: space-between;
    border-top: #DEDFE0 1px solid;
    .item{
      width: 50%;
      text-align: center;
      padding:11px 0;
      font-size: 18px;
    }
    .manualInput{
      color: #666666;
      background-color: #ffffff;
    }
    .scanInput{
      background-color: #3DA5FE;
      color:#ffffff !important;
    }
  }
}
</style>
