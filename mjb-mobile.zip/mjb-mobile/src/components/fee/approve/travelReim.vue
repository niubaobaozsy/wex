<!--
  describe：差旅申请单审批/通用费用申请审批
  created by：张绍武
  date：2017-11-27
-->
<template>
  <div class="approval has-footer">
    <my-header :title='top.type' @previous="goBack"></my-header>
    <div class="top">
      <div class="top-list">
        <p class="applyer">{{order.apply_name}}
          <span v-if="order.org_name">|</span> {{order.org_name}}</p>
        <i v-if="order.fee_apply_code || order.fee_reim_code">{{top.type}} {{order.fee_apply_code || order.fee_reim_code}}</i>
      </div>
      <div v-if="order.apply_amount !== undefined || order.apply_reim_amount !== undefined">
        <p>￥{{ (order.apply_amount * 1).toFixed(2) || (order.apply_reim_amount * 1).toFixed(2) }}</p>
        <section>| {{ order.currency_code }}</section>
        <p v-if="order.order_type === 'CL'&& myApplyMenuCfg[order.order_type].hasTravelType" class="travel-type">
          {{order.attribute15_name}}
        </p>
      </div>
      <div>
        <section>{{ order.reason_desc }}</section>
        <p v-if="isUrgentCfg" class="travel-type">
          {{order.is_urgent === 'Y' ? '加急：是' : '加急：否' }}
        </p>
      </div>
      <!-- <section>{{ order.reason_desc }}</section> -->

    </div>
    <div class="main-top" v-if="this.order.order_type === 'CL'">
      <ul>
        <li v-if="order.is_over_standard !== 'N'">
          <p>超标原因</p>
          <div>{{order.over_standard_reason}}</div>
        </li>
      </ul>
    </div>
    <div class='subject' v-if="this.order.order_type !== 'CL'">
      <ul class="subject-ul">
        <li class="subject-li" v-for='(item,index) in order.emseaapplyls' :key="index" :class="{'stop' : Listshow.indexOf(index) !== -1}">
          <div class="border-bottom border-top" @click="addclass(index)">
            <img :src='top.showbottom' v-show="Listshow.indexOf(index) === -1">
            <img :src='top.hidetop' v-show="Listshow.indexOf(index) !== -1">
            <section class="main-top">预算明细{{index+1}}</section>
          </div>
          <div>
            <span>申请金额</span>
            <section>￥{{(item.apply_amount * 1).toFixed(2)}}</section>
          </div>
          <div>
            <span>预算部门</span>
            <section>{{item.busi_org_name}}</section>
          </div>
          <div>
            <span>经济事项</span>
            <section>{{item.fee_type_name}}</section>
          </div>
          <div>
            <span>预算来源</span>
            <section>{{item.budget_node_desc}}</section>
          </div>
          <div class='bottom-b'>
            <span>金额合计：</span>
            <section class="amount">￥{{(item.apply_amount * 1).toFixed(2)}}</section>
          </div>
        </li>
      </ul>
    </div>
    <div class="main" v-if="this.order.order_type === 'CL'">
      <ul>
        <li v-if="item.from_area_name" v-for='(item,index) in travel' :key="index" :class="{'stop' : Listshow.indexOf(index) !== -1}">
          <div class="border-bottom border-top" @click="addclass(index)">
            <div>
              <section>行程{{index+1}}</section>
            </div>
            <div>
              <img :src='top.arrowtop' class='img-animeat' v-show="Listshow.indexOf(index) === -1">
              <img :src='top.arrow' class='img' v-show="Listshow.indexOf(index) !== -1">
            </div>
          </div>
          <div class='border-bottom'>
            <span>地点</span>
            <section>{{item.from_area_name}} → {{item.to_area_name}}</section>
          </div>
          <div class='border-bottom'>
            <span v-if="myApplyMenuCfg[order.order_type].compnayPayAir">出行人</span>
            <span v-else>出差人</span>
            <div>
              <section>{{item.travel_persons_name}}</section>
            </div>
          </div>
          <div>
            <span>日期</span>
            <section>{{item.start_date.substring(0,10)}}</section>
          </div>
        </li>
      </ul>
    </div>
    <div class='has-bottom more' v-if="this.order.order_type === 'CL' && arr.length">
      <my-expenseSee @totalSum="gettotalSum" :order='arr' :show="showExpenses" @on-hide="hideExpense"></my-expenseSee>
      <div class='router border-bottom' @click=" showExpenses = true " @on-hide="hideExpense" v-if="cost">
        <div>费用预估</div>
        <div class='detailed' v-if="airFee">￥{{(cost * 1).toFixed(2)}}
          <span> (含飞机票 ￥{{airFee.toFixed(2)}})</span>
          <img :src='top.arrow' class='img'>
        </div>
        <div class='detailed' v-else>￥{{(cost * 1).toFixed(2)}}<img :src='top.arrow' class='img'></div>
      </div>
      <my-budgetsee :title='budgetseeArr' :show="applyBack" @on-hide="hideArea"></my-budgetsee>
      <div v-if='order.emseaapplyls.length > 0'>
        <div class='router border-bottom' v-if="order.order_type === 'CL' && myApplyMenuCfg[order.order_type].compnayPayAir && airBdgArr.length > 0" @click="goBudgetsee('airBdgArr')">
          <div>公司订票预算来源</div>
          <div class='detailed'>￥{{airBdgFee.toFixed(2)}}<img :src='top.arrow' class='img'></div>
        </div>

        <div class='router' v-if="order.order_type === 'CL' && myApplyMenuCfg[order.order_type].compnayPayAir && noAirBdgArr.length > 0" @click=" goBudgetsee('noAirBdgArr')">
          <div>预算来源(不含公司订票)</div>
          <div class='detailed'>￥{{noAirBdgFee.toFixed(2)}}<img :src='top.arrow' class='img'></div>
        </div>

        <div class='router' v-else @click="goBudgetsee()">
          <div>预算来源</div>
          <div class='detailed'>￥{{(order.approve_amount *1).toFixed(2)}}<img :src='top.arrow' class='img'></div>
        </div>

      </div>
    </div>
    <attachment :formInstanceId="order.form_instance_id"></attachment>
    <!-- <div class="enclosure" v-if="this.order.order_type === 'CL'" @click="enclosure">
          <div>附件</div>
          <div class='detailed'>共{{order.approve_amount}}份<img :src='top.arrow' class='img'></div>
        </div> -->
    <div class='examine' v-if="list.length || table.length">
      <div class='examine-top'>
        <span>审核记录</span>
      </div>
      <my-progress :title='list' :list='table' :current='actionName'></my-progress>
    </div>
    <div class="footerBtn" v-if="fdStatus">
      <div class="item scanInput" @click="goEdit">编辑</div>
      <div class="item manualInput" @click="del">删除</div>
    </div>
    <div class="bottom-list" v-if="showBottomList">
      <div class="flet" v-if="oplist.length && oplist[0].operationType !== 'handler_returnCommunicate'">
        <div class="more" @click="more(oplist[2])" v-if="oplist.length > 2 && showoplist.indexOf(oplist[2].operationType) !== -1">{{Object.keys(menus).length > 1 ? "更多": oplist[2].operationName}}</div>
        <div class="reject" @click="change(oplist[1])" v-if="oplist.length > 1 && showoplist.indexOf(oplist[1].operationType) !== -1">{{this.oplist[1].operationName}}</div>
      </div>
      <div class="pass" @click="change(oplist[0])" v-if="oplist.length && showoplist.indexOf(oplist[0].operationType) !== -1">{{this.oplist[0].operationName}}</div>
    </div>
    <actionsheet v-model="showAction" :menus="menus" :show-cancel="showCancel" @on-click-menu="jump"></actionsheet>
    <reject :rejectInfo="rejectParams" v-if="showReject" @hide="showReject=false" @successs="state"></reject>
    <pass :rejectInfo="PassParams" v-if="showPass" @hide="showPass=false" @successs="state"></pass>
    <communication :infor="inforCommunication" v-if="inforCommunication.show" @hide="inforCommunication.show=false" @successs="state"></communication>
    <turn-to :infor="inforTurn" v-if="inforTurn.show" @hide="inforTurn.show=false" @successs="state"></turn-to>
  </div>
</template>

<script>
import { Actionsheet, Confirm } from 'vux';
import { platform } from '@/platform';
import MyHeader from '../../common/header';
import attachment from '../../common/attachment';
import rtarrow from '../../../assets/rt-arrow.png';
import top from '../../../assets/images/fee/approve/top.png';
import hideTravel from '../../../assets/images/fee/approve/hideTravel.png';
import showTravel from '../../../assets/images/fee/approve/showTravel.png';
import MyExpenseSee from '../../common/expenseSee';
import MyBudgetsee from '../../common/budGetsee';
import MyProgress from '../../common/proGress';
import reject from './approveReject.vue';
import pass from './approvePass.vue';
import communication from './communication.vue';
import turnTo from './turnTo.vue';

export default {
  components: {
    MyHeader,
    attachment,
    MyExpenseSee,
    MyBudgetsee,
    MyProgress,
    Actionsheet,
    Confirm,
    reject,
    pass,
    communication,
    turnTo,
  },
  data() {
    return {
      noAirBdgFee: 0,
      noAirBdgArr: [],
      airBdgFee: 0,
      airBdgArr: [],
      budgetseeArr: [],
      cost: 0,
      airFee: 0, // 对公飞机票金额合计
      showAction: false, // 是否显示更多组件
      showCancel: true, // 是否显示取消按钮
      travelShow: false,
      applyBack: false,
      showReject: false,
      relatedShow: false,
      showExpenses: false, // 消费
      showPass: false,
      popup: '撤回该沟通消息',
      show: false,
      top: {
        type: '',
        arrow: rtarrow,
        arrowtop: top,
        hidetop: hideTravel,
        showbottom: showTravel,
      },
      menus: {},
      Listshow: [],
      list: [],
      actionName: '',
      order: {},
      arr: [],
      oplist: [],
      travel: [],
      showoplist: ['handler_communicate', 'handler_returnCommunicate', 'handler_refuse', 'handler_cancelCommunicate', 'handler_commission', 'handler_pass'],
      table: [],
      process: [],
      rejectParams: {
        jumpToNodeId: '',
        formInstanceId: '',
        model_id: '',
        template_form_id: '',
      },
      PassParams: {
        formInstanceId: '',
        model_id: '',
        template_form_id: '',
      },
      inforCommunication: {
        show: false,
        status: '',  // 状态：check/reply
        formInstanceId: '',  // 表单实例id
        template_form_id: '',  // 表单模板id
        linkContant: [], // 流程节点的process-log[]  借款
      },
      inforTurn: {
        show: false,
        formInstanceId: '',  // 表单实例id
        form_template_id: '',  // 表单模板id
      },
      showBottomList: true, // 是否显示底部操作项
      orderType: '',
      allTravelTypes: [],
    };
  },
  created() {
    this.getDetail();
  },
  computed: {
    fdStatus() {
      return this.$store.state.approve.fdStatus
    },
    myApplyMenuCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.children;
    },
    isUrgentCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.isUrgent
    },
  },
  methods: {
    // 查看预算
    goBudgetsee(type) {
      this.budgetseeArr = type ? this[type] : this.order.emseaapplyls;
      this.applyBack = true;
    },
    gettotalSum(value) {
      console.log(value);
    },
    state() {
      setTimeout(() => {
        if (this.$store.state.extCall) {
          platform.exit();
        } else {
          this.$router.push({
            path: '/fee/approve/',
          });
        }
      }, 500);
    },
    // 附件页
    // enclosure() {
    //   this.$router.push({
    //     path: '/fee/enclosureList', query: { id: this.$route.query.id, type: this.order.order_type },
    //   });
    // },
    hideArea(type) {
      this.travelShow = false;
      this.showApply = false;
      this.trick = false;
      this.offset = false;
      this.relatedShow = false;
      this.applyBack = false;
    },
    selectArea() {
      this.travelShow = true;
      this.showApply = true;
      this.trick = true;
      this.offset = true;
      this.showBack = true;
    },
    // 组件消费关闭
    hideExpense() {
      this.showExpenses = false;
    },

    // 获取费用申请单单据信息
    async getDetail() {
      this.allTravelTypes = await this.$method.getDataFromDict('TRAVEL_TYPE'); // 获取所有出差类型数据
      const standardTypeDict = [{
          label: '市内交通费',
          value: 'SNJTF',
        }, {
          label: '餐费',
          value: 'CF',
        }];
      this.showLoading();
      this.$store.dispatch('myReQuest', {
        fee_apply_id: this.$route.query.id, // this.$route.query.id,
      }).then((res) => {
        if (res.code === '0000') {
          this.hideLoading();
          this.list = res.data.process_log.filter(log => log.fdActionKey.indexOf('走分支') === -1);
          this.order = res.data.order_msg.emseaapplyh;
          this.airBdgArr = [];
          this.airBdgFee = 0;
          this.noAirBdgArr = [];
          this.noAirBdgFee = 0;

          this.order.emseaapplyls.forEach(item => {
            if (item.attribute1 === 'COMPANY' && item.attribute13 === 'AIRPLANE') {
              this.airBdgArr.push(item);
              this.airBdgFee += item.approve_amount;
            } else {
              this.noAirBdgArr.push(item);
              this.noAirBdgFee += item.approve_amount;
            }
          });

          this.airBdgFee = parseFloat(this.airBdgFee);
          this.noAirBdgFee = parseFloat(this.noAirBdgFee);

          // 出差类型code转name
          if (this.order.order_type === 'CL' && this.myApplyMenuCfg[this.order.order_type].hasTravelType) {
            this.$set(this.order, 'attribute15_name', this.$method.getValueInArray(this.order.attribute15, this.allTravelTypes, 'itemValue', 'itemName'));
          }
          this.actionName = res.data.current_process_info.actionUidName;
          // 获取操作按钮
          if (this.order.order_type !== 'TY') {
            let moneyCat = 0;
            this.arr[0] = this.order.emseaapplytravels;// 行程
            this.arr[0].forEach((data) => {
              if (data.emseatransportdetails) {
                data.trans = data.emseatransportdetails; // 交通工具
              }
              data.emseatransportdetails.forEach((moneyData) => {
                if (moneyData.approve_transport_fee) {
                  moneyCat += moneyData.approve_transport_fee;
                  if (moneyData.attribute1 === 'COMPANY' && moneyData.transport === 'AIRPLANE' && this.order.order_type === 'CL' && this.myApplyMenuCfg[this.order.order_type].hasTravelType) {
                    this.airFee = this.airFee + moneyData.approve_transport_fee; // 对公飞机票金额合计
                  }
                }
              });
            });
            // this.arr[1] = this.order.emseaapplytravels.emseatransportdetails; // 交通工具
            this.arr[2] = this.order.emsearentdetails;// 住宿
            let moneyHotel = 0;
            this.arr[2].forEach((hotelData) => {
              if (hotelData.approve_rent_fee) {
                moneyHotel += hotelData.approve_rent_fee;
              }
            });
            this.arr[3] = this.order.emseaassistantdetails; // 补助
            let subsidy = 0;
            this.arr[3].forEach((subsidyData) => {
              if (subsidyData.standard_type) {
                subsidyData.standard_type_name = this.$method.getValueInArray(subsidyData.standard_type, standardTypeDict, 'value', 'label');
              }
              if (subsidyData.approve_assistant_fee) {
                subsidy += subsidyData.approve_assistant_fee;
              }
            });
            this.arr[4] = this.order.emseaotherfeedetails; // 其他
            let other = 0;
            this.arr[4].forEach((otherData) => {
              if (otherData.approve_other_fee) {
                other += otherData.approve_other_fee;
              }
            });
            this.cost = other + subsidy + moneyHotel + moneyCat;
          }
          this.orderType = res.data.order_msg.emseaapplyh.order_type
          this.travel = res.data.order_msg.emseaapplyh.emseaapplytravels;
          this.process = res.data.current_process_info;
          this.table = res.data.process_table;
          this.getOplist();
          if (this.order.order_type === 'CL') {
            this.top.type = res.data.order_msg.emseaapplyh.order_type_name;
          } else {
            this.top.type = res.data.order_msg.emseaapplyh.order_type_name;
          }
        } else {
          this.hideLoading();
          this.showToast({ msg: res.msg });
          this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    // 获取操作状态按钮
    getOplist() {
      this.$store.dispatch('getOplist', {
        formInstanceId: `${this.$route.query.id}_EA`,
        model_id: '001',
        template_form_id: this.order.form_template_id,
      })
        .then((res) => {
          if (res.code === '0000') {
            console.log(res.data);
            let list = [];
            if (res.data.length) {
              res.data.forEach((item) => {
                list = list.concat(item.operations);
              });
              const newList = [];
              list.forEach((item, index) => {
                if (item.operationType === 'handler_refuse') {
                  list.splice(index, 1);
                  list.splice(1, 0, item);
                }
                if (newList.indexOf(item.operationType) === -1) {
                  newList.push(item.operationType);
                } else {
                  list.splice(index, 1);
                }
              });
              this.oplist = list;
              this.oplist.forEach((item, index) => {
                if (index > 1 && this.showoplist.indexOf(item.operationType) !== -1) {
                  console.log(item.operationName);
                  const obj = {
                    [item.operationType]: `<span style="color: #666666;">${item.operationName}</span>`,
                  };
                  this.menus = Object.assign({}, this.menus, obj);
                  console.log(this.menus);
                }
              });
            } else {
              list = [];
            }
          } else {
            this.showToast({ msg: res.msg });
          }
        });
    },
    //      获取取消沟通节点
    cancelOpparam() {
      this.$store.dispatch('cancelOpparam', {
        approveType: 'handler_cancelCommunicate',
        formInstanceId: `${this.$route.query.id}_EA`, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.order.form_template_id,
      }).then((res) => {
        if (res.code === '0000') {
          const communicateWorkitemList = res.data.handler_cancelCommunicate.communicateWorkitemList;
          let communicateArr = '';
          communicateWorkitemList.forEach((item) => {
            communicateArr += `${item.id};`;
          });
          this.celcommunicate(communicateArr);
        } else {
          this.showToast({ msg: res.msg });
          //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    //      取消沟通
    celcommunicate(value) {
      this.showLoading();
      this.$store.dispatch('celcommunicate', {
        cancelHandlerIds: value,
        formInstanceId: `${this.$route.query.id}_EA`, // this.$route.query.id,
        model_id: '001',
        template_form_id: this.order.form_template_id,
      }).then((res) => {
        if (res.code === '0000') {
          this.hideLoading();
          this.showToast({ msg: '成功取消沟通' });
          setTimeout(() => {
            if (this.$store.state.extCall) {
              platform.exit();
            } else {
              this.$router.push({
                path: '/fee/approve/',
              });
            }
          }, 500);
        } else {
          this.hideLoading();
          this.showToast({ msg: res.msg });
          //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
        }
      });
    },
    change(obj) {
      switch (obj.operationType) {
        case 'handler_communicate':
          console.log('沟通');
          this.inforCommunication.show = true;
          this.inforCommunication.status = '';
          this.inforCommunication.formInstanceId = `${this.$route.query.id}_EA`;
          this.inforCommunication.template_form_id = this.order.form_template_id;
          this.inforCommunication.linkContant = this.list;
          break;
        case 'handler_cancelCommunicate':
          console.log('取消沟通');
          this.cancelOpparam();
          break;
        case 'handler_refuse':
          this.rejectParams.jumpToNodeId = this.table[0].fdNodeId;
          this.rejectParams.formInstanceId = `${this.$route.query.id}_EA`;  //  this.$route.query.id
          this.rejectParams.model_id = '001';
          this.rejectParams.template_form_id = this.order.form_template_id;
          this.showReject = true;
          console.log('驳回');
          break;
        case 'handler_commission':
          console.log('转办');
          this.inforTurn.show = true;
          this.inforTurn.formInstanceId = `${this.$route.query.id}_EA`;
          this.inforTurn.form_template_id = this.order.form_template_id;
          break;
        case 'handler_returnCommunicate':
          this.inforCommunication.show = true;
          this.inforCommunication.status = 'reply';
          this.inforCommunication.formInstanceId = `${this.$route.query.id}_EA`;
          this.inforCommunication.template_form_id = this.order.form_template_id;
          this.inforCommunication.linkContant = this.list;
          break;
        case 'handler_pass':
          this.PassParams.formInstanceId = `${this.$route.query.id}_EA`;
          this.PassParams.model_id = '001';
          this.PassParams.template_form_id = this.order.form_template_id;
          this.showPass = true;
          break;
        case 'drafter_press':
          this.PassParams.formInstanceId = `${this.$route.query.id}_EA`;
          this.PassParams.model_id = '001';
          this.PassParams.template_form_id = this.order.form_template_id;
          this.showPass = true;
          console.log('通过');
          break;
        default:
      }
    },
    // 沟通/转办
    jump(ket) {
      console.log(ket);
      switch (ket) {
        case 'handler_communicate':
          console.log('沟通');
          this.inforCommunication.status = '';
          this.inforCommunication.formInstanceId = `${this.$route.query.id}_EA`;
          this.inforCommunication.template_form_id = this.order.form_template_id;
          this.inforCommunication.linkContant = this.list;
          this.inforCommunication.show = true;
          console.log(ket);
          break;
        case 'handler_commission':
          console.log('转办');
          this.inforTurn.show = true;
          this.inforTurn.formInstanceId = `${this.$route.query.id}_EA`;
          this.inforTurn.form_template_id = this.order.form_template_id;
          break;
        case 'handler_refuse':
          this.rejectParams.jumpToNodeId = this.table[0].fdNodeId;
          this.rejectParams.formInstanceId = `${this.$route.query.id}_EA`;  //  this.$route.query.id
          this.rejectParams.model_id = '001';
          this.rejectParams.template_form_id = this.order.form_template_id;
          this.showReject = true;
          break;
        default:
      }
    },
    // 确定撤回
    onConfirm() {
      this.$store.dispatch('celCommunicate', {
        cancelHandlerIds: '15ad5ed801c7b96e5cdbd59472281e74',
        formInstanceId: this.order.formInstanceId, // this.order.formInstanceId,
        model_id: '001',
        template_form_id: this.process.flowTemplateId,
      }).then((res) => {
        if (res.code === '0000') {
          console.log(res);
        } else {
          this.showToast({ msg: res.msg });
        }
      });
    },
    // 更多
    more(obj) {
      console.log(obj, this.menus);
      if (Object.keys(this.menus).length > 1) {
        this.showAction = !this.showAction;
      } else {
        switch (obj.operationType) {
          case 'handler_communicate':
            console.log('沟通');
            this.inforCommunication.show = true;
            this.inforCommunication.status = '';
            this.inforCommunication.formInstanceId = `${this.$route.query.id}_EA`;
            this.inforCommunication.template_form_id = this.order.form_template_id;
            this.inforCommunication.linkContant = this.list;
            break;
          case 'handler_cancelCommunicate':
            console.log('取消沟通');
            this.cancelOpparam();
            break;
          case 'handler_commission':
            console.log('转办');
            this.inforTurn.show = true;
            this.inforTurn.formInstanceId = `${this.$route.query.id}_EA`;
            this.inforTurn.form_template_id = this.order.form_template_id;
            break;
          case 'handler_returnCommunicate':
            console.log('回复');
            this.inforCommunication.show = true;
            this.inforCommunication.status = 'reply';
            this.inforCommunication.formInstanceId = `${this.$route.query.id}_EA`;
            this.inforCommunication.template_form_id = this.order.form_template_id;
            this.inforCommunication.linkContant = this.list;
            break;
          case 'handler_pass':
            this.PassParams.formInstanceId = `${this.$route.query.id}_EA`;
            this.PassParams.model_id = '001';
            this.PassParams.template_form_id = this.order.form_template_id;
            this.showPass = true;
            break;
          case 'handler_refuse':
            this.rejectParams.jumpToNodeId = this.table[0].fdNodeId;
            this.rejectParams.formInstanceId = `${this.$route.query.id}_EA`;  //  this.$route.query.id
            this.rejectParams.model_id = '001';
            this.rejectParams.template_form_id = this.order.form_template_id;
            this.showReject = true;
            console.log('驳回');
            break;
          default:
        }
      }
    },
    // 作废
    toVoid() { },
    goBack() {
      if (this.$store.state.extCall) {
        platform.exit();
      } else {
        this.$router.go(-1);
      }
    },
    // 点击收起
    addclass(index) {
      const newIndex = this.Listshow.indexOf(index);
      if (newIndex === -1) {
        this.Listshow.push(index);
      } else {
        this.Listshow.splice(newIndex, 1);
      }
    },
    goEdit() {
      if (this.$route.query.type === 'EA') {
        if (this.orderType === 'nonsupport') {
          this.showToast({ msg: '移动端暂不支持该类型单据的编辑，请移步PC端' });
        } else if (this.$route.query.id && this.orderType) {
          setTimeout(() => {
            this.$router.push({
              path: '/fee/myApply/create/addTravelApply', query: { id: this.$route.query.id, type: this.orderType === 'TY' ? 'EA' : this.orderType },
            });
          }, 500);
        }
      } else if (this.$route.query.type === 'EC') {
        if (this.orderType === 'nonsupport') {
          this.showToast({ msg: '移动端暂不支持该类型操作，请移步PC端' });
        } else if (this.$route.query.id && this.orderType) {
          setTimeout(() => {
            this.$router.push({
              path: '/fee/myReimburse/create', query: { id: this.$route.query.id, type: this.orderType },
            });
          }, 500);
        }
      }
    },
    delBill() {
      if (this.orderType === 'LM') {
        this.$store.dispatch('deleteLoan', { loan_info_id: this.$route.query.id }).then((res) => {
          if (res.code === '0000') {
            this.showToast({ msg: '操作成功！' });
            setTimeout(() => {
              this.$router.push('/fee/approve/approveHome/unApproved')
            }, 800);
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      } else {
        this.$store.dispatch('deleteFeeApply', { fee_apply_id: this.$route.query.id }).then((res) => {
          if (res.code === '0000') {
            this.showToast({ msg: '操作成功！' });
            setTimeout(() => {
              this.$router.push('/fee/approve/approveHome/unApproved')
            }, 800);
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      }
    },
    del() {
      let self = this;
      this.$vux.confirm.show({
        title: '作废',
        content: '确定作废该申请单吗？',
        onConfirm() {
          self.delBill();
        },
      });
    }
  },
  mounted() {
    if (this.$route.query.isApproved) {
      this.showBottomList = false;
    }
  },
};
</script>

<style lang='less' scoped>
.approval {
  font-family: PingFangSC-Regular;
  font-size: 16px;
  color: #000000;
  line-height: 16px;
}

.top {
  background: #484759; // width: 92%;
  padding: 0 15px;
  color: #ffffff;
  margin-top: 45px;
  div {
    display: flex;
    align-items: center;
  }
  div:nth-of-type(1) {
    display: flex;
    padding: 11px 0 15px 0;
    justify-content: space-between;
    align-items: center;
    .applyer {
      width: 50%;
    }
    i {
      position: absolute;
      right: 0;
      display: inline-block;
      font-style: normal;
      font-size: 12px;
      padding: 0 6px 0 8px;
      height: 20px;
      background: #6F6E82;
      border-radius: 10px 0 0 10px;
      text-align: center;
      line-height: 20px;
    }
  }
  div:nth-of-type(2) {
    padding-bottom: 15px;
    p {
      margin-right: 5px;
      color: #3DA5FE;
      &.travel-type {
        color: #fff;
        margin: 0;
      }
    }
    section {
      padding-bottom: 0!important;
    }
  }
  section {
    padding-bottom: 19px;
    opacity: 0.6;
    line-height: 22px;
  }
}

.main-top {
  padding: 0 4%;
  background: #FFFFFF;
  color: #858585;
  ul {
    list-style-type: none;
    margin-bottom: 10px;
    li {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 50px;
    }
  }
}

.main {
  width: 92%;
  padding: 0 4%;
  background: #FFFFFF;
  color: #000000;
  ul {
    list-style-type: none;
    li {
      &.stop {
        height: 50px;
        overflow: hidden;
      }
      div {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 50px;
      }
      span {
        color: #858585;
      }
    }
  }
}

.has-bottom {
  margin-top: 10px;
  padding-left: 13px;
  background: #ffffff;
  box-shadow: 0 0 0 0 #DEDFE0, 0 0 0 0 #DEDFE0;
  .router {
    height: 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #858585;
    .detailed {
      color: #3DA5FE;
      padding-right: 13px;
    }
  }
}

.examine {
  background: #ffffff;
  margin-bottom: 100px;
  .examine-top {
    height: 48px;
    padding: 0 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #858585;
    margin-top: 10px;
    border-bottom: 1px solid #cbcfd6;
    p {
      width: 70px;
      height: 30px;
      background: #3da5fe;
      text-align: center;
      line-height: 30px;
      border-radius: 40px;
    }
  }
}

.bottom-list {
  width: 100%;
  text-align: center;
  line-height: 50px;
  margin-bottom: 0;
  background: #ffffff;
  box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
  position: fixed;
  bottom: 0;
  display: flex;
  justify-content: space-between;
  color: #666666;
  font-size: 18px;
  .flet {
    flex: 1;
    display: flex;
    .more {
      flex: 1;
    }
    .reject {
      flex: 1;
    }
  }
  .pass {
    flex: 1;
    background: #3DA5FE;
    color: #ffffff;
  }
}

.bottom-withdraw {
  width: 100%;
  height: 50px;
  text-align: center;
  line-height: 50px;
  margin-bottom: 0;
  background: #ffffff;
  box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
  position: fixed;
  bottom: 0;
  text-align: center;
  font-size: 18px;
  color: #666666;
}

.bottom-reply {
  width: 100%;
  height: 50px;
  text-align: center;
  line-height: 50px;
  margin-bottom: 0;
  background: #ffffff;
  background: #3DA5FE;
  position: fixed;
  bottom: 0;
  text-align: center;
  box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.10);
  font-size: 18px;
  color: #FFFFFF;
}

.img {
  width: 7px;
  height: 13px;
  padding-left: 10px;
}

.img-animeat {
  width: 13px;
  height: 8px;
  padding-left: 10px;
}

.img-show {
  width: 7px;
  height: 6px;
  padding-right: 8px;
}

.subject {
  width: 100%;
}

.subject-ul {
  font-size: 16px;
  color: #000000;
  list-style: none;
  .subject-li {
    background: #ffffff;
    margin-top: 10px;
    font-size: 14px;
    &.stop {
      height: 50px;
      overflow: hidden;
    }
    div {
      padding: 10px 15px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 0 0 0 #DEDFE0, 0 0 0 0 #DEDFE0;
      span {
        color: #858585;
      }
      section {
        text-align: right;
      }
    }
    div:nth-child(1) {
      height: 50px;
      box-sizing: content-box;
      justify-content: initial;
      margin: 0;
      padding: 0 15px;
      section {
        font-size: 16px;
      }
    }
    div:nth-child(2) {
      section {
        font-size: 16px;
      }
    }
  }
}

.bottom-b {
  display: block;
  box-sizing: border-box;
  height: 50px;
  text-align: right;
  line-height: 34px;
  background: #ffffff;
  .amount {
    color: #3DA5FE;
  }
  span {
    color: #3DA5FE;
  }
}

.footerBtn {
  line-height: 1.6;
  width: 100%;
  position: fixed;
  bottom: 0;
  display: flex;
  justify-content: space-between;
  border-top: #DEDFE0 1px solid;
  .item {
    width: 50%;
    text-align: center;
    padding: 11px 0;
    font-size: 18px;
  }
  .manualInput {
    color: #666666;
    background-color: #ffffff;
  }
  .scanInput {
    background-color: #3DA5FE;
    color: #ffffff !important;
  }
}

.travel-type {
  position: absolute;
  right: 0;
  display: inline-block;
  font-style: normal;
  font-size: 12px;
  padding: 0 6px 0 8px;
  height: 20px;
  background: #6F6E82;
  border-radius: 10px 0 0 10px;
  text-align: center;
  line-height: 20px;
}
</style>
