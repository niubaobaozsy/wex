<!--
  describe：审批通用费用申请通用报销
  created by：黄喆
  date：2017-12-05
-->
<template>
  <div class="approval has-footer">
    <my-header :title='top.type' @previous="goBack"></my-header>
    <div class="top">
      <div class="top-list">
        <p class="applyer">{{emsecfeereimh.apply_name}} <span v-if="emsecfeereimh.org_name">|</span> {{emsecfeereimh.org_name}}</p><i>{{emsecfeereimh.order_type_name}} {{emsecfeereimh.fee_reim_code}}</i>
      </div>
      <div class="top-currency" v-if="emsecfeereimh.approve_reim_amount !== undefined">
        <p><span>￥</span>{{ (emsecfeereimh.approve_reim_amount * 1).toFixed(2) }}</p>
        <section>| {{ emsecfeereimh.currency_code }}</section>
        <p  v-if="emsecfeereimh.order_type ==='CL' && myApplyMenuCfg[emsecfeereimh.order_type].hasTravelType" class="travel-type">{{emsecfeereimh.attribute3_name}}</p>
      </div>
      <div class="reason_desc">
        <!-- <p class="reason">{{ emsecfeereimh.reason_desc }}</p> -->
        <!-- 屏蔽reason_desc,展示sensitive_info -->
        <p class="reason">{{ emsecfeereimh.sensitive_info }}</p>
        <p v-if="isUrgentCfg" class="isUrgent">
          {{emsecfeereimh.is_urgent === 'Y' ? '加急：是' : '加急：否' }}
        </p>
      </div>

      <!-- <p class="reason">{{ emsecfeereimh.sensitive_info }} </p> -->
    </div>
    <div v-if="orderType === 'CL'">
      <div class='border-bottom margin-top no-top ' v-if="emsecfeereimh.is_over_standard !== 'N'">
        <div class="type">超标原因</div>
        <div class='detailed'>{{emsecfeereimh.over_standard_reason}}</div>
      </div>
      <div v-if="emsecfeereimh.emsEcFeeBudgets" class='border-bottom margin-top' @click="relation">
        <div class="type" >申请单</div>
        <div class='detailed'>
          <img :src='top.arrow' class='img'>
        </div>
      </div>
      <div class="white-bg" v-for="(item, index) in emsecfeereimh.feeTravels" :key="index" @click="trip(item)">
        <div class='border-bottom margin-top no-top'>
          <div class="type data-type">行程{{index+1}}</div>
          <div class='detailed'><img :src='top.arrow' :class="['img', {'arrow_top': showTrip.indexOf(item) === -1}]"></div>
        </div>
        <div v-if='showTrip.indexOf(item) === -1'>
          <div class='border-bottom margin-top no-top margin-left'>
            <div class="type">地点</div>
            <div class='detailed'>{{item.from_area_name}}→{{item.to_area_name}}</div>
          </div>
          <div class='border-bottom margin-top no-top margin-left'>
            <div class="type" v-if="emsecfeereimh.order_type ==='CL' && myApplyMenuCfg[emsecfeereimh.order_type].compnayPayAir">出行人</div>
            <div class="type" v-else>出差人</div>
            <div class='detailed'>{{item.travel_persons_name}}</div>
          </div>
          <div class='border-bottom margin-top no-top'>
            <div class="type">日期</div>
            <div class='detailed' v-if="item.start_date">
              {{item.start_date.substring(0,10)}}
            </div>
          </div>
        </div>
      </div>
      <div class="white-bg">
        <expense-see :order='arr' :show="applyBack" @on-select="selectArea" @on-hide="hideArea"></expense-see>
        <div class='border-bottom margin-top margin-lr' @click="applyBack = true">
          <div class="type">费用明细</div>
          <div class='detailed'>
            <span class="money">￥{{(cost * 1).toFixed(2)}}</span>
            <img :src='top.arrow' class='img'>
          </div>
        </div>
      </div>
      <div class="white-bg border-bottom">
        <my-budgetsee :title='emsecfeereimh.emsEcFeeBudgets' :show="travelShow" @on-select="selectArea"  @on-hide="hideBudgetsee"></my-budgetsee>
        <div class='margin-top no-top margin-lr' @click="travelShow = true">
          <div class="type">预算来源</div>
          <div class='detailed'>
            <span class="money">￥{{(messagesApply * 1).toFixed(2)}}</span>
            <img :src='top.arrow' class='img'>
          </div>
        </div>
      </div>
      <!-- <div class='border-bottom margin-top'>
        <div class="type">附件</div>
        <div class='detailed'>
          <img :src='top.arrow' class='img'>
        </div>
      </div> -->
    </div>
    <div v-if="orderType !== 'CL'">
      <div class='border-bottom margin-top'>
        <div class="type data-type"><img class="showbottom" :src="top.showbottom" alt="">预算明细</div>
        <div class='detailed'></div>
      </div>
      <div v-if="emsecfeereimh.emsEcFeeBudgets && emsecfeereimh.emsEcFeeBudgets.length !== 0">
        <ul class="border-bottom white-bg" v-for="(budget, index) in emsecfeereimh.emsEcFeeBudgets" :key="index">
          <li class='border-bottom margin-top no-top margin-left'>
            <div class="type">预算来源</div>
            <div class='detailed'>
              {{budget.budget_node_desc}}
            </div>
          </li>
          <li class='border-bottom margin-top no-top margin-left'>
            <div class="type">预算部门</div>
            <div class='detailed'>
              {{budget.busi_org_name}}
            </div>
          </li>
          <li class='border-bottom margin-top no-top margin-left'>
            <div class="type">经济事项</div>
            <div class='detailed'>
              {{budget.bill_type_name}}
            </div>
          </li>
          <li class='border-bottom margin-top no-top margin-left'>
            <div class="type">业务描述</div>
            <div class='detailed'>
              {{budget.sensitive_info}}
            </div>
          </li>
          <li class='margin-top no-top'>
            <div class="type">金额</div>
            <div class='detailed blue'>
              ￥{{ (budget.approve_reim_amount * 1).toFixed(2) }}
            </div>
          </li>
        </ul>
      </div>
    </div>
    <attachment :formInstanceId="formInstanceId"></attachment>
    <div class='border-bottom margin-top'>
      <div class="type">审批记录</div>
      <div class='detailed'></div>
    </div>
    <my-progress :title='list' :list="listNew" :current="current"></my-progress>
    <!--v-if="oplists.length === 4"-->
    <div class="bottom-list" v-if="showBottomList">
      <div class="flet">
        <div class="more" @click="more(oplist[2])" v-if="oplist.length > 2 && showoplist.indexOf(oplist[2].operationType) !== -1">{{Object.keys(menus).length > 1 ? "更多": oplist[2].operationName}}</div>
        <div class="reject" @click="change(oplist[1])" v-if="oplist.length > 1 && showoplist.indexOf(oplist[1].operationType) !== -1">{{this.oplist[1].operationName}}</div>
      </div>
      <div class="pass" @click="change(oplist[0])" v-if="this.oplist.length && showoplist.indexOf(oplist[0].operationType) !== -1">{{this.oplist[0].operationName}}</div>
    </div>
    <div class="footerBtn" v-if="fdStatus">
      <div class="item scanInput" @click="goEdit">编辑</div>
      <div class="item manualInput" @click="del">删除</div>
    </div>
    <actionsheet v-model="showAction" :menus="menus" :show-cancel="showCancel" @on-click-menu="jump"></actionsheet>
    <reject :rejectInfo="operateDeta" v-if="showReject" @hide="showReject=false" @successs="state"></reject>
    <pass :rejectInfo="operateDeta" v-if="showPass" @hide="showPass=false" @successs="state"></pass>
    <communication :infor="operateDeta" v-if="operateDeta.show" @hide="operateDeta.show=false" @successs="state"></communication>
    <turn-to :infor="inforTurn" v-if="inforTurn.show" @hide="inforTurn.show=false" @successs="state"></turn-to>
    <approve-relatedapply :list="emsecfeereimh.emsEcFeeBudgets" :show.sync="showRelated" @on-hide="hideRelate"/>
  </div>
</template>

<script type="text/ecmascript-6">
  import { Actionsheet } from 'vux';
  import { platform } from '@/platform';
  import myHeader from '../../common/header';
  import rtarrow from '../../../assets/rt-arrow.png';
  //  审批进度
  import myProgress from '../../common/proGress';
  import hideTravel from '../../../assets/images/fee/approve/hideTravel.png';
  import showTravel from '../../../assets/images/fee/approve/showTravel.png';
  import reject from './approveReject.vue';
  import pass from './approvePass.vue';
  import communication from './communication.vue';
  import approveRelatedapply from './approveRelatedapply.vue';
  import turnTo from './turnTo.vue';
//  费用预估
  import expenseSee from '../../common/expenseSee';
//  预算明细
  import myBudgetsee from '../../common/budGetsee';
  import attachment from '../../common/attachment';

  export default {
    components: {
      myHeader,
      Actionsheet,
      myProgress,
      reject,
      pass,
      communication,
      turnTo,
      expenseSee,
      myBudgetsee,
      approveRelatedapply,
      attachment,
    },
    data() {
      return {
        messagesApply: '',
        showRelated: false,
        showAction: false, // 是否显示更多组件
        showCancel: true,  // 是否显示取消按钮
        top: {
          type: '员工费用报销',
          arrow: rtarrow,
          hidetop: hideTravel,
          showbottom: showTravel,
        },
        menus: {},
        applyaList: [],
        list: [],
        arr: [],
        listNew: [],
        current:'',
        oplist: [],
        showoplist: ['handler_communicate', 'handler_returnCommunicate', 'handler_refuse', 'handler_cancelCommunicate', 'handler_commission', 'handler_pass'],
        emsecfeereimh: {},
        showReject: false,
        showPass: false,
        showTrip: [],
        formInstanceId: '',
        operateDeta: {
          jumpToNodeId: '',
          formInstanceId: '',
          model_id: '001',
          template_form_id: '',
          show: false,
          status: '',  // 状态：check/reply
          linkContant: [],
        },
        inforTurn: {
          show: false,
          formInstanceId: '',  // 表单实例id
          form_template_id: '',  // 表单模板id2222222
        },
        type: 'ty-bx',
        applyBack: false,  // 报销审批预算来源显示隐藏
        travelShow: false,  // 报销审批费用预估显示隐藏
        cost: 0,  // 费用预估
        orderType: '',
        showBottomList: true, // 是否显示底部操作项
        allTravelTypes:[],
      };
    },
    mounted() {
      if (this.$route.query.isApproved) {
        this.showBottomList = false;
      }
      this.getFee();
    },
    computed:{
      fdStatus(){
        return this.$store.state.approve.fdStatus
      },
      isUrgentCfg() {
       return this.$store.state.menuConfig.fee.children.myApply.isUrgent
      },
      myApplyMenuCfg() {
        return this.$store.state.menuConfig.fee.children.myApply.children;
      }
    },
    methods: {
      state() {
        setTimeout(() => {
          if (this.$store.state.extCall) {
            platform.exit();
          } else {
            this.$router.push({
              path: '/fee/approve/',
            });
          }
        }, 500);
      },
      goBack() {
        this.$store.commit('REC_FDSTATUS')
        if (this.$store.state.extCall) {
          platform.exit();
        } else {
          this.$router.go(-1);
        }
      },
      // 批量获取业务字典编码对应的数据
      async getDictData() {
        if (this.emsecfeereimh.order_type === 'CL' && this.myApplyMenuCfg[this.emsecfeereimh.order_type].hasTravelType) {
            this.allTravelTypes = await this.$method.getDataFromDict('TRAVEL_TYPE'); // 获取所有出差类型数据
            // this.emsecfeereimh.attribute3_name = this.$method.getValueInArray(this.emsecfeereimh.attribute3, this.allTravelTypes, 'itemValue', 'itemName');
            this.$set(this.emsecfeereimh, 'attribute3_name', this.$method.getValueInArray(this.emsecfeereimh.attribute3, this.allTravelTypes, 'itemValue', 'itemName'));
        }
      },
      // 获取单据详情
      getFee() {
        const standardTypeDict = [{
          label: '市内交通费',
          value: 'SNJTF',
        }, {
          label: '餐费',
          value: 'CF',
        }];
        this.showLoading();
        this.$store.dispatch('getFee', {
          fee_reim_id: this.$route.query.id, // this.$route.query.id,
        }).then((res) => {
          if (res.code === '0000') {
            this.hideLoading();
            this.emsecfeereimh = res.data.emsecfeereimh;
            this.orderType = res.data.orderType;
            this.getDictData(); // 出差类型code转name
            if (this.orderType === 'CL') {
              let moneyCat = 0;
              this.arr[0] = this.emsecfeereimh.feeTravels;// 行程
              this.arr[0].forEach((data) => {
                if (data.transportDetails) {
                  data.trans = data.transportDetails; // 交通工具
                }
                data.transportDetails.forEach((moneyData) => {
                  console.log(moneyData, 'moneyData');
                  if (moneyData.approve_transport_fee) {
                    moneyCat += moneyData.approve_transport_fee;
                  }
                });
              });
              console.log(moneyCat);
              // this.arr[1] = this.emsecfeereimh.feeTravels.transportDetails; // 交通工具
              this.arr[2] = this.emsecfeereimh.rentDetails;// 住宿
              let moneyHotel = 0;
              this.arr[2].forEach((hotelData) => {
                if (hotelData.approve_rent_fee) {
                  moneyHotel += hotelData.approve_rent_fee;
                }
              });
              console.log(moneyHotel);
              this.arr[3] = this.emsecfeereimh.assistantDetails; // 补助
              let subsidy = 0;
              this.arr[3].forEach((subsidyData) => {
                if (subsidyData.standard_type) {
                  subsidyData.standard_type_name = this.$method.getValueInArray(subsidyData.standard_type, standardTypeDict, 'value', 'label');
                }
                if (subsidyData.approve_assistant_fee) {
                  subsidy += subsidyData.approve_assistant_fee;
                }
              });
              console.log(subsidy, 'subsidy');
              this.arr[4] = this.emsecfeereimh.ecOtherFeeDetails; // 其他
              let other = 0;
              this.arr[4].forEach((otherData) => {
                if (otherData.approve_other_fee) {
                  other += otherData.approve_other_fee;
                }
              });
              console.log(other, 'other');
              this.cost = other + subsidy + moneyHotel + moneyCat;
            }
            this.formInstanceId = res.data.formInstanceId;
            this.operateDeta.formInstanceId = this.formInstanceId;
            this.operateDeta.template_form_id = this.emsecfeereimh.form_template_id;
            const lengths = this.emsecfeereimh.emsEcFeeBudgets ? this.emsecfeereimh.emsEcFeeBudgets.length : 0;
            console.log(lengths, 'lengths');
            if (lengths) {
              let messages = 0;
              this.emsecfeereimh.emsEcFeeBudgets.forEach((item) => {
                if (item.approve_reim_amount) {
                  messages += item.approve_reim_amount - 0;
                }
              });
              this.messagesApply = messages;
            }
            if (this.orderType === 'CL') {
              this.top.type = '差旅报销';
            }
            // 获取操作按钮
            this.grtFlowt();
            this.getLog();
            this.getOplist();
          } else {
            this.hideLoading();
            this.showToast({ msg: '找不到报销单' });
            this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
          }
        });
      },
      // 审批节点未审批
      grtFlowt() {
        this.$store.dispatch('grtFlowt', {
          formInstanceId: this.formInstanceId, // this.$route.query.id,
          model_id: '001',
          template_form_id: this.emsecfeereimh.form_template_id,
        }).then((res) => {
          if (res.code === '0000') {
            this.listNew = res.data;
            this.listNew.forEach(item =>{
            if(item.current){
              this.current = item.fdNodeHandlerNames;
            }
          })
          }
        });
      },
      // 获取已经审批过得节点信息
      getLog() {
        this.$store.dispatch('getLog', {
          formInstanceId: this.formInstanceId, // this.$route.query.id,
          model_id: '001',
          template_form_id: this.emsecfeereimh.form_template_id,
        }).then((res) => {
          if (res.code === '0000') {
            this.list = res.data;
          } else {
            this.showToast({ msg: '找不到待审批节点信息' });
            //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
          }
        });
      },
      // 点击控制行程显示和隐藏
      trip(value) {
        const length = this.showTrip.indexOf(value);
        if (length === -1) {
          this.showTrip.push(value);
        } else {
          this.showTrip.splice(length, 1);
        }
      },
      // 获取操作按钮节点
      getOplist() {
        this.$store.dispatch('getOplist', {
          formInstanceId: this.formInstanceId,
          model_id: '001',
          template_form_id: this.emsecfeereimh.form_template_id,
        })
          .then((res) => {
            if (res.code === '0000') {
              let list = [];
              if (res.data.length) {
                res.data.forEach((item) => {
                  list = list.concat(item.operations);
                });
                const newList = [];
                list.forEach((item, index) => {
                  if (item.operationType === 'handler_refuse') {
                    list.splice(index, 1);
                    list.splice(1, 0, item);
                  } else if (item.operationType === 'handler_pass') {
                    list.splice(index, 1);
                    list.splice(0, 0, item);
                  }
                  if (newList.indexOf(item.operationType) === -1) {
                    newList.push(item.operationType);
                  } else {
                    list.splice(index, 1);
                  }
                });
                this.oplist = list;
                console.log('2222', this.oplist);
                this.oplist.forEach((item, index) => {
                  if (index > 1 && this.showoplist.indexOf(item.operationType) !== -1) {
                    const obj = {
                      [item.operationType]: `<span style="color: #666666;">${item.operationName}</span>`,
                    };
                    this.menus = Object.assign({}, this.menus, obj);
                  }
                });
              } else {
                list = [];
              }
            } else {
              this.showToast({ msg: res.msg });
            }
          }, () => {
            this.showToast({ msg: '页面开小差，请稍候重试' });
          });
      },
      // 点击更多的时候的沟通/转办
      jump(ket) {
        switch (ket) {
          case 'handler_communicate':
            this.operateDeta.status = '';
            this.operateDeta.linkContant = this.list;
            this.operateDeta.show = true;
            break;
          case 'handler_commission':
            this.inforTurn.show = true;
            this.inforTurn.formInstanceId = this.formInstanceId;
            this.inforTurn.form_template_id = this.emsecfeereimh.form_template_id;
            break;
          case 'handler_refuse':
            this.operateDeta.jumpToNodeId = this.listNew[0].fdNodeId;
            this.showReject = true;
            break;
          default:
        }
      },
      // 获取取消沟通节点
      cancelOpparam() {
        this.$store.dispatch('cancelOpparam', {
          approveType: 'handler_cancelCommunicate',
          formInstanceId: this.formInstanceId, // this.$route.query.id,
          model_id: '001',
          template_form_id: this.emsecfeereimh.form_template_id,
        }).then((res) => {
          if (res.code === '0000') {
            const communicateWorkitemList = res.data.handler_cancelCommunicate.communicateWorkitemList;
            let communicateArr = '';
            communicateWorkitemList.forEach((item) => {
              communicateArr += `${item.id};`;
            });
            this.celcommunicate(communicateArr);
          } else {
            this.showToast({ msg: res.msg });
            //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
          }
        });
      },
      // 取消沟通
      celcommunicate(value) {
        this.showLoading();
        this.$store.dispatch('celcommunicate', {
          cancelHandlerIds: value,
          formInstanceId: this.formInstanceId, // this.$route.query.id,
          model_id: '001',
          template_form_id: this.emsecfeereimh.form_template_id,
        }).then((res) => {
          if (res.code === '0000') {
            this.hideLoading();
            this.showToast({ msg: '成功取消沟通' });
            setTimeout(() => {
              if (this.$store.state.extCall) {
                platform.exit();
              } else {
                this.$router.push({
                  path: '/fee/approve/',
                });
              }
            }, 500);
          } else {
            this.hideLoading();
            this.showToast({ msg: res.msg });
            //   this.$router.push({ path: '/fee/approve/approveHome/unApproved' });  // 路由跳转
          }
        });
      },
      // 点击关联申请单
      relation() {
        this.showRelated = true;
      },
     // 关闭关联申请单
      hideRelate() {
        this.showRelated = false;
      },
      // 更多
      more(obj) {
        if (Object.keys(this.menus).length > 1) {
          this.showAction = !this.showAction;
        } else {
          switch (obj.operationType) {
            case 'handler_communicate':
              this.operateDeta.show = true;
              this.operateDeta.status = '';
              this.operateDeta.linkContant = this.list;
              break;
            case 'handler_cancelCommunicate':
              this.cancelOpparam();
              break;
            case 'handler_commission':
              this.inforTurn.show = true;
              this.inforTurn.formInstanceId = this.formInstanceId;
              this.inforTurn.form_template_id = this.emsecfeereimh.form_template_id;
              break;
            case 'handler_returnCommunicate':
              this.operateDeta.show = true;
              this.operateDeta.status = 'reply';
              this.operateDeta.linkContant = this.list;
              break;
            case 'handler_pass':
              this.showPass = true;
              break;
            default:
          }
        }
      },
      change(obj) {
        switch (obj.operationType) {
          case 'handler_communicate':
            this.operateDeta.show = true;
            this.operateDeta.status = '';
            this.operateDeta.linkContant = this.list;
            break;
          case 'handler_cancelCommunicate':
            this.cancelOpparam();
            break;
          case 'handler_refuse':
            this.operateDeta.jumpToNodeId = this.listNew[0].fdNodeId;
            this.showReject = true;
            break;
          case 'handler_commission':
            this.inforTurn.show = true;
            this.inforTurn.formInstanceId = this.formInstanceId;
            this.inforTurn.form_template_id = this.emsecfeereimh.form_template_id;
            break;
          case 'handler_returnCommunicate':
            this.operateDeta.show = true;
            this.operateDeta.status = 'reply';
            this.operateDeta.linkContant = this.list;
            break;
          case 'handler_pass':
            this.showPass = true;
            break;
          case 'drafter_press':
            this.showPass = true;
            break;
          default:
        }
      },
      // 来源
      selectArea() {
        console.log(99999999);
      },
      // 关闭预算来源
      hideArea() {
        this.applyBack = false;
      },
      // 费用明细返回；
      hideBudgetsee() {
        this.travelShow = false;
      },
      goEdit(){
        if(this.$route.query.type === 'EA'){
            if (this.orderType === 'nonsupport') {
                this.showToast({ msg: '移动端暂不支持该类型单据的编辑，请移步PC端' });
            } else if (this.$route.query.id && this.orderType) {
              setTimeout(() => {
                this.$router.push({
                  path: '/fee/myApply/create/addTravelApply', query: { id: this.$route.query.id, type: this.orderType },
                });
              }, 500);
            }
          }else if(this.$route.query.type === 'EC'){
            if (this.orderType === 'nonsupport') {
                this.showToast({ msg: '移动端暂不支持该类型操作，请移步PC端' });
              } else if (this.$route.query.id && this.orderType) {
                setTimeout(() => {
                  this.$router.push({
                    path: '/fee/myReimburse/create', query: { id: this.$route.query.id, type: this.orderType },
                });
              }, 500);
            }
        }
      },
      delBill(){
        this.$store.dispatch('deleteFeeReim',{fee_reim_id:this.$route.query.id})
          .then(res =>{
            if(res.code === '0000'){
              this.showToast({msg:'操作成功'})
              this.$router.push('/fee/approve/approveHome/unApproved')
            }else if(res && res.code){
              this.showToast({msg:`请求异常(${res.code})`})
            }
          })
      },
      del(){
        let self = this;
        this.$vux.confirm.show({
            title: '作废',
            content: '确定作废该报销单吗？',
            onConfirm() {
              self.delBill();
            },
          });
      }
    },
  };
</script>

<style lang="less" rel="stylesheet/less" scoped>
  .approval{
    font-size: 16px;
    color: #000000;
    line-height: 16px;
    .top{
      background: #484759;
      padding: 15px;
      position: relative;
      color: #ffffff;
      margin-top: 45px;
      .top-list{
        display: flex;
        padding:11px 0 15px 0;
        justify-content: space-between;
        align-items: center;
        .applyer {
          width: 50%;
        }
        i{
          position: absolute;
          right:0;
          display: inline-block;
          font-style: normal;
          font-size: 12px;
          padding: 0 6px 0 8px;
          height:20px;
          background: #6F6E82;
          border-radius: 10px 0 0 10px;
          text-align: center;
          line-height:20px;
        }
      }
      .top-currency{
        display: flex;
        align-items: center;
        padding-bottom:15px;
        p{
          margin-right:5px;
          color:#3DA5FE;
          &.travel-type{
            color:#fff;
            margin: 0;
          }
        }
      }
      .reason_desc{
        display:flex;
        .reason{
          padding-bottom: 19px;
          opacity: 0.6;
        }
        .isUrgent{
          position: absolute;
          right: 0;
          display: inline-block;
          font-style: normal;
          font-size: 12px;
          padding: 0 6px 0 8px;
          height: 20px;
          background: #6F6E82;
          border-radius: 10px 0 0 10px;
          text-align: center;
          line-height: 20px;
          color: #fff;
          margin: 0;
        }
      }

    }
    .white-bg {
      background: #ffffff;
    }
    .margin-top {
      display: flex;
      justify-content: space-between;
      background: #ffffff;
      padding: 13px;
      margin-top: 10px;
      line-height: 24px;
      &.no-top {
         margin-top: 1px;
       }
      &.margin-left {
        padding: 13px 13px 13px 0;
        margin-left: 13px;
      }
      &.margin-lr {
         padding: 13px 0;
         margin-left: 13px;
         margin-right: 13px;
       }
      .type {
        width: 105px;
        color: #858585;
        .showbottom {
          width: 7px;
          margin: 3px 8px 3px 0;
          display: inline-block;
        }
        &.data-type {
          color: #000000;
        }
      }
      .detailed {
        width: 100%;
        text-align: end;
        .money {
          color: #3DA5FE;
        }
        &.blue {
          color: #3DA5FE;
         }
        .img {
          width: 9.5px;
          &.arrow_top {
             transform: rotate(-90deg);
           }
        }
      }
    }
    .bottom-list {
      width: 100%;
      text-align: center;
      line-height: 50px;
      margin-bottom: 0;
      background: #ffffff;
      box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
      position: fixed;
      bottom: 0;
      display: flex;
      justify-content: space-between;
      color: #666666;
      font-size:18px;
      .flet {
        flex: 1;
        display: flex;
        .more {
          flex: 1;
        }
        .reject {
          flex: 1;
        }
      }
      .pass{
        flex: 1;
        background:#3DA5FE;
        color:#ffffff;
      }
    }
  }
  .footerBtn{
  line-height: 1.6;
  width: 100%;
  position: fixed;
  bottom: 0;
  display: flex;
  justify-content: space-between;
  border-top: #DEDFE0 1px solid;
  .item{
    width: 50%;
    text-align: center;
    padding:11px 0;
    font-size: 18px;
  }
  .manualInput{
    color: #666666;
    background-color: #ffffff;
  }
  .scanInput{
    background-color: #3DA5FE;
    color:#ffffff !important;
  }
}
.travel-type{
  position: absolute;
  right: 0;
  display: inline-block;
  font-style: normal;
  font-size: 12px;
  padding: 0 6px 0 8px;
  height: 20px;
  background: #6F6E82;
  border-radius: 10px 0 0 10px;
  text-align: center;
  line-height: 20px;

}
</style>
