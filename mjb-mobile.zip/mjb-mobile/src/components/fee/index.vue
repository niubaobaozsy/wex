<!--
  describe：费用页面
  created by：欧倩伶
  date：2017-10-19
-->
<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>
