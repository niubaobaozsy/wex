<!--
  describe：预算来源
  created by：欧倩伶
  date：2017-11-10
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myReimburse/addBudget.less';
</style>
<template>
  <div>
    <my-header :title="top.title" :showBack="true" :showRedDot="true" @previous="goBack"></my-header>
    <div style="margin-top:60px;" v-edit :data-edit="budgetList.length">
      <div class="detail" v-for="(item, index) in budgetList" :key="index">
        <div class="headline border">
          <div class="flexItem" @click="show(index)">
            <img v-if="!item.isclose" :src="down" class="down"><img v-if="item.isclose" :src="up" class="down">
            <div>预算来源{{index+1}}</div>
          </div>
          <div class="del" @click="delItem(item, index)" v-edit :data-edit="budgetList.lenght">删除</div>
        </div>
        <div v-if="!item.isclose" class="box border-bottom">
          <div class="amoutItem border-bottom">
            <div>申请金额</div>
            <currency v-focus v-edit class="amount" currency="¥" v-model="item.apply_reim_amount" :precision="2" placeholder="请输入金额" v-edit></currency>
          </div>
          <div class="cell border-bottom" v-edit :data-edit="item.busi_org_id">
            <div class="text">预算部门</div>
            <div class="flexItem" @click="showBudgetOrg(item, index)">
              <p>{{item.busi_org_name}}</p>
              <img class="rightArrow" :class="{'show': item.fee_apply_l_id}" :src="rightArrow" alt="">
            </div>
          </div>
          <div class="cell border-bottom" v-edit :data-edit="item.fee_type_code">
            <div class="text">经济事项</div>
            <div class="flexItem" @click="economicsEvent(item, index)">
              <p>{{item.budget_node_name || item.fee_type_name}}</p>
              <img class="rightArrow" :class="{'show': item.fee_apply_l_id}" :src="rightArrow" alt="">
            </div>
          </div>
          <div class="cell" :class="{'border-bottom': reimburseType === 'TY'}" v-edit :data-edit="item.budget_node_id">
            <div class="text">预算来源</div>
            <div class="flexItem" @click="budgetSource(item, index)">
              <p>{{(autoShow && listIndex === index) ? budgetList[listIndex].budget_node_desc : item.budget_node_desc}}</p>
              <img class="rightArrow" :class="{'show': item.fee_apply_l_id}" :src="rightArrow" alt="">
            </div>
          </div>
          <div v-if="reimburseType === 'TY'" class="cell" style="height: auto;" v-edit :data-edit="item.fee_happened_date">
            <div class="text">发生日期</div>
            <div class="flexItem" @click="openCal(index)">
              <img :src="calenderImg" alt="calenderImg" style="width:16px;height:15px;margin-top:3px;">
              <p class="input_date">{{item.fee_happened_date || '请设置发生日期'}}</p>
              <img class="rightArrow" :src="rightArrow" alt="">
            </div>
          </div>
        </div>
      </div>
      <div class="addItem border" @click="addItem">
        <img :src="add" alt="">
        <p>添加预算</p>
      </div>
    </div>
    <!-- 底部 -->
    <div class="footer">
      <div class="sum">
        <span>金额总计：</span>
        <currency currency="¥" :value="totalSum" :precision="2" :read-only="true" style="width:30%;"></currency>
      </div>
      <div class="btn" @click="submit">确认</div>
    </div>
    <bugdet-org v-model="bugdet" :show.sync="showBdOrg" :defBdOrg="busiOrgs" @confirm="setDept" />
    <event :show="showEvent" ref="event" @on-select="selectEvent" @on-hide="hideEvent" :id="budgetList[listIndex]?budgetList[listIndex].busi_org_id:''"></event>
    <sources :show="showSources" ref="sources" @on-select="selectSources" @on-hide="hideSources" :dept-id="budgetList[listIndex]?budgetList[listIndex].busi_org_id:''" :sources-id="budgetList[listIndex]?budgetList[listIndex].fee_type_id:''"></sources>
    <calendar :show.sync="showCalendar" @pickDate="onPickdate" v-model="pick_date"></calendar>
  </div>
</template>

<script type="text/ecmascript-6">
import MyHeader from '../../common/header';
import bugdetOrg from '../../common/bugdetOrg';
import event from '../../common/economicsEvent';
import sources from './budgetSource';
import down from '../../../assets/images/fee/myApply/triangledown2x.png';
import up from '../../../assets/images/fee/myApply/triangleup2x.png';
import add from '../../../assets/images/fee/myApply/add.png';
import rightArrow from '../../../assets/rt-arrow.png';
import currency from '../../common/currency';
import calendar from '../../common/myCalendar';
import calImg from '../../../assets/images/fee/myApply/calendar.png';

export default {
  components: {
    MyHeader,
    bugdetOrg,
    event,
    sources,
    currency,
    calendar,
  },
  data() {
    return {
      invoice: {},
      pick_date: '',
      down,
      up,
      add,
      rightArrow,
      showBdOrg: false,
      showEvent: false,
      showSources: false,
      isSave: false,
      isNext: true,
      listIndex: 0,
      sum: 0,
      showCalendar: false,
      calenderImg: calImg, // 日历小图标的路径
      top: {
        title: '预算来源',
      },
      bugdet: {},
      busiOrgs: [],
      budgetList: [],
      autoShow: false,
    };
  },
  methods: {
    // 打开日历
    openCal(index) {
      this.showCalendar = true;
      this.listIndex = index;
      this.pick_date = this.budgetList[this.listIndex].fee_happened_date ? this.budgetList[this.listIndex].fee_happened_date.slice(0, 10) : '';
    },
    // 点击选择时间
    onPickdate() {
      this.showCalendar = false;
      this.budgetList[this.listIndex].fee_happened_date = this.pick_date;
    },
    // formatCurrency(number) {
    //   return `￥${(Math.round(number * 100) / 100).toFixed(2)}`;
    // },
    formatDate(date) {
      if (date) {
        const temp1 = date.getFullYear();
        const temp2 = (date.getMonth() + 1 < 10 ? `0${(date.getMonth() + 1)}` : date.getMonth() + 1);
        const temp3 = (date.getDate() + 1 < 10 ? `0${(date.getDate() + 1)}` : date.getDate() + 1);
        return `${temp1}-${temp2}-${temp3}`;
        //      const temp1 = time.substr(0, 4);
      }
      return null;
      //      const temp2 = time.substr(5, 2);
      //      const temp3 = time.substr(8, 2);
    },
    goBack() {
      this.$router.go(-1);
    },
    show(index) {
      this.budgetList[index].isclose = !this.budgetList[index].isclose;
    },
    addItem() {
      this.budgetList.push({
        apply_reim_amount: '',
        approve_reim_amount: '',
        isclose: false,
        busi_org_name: this.busiOrgs[0].busi_org_name,
        busi_org_id: this.busiOrgs[0].busi_org_id,
      });
    },
    delItem(item, index) {
      if (!item.fee_apply_l_id) {
        this.budgetList.splice(index, 1);
      } else {
        this.showToast({ msg: '该预算来源由申请单带出，不可删除，可以修改预算金额' });
      }
    },
    // 输入金额
    // iput(index) {
    //   this.budgetList[index].label = false;
    // },
    // noput(index) {
    //   const self = this;
    //   self.budgetList[index].label = true;
    // },
    // 选择预算部门
    showBudgetOrg(item, index) {
      if (!item.fee_apply_l_id) {
        this.showBdOrg = true;
        this.listIndex = index;
      }
      // this.$refs.dept.getBudgetDept();
    },
    setDept(param) {
      this.budgetList[this.listIndex].busi_org_name = param.busi_org_name;
      this.budgetList[this.listIndex].busi_org_id = param.busi_org_id;
    },
    hideDept() {
      this.showDept = false;
    },
    // 选择经济事项
    economicsEvent(item, index) {
      // 如果没有选中预算部门，则不能选择经济事项
      if (!item.fee_apply_l_id) {
        if (!this.budgetList[this.listIndex].busi_org_name) {
          this.showToast({ msg: '请先选择预算部门' });
          return false;
        }
        this.showEvent = true;
        this.listIndex = index;
        this.$refs.event.getFeeTypeList();
      }
      return null;
    },
    selectEvent(param) {
      this.showEvent = false;
      this.autoShow = false;
      this.budgetList[this.listIndex].fee_type_id = param.fee_type_id;
      this.budgetList[this.listIndex].fee_type_name = param.fee_type_name;
      this.getSourceList(this.listIndex);
    },
    hideEvent() {
      this.showEvent = false;
    },
    // 选择预算来源
    budgetSource(item, index) {
      if (!item.fee_apply_l_id) {
        if (!this.budgetList[this.listIndex].busi_org_name) {
          this.showToast({ msg: '请先选择预算部门' });
          return false;
        }
        if (!this.budgetList[this.listIndex].fee_type_name) {
          this.showToast({ msg: '请先选择经济事项' });
          return false;
        }
        this.showSources = true;
        this.listIndex = index;
        this.$refs.sources.getSourceList();
      }
      return null;
    },
    selectSources(param) {
      this.showSources = false;
      this.budgetList[this.listIndex].budget_name = param.budget_name;
      this.budgetList[this.listIndex].budget_node_name = param.budget_node_name;
      this.budgetList[this.listIndex].budget_node_id = param.budget_node_id;
      this.budgetList[this.listIndex].budget_node_desc = param.budget_node_desc;
      this.budgetList[this.listIndex].budget_headers_id = param.budget_headers_id;
    },
    hideSources() {
      this.showSources = false;
    },
    // 获取预算来源列表
    getSourceList(index) {
      const pamars = {
        busi_org_id: this.budgetList[this.listIndex] ? this.budgetList[this.listIndex].busi_org_id : '',
        fee_type_id: this.budgetList[this.listIndex] ? this.budgetList[this.listIndex].fee_type_id : '',
        page_number: 1,
        page_size: 2,
      };
      this.$store.dispatch('getBudgetSource', pamars)
        .then((rep) => {
          if (rep.code === '0000') {
            if (rep.data.info.length === 1) {
              this.budgetList[index].budget_name = rep.data.info[0].budget_name;
              this.budgetList[index].budget_node_name = rep.data.info[0].budget_node_name;
              this.budgetList[index].budget_node_id = rep.data.info[0].budget_node_id;
              this.budgetList[index].budget_node_desc = rep.data.info[0].budget_node_desc;
              this.budgetList[index].budget_headers_id = rep.data.info[0].budget_headers_id;
              this.autoShow = true;
            }
          } else {
            this.showToast({ msg: rep.msg });
          }
        });
    },
    // 保存草稿
    // saveDraft() {
    //   const self = this;
    //   self.budgetList.forEach((item) => {
    //     item.currency_code = self.currencyInfo.currency_code;
    //     item.currency_name = self.currencyInfo.currency_name;
    //     item.conversion_rate = 1;
    //     item.avail_amount = item.apply_reim_amount;
    //     item.approve_reim_amount = item.apply_reim_amount;
    //     item.approve_amount = item.apply_reim_amount;
    //     item.fee_happened_date = self.feeAdvanceDate;
    //     item.is_last_reim = 'N';
    //     item.is_released_budget = 'N';
    //   });
    //   self.emsecfeereimh.emsEcFeeBudgets = self.emsecfeereimh.emsEcFeeBudgets.concat(self.budgetList);
    //   const params = {
    //     emsecfeereimh: self.emsecfeereimh,
    //   };
    //   self.$store.dispatch('saveFeeApply', params).then((rep) => {
    //     self.hideLoading();
    //     if (rep.code === '0000') {
    //       self.$store.commit('CHECK_RESULT', rep.data.emsecfeereimh);
    //       self.emsecfeereimh.fee_apply_id = rep.data.emsecfeereimh.fee_apply_id;
    //       self.emsecfeereimh.fee_apply_code = rep.data.emsecfeereimh.fee_apply_code;
    //       const travelList = rep.data.emsecfeereimh.emseaapplytravels;
    //       const detailList = rep.data.emsecfeereimh.emsEcFeeBudgets;
    //       if (travelList) {
    //         for (let i = 0; i < travelList.length; i++) {
    //           self.emsecfeereimh.emseaapplytravels[i].fee_apply_id = travelList[i].fee_apply_id;
    //           self.emsecfeereimh.emseaapplytravels[i].fee_travel_id = travelList[i].fee_travel_id;
    //         }
    //       }
    //       if (detailList) {
    //         for (let k = 0; k < detailList.length; k++) {
    //           self.emsecfeereimh.emsEcFeeBudgets[k].fee_apply_id = detailList[k].fee_apply_id;
    //           self.emsecfeereimh.emsEcFeeBudgets[k].fee_apply_l_id = detailList[k].fee_apply_l_id;
    //         }
    //       }
    //       // self.$store.commit('FEE_BUDGETS_INFO', this.feeApplyList);
    //       self.showToast({ msg: '保存草稿成功', width: '12em' });
    //       this.isSave = true;
    //     } else {
    //       self.showToast({ msg: '保存草稿失败' });
    //     }
    //   }, () => {
    //     self.hideLoading();
    //     self.showToast({ msg: '页面开小差，请重试' });
    //   });
    // },
    // 确认
    submit() {
      this.isNext = true;
      const userInfo = this.$store.state.userInfo.user;
      const feeTravels = this.emsecfeereimh.feeTravels || [];
      let feeHappenedDate = 0;
      let feeHappenedDateStr = '';
      feeTravels.forEach((travel) => {
        if (feeHappenedDate < Date.parse(new Date(travel.end_date.split(' ')[0]))) {
          feeHappenedDate = Date.parse(new Date(travel.end_date.split(' ')[0]));
          feeHappenedDateStr = travel.end_date;
        }
      });
      this.budgetList.forEach((item) => {
        if (!item.apply_reim_amount) {
          this.showToast({ msg: '请填写申请金额', width: '12em' });
          this.isNext = false;
        }
        if (!item.busi_org_name) {
          this.showToast({ msg: '请填写预算部门', width: '12em' });
          this.isNext = false;
        }
        if (!item.budget_node_name) {
          this.showToast({ msg: '请填写经济事项', width: '12em' });
          this.isNext = false;
        }
        if (!item.budget_node_desc) {
          this.showToast({ msg: '请填写预算来源', width: '12em' });
          this.isNext = false;
        }
        if (!item.fee_happened_date && this.reimburseType === 'TY') {
          this.showToast({ msg: '请选择发生日期', width: '12em' });
          this.isNext = false;
        }

        // item.approve_reim_amount = item.approve_reim_amount;
        // item.fee_apply_l_id = item.fee_apply_l_id;
        // item.fee_apply_id = item.fee_apply_id;
        item.currency_code = 'CNY';
        item.currency_name = '人民币';
        item.conversion_rate = 1;
        item.apply_reim_amount = item.apply_reim_amount;
        // item.approve_reim_amount = item.apply_reim_amount;
        item.bill_type_id = item.fee_type_id;
        item.created_by = userInfo.userId;
        item.created_name = userInfo.userName;
        item.tenant_id = userInfo.tenantId;
        if (this.reimburseType === 'CL') {
          // item.fee_happened_date = this.budgetList[0].fee_happened_date;
          item.fee_happened_date = feeHappenedDateStr;
        }
        item.fee_reim_id = this.emsecfeereimh.fee_reim_id;
        // item.is_last_reim = 'N';
        // item.is_released_budget = 'N';
        item.budget_main_id = '';
        item.fee_budget_id = '';
        return null;
      });
      if (!this.isNext) {
        return false;
      }
      const emsecfeereimh = Object.assign({}, this.emsecfeereimh, { emsEcFeeBudgets: this.budgetList });
      emsecfeereimh.apply_reim_amount = this.totalSum;
      this.$store.commit('EMSEC_FEEREIMH', emsecfeereimh);
      this.showToast({ msg: '添加预算来源成功', width: '12em' });
      this.$router.go(-1);
      return null;
    },

    // 初始化
    init() {
      const self = this;
      this.budgetList = [];
      if (this.emsecfeereimh.emsEcFeeBudgets.length) {
        this.emsecfeereimh.emsEcFeeBudgets.forEach((item, index) => {
          const busiOrgs = {
            busi_org_name: item.busi_org_name,
            busi_org_id: item.busi_org_id,
          };
          this.busiOrgs.push(busiOrgs);
          const obj = {};
          // obj.approve_reim_amount = item.approve_reim_amount;
          obj.fee_apply_l_id = item.fee_apply_l_id;
          obj.fee_apply_id = item.fee_apply_id;
          obj.approve_reim_amount = item.approve_reim_amount;
          obj.apply_reim_amount = item.apply_reim_amount;
          // obj.apply_reim_amount = this.emsecfeereimh.emsEcFeeBudgets.length < 2 ? this.emsecfeereimh.totalBudgetFee : item.apply_reim_amount;
          obj.avail_amount = item.avail_amount;
          obj.busi_org_id = item.busi_org_id;
          obj.busi_org_name = item.busi_org_name;
          obj.fee_type_name = item.fee_type_name;
          obj.fee_type_id = item.fee_type_id;
          obj.budget_headers_id = item.budget_headers_id;
          obj.budget_name = item.budget_name;
          obj.budget_node_id = item.budget_node_id;
          obj.budget_node_name = item.budget_node_name;
          obj.budget_node_desc = item.budget_node_desc;
          obj.isclose = false;
          obj.fee_happened_date = item.fee_happened_date ? item.fee_happened_date.split(' ')[0] : '';
          // obj.label = true;
          // sensitive_info：引了ea单，取ea行预算的reason_desc，没有引ea单，则取'';
          obj.sensitive_info = (item.fee_apply_l_id && item.fee_apply_id) ? item.sensitive_info : this.emsecfeereimh.sensitive_info;
          self.$set(self.budgetList, index, obj);
        });
      } else if (this.detailMessage) {
        this.busiOrgs = this.detailMessage.busiOrgs;
        const obj = {};
        obj.busi_org_name = this.detailMessage.busi_org_name;
        obj.busi_org_id = this.detailMessage.busi_org_id;
        this.$set(self.budgetList, 0, obj);
      } else {
        const obj = {};
        this.busiOrgs = [
          {
            busi_org_name: '',
            busi_org_id: '',
          },
        ];
        obj.busi_org_name = '';
        obj.busi_org_id = '';
        self.$set(self.budgetList, 0, obj);
        this.showToast({ msg: '该申请人信息中无默认选预算部门' });
      }
    },
  },
  computed: {
    reimburseType() {
      return this.$store.state.myReimburse.reimburseCreate.reimburseType;
    },
    totalSum() {
      let sum = 0;
      this.budgetList.forEach((item) => {
        item.approve_reim_amount = item.apply_reim_amount;
        sum += parseFloat(item.apply_reim_amount) ? parseFloat(item.apply_reim_amount) : 0;
      });
      return sum;
    },
    // 信息
    emsecfeereimh() {
      return this.$store.state.myReimburse.emsecfeereimh;
    },
    // 获取默认个人配置信息
    detailMessage() {
      return this.$store.state.login.defCfg;
    },
  },
  mounted() {
    this.init();
  },
};
</script>
