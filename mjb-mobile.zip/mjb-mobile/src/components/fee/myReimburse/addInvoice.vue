<!--
  describe：添加发票
  created by：欧倩伶
  date：2017-11-18
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myReimburse/addInvoice.less';
</style>
<template>
  <div>
    <my-header :title="top.title" :showBack="true" :showRedDot="true" @previous="goBack"></my-header>
    <div class="has-footer has-header" v-edit :data-edit="emsecfeereimh.invoiceTaxRS.length">
      <!-- 发票列表 -->
      <div class="invoiceBox border-bottom" v-for="(item, index) in emsecfeereimh.invoiceTaxRS" :key="index" @click="editInvoice(index)">
         <div class="invoiceLeft">
          <div class="delItem mr" @click.stop.prevent="delItem(index)">
            <img :src="deleteBtn" alt="">
          </div>
          <div class="invoiceSecondCol">
            <p>发票号码：{{ item.invoice_num }}</p>
            <p>{{ item.sales_unit_name }}</p>
            <p>{{ item.invoice_date.split(' ')[0] }}</p>
          </div>
        </div>
        <div class="invoiceThirdCol">
          <p class="invoicePrice">￥{{ parseFloat(item.tax_amount).toFixed(2) }}</p>
        </div>
      </div>
      <div class="addItem border" @click="editInvoice(-1)">
        <img :src="add" alt="">
        <p>添加发票</p>
      </div>
    </div>
    <!-- 底部 -->
    <div class="footer">
      <div class="sum">税额总计：
        <p>{{taxSum}}</p>
      </div>
      <div class="btn" @click="submit">确认</div>
    </div>
    <invoiceManually :show.sync="showInvoice" v-model="invoice" @confirm="onInvoiceConfirm"></invoiceManually>
  </div>
</template>

<script>
import MyHeader from '../../common/header';
import add from '../../../assets/images/fee/myApply/add.png';
import deleteBtn from '../../../assets/images/fee/myApply/delete2x.png';
import invoiceManually from './invoiceManually';

export default {
  components: {
    MyHeader,
    invoiceManually,
  },

  data() {
    return {
      add,
      deleteBtn,
      isSave: false,
      isNext: true,
      showInvoice: false,
      listIndex: 0,
      sum: 0,
      invoiceIndex: -1,
      top: {
        title: '添加发票',
      },
      pageInfo: {
        page_number: 1,
        page_size: 10,
      },
      invoiceList: [],
      invoice: {},
    };
  },
  methods: {
    formatCurrency(number) {
      return `￥${(Math.round(number * 100) / 100).toFixed(2)}`;
    },
    goBack() {
      this.$router.go(-1);
    },
    delItem(index) {
      const _this = this;
      this.$vux.confirm.show({
        title: '删除',
        content: '确定删除该数据吗？',
        onConfirm() {
          _this.emsecfeereimh.invoiceTaxRS.splice(index, 1);
          _this.$store.commit('EMSEC_FEEREIMH', _this.emsecfeereimh);
        },
      });
    },
    editInvoice(index) {
      this.invoiceIndex = index;
      if (index === -1) {
        this.invoice = {
          invoice_amount: '',
          invoice_date: '',
          invoice_num: '',
          sales_unit_name: '',
          tax_amount: '',
          invoice_maker: '',
          bill_type_id: '',
          bill_type_name: '',
        };
      } else {
        this.invoice = this.emsecfeereimh.invoiceTaxRS[index];
      }
      this.showInvoice = true;
    },
    // 确认
    submit() {
      if (this.taxSum > 0) {
        this.showToast({ msg: '添加发票成功', width: '12em' });
      }
      this.$router.go(-1);
    },
    onInvoiceConfirm(invoice) {
      const invoiceTaxRS = Object.assign([], this.emsecfeereimh.invoiceTaxRS);
      let emsecfeereimh = {};
      if (this.invoiceIndex === -1) {
        invoice.fee_reim_id = this.emsecfeereimh.fee_rem_id;
        invoice.invoice_maker = this.emsecfeereimh.apply_name;
        invoice.conversion_rate = 1;
        invoice.currency_code = 'CNY';
        invoice.currency_name = '人民币';
        invoice.invoice_source_system = '';
        invoice.invoice_tax_r_id = '';
        invoiceTaxRS.push(invoice);
      } else {
        invoiceTaxRS[this.invoiceIndex] = Object.assign({}, invoiceTaxRS[this.invoiceIndex], invoice);
      }
      emsecfeereimh = Object.assign({}, this.emsecfeereimh, { invoiceTaxRS });
      this.$store.commit('EMSEC_FEEREIMH', emsecfeereimh);
    },
  },
  computed: {
    taxSum() {
      let sum = 0;
      this.emsecfeereimh.invoiceTaxRS.forEach((item) => {
        sum += parseFloat(item.tax_amount) || 0;
      });
      return Number(sum.toFixed(2));
    },
    taxWatch() {
      let result = '';
      this.emsecfeereimh.invoiceTaxRS.forEach((item) => {
        result += `/${item.invoice_num}/${item.invoice_date}/${item.invoice_amount}/${item.tax_amount}/${item.sales_unit_name}/${item.bill_type_id}/${item.bill_type_name}/`;
      });
      return result;
    },
    emsecfeereimh() {
      return this.$store.state.myReimburse.emsecfeereimh;
    },
    // defaultReimInfo() {
    //   return this.$store.state.myReimburse.defaultReimInfo;
    // },
    // reimInfoBySave() {
    //   return this.$store.state.myReimburse.defaultReimInfo;
    // },
  },
};
</script>
<style lang="less" scoped>
.mr{
  margin-right: 18px !important;
}
</style>

