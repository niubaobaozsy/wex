<!--
  describe：费用预估
  created by：欧倩伶
  date：2017-11-08
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myReimburse/expenseEstimate.less';
</style>
<template>
  <div>
    <my-header :title="top.title" :rightItem="'自动生成'" :showBack="true" :showRedDot="true" @previous="goBack" @on-click="getStandard"></my-header>
    <div class="main-wrap has-header has-footer">
      <!-- 交通 -->
      <div class="detail" v-for="(item,index) in expenseList.feeTravels" :key="index">
        <div class="headline border" @click="show('transport', index)">
          <div class="flexItem">
            <img v-if="!transportIsclose[index]" :src="down" class="down"><img v-if="transportIsclose[index]" :src="up" class="down">
            <div>交通
              <span v-if="item.from_area_name">({{item.from_area_name}} <img :src="to" class="to"> {{item.to_area_name}})</span>
            </div>
          </div>
          <currency currency="合计：¥" :value="travelFee[index]" :precision="2" :read-only="true" style="width:40%;"></currency>
        </div>
        <div v-if="!transportIsclose[index]" v-edit :data-edit="item.transportDetails ? item.transportDetails.length : 0">
          <div class="feeItem border-bottom" v-for="(feeItem,feeIndex) in item.transportDetails" :key="feeIndex">
            <div v-if="item.transportDetails.length" class="delItem">
              <img :src="deleteBtn" alt="" @click="delFeeItem('transport', index, feeIndex)">
            </div>
            <div class="flex1">
              <!-- 公司结算，不可修改 -->
              <div v-if="feeItem.attribute1 !== 'COMPANY'" class="vehicle border-bottom" @click="showSheet(index,feeIndex)" v-edit :data-edit="feeItem.transport">
                <div class="text">工具</div>
                <div class="flexItem">
                  <div class="trsp" v-if="feeItem.transport==='AIRPLANE'"><img class="icon" :src="plane">飞机</div>
                  <div class="trsp" v-if="feeItem.transport==='TRAIN'"><img class="icon" :src="train">火车</div>
                  <div class="trsp" v-if="feeItem.transport==='BUS'"><img class="icon" :src="car">汽车</div>
                  <div class="trsp" v-if="feeItem.transport==='SHIP'"><img class="icon" :src="ship">轮船</div>
                  <img class="rightArrow" :src="rightArrow" alt="">~
                </div>
              </div>
              <div v-else class="vehicle border-bottom">
                <div class="text">工具</div>
                <div class="flexItem">
                  <div class="trsp" v-if="feeItem.transport==='AIRPLANE'"><img class="icon" :src="plane">飞机</div>
                  <div class="trsp" v-if="feeItem.transport==='TRAIN'"><img class="icon" :src="train">火车</div>
                  <div class="trsp" v-if="feeItem.transport==='BUS'"><img class="icon" :src="car">汽车</div>
                  <div class="trsp" v-if="feeItem.transport==='SHIP'"><img class="icon" :src="ship">轮船</div>
                  <!-- <img class="rightArrow" :src="rightArrow" alt=""> -->
                </div>
              </div>
              <div class="amoutItem">
                <div>金额</div>
                <currency v-if="feeItem.attribute1 !== 'COMPANY'" class="amount" currency="¥" v-model="feeItem.transport_fee" :precision="2" placeholder="请输入金额" v-edit></currency>
                <label v-else class="amount">￥0.00</label>
                <!-- <input-box :blueFont="feeItem.label" :placeholder="'请输入金额'" :inputValue="feeItem.label ? formatCurrency(feeItem.transport_fee) : feeItem.transport_fee" :isAmount="true" @get-value="getAmount" @select="clickInput('transport', index, feeIndex)" @on-blur="onBlur" :autoFocus="false"></input-box> -->
              </div>
            </div>
          </div>
          <div class="addItem border-bottom" @click="addFeeItem('transport', index)">
            <img :src="add" alt="">
            <p>交通工具</p>
          </div>
        </div>
      </div>

      <!-- 住宿 -->
      <div class="detail">
        <div class="headline border" @click="show('rent')">
          <div class="flexItem">
            <img v-if="!rentIsclose" :src="down" class="down"><img v-if="rentIsclose" :src="up" class="down">
            <div>住宿</div>
          </div>
          <currency currency="合计：¥" :value="hotelFee" :precision="2" :read-only="true"></currency>
        </div>
        <div v-if="!rentIsclose" v-edit :data-edit="expenseList.rentDetails ? expenseList.rentDetails.length : 0">
          <div class="feeItem border-bottom" v-for="(item,index) in expenseList.rentDetails" :key="index">
            <div class="delItem">
              <img :src="deleteBtn" alt="" @click="delFeeItem('rent', index)">
            </div>
            <div class=" flex1">
              <div class="vehicle border-bottom">
                <div class="text">住宿人</div>
                <div class="flexItem">
                  <p>{{item.travel_persons_name}}</p>
                </div>
              </div>
              <div class="vehicle border-bottom" @click="openArea('rent', index)" v-edit :data-edit="item.to_area_name">
                <div class="text">住宿城市</div>
                <div class="flexItem">
                  <p>{{item.to_area_name}}</p>
                  <img class="rightArrow" :src="rightArrow" alt="">
                </div>
              </div>
              <div class="vehicle border-bottom" @click="selectCalendar('rent',index)" v-edit :data-edit="watchDateStr(item.start_date, item.end_date)">
                <div class="text">住宿时间</div>
                <div class="flexItem">
                  <img class="calendarIcon" :src="calendarIcon" alt="">
                  <p v-if="item.start_date">{{formatDate(item.start_date)}}-{{formatDate(item.end_date)}}</p>
                  <img class="rightArrow" :src="rightArrow" alt="">
                </div>
              </div>
              <div class="amoutItem">
                <div>住宿费用</div>
                <currency class="amount" currency="¥" v-edit.overStd :data-edit="item.rent_fee" v-model="item.rent_fee" :precision="2" placeholder="请输入金额"></currency>
                <!-- <input-box :blueFont="item.label" :placeholder="'请输入金额'" :inputValue="item.label ? formatCurrency(item.rent_fee) : item.rent_fee" :isAmount="true" @get-value="getAmount" @select="clickInput('rent', index)" @on-blur="onBlur" :autoFocus="false"></input-box> -->
              </div>
            </div>
          </div>
          <div class="addItem border-bottom" @click="addFeeItem('rent')">
            <img :src="add" alt="">
            <p>住宿费用</p>
          </div>
        </div>
      </div>
      <!-- 补助 -->
      <div class="detail">
        <div class="headline border" @click="show('assistant')">
          <div class="flexItem">
            <img v-if="!assIsclose" :src="down" class="down"><img v-if="assIsclose" :src="up" class="down">
            <div>补助</div>
          </div>
          <currency currency="合计：¥" :value="subsidyFee" :precision="2" :read-only="true"></currency>
        </div>
        <div v-if="!assIsclose" v-edit :data-edit="expenseList.assistantDetails ? expenseList.assistantDetails.length : 0">
          <div class="feeItem border-bottom" v-for="(item,index) in expenseList.assistantDetails" :key="index">
            <div class="delItem">
              <img :src="deleteBtn" alt="" @click="delFeeItem('assistant', index)">
            </div>
            <div class=" flex1">
              <div class="vehicle border-bottom">
                <div class="text">补助人</div>
                <div class="flexItem">
                  <p>{{item.assistant_persons_name}}</p>
                </div>
              </div>
              <div v-if="hasAssistantFeeType" class="vehicle border-bottom" @click="showSetStandardType(index)" v-edit :data-edit="item.standard_type">
                <div class="text">补助类型</div>
                <div class="flexItem">
                  <p>{{item.standardType.label}}</p>
                  <img class="rightArrow" :src="rightArrow" alt="">
                </div>
              </div>
              <div class="vehicle border-bottom" @click="openArea('assistant',index)" v-edit :data-edit="item.to_area_name">
                <div class="text">城市</div>
                <div class="flexItem">
                  <p>{{item.to_area_name}}</p>
                  <img class="rightArrow" :src="rightArrow" alt="">
                </div>
              </div>
              <div class="vehicle border-bottom" @click="selectCalendar('assistant',index)" v-edit :data-edit="watchDateStr(item.start_date, item.end_date)">
                <div class="text">时间</div>
                <div class="flexItem">
                  <img class="calendarIcon" :src="calendarIcon" alt="">
                  <p v-if="item.start_date">{{formatDate(item.start_date)}}-{{formatDate(item.end_date)}}</p>
                  <img class="rightArrow" :src="rightArrow" alt="">
                </div>
              </div>
              <div class="amoutItem">
                <div>补助费用</div>
                <currency class="amount" currency="¥" v-edit.overStd :data-edit="item.assistant_fee" v-model="item.assistant_fee" :precision="2" placeholder="请输入金额" v-edit></currency>
                <!-- <input-box :blueFont="item.label" :placeholder="'请输入金额'" :inputValue="item.label ? formatCurrency(item.assistant_fee) : item.assistant_fee" :isAmount="true" @get-value="getAmount" @select="clickInput('assistant', index)" @on-blur="onBlur" :autoFocus="false"></input-box> -->
              </div>
            </div>
          </div>
          <div class="addItem border-bottom" @click="addFeeItem('assistant')">
            <img :src="add" alt="">
            <p>补助费用</p>
          </div>
        </div>
      </div>
      <!-- 其他 -->
      <div class="detail">
        <div class="headline border" @click="show('other')">
          <div class="flexItem">
            <img v-if="!othIsclose" :src="down" class="down"><img v-if="othIsclose" :src="up" class="down">
            <div>其他</div>
          </div>
          <currency currency="合计：¥" :value="otherFee" :precision="2" :read-only="true"></currency>
        </div>
        <div v-if="!othIsclose" v-edit :data-edit="expenseList.ecOtherFeeDetails ? expenseList.ecOtherFeeDetails.length : 0">
          <div class="feeItem border-bottom" v-for="(item,index) in expenseList.ecOtherFeeDetails" :key="index">
            <div class="delItem">
              <img :src="deleteBtn" alt="" @click="delFeeItem('other', index)">
            </div>
            <div class="flex1">
              <div class="amoutItem border-bottom">
                <div>费用金额</div>
                <currency class="amount" currency="¥" v-model="item.other_fee" :precision="2" placeholder="请输入金额" v-edit></currency>
                <!-- <input-box :blueFont="item.label" :placeholder="'请输入金额'" :inputValue="item.label ? formatCurrency(item.other_fee) : item.other_fee" :isAmount="true" @get-value="getAmount" @select="clickInput('other', index)" @on-blur="onBlur" :autoFocus="false"></input-box> -->
              </div>
              <div class="amoutReason">
                <div>消费事由</div>
                <div class="ERTextarea" v-edit :data-edit="item.reason_desc ? item.reason_desc.length : 0">
                  <x-textarea :max="40" v-model="item.reason_desc"></x-textarea>
                </div>
              </div>
            </div>
          </div>
          <div class="addItem border-bottom" @click="addFeeItem('other')">
            <img :src="add" alt="">
            <p>其他费用</p>
          </div>
        </div>
      </div>
      <!-- 底部 -->
      <div class="footer">
        <div class="sum">
          <span>金额总计：</span>
          <currency currency="¥" :value="totalSum" :precision="2" :read-only="true"></currency>
        </div>
        <div class="btn" @click="submit">确认</div>
      </div>
    </div>
    <Actionsheet v-model="showAction" :menus="menus" @on-click-menu="selectTool" :show-cancel="true"></Actionsheet>
    <Actionsheet v-model="showStandardType" :menus="standardTypeMenus" @on-click-menu="selectStandardType" :show-cancel="true"></Actionsheet>
    <calendar v-model="date" :show.sync="showCalendar" @pickDate="pickDate" />
    <select-city v-if="showArea" :headTitle="headTitle" @select-city="selecCity" tempType="travel" @close-panel="closePanel4cities()"></select-city>
  </div>
</template>

<script >
import { XTextarea, Actionsheet } from 'vux';
import MyHeader from '../../common/header';
import calendar from '../../common/myCalendar';
import selectCity from '../../common/selectCity';
import to from '../../../assets/images/fee/myApply/to.png';
import add from '../../../assets/images/fee/myApply/add2x.png';
import deleteBtn from '../../../assets/images/fee/myApply/delete2x.png';
import rightArrow from '../../../assets/images/fee/myApply/right2x.png';
import plane from '../../../assets/images/fee/myApply/aircraft2x.png';
import train from '../../../assets/images/fee/myApply/train2x.png';
import car from '../../../assets/images/fee/myApply/car2x.png';
import ship from '../../../assets/images/fee/myApply/ship2x.png';
import down from '../../../assets/images/fee/myApply/triangledown2x.png';
import up from '../../../assets/images/fee/myApply/triangleup2x.png';
import calendarIcon from '../../../assets/images/fee/myApply/calendar.png';
import currency from '../../common/currency';

export default {
  components: {
    MyHeader,
    Actionsheet,
    XTextarea,
    calendar,
    selectCity,
    currency,
  },
  data() {
    return {
      to,
      down,
      up,
      rightArrow,
      plane,
      train,
      car,
      ship,
      calendarIcon,
      add,
      deleteBtn,
      showAction: false,
      showStandardType: false,
      showCalendar: false,
      isSave: false,
      showArea: false,
      rentIsclose: true,
      assIsclose: true,
      othIsclose: true,
      travelIndex: '',
      costIndex: '',
      dateIndex: '',
      dateType: '',
      areaType: '',
      areaIndex: '',
      headTitle: '选择城市',
      date: [],
      top: {
        title: '费用预估',
      },
      menus: {
        menu1: `<img class="icon" src="${plane}" alt=""><p>飞机</p>`,
        menu2: `<img class="icon" src="${train}" alt=""><p>火车</p>`,
        menu3: `<img class="icon" src="${car}" alt=""><p>汽车</p>`,
        menu4: `<img class="icon" src="${ship}" alt=""><p>轮船</p>`,
      },
      standardTypeMenus: [{
          label: '市内交通费',
          value: 'SNJTF',
        }, {
          label: '餐费',
          value: 'CF',
        }
      ],
      standardTypeEditIndex: 0,
      expenseList: {},
      transport: {
        approve_conversion_rate: 1,
        approve_transport_fee: 0,
        conversion_rate: 1,
        currency_code: 'CNY',
        id: '',
        transport: 'AIRPLANE',
        transport_fee: 0,
        travel_id: '',
        currency_name: '人民币元',
        label: false,    // 非接口所有
      },
      transportIsclose: [],
      money: [],
      indexStr: '',
      feeIndexStr: '',
      type: '',
    };
  },
  mounted() {
    this.init();
    if (!this.emsecfeereimh.assistantDetails.length && !this.emsecfeereimh.rentDetails.length) {
      // this.getStandard(); // 不自动「自动生成」住宿/补助标准
      this.$store.commit('REIM_FEE_STD_EXP', true);
    } else {
      const _this = this;
      if (!this.feeStdExp) {
        this.$store.commit('REIM_FEE_STD_EXP', true);
        this.$vux.confirm.show({
          title: '提示',
          content: '检测到行程发生变化，是否重新生成住宿及补助费用？',
          onConfirm() {
            _this.getStandard();
          },
        });
      }
    }
  },
  methods: {
    formatDate(time) {
      if (!time) return null;
      if (time.indexOf('/') !== -1) {
        const temp1 = time.substr(0, 4);
        const temp2 = time.substr(5, 2);
        const temp3 = time.substr(8, 2);
        return `${temp1}-${temp2}-${temp3}`;
      }
      if (time.indexOf('月') !== -1) return time;
      const temp4 = time.substr(5, 2);
      const temp5 = time.substr(8, 2);
      return `${temp4}月${temp5}日`;
    },
    goBack() {
      console.log(this.emsecfeereimh.ecOtherFeeDetails);
      this.$router.go(-1);
    },
    // 获取标准
    getStandard() {
      const commObj = {
        index: 0,
        to_area: '',
        date: null,
        fee_apply_id: '',
        tenant_id: '',
        currency_code: 'CNY',
        currency_name: '人民币',
        conversion_rate: '1',
        approve_conversion_rate: '1',
        reason_desc: '',
        seq_no: '',
        created_by: '',
        created_name: '',
        creation_date: '',
        last_updated_by: '',
        last_updated_name: '',
        last_update_date: '',
        travel_days: 0,
      };
      const param = [];
      this.emsecfeereimh.feeTravels.forEach((item) => {
        let obj = {
          from_area_id: item.from_area_id,
          from_area_name: item.from_area_name,
          from_area_code: item.from_area_id,
          to_area_id: item.to_area_id,
          to_area_name: item.to_area_name,
          to_area_code: item.to_area_id,
          travel_persons: item.travel_persons,
          travel_persons_name: item.travel_persons_name,
          start_date: item.start_date.split(' ')[0],
          end_date: item.end_date.split(' ')[0],
        };
        param.push(obj);
      });
      this.$store.commit('REIM_FEE_STD_EXP', true);
      this.showLoading();
      this.$store.dispatch('getStand', param).then(
        (rep) => {
          this.hideLoading();
          if (rep.code === '0000') {
            const rentList = [];
            const assistantList = [];
            if (rep.data && rep.data.zsList) {
              rep.data.zsList.forEach((item) => {
                let rentObj = {
                  rent_fee: item.rent_fee,
                  to_area_name: item.to_area_name || '',
                  to_area_id: item.to_area_id || '',
                  attribute2: item.to_area_code || '',
                  end_date: item.end_date || '',
                  start_date: item.start_date || '',
                  travel_persons_name: item.travel_persons_name,
                  travel_persons: item.travel_persons,
                  to_area_code: item.to_area_code,
                  approve_rent_fee: '',
                  is_peer: '',
                  lodging_days: '',
                  rent_id: '',
                };
                rentObj = Object.assign({}, rentObj, commObj);
                rentList.push(rentObj);
              });
            }
            if (rep.data && rep.data.bzList) {
              const standardTypeDict = [{
                  label: '市内交通费',
                  value: 'SNJTF',
                }, {
                  label: '餐费',
                  value: 'CF',
                }
              ];
              rep.data.bzList.forEach((item) => {
                if (item.standard_type) {
                  item.standardType = standardTypeDict.filter((i) => i.value === item.standard_type)[0];
                }
                let assistantObj = {
                  assistant_fee: item.assistant_fee,
                  to_area_name: item.to_area_name || '',
                  to_area_id: item.to_area_id || '',
                  attribute2: item.to_area_code || '',
                  end_date: item.end_date || '',
                  start_date: item.start_date || '',
                  assistant_persons_name: item.travel_persons_name,
                  assistant_persons: item.travel_persons,
                  to_area_code: item.to_area_code,
                  approve_assistant_fee: '',
                  assistant_day: '',
                  id: '',
                };
                if (this.hasAssistantFeeType) {
                    assistantObj.standard_type = item.standard_type;
                    assistantObj.standardType = item.standardType;
                  }
                assistantObj = Object.assign({}, assistantObj, commObj);
                assistantList.push(assistantObj);
              });
            }
            const expenseList = {
              rentDetails: rentList,
              assistantDetails: assistantList,
            };
            this.expenseList = Object.assign({}, this.expenseList, expenseList);
            this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, this.expenseList));
            console.log('this.expenseList', this.expenseList);
          } else if (rep && rep.code) {
            this.showToast({ msg: rep.msg || '获取住宿费和补助费失败' });
          }
        },
      );
    },
    // 初始化
    init() {
      if (this.emsecfeereimh.feeTravels.length) {
        this.expenseList = JSON.parse(JSON.stringify(this.emsecfeereimh));
        this.expenseList.feeTravels.forEach((item, index) => {
          this.transportIsclose[index] = true;
          if (!item.transportDetails) {
            // this.$set(item, 'transportDetails', [Object.assign({}, this.transport)]);
            this.$set(item, 'transportDetails', []);
          }
          item.transportDetails.forEach((data) => {
            if(data.attribute1 === 'COMPANY') {
              data.transport_fee = 0;
            }
          })
        });
        this.emsecfeereimh.ecOtherFeeDetails.forEach((item, index) => {
          item.happend_date = this.expenseList.feeTravels[0].start_date || null;
          if (!item.approve_other_fee) {
            this.emsecfeereimh.ecOtherFeeDetails.splice(index, 1);
          }
        });
      }
    },
    // 保存草稿
    // saveDraft() {
    //   this.showLoading();
    //   // 将expenseList对象存到this.emseaapplyh.emseaapplyhexts数组里
    //   this.emsecfeereimh.emsecfeereimhexts = [this.expenseList];
    //   // this.emsecfeereimh.pay_amount = this.totalSum
    //   this.$store.commit('CONSUME_AMOUNT', this.totalSum);
    //   this.$store.dispatch('saveReimInfo', this.emsecfeereimh).then((rep) => {
    //     this.hideLoading();
    //     if (rep.code === '0000') {
    //       this.$store.commit('CHECK_RESULT', rep.data.emsecfeereimh);
    //       this.emsecfeereimh.fee_reim_id = rep.data.emsecfeereimh.fee_reim_id;
    //       this.emsecfeereimh.fee_reim_code = rep.data.emsecfeereimh.fee_reim_code;
    //       const travelList = rep.data.emsecfeereimh.feeTravels; // 行程明细
    //       const detailList = rep.data.emsecfeereimh.emsEcFeeBudgets; // 预算明细
    //       if (travelList) {
    //         for (let i = 0; i < travelList.length; i++) {
    //           this.emsecfeereimh.feeTravels[i].fee_reim_id = travelList[i].fee_reim_id;
    //           this.emsecfeereimh.feeTravels[i].fee_travel_id = travelList[i].fee_travel_id;
    //         }
    //       }
    //       if (detailList) {
    //         for (let k = 0; k < detailList.length; k++) {
    //           this.emsecfeereimh.emsEcFeeBudgets[k].fee_reim_id = detailList[k].fee_reim_id;
    //           this.emsecfeereimh.emsEcFeeBudgets[k].fee_budget_id = detailList[k].fee_budget_id;
    //         }
    //       }
    //       this.$store.commit('EMSEC_FEEREIMH', this.emsecfeereimh);
    //       this.showToast({ msg: '保存草稿成功', width: '12em' });
    //       this.isSave = true;
    //     } else {
    //       this.showToast({ msg: '保存草稿失败' });
    //     }
    //   });
    //   return null;
    // },
    // 确认
    submit() {
      let close = true;
      //      if (!this.expenseList.feeTravels.length) {
      //        this.showToast({ msg: '请填写交通费用报销信息！', width: '12em' });
      //        return false;
      //      } else if (!this.expenseList.rentDetails.length) {
      //        this.showToast({ msg: '请填写住宿费用报销信息！', width: '12em' });
      //        return false;
      //      } else if (!this.expenseList.assistantDetails.length) {
      //        this.showToast({ msg: '请填写补助费用报销信息！', width: '12em' });
      //        return false;
      //      } else if (!this.expenseList.ecOtherFeeDetails.length) {
      //        this.showToast({ msg: '请填写其他费用报销信息！', width: '12em' });
      //        return false;
      //      }
      // 交通消费校验
      this.expenseList.feeTravels.forEach((item, index) => {
        item.approve_transport_fee = item.transport_fee;
        item.assistant_persons = item.assistant_persons ? item.assistant_persons : this.expenseList.feeTravels[index].travel_persons;
        item.assistant_persons_name = item.assistant_persons_name ? item.assistant_persons_name : this.expenseList.feeTravels[index].travel_persons_name;
        //      住宿消费效验无法通过，后端让暂时放在扩展属性2
        item.transportDetails.forEach((feeItem) => {
          if(feeItem.attribute1 === 'COMPANY') {
             feeItem.transport_fee = 0;
             feeItem.approve_transport_fee = 0;
          }
          feeItem.approve_transport_fee = feeItem.transport_fee;
          if (!feeItem.transport) {
            this.showToast({ msg: '交通：交通工具不能为空!', width: '12em' });
            close = false;
          } else if (feeItem.attribute1 !== 'COMPANY' && !feeItem.transport_fee) {
            this.showToast({ msg: '交通：交通费用不能为空!', width: '12em' });
            close = false;
          }
        });
      });
      // 住宿消费校验
      this.expenseList.rentDetails.forEach((item) => {
        item.approve_rent_fee = item.rent_fee;
        // item.travel_persons = item.assistant_persons ? item.assistant_persons : this.expenseList.feeTravels[0].travel_persons;
        // item.travel_persons_name = item.assistant_persons_name ? item.assistant_persons_name : this.expenseList.feeTravels[0].travel_persons_name;
        //      住宿消费效验无法通过，后端让暂时放在扩展属性2
        item.attribute2 = item.to_area_id;
        if (!item.to_area_name) {
          this.showToast({ msg: '住宿：住宿城市不能为空!', width: '12em' });
          close = false;
        } else if (!item.start_date && !item.end_date) {
          this.showToast({ msg: '住宿：住宿日期不能为空!', width: '12em' });
          close = false;
        } else if (!item.rent_fee) {
          this.showToast({ msg: '住宿：住宿费用不能为空!', width: '12em' });
          close = false;
        }
      });
      // 补助费校验
      this.expenseList.assistantDetails.forEach((item) => {
        item.approve_assistant_fee = item.assistant_fee;
        item.attribute2 = item.to_area_id;
        // item.assistant_persons = item.assistant_persons ? item.assistant_persons : this.expenseList.feeTravels[0].travel_persons;
        // item.assistant_persons_name = item.assistant_persons_name ? item.assistant_persons_name : this.expenseList.feeTravels[0].travel_persons_name;
        //      住宿消费效验无法通过，后端让暂时放在扩展属性2
        if (!item.to_area_name) {
          this.showToast({ msg: '补助：住宿城市不能为空!', width: '12em' });
          close = false;
        } else if (!item.start_date && !item.end_date) {
          this.showToast({ msg: '补助：住宿日期不能为空!', width: '12em' });
          close = false;
        } else if (!item.assistant_fee) {
          this.showToast({ msg: '补助：补助费用不能为空!', width: '12em' });
          close = false;
        }
      });
      // 其他消费校验
      this.expenseList.ecOtherFeeDetails.forEach((item) => {
        item.approve_other_fee = item.other_fee;
        item.happend_date = this.getCurTimeStr();
        item.last_updated_by = this.getCurTimeStr();
        item.assistant_persons = this.expenseList.feeTravels[0].travel_persons;
        item.assistant_persons_name = this.expenseList.feeTravels[0].travel_persons_name;
        //      住宿消费效验无法通过，后端让暂时放在扩展属性2
        if (!item.reason_desc) {
          this.showToast({ msg: '其他：消费事由不能为空!', width: '12em' });
          close = false;
        } else if (!item.other_fee) {
          this.showToast({ msg: '其他：消费金额不能为空!', width: '12em' });
          close = false;
        }
      });
      if (close) {
        this.expenseList.approve_reim_amount = this.totalSum;
        this.expenseList.apply_reim_amount = this.totalSum;
        this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, this.expenseList));
        this.$store.commit('CONSUME_AMOUNT', this.totalSum);
        this.$router.go(-1);
      }
      return close;
    },
    // 日期选择
    selectCalendar(type, index) {
      this.date = [];
      if (type === 'rent') {
        this.date.push(this.expenseList.rentDetails[index].start_date.split(' ')[0]);
        this.date.push(this.expenseList.rentDetails[index].end_date.split(' ')[0]);
      } else if (type === 'assistant') {
        this.date.push(this.expenseList.assistantDetails[index].start_date.split(' ')[0]);
        this.date.push(this.expenseList.assistantDetails[index].end_date.split(' ')[0]);
      }
      this.showCalendar = true;
      this.dateIndex = index;
      this.dateType = type;
    },
    pickDate() {
      if (this.dateType === 'rent') {
        this.expenseList.rentDetails[this.dateIndex].start_date = this.date[0];
        this.expenseList.rentDetails[this.dateIndex].end_date = this.date[1];
      } else if (this.dateType === 'assistant') {
        this.expenseList.assistantDetails[this.dateIndex].start_date = this.date[0];
        this.expenseList.assistantDetails[this.dateIndex].end_date = this.date[1];
      }
      this.date = [];
    },
    // 选择城市
    openArea(type, index) {
      this.showArea = true;
      this.areaType = type;
      this.areaIndex = index;
    },
    showSetStandardType(index) {
      this.showStandardType = true;
      this.standardTypeEditIndex = index;
    },
    selectStandardType(value) {
      if (value === 'cancel') return false;
      let editItem = this.expenseList.assistantDetails[this.standardTypeEditIndex];
      editItem.standard_type = value;
      editItem.standardType = this.standardTypeMenus.filter((item) => item.value === value)[0];
    },
    closePanel4cities() {
      this.showArea = false;
    },
    selecCity(item) {
      if (this.areaType === 'rent') {
        this.expenseList.rentDetails[this.areaIndex].to_area_name = item.area_name;
        this.expenseList.rentDetails[this.areaIndex].to_area_id = item.area_code;
      } else if (this.areaType === 'assistant') {
        this.expenseList.assistantDetails[this.areaIndex].to_area_name = item.area_name;
        this.expenseList.assistantDetails[this.areaIndex].to_area_id = item.area_code;
      }
    },
    // 选择交通工具
    showSheet(index, feeIndex) {
      this.showAction = true;
      this.travelIndex = index;
      this.costIndex = feeIndex;
    },
    selectTool(key) {
      const self = this;
      if (key === 'menu1') {
        self.expenseList.feeTravels[self.travelIndex].transportDetails[self.costIndex].transport = 'AIRPLANE';
      } else if (key === 'menu2') {
        self.expenseList.feeTravels[self.travelIndex].transportDetails[self.costIndex].transport = 'TRAIN';
      } else if (key === 'menu3') {
        self.expenseList.feeTravels[self.travelIndex].transportDetails[self.costIndex].transport = 'BUS';
      } else if (key === 'menu4') {
        self.expenseList.feeTravels[self.travelIndex].transportDetails[self.costIndex].transport = 'SHIP';
      }
    },
    // 展开详细信息、删除、添加
    show(feeTypeName, index) {
      if (feeTypeName === 'transport') {
        const arr = [];
        arr[index] = !this.transportIsclose[index];
        this.transportIsclose = Object.assign([], this.transportIsclose, arr);
      } else if (feeTypeName === 'rent') {
        this.rentIsclose = !this.rentIsclose;
      } else if (feeTypeName === 'assistant') {
        this.assIsclose = !this.assIsclose;
      } else if (feeTypeName === 'other') {
        this.othIsclose = !this.othIsclose;
      }
    },
    delFeeItem(feeTypeName, index, feeIndex) {
      if (feeTypeName === 'transport') {
        const arr = this.expenseList.feeTravels;
        arr[index].transportDetails.splice(feeIndex, 1);
        this.expenseList.feeTravels = Object.assign([], this.expenseList.feeTravels, arr);
        // this.expenseList.feeTravels[index].transportDetails.splice(feeIndex, 1);
      } else if (feeTypeName === 'rent') {
        this.expenseList.rentDetails.splice(index, 1);
      } else if (feeTypeName === 'assistant') {
        this.expenseList.assistantDetails.splice(index, 1);
      } else if (feeTypeName === 'other') {
        this.expenseList.ecOtherFeeDetails.splice(index, 1);
      }
    },
    addFeeItem(feeTypeName, index) {
      if (feeTypeName === 'transport') {
        const arr = this.expenseList.feeTravels;
        const obj = {
          approve_conversion_rate: 1,
          approve_transport_fee: 0,
          conversion_rate: 1,
          currency_code: 'CNY',
          id: '',
          transport: 'AIRPLANE',
          transport_fee: 0,
          travel_id: '',
          currency_name: '人民币元',
          label: false,    // 非接口所有
        };
        arr[index].transportDetails.push(obj);
        this.expenseList.feeTravels = Object.assign([], this.expenseList.feeTravels, arr);
      } else if (feeTypeName === 'rent') {
        const rentDetails = {
          approve_conversion_rate: 1,
          approve_rent_fee: 0,
          conversion_rate: 1,
          currency_code: 'CNY',
          end_date: '',
          fee_reim_id: '',
          is_peer: '',
          lodging_days: 0,
          rent_fee: 0,
          rent_id: '',
          seq_no: 1,
          start_date: '',
          to_area_id: '',
          to_area_name: '',
          travel_persons: this.expenseList.feeTravels[0].travel_persons,
          travel_persons_name: this.expenseList.feeTravels[0].travel_persons_name,
          to_area: '',
          currency_name: '人民币元',
          label: false,    // 非接口所有
        };
        this.expenseList.rentDetails.push(rentDetails);
      } else if (feeTypeName === 'assistant') {
        const assistantDetails = {
          approve_assistant_fee: 0,
          approve_conversion_rate: 1,
          assistant_day: 0,
          assistant_fee: 0,
          assistant_persons: this.expenseList.feeTravels[0].travel_persons,
          assistant_persons_name: this.expenseList.feeTravels[0].travel_persons_name,
          conversion_rate: 1,
          currency_code: 'CNY',
          end_date: '',
          fee_reim_id: '',
          id: '',
          sensitive_info: '',
          seq_no: 1,
          start_date: '',
          to_area_id: '',
          to_area_name: '',
          to_area: '',
          currency_name: '人民币元',
          label: false,    // 非接口所有
        };
        if (this.hasAssistantFeeType) {
          assistantDetails.standard_type = this.standardTypeMenus[0].value;
          assistantDetails.standardType = this.standardTypeMenus[0];
        }
        this.expenseList.assistantDetails.push(assistantDetails);
      } else if (feeTypeName === 'other') {
        const ecOtherFeeDetails = {
          approve_conversion_rate: 1,
          approve_other_fee: 0,
          conversion_rate: 1,
          currency_code: 'CNY',
          fee_reim_id: '',
          other_fee: 0,
          other_id: '',
          reason_desc: '',
          seq_no: 1,
          currency_name: '人民币元',
          label: false,    // 非接口所有
          happend_date: this.getCurTimeStr(),
        };
        this.expenseList.ecOtherFeeDetails.push(ecOtherFeeDetails);
      }
    },
    getCurTimeStr() {
      const time = new Date();
      return `${time.getFullYear()}-${time.getMonth() < 9 ? '0' : ''}${time.getMonth() + 1}-${time.getDate() <= 9 ? '0' : ''}${time.getDate()}`;
    },
    arraySum(arr) {
      let sum = 0;
      arr.forEach((item) => {
        sum += parseFloat(item);
      });
      return sum;
    },
    watchDateStr(date1, date2) {
      return `${date1}-${date2}`;
    },
  },
  computed: {
    travelFee() {
      const travelSum = [];
      if (this.expenseList.feeTravels) {
        this.expenseList.feeTravels.forEach((item) => {
          if (item.transportDetails) {
            let travelItem = 0;
            item.transportDetails.forEach((feeItem) => {
              travelItem += parseFloat(feeItem.transport_fee) ? parseFloat(feeItem.transport_fee) : 0;
            });
            travelSum.push(travelItem);
          }
        });
      }
      return travelSum;
    },
    hotelFee() {
      let hotelSum = 0;
      if (this.expenseList.rentDetails) {
        this.expenseList.rentDetails.forEach((item) => {
          hotelSum += parseFloat(item.rent_fee) ? parseFloat(item.rent_fee) : 0;
        });
      }
      return hotelSum;
    },
    subsidyFee() {
      let subsidySum = 0;
      if (this.expenseList.assistantDetails) {
        this.expenseList.assistantDetails.forEach((item) => {
          subsidySum += parseFloat(item.assistant_fee) ? parseFloat(item.assistant_fee) : 0;
        });
      }
      return subsidySum;
    },
    otherFee() {
      let otherSum = 0;
      if (this.expenseList.ecOtherFeeDetails) {
        this.expenseList.ecOtherFeeDetails.forEach((item) => {
          otherSum += parseFloat(item.other_fee) ? parseFloat(item.other_fee) : 0;
        });
      }
      return otherSum;
    },
    totalSum() {
      let travelFeeSum = 0;
      this.travelFee.forEach((item) => {
        travelFeeSum += parseFloat(item);
      });
      let sum = parseFloat(travelFeeSum + this.hotelFee + this.subsidyFee + this.otherFee);
      return Number(sum.toFixed(2));
    },
    // 获取数据
    emsecfeereimh() {
      return this.$store.state.myReimburse.emsecfeereimh;
    },
    applyDate() {
      const date = new Date().toLocaleDateString();// 获取日期："2017/11/15"
      return this.formatDate(date);
    },
    feeStdExp() {
      return this.$store.state.myReimburse.feeStdExp;
    },
    hasAssistantFeeType() {
      return this.$store.state.menuConfig.fee.hasAssistantFeeType || false;
    },
  },
  filters: {
    filterA(value) {
      return `￥${(Math.round(value * 100) / 100).toFixed(2)}`;
    },
  },
};
</script>
