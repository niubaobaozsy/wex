<!--
  describe：差旅报销
  created by：李怡敏
  date：2017-11-18
-->
<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>
