 <!--
  describe："发票-税类型"
  created by：panjm
  date：2017-12-29
-->
 <template>
  <div class="content" v-if="show">
    <my-header :title="'选择税费类型'" :showBack="true" @previous="goBack" :rightItem="'确定'" @on-click="confirm"></my-header>
    <group class="has-header">
      <radio :options="showTaxList" v-model="feeTypesPicked"></radio>
    </group>
  </div>
</template>

<script>
import { Radio, Group } from 'vux';
import MyHeader from '../../common/header';

export default {
  components: {
    Radio,
    Group,
    MyHeader,
  },
  props: {
    show: {
      type: Boolean,
      required: true,
      default: false,
    },
    options: {
      type: Array,
      required: true,
      default: [],
    },
    value: {
      type: Object,
      required: true,
      default: {
        fee_type_id: '',
      },
    },
    // invoiceIndex: {
    //   type: Number,
    //   required: false,
    //   default: 0,
    // },
  },
  data() {
    return {
      showTaxList: [],
      feeTypesPicked: '',
      feeTypes: {},
      // taxList: [],
    };
  },
  methods: {
    // change(value, label) {
    //   console.log(value, label);
    //   this.taxList.forEach((item) => {
    //     item.checked = item.fee_type_name === value;
    //   });
    // },
    goBack() {
      this.$emit('hide');
      this.$emit('update:show', false);
    },
    confirm() {
      // let checkedFlag = false;
      // this.taxList.forEach((item) => {
      //   if (item.checked) {
      //     this.feeTypes = item;
      //     checkedFlag = true;
      //   }
      // });
      if (this.feeTypesPicked) {
        // this.emsecfeereimh.invoiceTaxRS[0].feeTypes = this.feeTypes;
        // this.$store.commit('EMSEC_FEEREIMH', this.emsecfeereimh);
        this.options.forEach((option) => {
          if (this.feeTypesPicked === option.fee_type_name) {
            this.feeTypes.fee_type_id = option.fee_type_id;
            this.feeTypes.fee_type_name = option.fee_type_name;
          }
        });
        this.$emit('getFeeTypes', this.feeTypes);
        this.$emit('input', this.feeTypes);
        this.$emit('hide', this.feeTypes);
        this.$emit('update:show', false);
      } else {
        this.showToast({ msg: '您还未选择税费类型, 请点击选择！' });
      }
    },
  },
  mounted() {
    // this.getTaxList();
  },
  computed: {
    // feeTypeId() {
    //   const invoice = this.$store.state.myReimburse.emsecfeereimh.invoiceTaxRS[this.invoiceIndex] || [];
    //   return invoice.bill_type_id || '';
    // },
  },
  watch: {
    show(nVal) {
      if (nVal) {
        this.options.forEach((option) => {
          this.showTaxList.push(option.fee_type_name);
          if (option.fee_type_id === this.value.fee_type_id) {
            this.feeTypesPicked = option.fee_type_name;
            this.feeTypes.fee_type_id = this.value.fee_type_id;
            this.feeTypes.fee_type_name = option.fee_type_name;
          }
        });
      }
    },
  },
};
</script>
<style lang="less" scoped>

</style>
