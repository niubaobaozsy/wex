<!--
  describe： Homepage of reimburse creation
  created by：Zhuangyh
  date：2017-11-24
-->
<template>
  <div>
    <my-header v-show="!childRtFullScreen" :title="top.title" :headerClass="top.headerTop" @previous="goBack" :rightItem="!tplProcess[currentStep].hideSaveBtn?top.rightTitle:''" @on-click="saveDraft(true)"></my-header>
    <process-bar v-show="!childRtFullScreen" class="has-header process-bar border-bottom" :process="process" :currentStep="currentStep" @on-click="goRouter"></process-bar>
    <div :class="{'has-header': !childRtFullScreen, 'has-process-bar': !childRtFullScreen}">
      <keep-alive>
        <router-view ref="childRt"></router-view>
      </keep-alive>
      <div v-show="!childRtFullScreen" class="footer-btn columns is-mobile is-gapless">
        <button class="column" @click="goPrevious" v-if="currentStep">上一步</button>
        <button class="column" @click="goNext" :class="{available: reimburseCreate.ableNext}" v-if="currentStep<(tplProcess.length-1)">下一步</button>
        <button class="column" @click="submit" :class="{available: reimburseCreate.ableNext}" v-if="currentStep===(tplProcess.length-1)">提交</button>
      </div>
    </div>
    <over-standard :show="showOverStand" @on-select="onOverStandSubmit" @on-hide="onOverStandHide"></over-standard>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import store from '@/store';
import myReimburse from '@/store/myReimburse';
import myHeader from '../../common/header';
import processBar from '../../common/processBar';
import overStandard from '../../common/overStandReason';

export default {
  components: {
    myHeader,
    processBar,
    overStandard,
  },
  data() {
    return {
      tplCfg: {
        CL: {
          top: {
            title: '差旅报销',
            rightTitle: '保存草稿',
          },
          process: [
            {
              procName: '差旅报销',
              procRt: 'basicInformation',
            }, {
              procName: '行程及消费',
              procRt: 'consumeRecord',
            }, {
              procName: '发票及预算',
              procRt: 'invoiceBudget',
            }, {
              procName: '附件',
              procRt: 'addReimburseAttachment',
              // saveBeforeIn: true,
            }, {
              procName: '审批流程',
              procRt: 'confirmApplyCompensate',
              hideSaveBtn: true,
            },
          ],
          rtWhitelist: [
            '/fee/myReimburse/feeBudget',
            '/fee/myReimburse/travelSysUsed',
            '/fee/myReimburse/addInvoice',
            '/fee/myReimburse/addBudget',
            '/fee/myReimburse/addLoan',
            '/mine/collectionTitle',
          ],
          validateRule: () => {
            console.log('validateRule');
            return true;
          },
        },
        TY: {
          top: {
            title: '费用报销',
            rightTitle: '保存草稿',
          },
          process: [
            {
              procName: '费用报销',
              procRt: 'basicInformation',
            }, {
              procName: '发票及预算',
              procRt: 'invoiceBudget',
            }, {
              procName: '附件',
              procRt: 'addReimburseAttachment',
              // saveBeforeIn: true,
            }, {
              procName: '审批流程',
              procRt: 'confirmApplyCompensate',
              hideSaveBtn: true,
            },
          ],
          rtWhitelist: ['/fee/myReimburse/addInvoice', '/fee/myReimburse/addBudget', '/fee/myReimburse/addLoan', '/mine/collectionTitle'],
          validateRule: () => {
            console.log('validateRule');
            return true;
          },
        },
      },
      // isSave: false,
      nativeNav: false,
      showOverStand: false,
      childRtFullScreen: false,
      delOverStdRes: false,
    };
  },
  methods: {
    goStep(index) {
      this.$store.commit('REIMBURSE_CREATE', { currentStep: index });
      this.$router.push(this.tplProcess[this.currentStep].procRt);
    },
    goRouter(index) {
      this.nativeNav = true;
      if (this.goRouterValidate()) {
        if (index === this.currentStep) {
          this.nativeNav = false;
          return false;
        }
        if (index === this.currentStep + 1) {
          this.goNext();
        } else if (index === this.currentStep - 1) {
          this.goPrevious();
        } else if ((((index > this.currentStep + 1) && this.goNextValidate()) || ((index < this.currentStep - 1) && this.goPreviousValidate())) && this.validateRuleCheck()) {
          if ((index > this.currentStep + 1) && index === this.tplProcess.length - 1) {
            this.saveAndCheck().then(() => {
              this.goStep(index);
            });
          } else if ((index > this.currentStep + 1) && this.tplProcess[index].saveBeforeIn) {
            if (!this.emsecfeereimh.fee_reim_id) {
              this.saveDraft().then(() => {
                this.goStep(index);
              });
            } else {
              this.goStep(index);
            }
          } else {
            this.goStep(index);
          }
        } else {
          this.nativeNav = false;
          return false;
        }
      }
      this.nativeNav = false;
      return true;
    },
    saveDraft(notAuto) {
      if (this.saveDraftValidate()) {
        // 判断是否含借款
        if (this.emsecfeereimh.feeLoans.length !== 0 && Object.keys(this.emsecfeereimh.feeLoans[0]).length !== 0) {
          this.emsecfeereimh.need_app_loan_flag = true;
          this.emsecfeereimh.need_app_loan = 'Y';
        } else {
          this.emsecfeereimh.need_app_loan_flag = false;
          this.emsecfeereimh.need_app_loan = 'N';
        }
        // 判断是否含发票
        if (this.emsecfeereimh.invoiceTaxRS.length !== 0) {
          this.emsecfeereimh.need_input_tax = 'Y';
        } else {
          this.emsecfeereimh.need_input_tax = 'N';
        }
        let budgetTotalFee = 0;
        let approveReimamount = 0;
        let taxTotalFee = 0;
        let loanTotalFee = 0;
        this.emsecfeereimh.invoiceTaxRS.forEach((item) => {
          taxTotalFee += item.tax_amount;
          // taxTotalFee = Math.floor(taxTotalFee * 100) / 100;
        });
        taxTotalFee = Number(taxTotalFee.toFixed(2));
        this.emsecfeereimh.emsEcFeeBudgets.forEach((item) => {
          budgetTotalFee += item.apply_reim_amount;
          approveReimamount += item.approve_reim_amount;
          // budgetTotalFee = Math.floor(budgetTotalFee * 100) / 100;
          // approveReimamount = Math.floor(approveReimamount * 100) / 100;
        });
        budgetTotalFee = Number(budgetTotalFee.toFixed(2)); // 预算合计
        approveReimamount = Number(approveReimamount.toFixed(2)); // 预算申请金额 = 预算批准金额

        this.emsecfeereimh.feeLoans.forEach((item) => {
          loanTotalFee += item.repay_amount;
          // loanTotalFee = Math.floor(loanTotalFee * 100) / 100;
        });
        loanTotalFee = Number(loanTotalFee.toFixed(2)); // 抵扣合计
        this.emsecfeereimh.apply_reim_amount = budgetTotalFee + taxTotalFee; // 报销申请合计 = 预算合计 + 税额合计
        this.emsecfeereimh.approve_reim_amount = approveReimamount + taxTotalFee; // 报销批准合计
        this.emsecfeereimh.total_loan_amount = loanTotalFee; // 抵扣合计
        this.emsecfeereimh.pay_amount = this.emsecfeereimh.apply_reim_amount - loanTotalFee; // 本次实付款 = 报销申请合计 - 抵扣合计

        this.emsecfeereimh.feeTravels.forEach((item) => {
          item.transportDetails.forEach((feeItem) => {
            if (feeItem.attribute1 === 'COMPANY') {
              feeItem.approve_transport_fee = 0;
              feeItem.transport_fee = 0;
            }
          })
        })

        return new Promise((resolve) => {
          this.showLoading();
          this.$store.dispatch('saveReimInfo', this.emsecfeereimh).then((rep) => {
            this.hideLoading();
            if (rep && rep.code === '0000') {
              if (rep.data && rep.data.emsecfeereimh && rep.data.emsecfeereimh.fee_reim_id) {
                const standardTypeDict = [{
                    label: '市内交通费',
                    value: 'SNJTF',
                  }, {
                    label: '餐费',
                    value: 'CF',
                  }
                ];
                if (rep.data.emsecfeereimh.assistantDetails) {
                  rep.data.emsecfeereimh.assistantDetails.forEach((item) => {
                    if (item.standard_type) {
                      item.standardType = standardTypeDict.filter((i) => i.value === item.standard_type)[0];
                    }
                  });
                }
                this.$store.commit('REIMBURSE_CREATE', { isSave: true });
                this.emsecfeereimh.formInstanceId = rep.data.formInstanceId;
                this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, rep.data.emsecfeereimh));
                if (notAuto) {
                  this.showToast({ msg: '保存成功' });
                }
                resolve(rep.data.emsecfeereimh.fee_reim_id);
              }
            } else if (rep && rep.code) {
              this.showToast({ msg: `保存失败(${rep.code}):${rep.msg}` });
            }
          });
        });
      }
      return null;
    },
    submitValidate() {
      const beforeSubmit = this.$refs.childRt.beforeSubmit;
      const result = (beforeSubmit && typeof (beforeSubmit) === 'function' && beforeSubmit()) || beforeSubmit === undefined;
      return result;
    },
    submit() {
      if (this.submitValidate()) {
        const params = {
          auditNote: '',
          formInstanceId: this.emsecfeereimh.formInstanceId,
          template_form_id: this.emsecfeereimh.form_template_id,
          model_id: '001',
          mustModifyHandler: this.flowNode,
        };
        this.showLoading();
        this.$store.dispatch('submit', params).then((rep) => {
          this.hideLoading();
          if (rep && rep.code === '0000') {
            this.showToast({ msg: '提交成功' });
            this.$router.push('/fee/myReimburse/reimburseHome/beingApproved');
          } else if (rep && rep.code) {
            this.showToast({ msg: rep.msg });
          }
        });
      }
    },
    check(id) {
      return new Promise((resolve) => {
        const self = this;
        self.showLoading();
        let params = {
          fee_reim_id: id,
          order_current_status: 'EDIT',  // 获取当前单据状态, EDIT(提单)/APPROVE(审单)
        }
        self.$store.dispatch('frCheckFeeReim', params)
          .then((rep) => {
            self.hideLoading();
            if (rep && rep.code === '0000') {
                if (this.emsecfeereimh.over_standard_reason) {
                  const overStdParams = {
                    over_standard_reason: '',
                    is_over_standard: 'N',
                  }
                  this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, overStdParams));
                  this.delOverStdRes = true;
                }
              resolve();
            } else if (rep && rep.code === '0001' && rep.data.errorType === 'STANDARD') {
              self.alert({
                content: rep.data.msg,
                onHide() {
                  if (!self.emsecfeereimh.over_standard_reason) {
                    self.showOverStand = true;
                    self.$store.commit('REIM_OVER_STD_EXP', true);
                    resolve();
                  } else {
                    if (!self.overStdExp) {
                      self.showOverStand = true;
                      self.$store.commit('REIM_OVER_STD_EXP', true);
                      resolve();
                    } else {
                      self.showOverStand = false;
                      resolve();
                    }
                  }
                },
              });
            } else if (rep && rep.code === '0001') {
              self.alert({
                content: rep.data.msg,
                onHide() {
                  resolve();
                },
              });
            } else if (rep.code === '0002') {
              self.alert({ content: rep.data.msg });
            } else {
              self.alert({ content: rep.msg || '未知异常' });
            }
          });
      });
    },
    saveAndCheck() {
      return new Promise((resolve) => {
        this.saveDraft().then((id) => {
          this.check(id).then(() => {
            // 如果超标理由在校验后被删除，需要再保存一次
            if (this.delOverStdRes) {
              this.saveDraft().then(() => {
                resolve();
              })
            } else {
              resolve();
            }
          });
        });
      });
    },
    goBack() {
      this.$router.push('/fee/myReimburse');
    },
    validateRuleCheck() {
      const validateRule = this.tpl.validateRule;
      const result = (validateRule && typeof (validateRule) === 'function' && validateRule()) || validateRule === undefined;
      return result;
    },
    goRouterValidate() {
      const beforeGoRouter = this.$refs.childRt.beforeGoRouter;
      const result = (beforeGoRouter && typeof (beforeGoRouter) === 'function' && beforeGoRouter(index)) || beforeGoRouter === undefined;
      return result;
    },
    goPreviousValidate() {
      const beforePrevious = this.$refs.childRt.beforePrevious;
      const result = (beforePrevious && typeof (beforePrevious) === 'function' && beforePrevious()) || beforePrevious === undefined;
      return result;
    },
    goNextValidate() {
      const beforeNext = this.$refs.childRt.beforeNext;
      const result = (beforeNext && typeof (beforeNext) === 'function' && beforeNext()) || beforeNext === undefined;
      return result;
    },
    saveDraftValidate() {
      const beforeSaveDraft = this.$refs.childRt.beforeSaveDraft;
      const result = (beforeSaveDraft && typeof (beforeSaveDraft) === 'function' && beforeSaveDraft()) || beforeSaveDraft === undefined;
      return result;
    },
    goPrevious() {
      this.nativeNav = true;
      if (this.goPreviousValidate()) {
        this.$store.commit('REIMBURSE_CREATE', { currentStep: this.currentStep - 1 });
        this.$router.push(this.tplProcess[this.currentStep].procRt);
      }
      this.nativeNav = false;
    },
    nextStep() {
      this.$store.commit('REIMBURSE_CREATE', { currentStep: this.currentStep + 1 });
      this.$router.push(this.tplProcess[this.currentStep].procRt);
    },
    goNext() {
      this.nativeNav = true;
      if (this.goNextValidate()) {
        if (this.currentStep === this.tplProcess.length - 2) {
          this.saveAndCheck().then(() => {
            this.nextStep();
          });
        } else if (this.tplProcess[this.currentStep + 1].saveBeforeIn) {
          if (!this.emsecfeereimh.fee_reim_id) {
            this.saveDraft().then(() => {
              this.nextStep();
            });
          } else {
            this.nextStep();
          }
        } else {
          this.nextStep();
        }
      }
      this.nativeNav = false;
    },
    onOverStandSubmit(reason) {
      const emsecfeereimh = {
        is_over_standard: 'Y',
        over_standard_reason: reason,
      };
      this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, emsecfeereimh));
      this.saveDraft().then(() => {
        this.showOverStand = false;
      });
    },
    onOverStandHide() {
      this.showOverStand = false;
    },
  },
  computed: {
    ...mapState({
      reimburseCreate: state => state.myReimburse.reimburseCreate,
      currentStep: state => state.myReimburse.reimburseCreate.currentStep,
      overStdExp: state => state.myReimburse.overStdExp,
      tpl(state) {
        return this.tplCfg[state.myReimburse.reimburseCreate.reimburseType || 'CL'];
      },
      tplProcess(state) {
        return this.tplCfg[state.myReimburse.reimburseCreate.reimburseType || 'CL'].process;
      },
      top(state) {
        return this.tplCfg[state.myReimburse.reimburseCreate.reimburseType || 'CL'].top;
      },
      rtWhitelist(state) {
        return this.tplCfg[state.myReimburse.reimburseCreate.reimburseType || 'CL'].rtWhitelist || [];
      },
      process(state) {
        const process = [];
        this.tplCfg[state.myReimburse.reimburseCreate.reimburseType || 'CL'].process.forEach((item) => {
          process.push(item.procName);
        });
        return process;
      },
      emsecfeereimh: state => state.myReimburse.emsecfeereimh,
      emsecfeetravels: state => state.myReimburse.emsecfeetravels,
      emsecfeereimhexts: state => state.myReimburse.emsecfeereimhexts,
      reimInfoBySave: state => state.myReimburse.reimInfoBySave,
      flowNode: state => state.myReimburse.flowNode,
    }),

  },
  mounted() {
    if (!this.reimburseCreate.reimburseType) {
      this.$router.push('/fee/myReimburse/create/');
    }
  },
  beforeRouteEnter(to, from, next) {
    store.dispatch('getDefaultConfig').then((rep) => {
      if (rep) next();
    });
  },
  beforeRouteUpdate(to, from, next) {
    if (to.path === '/fee/myReimburse/create/viewApplyDetail' ||
    to.path === '/fee/myReimburse/create/collectionTitle' ||
    to.path === '/fee/myReimburse/create/executeMsg' ||
    to.path === '/fee/myReimburse/create/mineBackInfo') {
      this.childRtFullScreen = true;
    } else {
      this.childRtFullScreen = false;
    }
    if (this.nativeNav) {
      next();
    } else {
      if (this.tplProcess[this.currentStep - 1] && to.path === `/fee/myReimburse/create/${this.tplProcess[this.currentStep - 1].procRt}`) {
        this.$store.commit('reimburseCreate', { currentStep: this.currentStep - 1 });
      } else if (this.tplProcess[this.currentStep + 1] && to.path === `/fee/myReimburse/create/${this.tplProcess[this.currentStep + 1].procRt}`) {
        this.$store.commit('reimburseCreate', { currentStep: this.currentStep + 1 });
      }
      next();
    }
  },
  beforeRouteLeave(to, from, next) {
    const _this = this;
    if (!this.reimburseCreate.isSave && (this.rtWhitelist.indexOf(to.path) === -1) && (to.path !== '/')) {
      this.$vux.confirm.show({
        content: '尚未保存，退出将清空当前页面内容，确认退出？',
        onConfirm() {
          _this.$store.commit('MY_REIMBURSE', JSON.parse(JSON.stringify(myReimburse.stateInit)));
          next();
        },
        onCancel() {
          next(false);
        },
      });
    } else if (this.rtWhitelist.indexOf(to.path) !== -1) {
      next();
    } else {
      _this.$store.commit('MY_REIMBURSE', JSON.parse(JSON.stringify(myReimburse.stateInit)));
      next();
    }
  },
};
</script>
<style lang="less" scoped>
.process-bar {
  position: fixed;
  z-index: 99;
  width: 100%;
  top: 0;
  left: 0;
}

.has-process-bar {
  padding: 70px 0 0;
}

button {
  border: none;
  outline: none;
  background: none;
}

.footer-btn {
  position: fixed;
  bottom: 0;
  width: 100%;
  button {
    height: 50px;
    font-size: 18px;
    box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.10);
    &:first-child {
      background: #FFFFFF;
      color: #666666;
    }
    &:last-child {
      color: #FFFFFF;
      background: #C1C1C1;
      &.available {
        background: #3DA5FE;
      }
    }
  }
}
</style>
