<!--
  describe：添加发票
  created by：欧倩伶
  date：2017-11-18
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myReimburse/addInvoice.less';
</style>
<template>
  <div>
    <my-header :title="top.title" :rightItem="'确定'" :showBack="true" :showRedDot="true" @previous="goBack" @on-click="submit"></my-header>
    <div class="has-footer has-header">
      <!-- 发票列表 -->
      <div v-if="invoiceList.length">
        <div class="invoiceBox" v-for="(item, index) in invoiceList" :key="index" @click="selectInvoice(item, index)">
          <div class="invoiceLeft">
            <div class="delItem">
              <img v-if="!item.checked" :src="select" alt="">
              <img v-if="item.checked" :src="selectActive" alt="">
            </div>
            <div :class="['invoiceType',{'blue':tempType[item.invoice_type_name]=='专票'},{'green':tempType[item.invoice_type_name]=='普票'},{'pink':tempType[item.invoice_type_name]=='电子'}]">
              {{ tempType[item.invoice_type_name] }}
            </div>
            <div class="invoiceSecondCol">
              <p>发票号码：{{ item.invoice_num }}</p>
              <p>{{ item.sales_unit_name }}</p>
              <p>{{ item.invoice_date }}</p>
            </div>
          </div>
          <div class="invoiceThirdCol">
            <p class="invoicePrice">￥{{ item.amount_sum.toFixed(2) }}</p>
            <span class="invoiceStatus" v-if="item.first_node_status=='未查检'">{{ item.first_node_status }}</span>
          </div>
        </div>
      </div>
      <div v-if="invoiceList.length === 0 && !isLoading">
        <img class="no_data_img" src="../../../assets/images/common/no_data.png" alt="">
        <p class="no_data_text">暂无发票信息</p>
      </div>
    </div>
  </div>
</template>

<script>
import MyHeader from '../../common/header';
import select from '../../../assets/images/fee/myReimburse/select.png';
import selectActive from '../../../assets/images/fee/myReimburse/select_active.png';

export default {
  components: {
    MyHeader,
  },

  data() {
    return {
      select,
      selectActive,
      isSave: false,
      isLoading: true,
      currentItem: '',
      top: {
        title: '选择发票',
      },
      pageInfo: {
        page_number: 1,
        page_size: 10,
      },
      tempType: {
        1: '专票',
        2: '专票',
        3: '普票',
        4: '普票',
        10: '电子',
        11: '普票',
      },
      invoiceList: [],
      selectList: [],
    };
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    selectInvoice(item) {
      item.checked = !item.checked;
    },
    // 确认
    submit() {
      this.selectList = [];
      this.invoiceList.forEach((item) => {
        if (item.checked) {
          const info = {
            invoice_type_name: item.invoice_type_name,
            invoice_maker: item.sales_unit_name,     // 开票方
            invoice_num: item.invoice_num,           // 发票号
            invoice_date: item.invoice_date,         // 开票日期
            invoice_amount: item.amount_sum,         // 发票金额
            tax_amount: item.tax_amount,             // 税额
            invoice_source_id: item.invoice_id,      // 票夹中的发票id
            invoice_source_system: 'SMART_DOCUMENT', // 固定"SMART_DOCUMENT"
            thumbnail_content: item.thumbnail_content,
            file_id: item.file_id,
          };
          this.selectList.push(info);
        } else {
          this.selectList = this.selectList.filter(selectItem => selectItem.invoice_num !== this.currentItem.invoice_num);
        }
      });
      this.$store.commit('INVOICE_TAXRS_INFO', this.selectList);
      this.showToast({ msg: '添加发票成功', width: '12em' });
      this.$router.go(-1);
    },
    // 请求发票列表
    getInvoiceList() {
      this.showLoading();
      const params = {
        query_param: {
          pageSize: this.pageInfo.page_size,
          pageNumber: this.pageInfo.page_number,
          related: 0,
        },
      };
      const self = this;
      this.$store.dispatch('reimInvoiceQuery', params).then((res) => {
        this.hideLoading();
        this.isLoading = false;
        if (res && res.code === '0000') {
          if (res.data.totalPage > self.pageInfo.page_number) {
            self.hasNextPage = true;
            self.pageInfo.page_number++;
            this.loadMore = true;
          } else {
            self.hasNextPage = false;
            this.loadMore = false;
          }
          if (res.data.list) {
            res.data.list.forEach((item) => {
              item.checked = false;
              item.invoice_type_name = item.invoice_type_name ? parseInt(item.invoice_type_name, 10) : '';
              this.invoicetaxrs.forEach((taxrsItem) => {
                if (item.invoice_num === taxrsItem.invoice_num) {
                  item.checked = true;
                }
              });
            });
            this.invoiceList = this.invoiceList.concat(res.data.list);
          } else {
            this.invoiceList = [];
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
  },
  computed: {
    invoicetaxrs() {
      return this.$store.state.myReimburse.emsecinvoicetaxrs;
    },
  },
  mounted() {
    this.getInvoiceList();
  },
};
</script>
