<!--
  describe：差旅报销——“ 商旅系统已使用 ”
  created by：Yim Lee
  date：2017-11-18
-->
<template>
  <div>
    <my-header :title="'商旅系统已使用'" :showBack="true" @previous="goBack"></my-header>
    <div class="has-header">
      <!-- 商旅系统已使用 -->
      <div class="columns is-mobile is-gapless border-bottom consume" v-for="(item, index) in travelSystem" :key="index">
        <span class="text column">{{ item.text }}</span>
        <span class="column count">共{{ item.orderCount }}条</span>
        <span class="text">￥{{ item.feeAmount }}</span>
        <!-- 右箭头 -->
        <!-- <img src="../../../assets/rt-arrow.png" class="rt-arrow" alt="rightArrow"> -->
      </div>
    </div>
    <!-- 底部 -->
    <div class="footer">
      <div class="sum">金额总计：
        <p>¥{{travelSysUsedAmount}}</p>
      </div>
      <div class="btn" @click="goBack">确认</div>
    </div>
  </div>
</template>

<script>
import MyHeader from '../../common/header';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {
    };
  },
  computed: {
    travelSystem() {
      const fee = [
        {
          text: '飞机',
        },
        {
          text: '用车',
        },
        {
          text: '酒店',
        },
      ];
      const travelSysUsed = this.$store.state.myReimburse.travelSysUsed;
      fee[0].orderCount = travelSysUsed.airFee.length;
      fee[0].feeAmount = travelSysUsed.airFeeAmount.toFixed(2);
      fee[1].orderCount = travelSysUsed.carFee.length;
      fee[1].feeAmount = travelSysUsed.carFeeAmount.toFixed(2);
      fee[2].orderCount = travelSysUsed.hotelFee.length;
      fee[2].feeAmount = travelSysUsed.hotelFeeAmount.toFixed(2);
      return fee;
    },
    travelSysUsedAmount() {
      return this.$store.state.myReimburse.travelSysUsed.totalAmount.toFixed(2);
    },
  },
  methods: {
    // 返回 或 上一步
    goBack() {
      this.$router.go(-1);
    },
  },
  mounted() {},
  watch: {},
};
</script>
<style lang="less" scoped>
.columns {
  margin: 0 !important;
}

.rt-arrow {
  display: block;
  width: 9px;
  height: 15px;
  margin: auto 15px;
}

.consume {
  height: 50px;
  background: #FFFFFF;
  margin-bottom: 1px !important;
  .text,
  .count {
    line-height: 50px;
    margin-right: 15px;
    &:first-child {
      margin-left: 15px !important;
    }
  }
  .count {
    text-align: right;
    font-size: 14px;
    color: #C3C3C3;
    margin-right: 5px;
  }
}

.footer {
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 50px;
  display: flex;
  justify-content: space-between;
  padding: 14px 15px;
  box-sizing: border-box;
  background: #fff;
  font-size: 16px;
  .sum {
    display: flex;
    p {
      color: #3DA5FE;
    }
  }
  .btn {
    width: 71px;
    border-radius: 40px;
    background: #3DA5FE;
    text-align: center;
    line-height: 22px;
    color: #fff;
  }
}
</style>
