 <!--
  describe：查看报销单
  created by：周積坤
  date：2017-11-22
  data: 2017-12
  修改：黄喆（关联申请单，加待审批）
-->
<template>
  <div>
    <my-header :title='top.title' @previous='goBack'></my-header>
    <div class='has-footer'>
      <ul class='has-header top'>
        <li class="border-bottom">
          <p>类型
            <!-- <i :class="['status',{'yellow' : order.order_status == 'SUBMITED'},{'blue': order.order_status == 'AUDITED'}]">{{ order.order_status == 'SUBMITED' ? "审批中" : "已通过" }}</i> -->
            <!-- //"DRAFT":"草稿"；"SUBMITED":"审批中"；"AUDITED":"已通过"； -->
          </p>
          <div>
            <!-- order_type_name：单据类型名称 -->
            <section>{{order.order_type_name}}</section>
            <span>单号: {{order.fee_reim_code}}</span>
          </div>
        </li>
        <li class="border-bottom">
          <p>报销人</p>
          <div>
            {{order.apply_name}}
          </div>
        </li>
        <li class='border-bottom' v-if="order.order_type === 'CL'&& myApplyMenuCfg[order.order_type].hasTravelType">
          <p>出差类型</p>
          <div>
             {{order.attribute3_name}}
          </div>
        </li>
         <li class='border-bottom' v-if="isUrgentCfg">
          <p>是否加急</p>
          <div>
            {{order.is_urgent === 'Y' ? '是' : '否' }}
          </div>
        </li>
        <li v-if="order.order_type == 'CL'" class="border-bottom">
          <p>同行人</p>
          <div>
            {{order.feeTravels[0].travel_persons_name}}
          </div>
        </li>
        <li class="border-bottom">
          <p>业务描述</p>
          <div>
            {{order.sensitive_info}}
          </div>
        </li>
        <li v-if="order.is_over_standard =='Y'" class="border-bottom">
          <p>超标原因</p>
          <div>
            {{order.over_standard_reason}}
          </div>
        </li>
        <li class="border-bottom">
          <p>入账单位</p>
          <div>
            {{order.company_name}}
          </div>
        </li>
      </ul>
      <div class='examine'>
        <div class='top'>
          <span>审批记录</span>
          <!--点击催办-->
          <p @click='reminders()' v-if="order.order_status != 'AUDITED'">催办</p>
        </div>
        <my-progress :title='list' :list="processTable" :current="current"></my-progress>
      </div>
      <div class='has-bottom more'>
        <div v-if="number" class='router border-bottom' @click="showApply = true">
          <div>关联申请单</div>
          <div class='detailed'>共{{number}}条<img :src='top.arrow' class='img'></div>
        </div>
        <div class='router border-bottom' @click=" order.feeTravels.length ? travelShow = true : travelShow = false" v-if="order.order_type == 'CL'">
          <div>行程信息</div>
          <div class='detailed' v-if="order.feeTravels">共{{order.feeTravels.length}}条<img :src='top.arrow' class='img'></div>
        </div>
        <div class='router border-bottom' @click=" cost ? applyBack = true : applyBack = false" v-if="order.order_type === 'CL'">
          <div>费用明细</div>
          <div class='detailedMoney' v-if="order">￥{{cost.toFixed(2)}}<img :src='top.arrow' class='img'></div>
        </div>
      </div>
      <div class='has-bottom more'>
        <div v-if="order.invoiceTaxRS && order.invoiceTaxRS.length" class='router border-bottom' @click=" order.invoiceTaxRS.length ? trick = true : trick = false ">
          <div>发票</div>
          <div class='detailed'>共{{order.invoiceTaxRS.length}}张<img :src='top.arrow' class='img'></div>
        </div>
        <div class='router border-bottom' @click=" budgetFee ? Router2 = true : Router2 = false">
          <div>预算来源</div>
          <div class='detailedMoney' v-if="order.emsEcFeeBudgets">￥{{budgetFee.toFixed(2)}}<img :src='top.arrow' class='img'></div>
        </div>
        <div v-if="order.feeLoans && order.feeLoans.length" class='router border-bottom' @click=" order.feeLoans.length ? offset = true : offset = false">
          <div>冲抵借款</div>
          <div class='detailed'>共{{order.feeLoans.length}}张<img :src='top.arrow' class='img'></div>
        </div>
      </div>
      <div class='has-bottom addHeight'>
        <div class="router border-bottom" @click="router6()">
          <div>附件</div>
          <div class='detailed'>共{{imgList.length}}张<img :src='top.arrow' class='img'></div>
        </div>
      </div>
      <confirm v-model='show1' :title='title3' @on-confirm='onConfirm()'></confirm>
      <alert v-model='show' :content='title1'></alert>
      <div class='bottom' @click='withdraw()' v-if="order.order_status != 'AUDITED'">撤回</div>
      <relevance-apply :showList='order.emsEcFeeBudgets' :show="showApply" @on-hide="hideArea"></relevance-apply>
      <invoice-reimburse :showList='order.invoiceTaxRS' :show="trick" @on-hide="hideArea"></invoice-reimburse>
      <offset-borrow :showList='order.feeLoans' :show="offset" @on-hide="hideArea"></offset-Borrow>
      <my-expenseSee :order='arr' :show="applyBack" @on-hide="hideArea"></my-expenseSee>
      <my-budgetSee :title='order.emsEcFeeBudgets' :show="Router2" @on-hide="hideArea"></my-budgetSee>
      <my-journeySee :title="order.feeTravels" :show="travelShow" @on-hide="hideArea"></my-journeySee>
    </div>
  </div>
</template>

<script>
import { Confirm, Group, XSwitch, XButton, Alert } from 'vux';
import MyProgress from '../../common/proGress';
import MyHeader from '../../common/header';
import RelevanceApply from '../../common/relevanceApply';
import rtarrow from '../../../assets/rt-arrow.png';
import InvoiceReimburse from '../../common/invoiceReimburse';
import OffsetBorrow from '../../common/offsetBorrow';
import myJourneySee from '../../common/jourNeysee';  // 行程
import myExpenseSee from '../../common/expenseSee';  // 消费
import myBudgetSee from '../../common/budGetsee';    // 预算

export default {

  components: {
    MyProgress,
    myExpenseSee,
    myBudgetSee,
    MyHeader,
    Group,
    XSwitch,
    myJourneySee,
    Confirm,
    XButton,
    RelevanceApply,
    Alert,
    InvoiceReimburse,
    OffsetBorrow,
  },
  data() {
    return {
      title1: '',
      title3: '撤回该报销单',
      show: false,
      showApply: false,
      show1: false,
      trick: false,
      offset: false,
      travelShow: false,
      Router2: false,
      applyBack: false,
      cost: 0,
      top: {
        title: '查看报销单',
        arrow: rtarrow,
      },
      list: [],
      processTable: [],
      current: '',
      imgList: [],
      arrList: [],
      arr: [],
      order: {},
      firstList: {},
      allTravelTypes:[],
    };
  },
  computed: {
    myApplyMenuCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.children;
    },
    isUrgentCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.isUrgent
    },
    budgetFee() {
      let amountFee = 0;
      if (this.order.emsEcFeeBudgets && this.order.emsEcFeeBudgets.length !== 0) {
        this.order.emsEcFeeBudgets.forEach((items) => {
          if (items.apply_reim_amount) {
            amountFee += items.apply_reim_amount ? items.apply_reim_amount : 0;
          }
        });
      }
      return parseFloat(amountFee);
    },
    number() {
      let amountFee = 0;
      if (this.order.emsEcFeeBudgets && this.order.emsEcFeeBudgets.length !== 0) {
        this.order.emsEcFeeBudgets.forEach((items) => {
          if (items.fee_apply_id && items) {
            amountFee += 1;
          }
        });
      }
      return amountFee;
    },
  },
  created() {
    this.getAttachment();
    this.getData();
  },
  methods: {
    // 获取大图
    getBigImg(id) {
      this.showLoading();
      this.$store.dispatch('getBigImg', id).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          if (res.data) {
            this.imgList.push(res.data);
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    // 获取附件
    getAttachment() {
      this.imgList = [];
      const params = {
        source_system: 'Expense',
        source_order_id: this.$route.query.id,
        source_order_type: 'EC',
      };
      this.showLoading();
      this.$store.dispatch('getAttachment', params).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          if (res.data && res.data.info) {
            const list = res.data.info;
            list.forEach((item) => {
              this.getBigImg(item.file_id);
            });
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    router6() {
      // 附件
      this.$router.push({ path: '/fee/myReimburse/invoiceList', query: { imgList: this.imgList } });
    },
    // 点击组件显示隐藏
    hideArea() {
      this.travelShow = false;
      this.showApply = false;
      this.trick = false;
      this.Router2 = false;
      this.offset = false;
      this.applyBack = false;
    },
    // 批量获取业务字典编码对应的数据
    async getDictData() {
      if (this.order.order_type === 'CL' && this.myApplyMenuCfg[this.order.order_type].hasTravelType) {
        this.allTravelTypes = await this.$method.getDataFromDict('TRAVEL_TYPE') || []; // 获取所有出差类型数据
        this.$set(this.order, 'attribute3_name', this.$method.getValueInArray(this.order.attribute3,  this.allTravelTypes, 'itemValue', 'itemName'));
      }
    },

    // 数据获取
    getData() {
      this.showLoading();
      const standardTypeDict = [{
          label: '市内交通费',
          value: 'SNJTF',
        }, {
          label: '餐费',
          value: 'CF',
        }];
      this.$store.dispatch('getReimBursement', {
        fee_reim_id: this.$route.query.id,
        order_type: this.$route.query.type,
      }).then((res) => {
        if (res.code === '0000') {
          this.hideLoading();
          this.firstList = res.data.order_msg;
          this.list = res.data.process_log; // 审批记录
          this.processTable = res.data.process_table; // dai审批记录
          this.order = res.data.order_msg.emsecfeereimh;
          this.getDictData(); // 出差类型code转name
          this.current = res.data.current_process_info.actionUidName
          // budgetFee
          let moneyCat = 0;
          this.arr[0] = this.order.feeTravels;// 行程
          if (this.arr[0]) {
            this.arr[0].forEach((data) => {
              if (data.transportDetails) {
                data.trans = data.transportDetails; // 交通工具
              }
              data.trans.forEach((moneyData) => {
                moneyCat += moneyData.approve_transport_fee;
              });
            });
          }
          this.arr[2] = this.order.rentDetails;// 住宿
          let moneyHotel = 0;
          if (this.arr[2]) {
            this.arr[2].forEach((hotelData) => {
              moneyHotel += hotelData.approve_rent_fee;
            });
          }
          this.arr[3] = this.order.assistantDetails; // 补助
          let subsidy = 0;
          if (this.arr[3]) {
            this.arr[3].forEach((subsidyData) => {
              if (subsidyData.standard_type) {
                subsidyData.standard_type_name = this.$method.getValueInArray(subsidyData.standard_type, standardTypeDict, 'value', 'label');
              }
              subsidy += subsidyData.approve_assistant_fee;
            });
          }
          this.arr[4] = this.order.ecOtherFeeDetails; // 其他
          let other = 0;
          if (this.arr[4]) {
            this.arr[4].forEach((otherData) => {
              other += otherData.approve_other_fee;
            });
          }
          this.cost = other + subsidy + moneyHotel + moneyCat;
        }
      });
    },
    // 撤回申请单按钮
    withdraw() {
      this.show1 = !this.show1;
    },
    // 确定撤回报销单
    onConfirm() {
      this.showLoading();
      this.$store.dispatch('myBillBack', {
        auditNote: '撤回',   //  this.list.fdAuditNote审批意见
        formInstanceId: this.firstList.formInstanceId,  //  EC单
        model_id: '001',
        template_form_id: this.order.form_template_id,  // 表单模板id
      }).then((res) => {
        this.hideLoading();
        if (res.code === '0000') {
          this.$router.push({ path: '/fee/myReimburse/reimburseHome/beingApproved' });
        } else if (res.code && res.msg) {
          this.showToast({ msg: res.msg });
        }
      });
    },
    // 催办
    reminders() {
      this.showLoading();
      this.$store.dispatch('myReminDers', {
        auditNote: '请审批',   //  this.list.fdAuditNote审批意见
        formInstanceId: this.firstList.formInstanceId,  // this.order.formInstanceId EA单
        model_id: '001',
        template_form_id: this.order.form_template_id,  // this.process.flowTemplateId表单模板id
      }).then((res) => {
        if (res.code === '0000') {
          this.hideLoading();
          this.show = !this.show;
          this.title1 = '今天已经成功提醒审批人,明天再来催办吧';
        } else {
          this.title1 = res.msg;
        }
      });
    },
    goBack() {
      this.$router.go(-1);
    },
  },
};
</script>

<style lang='less' scoped>
.flex() {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.top {
  background: #ffffff;
  font-size: 16px;
  list-style: none;
  li {
    .flex;
    padding: 14px 0;
    margin: 0 15px;
    font-size: 16px;
    line-height: 22px;
    text-align: right;
    div {
      max-width: 250px;
    }
    p {
      text-align: left;
      color: #858585;
      &.hidden {
        display: none;
      }
    }
    section {
      font-size: 16px; // font-weight: 100;
      text-align: right;
    }
    .status {
      font-style: normal;
      display: inline-block;
      width: 52px;
      height: 19px;
      border-radius: 12px;
      font-size: 11px;
      color: #ffffff;
      line-height: 18px;
      text-align: center;
      margin-left: 10px;
    }
    .blue {
      background: #3da5fe;
    }
    .yellow {
      background: #FCB23C;
    }
  }
  li:nth-of-type(1) {
    padding: 14px 0 10px 0;
    span {
      font-size: 14px;
      color: #9b9b9b;
      line-height: 20px;
    }
  }
}

.show {
  display: block;
}

.examine {
  margin-top: 10px;
  background: #ffffff;
  .top {
    height: 48px;
    padding: 0 16px;
    .flex; // border-bottom: 1px solid #cbcfd6;
    p {
      color: #fff;
      width: 70px;
      height: 30px;
      background: #3da5fe;
      text-align: center;
      line-height: 30px;
      border-radius: 40px;
    }
  }
}

.addHeight {
  margin-bottom: 100px;
}

.has-bottom {
  margin-top: 10px;
  padding-left: 13px;
  background: #ffffff;
  .accessory {
    margin-top: 10px;
  }
  .router {
    height: 50px;
    .flex;
    color: #858585;
    &.show {
      display: block;
    }
    .detailed {
      font-size: 16px;
      color: #000000;
      padding-right: 13px;
    }
    .detailedMoney {
      font-size: 16px;
      color: #3DA5FE;
      padding-right: 13px;
    }
  }
}

.img {
  width: 7px;
  height: 13px;
  padding-left: 10px;
}

.has-footer {
  .bottom {
    width: 100%;
    height: 50px;
    text-align: center;
    line-height: 50px;
    margin-bottom: 0;
    background: #ffffff;
    box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.1);
    position: fixed;
    bottom: 0;
    &.hidden {
      display: none;
    }
  }
}
</style>
