 <template>
  <div class="content has-footer">
    <my-header :title="top.title" :headerClass="top.headerTop" @previous="goBack"></my-header>
    <div class="invoice-main has-header">
      <div class="invoice columns is-mobile is-gapless">
        <span class="invoice-title">发票号码</span>
        <input v-model="invoice.invoice_num" :disabled="true">
      </div>
      <div class="invoice columns is-mobile is-gapless">
        <span class="invoice-title">开票日期</span>
        <input v-model="invoice.invoice_date" :disabled="true">
      </div>
      <div class="invoice columns is-mobile is-gapless">
        <span class="invoice-title">含税金额</span>
        <currency currency="¥" :value="invoice.invoice_amount" :precision="2" :read-only="true"></currency>
        <!-- <input v-model="invoice.invoice_amount" :disabled="true"> -->
      </div>
      <div class="invoice columns is-mobile is-gapless">
        <span class="invoice-title">税额</span>
        <currency currency="¥" :value="invoice.tax_amount" :precision="2" :read-only="true"></currency>
        <!-- <input v-model="invoice.tax_amount" :disabled="true"> -->
      </div>
      <div class="invoice columns is-mobile is-gapless">
        <span class="invoice-title">不含税金额</span>
        <currency currency="¥" :value="invoice.no_tax_amount" :precision="2" :read-only="true"></currency>
        <!-- <input v-model="invoice.no_tax_amount" :disabled="true"> -->
      </div>
      <div class="invoice columns is-mobile is-gapless">
        <span class="invoice-title">开票方</span>
        <input v-model="invoice.sales_unit_name" :disabled="true">
      </div>
      <div class="invoice columns is-mobile is-gapless flex">
        <span class="invoice-title">税费类型</span>
        <input v-model="invoice.bill_type_name" :disabled="true">
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import myHeader from '../../common/header';
import currency from '../../common/currency';


export default {
  components: {
    myHeader,
    currency,
  },
  data() {
    return {
      invoice: {},
      top: {
        title: '发票详情',
      },
      taxTypeList: [],
      taxType: {},
    };
  },
  methods: {
    formatDate(time) {
      let result = '';
      if (time) {
        const num = new Date(time);
        result = `${num.getFullYear()}-${num.getMonth() + 1}-${num.getDate()}`;
      }
      return result;
    },
    goBack() { // 返回
      this.$router.go(-1);
    },
    // 获取税费类型
    getTaxList() {
      this.showLoading();
      this.$store.dispatch('getQueryIsTax').then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          if (res.data && res.data.info) {
            res.data.info.forEach((item) => {
              if (item.fee_type_id === this.invoice.bill_type_id) {
                this.$set(this.invoice, 'bill_type_name', item.fee_type_name);
              }
            });
          }
        }
      });
    },
  },
  mounted() {
    this.invoice = this.$route.query.invoice;
    this.invoice.invoice_date = this.formatDate(this.invoice.invoice_date);
    console.log(1111, this.invoice.invoice_date);
    this.getTaxList();
  },
};
</script>
<style lang="less" scoped>
@white: #FFFFFF;
@border-grey: #DEDFE0;
.content {
  position: fixed;
  background-color: #f4f4f4;
  top: 0;
  bottom: 0;
  width: 100%;
  z-index: 99;
}

.scale {
  content: "";
  position: absolute;
  left: 0px;
  right: 0px;
  transform: scaleY(.3);
  transform-origin: 0 0;
}

input {
  border: none;
  background: none;
  outline: none;
  font-size: 16px;
  line-height: 22px;
  flex: 1;
  min-width: 150px;
  padding: 0;
  color: #0076FF; // 光标颜色
  text-shadow: 0px 0px 0px #858585; // 字体颜色
  -webkit-text-fill-color: transparent; // 模拟让placeholder成镂空状态
  &::-webkit-input-placeholder {
    color: #C3C3C3;
    opacity: 0.5;
  }
}

p {
  border: none;
  background: none;
  outline: none;
  font-size: 16px;
  line-height: 50px;
  flex: 1;
  min-width: 150px;
  padding: 0;
  color: #0076FF; // 光标颜色
  text-shadow: 0px 0px 0px #858585; // 字体颜色
  -webkit-text-fill-color: transparent; // 模拟让placeholder成镂空状态
}

.bottom-border {
  position: relative;
  &:after {
    .scale;
    bottom: 0px;
    border-bottom: 1px solid @border-grey;
  }
}

.btn-on {
  background: #3DA5FE;
}

.btn-off {
  background: #C1C1C1;
}

.invoice-main {
  background: @white;
  .invoice {
    height: 50px;
    margin: 0;
    margin-left: 15px;
    .bottom-border;
    .invoice-title {
      display: block;
      width: 105px;
      font-size: 16px;
      padding: 14px 0; // margin-right: 18px;
      line-height: 22px;
      color: #000000;
    }
    img {
      width: 24px;
      height: 24px;
      padding: 13px 10px;
    } // .rightArrow {
    //   width: 12px;
    //   height: 20px;
    // }
    .inputBox {
      color: #858585;
    }
    .readonly-input {
      // display: flex;
      border: none;
      background: none;
      outline: none;
      height: 100%;
      font-size: 16px;
      line-height: 22px;
      text-shadow: 0px 0px 0px #858585; // 字体颜色
      -webkit-text-fill-color: transparent; // 模拟让placeholder成镂空状态
      &::-webkit-input-placeholder {
        color: #C3C3C3;
        opacity: 0.5;
      }
    }
    .input-like {
      flex-grow: 1;
      line-height: 50px;
      color: #727272;
      font-weight: normal;
      &.placeholder {
        color: #C3C3C3;
      }
    }
    .invoice-type {
      font-size: 12px;
      color: #3DA5FE;
      line-height: 17px;
      padding: 16px 15px;
    }
  }
  .footer-btn {
    position: fixed;
    bottom: 0;
    width: 100%;
    .btn {
      bottom: 0;
      height: 50px;
      font-size: 18px;
      color: @white;
      box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.10);
      border: none;
      outline: none;
    }
  }
}
</style>
