 <!--
  describe："报销-手工录入发票"
  created by：Yim Lee
  date：2017-12-08
-->
 <template>
  <div class="content has-footer" v-if="show">
    <my-header title="新增发票" :showBack="true" @previous="goBack"></my-header>
    <div class="invoice-main has-header border-bottom">
      <div class="invoice columns is-mobile is-gapless border-bottom">
        <span class="invoice-title">发票号码</span>
        <input placeholder="请输入发票号码" v-model="invoice.invoice_num" v-edit>
      </div>
      <div class="invoice columns is-mobile is-gapless border-bottom">
        <span class="invoice-title">开票日期</span>
        <div class="input-like" :class="{'placeholder': !invoice.invoice_date}" @click="onCellClick" v-edit :data-edit="invoice.invoice_date">{{invoice.invoice_date || '请设置开票日期'}}</div>
        <!-- <input placeholder="请设置开票日期" v-model="invoice.invoice_date" @click="onCellClick"> -->
        <img :src="calendarImg" alt="calendarImg" @click="onCellClick">
      </div>
      <div class="invoice columns is-mobile is-gapless border-bottom">
        <span class="invoice-title">含税金额</span>
        <currency currency="¥" v-model="invoice.invoice_amount" :precision="2" placeholder="请输入含税金额" v-edit></currency>
        <!-- <input placeholder="请输入含税金额" v-model="invoice.invoice_amount" @blur="invoiceCheck"> -->
      </div>
      <div class="invoice columns is-mobile is-gapless border-bottom">
        <span class="invoice-title">税额</span>
        <currency currency="¥" v-model="invoice.tax_amount" :precision="2" placeholder="请输入税额" v-edit></currency>
        <!-- <input placeholder="请输入税额" v-model="invoice.tax_amount" @blur="taxCheck"> -->
      </div>
      <div class="invoice columns is-mobile is-gapless border-bottom">
        <span class="invoice-title">不含税金额</span>
        <currency currency="¥" :value="noTaxAmount" :precision="2" :read-only="true" v-edit></currency>
        <!-- <p class="input-money">{{noTaxAmount}}</p> -->
      </div>
      <div class="invoice columns is-mobile is-gapless border-bottom">
        <span class="invoice-title">开票方</span>
        <input placeholder="请输入开票方" v-model="invoice.sales_unit_name" v-edit>
      </div>
      <div class="invoice columns is-mobile is-gapless flex" v-edit :data-edit="invoice.bill_type_name">
        <span class="invoice-title">税费类型</span>
        <input placeholder="请输入税类型" v-model="invoice.bill_type_name" @click="selectTaxs">
        <img class="rightArrow" :src="rightArrow" alt="rightArrow" @click="selectTaxs">
      </div>
      <div class="footer-btn columns is-mobile is-gapless">
        <button class="btn column" :class="ischeck?'btn-on':'btn-off'" @click="save">确定</button>
      </div>
    </div>
    <calendar :show.sync="showCalendar" v-model="invoice.invoice_date"></calendar>
    <tax-list :show.sync="showTaxs" :options="taxTypeList" v-model="taxType" @getFeeTypes="getFeeTypes"></tax-list>
  </div>
</template>

<script>
import MyHeader from '../../common/header';
import calendar from '../../common/myCalendar';
import currency from '../../common/currency';
import taxList from './taxList';
import calImg from '../../../assets/calendar.png';
import right from '../../../assets/rt-arrow.png';

export default {
  props: {
    show: {
      type: Boolean,
      required: true,
      default: false,
    },
    value: {
      type: Object,
      required: true,
      default: {
        invoice_amount: '',
        invoice_date: '',
        invoice_num: '',
        sales_unit_name: '',
        tax_amount: '',
        invoice_maker: '',
        bill_type_id: '',
        bill_type_name: '',
      },
    },
    // invoiceIndex: {
    //   type: Number,
    //   required: false,
    //   default: -1,
    // },
    // isEdit: {
    //   type: Boolean,
    //   required: false,
    //   default: false,
    // },
  },
  components: {
    MyHeader,
    calendar,
    taxList,
    currency,
  },
  data() {
    return {
      invoice: {},
      taxTypeList: [],
      taxType: {},
      // invoiceClear: {},
      // pick_date: '',
      calendarImg: calImg,  // 日历的图片
      rightArrow: right,    // 右箭头图片
      showCalendar: false,
      // showInvoiceMaker: false,
      // showCancel: true, // 是否显示取消按钮
      showTaxs: false,
    };
  },
  methods: {
    goBack() {
      const _this = this;
      if (this.invoice.invoice_amount !== '' || this.invoice.invoice_date !== '' || this.invoice.sales_unit_name !== '' || this.invoice.invoice_num !== '' || this.invoice.tax_amount !== '') {
        this.$vux.confirm.show({
          title: '返回',
          content: '返回将丢失当前页面数据，确定返回吗？',
          onConfirm() {
            // _this.pick_date = '';
            _this.$emit('hide');
            _this.$emit('update:show', false);
          },
        });
      } else {
        this.$emit('hide', this.invoice);
        this.$emit('update:show', false);
      }
    },
    // 点击选择时间
    // onPickDate() {
    //   this.invoice.invoice_date = this.pick_date;
    // },
    onCellClick() {
      this.showCalendar = true;
    },
    selectTaxs() {
      this.showTaxs = true;
    },
    ahm(a) {
      const b = /^\d{8}$/;
      const c = /^0{8}$/;
      const e = b.test(a);
      const f = c.test(a);
      return e && !f;
      // if (e && !f) {
      //   return true;
      // } else if (!e || f) {
      //   return false;
      // }
      // return false;
    },
    // testNumber(val) {
    //   if (!this.ahm(val) && val !== '') {
    //     this.showToast({ msg: '发票号码格式有误，必须为8位数！', width: '18em', time: 2000 });
    //     return false;
    //   }
    //   return true;
    // },
    // invoiceCheck() {
    //   this.invoice.invoice_amount = this.invoice.invoice_amount ? (parseFloat(this.invoice.invoice_amount)).toFixed(2) : this.invoice.invoice_amount;
    // },
    // taxCheck() {
    //   this.invoice.tax_amount = this.invoice.tax_amount ? (parseFloat(this.invoice.tax_amount)).toFixed(2) : this.invoice.tax_amount;
    //   if (this.noTaxAmount <= 0) {
    //     this.showToast({ msg: '税额不可大于等于含税金额', width: '18em', time: 2000 });
    //     return false;
    //   }
    //   return true;
    // },
    getFeeTypes(data) {
      this.invoice.bill_type_id = data.fee_type_id;
      this.invoice.bill_type_name = data.fee_type_name;
    },
    // getDetail() {
    //   if (this.invoiceIndex !== -1 && this.isEdit === true) {
    //     const invoice = this.emsecfeereimh.invoiceTaxRS[this.invoiceIndex];
    //     this.invoice = {
    //       invoice_amount: invoice.invoice_amount,
    //       invoice_date: invoice.invoice_date.split(' ')[0],
    //       invoice_num: invoice.invoice_num,
    //       sales_unit_name: invoice.sales_unit_name,
    //       tax_amount: invoice.tax_amount,
    //       // tax_rate: invoice.tax_rate,
    //       // no_tax_amount: invoice.no_tax_amount,
    //       invoice_maker: invoice.invoice_maker,
    //       bill_type_id: invoice.bill_type_id,
    //     };
    //     // this.feeTypes = invoice.feeTypes;
    //     // this.pick_date = invoice.invoice_date.split(' ')[0];
    //   }
    // },
    save() {
      // this.invoice.no_tax_amount = (this.invoice.invoice_amount - this.invoice.tax_amount).toFixed(2);
      // this.invoice.tax_rate = parseInt((this.invoice.tax_amount / this.invoice.invoice_amount) * 100);
      if (!this.invoice.invoice_num) {
        this.showToast({ msg: '发票号码不可为空！', width: '18em', time: 2000 });
        return false;
      } else if (!this.invoice.invoice_date) {
        this.showToast({ msg: '开票日期不可为空！', width: '18em', time: 2000 });
        return false;
      } else if (!this.invoice.invoice_amount) {
        this.showToast({ msg: '含税金额要大于0！', width: '18em', time: 2000 });
        return false;
      } else if (!this.invoice.tax_amount) {
        this.showToast({ msg: '税额要大于0', width: '18em', time: 2000 });
        return false;
      } else if (!this.invoice.sales_unit_name) {
        this.showToast({ msg: '销售方不可为空！', width: '18em', time: 2000 });
        return false;
      } else if (!this.invoice.bill_type_id) {
        this.showToast({ msg: '税费类型不可为空！', width: '18em', time: 2000 });
        return false;
      } else if (this.noTaxAmount <= 0) {
        this.showToast({ msg: '税额不可大于等于含税金额', width: '18em', time: 2000 });
        return false;
        // } else if (!this.ahm(this.invoice.invoice_num)) {
        //   this.showToast({ msg: '发票号码格式有误，必须为8位数！', width: '18em', time: 2000 });
        //   return false;
      }
      this.invoice.approve_tax_amount = this.invoice.tax_amount;
      this.$emit('confirm', this.invoice);
      this.$emit('input', this.invoice);
      this.$emit('hide', this.invoice);
      this.$emit('update:show', false);
      return true;
      // else if (this.isEdit) {
      //   const invoice = this.emsecfeereimh.invoiceTaxRS[this.invoiceIndex];
      //   invoice.bill_type_id = this.invoice.bill_type_id;
      //   invoice.invoice_amount = this.invoice.invoice_amount;
      //   invoice.invoice_date = this.invoice.invoice_date;
      //   invoice.invoice_maker = this.invoice.invoice_maker;
      //   invoice.invoice_num = this.invoice.invoice_num;
      //   invoice.sales_unit_name = this.invoice.sales_unit_name;
      //   invoice.tax_amount = this.invoice.tax_amount;
      //   // invoice.no_tax_amount = this.invoice.no_tax_amount;
      //   // invoice.feeTypes = this.feeTypes;
      //   // this.$store.commit('EMSEC_FEEREIMH', this.emsecfeereimh);
      //   // this.invoice = this.invoiceClear;
      //   // this.feeTypes = [{ fee_type_name: '' }];
      //   // this.pick_date = '';
      //   this.$emit('hide');
      //   this.$emit('update:show', false);
      // } else if (this.testNumber(this.invoice.invoice_num) && this.taxCheck()) {
      //   const invoiceTaxRS = {
      //     bill_type_id: this.invoice.bill_type_id,
      //     fee_reim_id: this.emsecfeereimh.fee_rem_id,
      //     invoice_amount: this.invoice.invoice_amount,
      //     invoice_date: this.invoice.invoice_date,
      //     invoice_num: this.invoice.invoice_num,
      //     sales_unit_name: this.invoice.sales_unit_name,
      //     tax_amount: this.invoice.tax_amount,
      //     invoice_maker: this.emsecfeereimh.apply_name,
      //     // tax_rate: this.invoice.tax_rate,
      //     // no_tax_amount: this.invoice.no_tax_amount,
      //     // feeTypes: this.feeTypes,
      //     conversion_rate: 1,
      //     currency_code: 'CNY',
      //     currency_name: '人民币',
      //     invoice_source_system: '',
      //     invoice_tax_r_id: '',
      //   };
      //   // this.invoice = this.invoiceClear; // 清空列表
      //   // this.pick_date = '';
      //   // this.feeTypes = [{ fee_type_name: '' }];
      //   this.emsecfeereimh.invoiceTaxRS.push(invoiceTaxRS);
      //   this.$emit('hide');
      //   this.$emit('update:show', false);
      // }
    },
    getTaxList() {
      this.showLoading();
      this.$store.dispatch('getQueryIsTax').then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          if (res.data && res.data.info) {
            let isDefaultNum = null;
            res.data.info.forEach((item, index) => {
              if (item.fee_type_id === this.invoice.bill_type_id) {
                this.$set(this.invoice, 'bill_type_name', item.fee_type_name);
              }
              if (item.fee_type_id === '394496') {
                // 新增进来的默认值 : “增值税专用发票-非固定资产”
                isDefaultNum = index;
              }
            });
            this.taxTypeList = res.data.info;
            console.log(this.invoice);
            if (!this.invoice.bill_type_id && isDefaultNum >= 0) {
              this.invoice.bill_type_id = this.taxTypeList[isDefaultNum].fee_type_id;
              this.invoice.bill_type_name = this.taxTypeList[isDefaultNum].fee_type_name;
              this.$set(this.invoice, 'bill_type_name', this.taxTypeList[isDefaultNum].fee_type_name);
              this.$set(this.invoice, 'bill_type_id', this.taxTypeList[isDefaultNum].fee_type_id);
            }
          }
        } else {
          this.showToast({ msg: res.msg });
        }
      }, () => {
        this.hideLoading();
        this.showToast({ msg: '页面开小差了' });
      });
    },
  },
  computed: {
    // emsecfeereimh: {
    //   get() {
    //     return this.$store.state.myReimburse.emsecfeereimh;
    //   },
    //   set() {
    //     const emsecfeereimh = Object.assign({}, this.emsecfeereimh, { invoiceTaxRS: this.emsecfeereimh.invoiceTaxRS });
    //     this.$store.commit('EMSEC_FEEREIMH', emsecfeereimh);
    //   },
    // },
    ischeck() {
      return this.invoice.invoice_amount !== '' && this.invoice.invoice_date !== '' && this.invoice.sales_unit_name !== '' && this.invoice.invoice_num !== '' && this.invoice.tax_amount !== '' && this.invoice.bill_type_id;
    },
    noTaxAmount() {
      return this.invoice.invoice_amount - this.invoice.tax_amount;
    },
  },
  watch: {
    show(nVal) {
      if (nVal) {
        this.invoice = this.value;
        this.invoice.invoice_date = this.invoice.invoice_date.split(' ')[0];
        this.taxType.fee_type_id = this.invoice.bill_type_id;
        this.getTaxList();
        // this.invoice = {
        //   invoice_amount: '',
        //   invoice_date: '',
        //   invoice_num: '',
        //   sales_unit_name: '',
        //   tax_amount: '',
        //   // tax_rate: '',
        //   // no_tax_amount: '',
        //   invoice_maker: '',
        //   bill_type_id: '',
        //   bill_type_name: '',
        // };
        // if (this.isEdit) this.getDetail();
      }
    },
  },
  // mounted() {
  //   this.invoiceClear = JSON.parse(JSON.stringify(this.invoice));
  // },
};
</script>
<style lang="less" scoped>
@white: #FFFFFF;
@border-grey: #DEDFE0;
.content {
  position: fixed;
  background-color: #f4f4f4;
  top: 0;
  bottom: 0;
  width: 100%;
  z-index: 99;
}

.scale {
  content: "";
  position: absolute;
  left: 0px;
  right: 0px;
  transform: scaleY(.3);
  transform-origin: 0 0;
}

input {
  border: none;
  background: none;
  outline: none;
  font-size: 16px;
  line-height: 22px;
  flex: 1;
  min-width: 150px;
  padding: 0;
  color: #0076FF; // 光标颜色
  text-shadow: 0px 0px 0px #858585; // 字体颜色
  -webkit-text-fill-color: transparent; // 模拟让placeholder成镂空状态
  &::-webkit-input-placeholder {
    color: #C3C3C3;
    opacity: 0.5;
  }
}

p {
  border: none;
  background: none;
  outline: none;
  font-size: 16px;
  line-height: 50px;
  flex: 1;
  min-width: 150px;
  padding: 0;
  color: #0076FF; // 光标颜色
  text-shadow: 0px 0px 0px #858585; // 字体颜色
  -webkit-text-fill-color: transparent; // 模拟让placeholder成镂空状态
}

.btn-on {
  background: #3DA5FE;
}

.btn-off {
  background: #C1C1C1;
}

.invoice-main {
  background: @white;
  .invoice {
    height: 50px;
    margin: 0;
    margin-left: 15px;
    .invoice-title {
      display: block;
      width: 105px;
      font-size: 16px;
      padding: 14px 0; // margin-right: 18px;
      line-height: 22px;
      color: #000000;
    }
    img {
      width: 24px;
      height: 24px;
      padding: 13px 10px;
    }
    .rightArrow {
      width: 12px;
      height: 20px;
    }
    .inputBox {
      color: #858585;
    }
    .readonly-input {
      // display: flex;
      border: none;
      background: none;
      outline: none;
      height: 100%;
      font-size: 16px;
      line-height: 22px;
      text-shadow: 0px 0px 0px #858585; // 字体颜色
      -webkit-text-fill-color: transparent; // 模拟让placeholder成镂空状态
      &::-webkit-input-placeholder {
        color: #C3C3C3;
        opacity: 0.5;
      }
    }
    .input-like {
      flex-grow: 1;
      line-height: 50px;
      color: #727272;
      font-weight: normal;
      &.placeholder {
        color: #C3C3C3;
      }
    }
    .invoice-type {
      font-size: 12px;
      color: #3DA5FE;
      line-height: 17px;
      padding: 16px 15px;
    }
  }
  .footer-btn {
    position: fixed;
    bottom: 0;
    width: 100%;
    .btn {
      bottom: 0;
      height: 50px;
      font-size: 18px;
      color: @white;
      box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.10);
      border: none;
      outline: none;
    }
  }
}
</style>
