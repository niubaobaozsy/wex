<!--
  describe："附件"
  created by：panjm
  date：2017-11-20
-->
<style lang="less" scoped>

</style>
<template>
  <div class="mine-wrap">
    <div class="mine-content">
      <my-header :title="top.title" @previous="goBack"></my-header>
      <div class="attachmentBox has-header">
        <div class="attachmentItem" v-for="(data, index) in attachmentItem" :key="index">
          <img :src="data.thumbnail_content">
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MyHeader from '../../common/header';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {
      top: {
        title: '附件',
      },
      attachmentItem: [],
    };
  },
  methods: {
    goBack() {
      this.$router.push('/fee');
    },
    getAttachment() {
      const params = {
        source_system: 'Expense',
        source_order_id: this.$route.query.id,
        source_order_type: 'EC',
      };
      this.showLoading();
      this.$store.dispatch('getAttachment', params).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          console.log('附件', res);
          if (res.data && res.data.info) {
            this.attachmentItem = res.data.info;
            this.attachmentItem.forEach((item) => {
              item.thumbnail_content = `data:image/png;base64,${item.thumbnail_content}`;
            });
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
  },
  mounted() {
    this.getAttachment();
  },
};
</script>
<style lang='less' scoped>
.attachmentBox{
  display: inline-flex;
  padding: 10px 10px;
  // border: 1px solid red;
  flex-wrap: wrap;
  background-color: #ffffff;
  .attachmentItem{
    img {
      width: 59px;
      height: 59px;
      margin: 5px 5px 0px;
      border: 1px solid #c1bfbf;
    }

  }
}
</style>

