<!--
  describe：添加借款单
  created by：欧倩伶
  date：2017-11-18
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myReimburse/addInvoice.less';
</style>
<template>
  <div>
    <my-header :title="top.title" :rightItem="'确定'" :showBack="true" :showRedDot="true" @previous="goBack" @on-click="submit"></my-header>
    <div class="has-footer has-header">
      <!-- 借款单列表 -->
      <div v-if="applyList.length">
        <div class="invoiceBox border" v-for="(item, index) in applyList" :key="index" @click="selectLoan(item, index)">
          <div class="invoiceLeft">
            <div class="delItem">
              <img v-if="!item.checked && !item.unop" :src="select" alt="">
              <img v-if="item.checked" :src="selectActive" alt="">
            </div>
            <div class="invoiceType blue">借款</div>
            <div class="invoiceSecondCol">
              <p>{{ item.sensitive_info }}</p>
              <p>{{ item.apply_date }}</p>
            </div>
          </div>
          <div class="invoiceThirdCol">
            <p class="invoicePrice">￥{{ item.approve_amount.toFixed(2) }}</p>
          </div>
        </div>
      </div>
      <div v-if="!applyList.length && !isLoading">
        <img class="no_data_img" src="../../../assets/images/common/no_data.png" alt="">
        <p class="no_data_text">暂无借款信息</p>
      </div>
    </div>
  </div>
</template>
<script>
import MyHeader from '../../common/header';
import select from '../../../assets/images/fee/myReimburse/select.png';
import selectActive from '../../../assets/images/fee/myReimburse/select_active.png';

export default {
  components: {
    MyHeader,
  },

  data() {
    return {
      select,
      selectActive,
      isSave: false,
      isLoading: true,
      currentItem: {},
      top: {
        title: '选择借款单',
      },
      pageInfo: {
        page_number: 1,
        page_size: 10,
      },
      tempType: {
        1: '借款',
      },
      applyList: [],
      selectList: [],
    };
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    selectLoan(item, index) {
      item.checked = !item.checked;
      if (item.checked) {
        this.applyList.forEach((listItem, listIndex) => {
          if (listIndex !== index) {
            listItem.checked = false;
          }
        });
      }
    },
    // 确认
    submit() {
      const feeLoansList = [];
      this.applyList.forEach((item) => {
        if (item.checked) {
          const feeLoans = {
            already_repay_amount: item.already_repay_amount,
            approve_amount: item.approve_amount,
            loan_info_code: item.loan_info_code,
            loan_info_id: item.loan_info_id,
            no_repay_amount: item.no_repay_amount,
            receiver: item.receiver,
            repay_amount: item.approve_amount,
            sensitive_info: item.sensitive_info,
          };
          feeLoansList.push(feeLoans);
        }
      });
      const emsecfeereimh = Object.assign({}, this.emsecfeereimh, { feeLoans: feeLoansList });
      this.$store.commit('EMSEC_FEEREIMH', emsecfeereimh);
      this.$router.go(-1);
    },
    // 请求借款单列表
    getLoanList() {
      this.showLoading();
      console.log(this.emsecfeereimh.company_id, 'this.emsecfeereimh.company_id');
      const params = {
        pageSize: this.pageInfo.page_size,
        pageNumber: this.pageInfo.page_number,
        query_param: {
          apply_name: this.emsecfeereimh.apply_name,
          apply_by: this.emsecfeereimh.apply_by,
          currency_code: 'CNY',
          company_id: this.emsecfeereimh.company_id,
          biz_flag: 0,
        },
      };
      const self = this;
      this.$store.dispatch('selectMyRepayLoan', params).then((res) => {
        this.hideLoading();
        this.isLoading = false;
        if (res && res.code === '0000') {
          if (res.data.totalPage > self.pageInfo.page_number) {
            self.hasNextPage = true;
            self.pageInfo.page_number++;
            this.loadMore = true;
          } else {
            self.hasNextPage = false;
            this.loadMore = false;
          }
          if (res.data && res.data.datalist) {
            res.data.datalist.forEach((item) => {
              item.checked = false;
              this.feeLoanList.forEach((listItem) => {
                if (item.loan_info_id === listItem.loan_info_id) {
                  item.checked = true;
                }
              });
            });
            this.applyList = this.applyList.concat(res.data.datalist);
          } else {
            this.applyList = [];
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
  },
  computed: {
    emsecfeereimh() {
      return this.$store.state.myReimburse.emsecfeereimh;
    },
    feeLoanList() {
      return this.$store.state.myReimburse.emsecfeereimh.feeLoans;
    },
  },
  mounted() {
    this.getLoanList();
  },
};
</script>
