 <!--
  describe：差旅报销（第二步）——“ 行程信息 & 消费记录 ”
  created by：Yim Lee
  date：2017-11-18
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myReimburse/consumeRecord.less';
</style>
 <template>
  <div>
    <!-- 行程信息 -->
    <div class="wrap" v-edit.feeStdExp.overStd :data-edit="travelRoute.length">
      <div class="travel-route border" v-for="(item,index) in travelRoute" :key="index">
        <div class="travel-title border-bottom columns is-mobile is-gapless">
          <div class="show-travel" @click="showRouteInfo(index)"><img :src="item.isshow ? showTravelImg : hideTravelImg"></div>
          <span class="column">行程{{ index+1 }}</span>
          <button @click="deleteRoute(index)">删除</button>
        </div>
        <div class="travel-info" ref="travelInfo">
          <div class="columns is-mobile is-gapless travel-info-item border-bottom">
            <span class="text">地点</span>
            <input-box :placeholder="'出发地'" v-edit.feeStdExp.overStd :data-edit="item.from_area_name || ''" :textCenter="true" :isreadOnly="true" :pickValue="item.from_area_name" @select="openArea('start', index)"></input-box>
            <span class="line">—</span>
            <input-box :placeholder="'目的地'" v-edit.feeStdExp.overStd :data-edit="item.to_area_name || ''" :textCenter="true" :isreadOnly="true" :pickValue="item.to_area_name" @select="openArea('end', index)"></input-box>
          </div>
          <div class="columns is-mobile is-gapless travel-info-item" v-edit.feeStdExp.overStd :data-edit="watchDateStr(item.start_date, item.end_date)" @click="onCellBClick(index)">
            <span class="text">日期</span>
            <div class="date">
              <img class="cal-img" :src="calenderImg" alt="calenderImg">
              <span class="date-info" :class="{placeholder: !dateStr(item.start_date, item.end_date)}">{{dateStr(item.start_date, item.end_date)||'请选择'}}</span>
            </div>
            <img :src="r_arrow" alt="rightArrow" class="rt-arrow">
            <!-- <div class="cal-img" @click="onCellBClick(index)">
              <img :src="calenderImg" alt="calenderImg">
            </div> -->
            <!-- <input-box :placeholder="'请选择'" :textCenter="false" :isreadOnly="true" :pickValue="(item.start_date && item.end_date) ? `${formatDate(item.start_date)} - ${formatDate(item.end_date)}` : ''" @select="onCellBClick(index)"></input-box> -->
            <!-- 右箭头 -->
          </div>
        </div>
      </div>
      <!-- 添加行程按钮 -->
      <div class="add-travle-btn border" @click="addTravelRoute">
        <img :src="addTravelBtn" alt="addTravelBtn">
        <span>添加行程</span>
      </div>
      <!-- 消费记录和商旅系统已使用 -->
      <div class="consume border">
        <div class="columns is-mobile is-gapless border-bottom consume-item" @click="openFeeBudget('feeBudget')">
          <span class="text column">消费记录</span>
          <span class="column count">共{{ totalBudget }}条</span>
          <!-- <span class="text">￥{{ emsecfeereimh.pay_amount.toFixed(2) }}</span> -->
          <span class="text">￥{{ consumeAmount.toFixed(2) }}</span>
          <!-- 右箭头 -->
          <img :src="r_arrow" class="rt-arrow" alt="rightArrow">
        </div>
        <div class="columns is-mobile is-gapless consume-item" @click="openTravelSys">
          <span class="text column">商旅系统已使用</span>
          <span class="text">￥{{travelSysUsedAmount}}</span>
          <!-- 右箭头 -->
          <img :src="r_arrow" alt="rightArrow" class="rt-arrow">
        </div>
      </div>
    </div>
    <calendar :show.sync="showCalendar" v-model="date" @pickDate="onPickDate">
    </calendar>
    <over-standard :show="showReason" @on-select="selectReason" @on-hide="hideReason"></over-standard>
    <select-city
      :headTitle="headTitle"
      :tempType="'travel'"
      v-if="showCity"
      @select-city="selecCity"
      @close-panel="hideCitiesPanel()"></select-city>
  </div>
</template>

<script type="text/ecmascript-6">
import showTravel from '../../../assets/images/fee/myApply/showTravel.png';
import hideTravel from '../../../assets/images/fee/myApply/hideTravel.png';
import add from '../../../assets/images/fee/myApply/addTravelBtn.png';
import InputBox from '../../common/input.vue';
import rArrow from '../../../assets/rt-arrow.png';
import calImg from '../../../assets/images/fee/myApply/calendar.png';
import calendar from '../../common/myCalendar';
import processBar from '../../common/processBar';
import selectCity from '../../common/selectCity';
import overStandard from '../../common/overStandReason';

export default {
  components: {
    InputBox,
    calendar,
    processBar,
    selectCity,
    overStandard,
  },
  data() {
    return {
      travelRoute: [],
      r_arrow: rArrow,   // 右箭头图标的路径
      showTravelImg: showTravel,  // 向下箭头图标的路径
      hideTravelImg: hideTravel,  // 向上箭头图标的路径
      addTravelBtn: add,  // 添加的图标路径
      calenderImg: calImg, // 日历小图标的路径
      showCalendar: false,
      pickValueIndex: 0,
      headTitle: '',
      showCity: false,
      currentIndex: 0, // 当前点击的行程index
      areaType: '',  // 当前正在选择的地点类型（出发地点或目的地点）
      date: [],  // 选择到的日期数组
      showFeeBudget: false,
      next: true,
      feeBudget: true,
      list: [],
      reimburseList: {},
      showReason: false,
      // travelArr: [],
      persons: {},
    };
  },
  computed: {
    // 差旅申请的所有参数
    emsecfeereimh() {
      return this.$store.state.myReimburse.emsecfeereimh;
    },
    // 选中的增值税发票信息列表
    invoiceTaxRS() {
      return this.$store.state.myReimburse.emsecfeereimh.invoiceTaxRS;
    },
    // 差旅申请单列表(预算明细数组)
    emsEcFeeBudgets() {
      return this.$store.state.myReimburse.emsecfeereimh.emsEcFeeBudgets;
    },
    // 行程明细
    feeTravels() {
      return this.$store.state.myReimburse.emsecfeereimh.feeTravels;
    },
    // 第一次保存,后台返回的数据.之后更新带上此数据
    reimInfoBySave() {
      return this.$store.state.myReimburse.reimInfoBySave;
    },
    // 交通消费记录
    transportTotal() {
      let sum = 0;
      this.feeTravels.forEach((item) => {
        if (item.transportDetails) {
          sum += item.transportDetails.length;
        }
      });
      return sum;
    },
    // 消费记录数
    totalBudget() {
      const total = this.transportTotal + this.emsecfeereimh.rentDetails.length + this.emsecfeereimh.assistantDetails.length + this.emsecfeereimh.ecOtherFeeDetails.length;
      return total;
    },
    // 所有类型的总费用（里面包含各类型的总费用）
    fee() {
      return this.$store.state.myReimburse.fee;
    },
    consumeAmount() {
      // return this.$store.state.myReimburse.consumeAmount;
      return this.$store.getters.reimTotalFee;
    },
    travelSysUsedAmount() {
      if (this.$store.state.myReimburse.travelSysUsed.totalAmount) {
        return this.$store.state.myReimburse.travelSysUsed.totalAmount.toFixed(2);
      }
      return 0;
    },
    feeStdExp() {
      return this.$store.state.myReimburse.feeStdExp;
    },
    hasAssistantFeeType() {
      return this.$store.state.menuConfig.fee.hasAssistantFeeType || false;
    },
  },
  methods: {
    // 添加行程
    addTravelRoute() {
      const routeObj = {
        airplane_fee: 0,
        approve_assistance_fee: 0,
        approve_main_fee: 0,
        approve_other_fee: 0,
        approve_rent_fee: 0,
        approve_sundry_fee: 0,
        approve_total_amount: 0,
        assistance_fee: 0,
        auto_fee: 0,
        conversion_rate: 0,
        end_date: '',
        fee_happened_date: '',
        fee_reim_id: '',
        fee_travel_id: '',
        from_area_id: '',
        attribute2: '',
        from_area_name: '',
        lodging_days: 0,
        main_fee: 0,
        other_fee: 0,
        rent_fee: 0,
        ship_fee: 0,
        start_date: '',
        sundry_fee: 0,
        to_area_id: '',
        to_area_name: '',
        total_amount: 0,
        train_fee: 0,
        isclose: false,       // 非接口所有
        // transportDetails: [
        //   {
        //     approve_conversion_rate: 1,
        //     approve_transport_fee: 0,
        //     conversion_rate: 1,
        //     currency_code: 'CNY',
        //     id: '',
        //     transport: 'AIRPLANE',
        //     transport_fee: 0,
        //     travel_id: '',
        //     currency_name: '人民币元',
        //     label: false,    // 非接口所有
        //   },
        // ],
        travel_days: 0,
        // travel_person_count: 0,
        // travel_persons: '',
        // travel_persons_name: '',
      };
      if (!this.feeTravels.length) {
        this.travelRoute = [];
        this.travelRoute.push(Object.assign({}, routeObj, this.persons));
      } else {
        const lastItem = this.feeTravels[this.feeTravels.length - 1];
        routeObj.from_area_name = lastItem.to_area_name;
        routeObj.from_area_id = lastItem.to_area_id;
        this.travelRoute.push(Object.assign({}, routeObj, this.persons));
      }
      this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, { feeTravels: this.travelRoute }));
    },
    // 删除行程
    deleteRoute(index) {
      const _this = this;
      // 在弹窗出现时触发
      this.$vux.confirm.show({
        content: '删除该行程？',
        // 点击“确定”时触发
        onConfirm() {
          _this.travelRoute.splice(index, 1);
          _this.feeTravels.splice(index, 1);
          const emsecfeereimh = Object.assign({}, _this.emsecfeereimh, { feeTravels: _this.feeTravels });
          _this.$store.commit('EMSEC_FEEREIMH', emsecfeereimh);

          // _this.$store.commit('FEE_TRAVELS_INFO', _this.feeTravels);
          // _this.travelRoute.forEach((item) => {
          //   if (item.routeIndex > (index + 1)) {
          //     item.routeIndex--;
          //     _this.$refs.travelInfo[index].hidden = _this.$refs.travelInfo[index + 1].hidden;
          //   }
          // });
          // _this.routeNum--;
        },
      });
    },
    // 点击打开选择城市页面
    openArea(type, index) {
      this.showCity = true;
      this.currentIndex = index;
      this.areaType = type;
      if (type === 'start') {
        this.headTitle = '选择出发地点';
      } else if (type === 'end') {
        this.headTitle = '选择目的地点';
      }
    },
    // 点击选择地点
    selecCity(item) {
      if (this.areaType === 'start') {
        this.travelRoute[this.currentIndex].from_area_name = item.area_name;
        // this.travelRoute[this.currentIndex].from_area_id = item.cityid;
        this.travelRoute[this.currentIndex].from_area_id = item.area_code;
        this.travelRoute[this.currentIndex].attribute2 = item.area_code;
        this.travelRoute[this.currentIndex].from_area = item;
      } else if (this.areaType === 'end') {
        this.travelRoute[this.currentIndex].to_area_name = item.area_name;
        // this.travelRoute[this.currentIndex].to_area_id = item.cityid;
        this.travelRoute[this.currentIndex].to_area_id = item.area_code;
        this.travelRoute[this.currentIndex].attribute2 = item.area_code;
        this.travelRoute[this.currentIndex].to_area = item;
      }
    },
    // 点击选择时间
    onPickDate() {
      this.travelRoute[this.pickValueIndex].start_date = this.date[0];
      this.travelRoute[this.pickValueIndex].end_date = this.date[1];
      this.date = [];
    },
    // 点击打开日历组件
    onCellBClick(index) {
      const arr = [
        this.travelRoute[index].start_date,
        this.travelRoute[index].end_date,
      ];
      this.date = arr;
      this.pickValueIndex = index;
      this.showCalendar = true;
    },
    // 将日期格式化成年月日的形式
    formatDate(date) {
      if (date) {
        const dateObj = new Date(date.split(' ')[0]);
        if (Object.prototype.toString.call(dateObj).slice(8, -1) === 'Date') {
          const month = dateObj.getMonth() + 1;
          const day = dateObj.getDate();
          return `${month}月${day}日`;
        }
      }
      return '';
    },
    dateStr(startDate, endDate) {
      const startDateStr = this.formatDate(startDate);
      const endDateStr = this.formatDate(endDate);
      if (startDateStr && endDateStr) return `${startDateStr} - ${endDateStr}`;
      return '';
    },
    // 点击下拉或折叠行程信息
    showRouteInfo(index) {
      if (this.$refs.travelInfo[index].hidden) {
        this.$refs.travelInfo[index].hidden = false;
        this.travelRoute[index].isshow = true;
      } else {
        this.$refs.travelInfo[index].hidden = true;
        this.travelRoute[index].isshow = false;
      }
    },
    // 计算行程天数
    computeRentDay(startDay, endDay) {
      const start = new Date(Date.parse(startDay)).getTime();
      const end = new Date(Date.parse(endDay)).getTime();
      const rentDays = Math.abs((start - end)) / (24 * 60 * 60 * 1000);
      return rentDays;
    },
    selectReason(param) {
      this.showReason = false;
      this.emsecfeereimh.over_standard_reason = param;
      this.$store.commit('EMSEC_FEEREIMH', this.emsecfeereimh);
    },
    hideReason() {
      this.showReason = false;
    },
    // 点击打开费用预算
    openFeeBudget(type) {
      let next = true;
      if (this.travelRoute.length === 0) {
        this.showToast({ msg: '请添加行程！' });
        return false;
      }
      for (let i = 0; i < this.travelRoute.length; i++) {
        if (this.travelRoute[i].from_area_name === '') {
          this.showToast({ msg: '出发地不能为空！' });
          next = false;
        } else if (this.travelRoute[i].to_area_name === '') {
          this.showToast({ msg: '目的地不能为空！' });
          next = false;
        } else if (this.travelRoute[i].end_date === '') {
          this.showToast({ msg: '行程时间不能为空！' });
          next = false;
        }
        const start = new Date(Date.parse(this.travelRoute[i].start_date)).getTime();
        const end = new Date(Date.parse(this.travelRoute[i].end_date)).getTime();
        if (end < start) {
          this.showToast({ msg: '结束时间不能早于开始时间！' });
          next = false;
        }
      }
      if (!next) {
        return next;
      }
      if (type === 'feeBudget') {
        this.$router.push('/fee/myReimburse/feeBudget');
      } else {
        if (!this.consumeAmount || !this.totalBudget) {
          this.showToast({ msg: '请添加消费记录！' });
          return false;
        }
        return true;
      }
      return true;
    },
    getStandard() {
      return new Promise((resolve) => {
        const commObj = {
          index: 0,
          to_area: '',
          date: null,
          fee_apply_id: '',
          tenant_id: '',
          currency_code: 'CNY',
          currency_name: '人民币',
          conversion_rate: '1',
          approve_conversion_rate: '1',
          reason_desc: '',
          seq_no: '',
          created_by: '',
          created_name: '',
          creation_date: '',
          last_updated_by: '',
          last_updated_name: '',
          last_update_date: '',
          travel_days: 0,
        };
        const param = [];
        this.emsecfeereimh.feeTravels.forEach((item) => {
          let obj = {
            from_area_id: item.from_area_id,
            from_area_name: item.from_area_name,
            from_area_code: item.from_area_id,
            to_area_id: item.to_area_id,
            to_area_name: item.to_area_name,
            to_area_code: item.to_area_id,
            travel_persons: item.travel_persons,
            travel_persons_name: item.travel_persons_name,
            start_date: item.start_date.split(' ')[0],
            end_date: item.end_date.split(' ')[0],
          };
          param.push(obj);
        });
        this.$store.commit('REIM_FEE_STD_EXP', true);
        this.showLoading();
        this.$store.dispatch('getStand', param).then(
          (rep) => {
            this.hideLoading();
            if (rep.code === '0000') {
              const rentList = [];
              const assistantList = [];
              if (rep.data && rep.data.zsList) {
                rep.data.zsList.forEach((item) => {
                  let rentObj = {
                    rent_fee: item.rent_fee,
                    to_area_name: item.to_area_name || '',
                    to_area_id: item.to_area_id || '',
                    attribute2: item.to_area_code || '',
                    end_date: item.end_date || '',
                    start_date: item.start_date || '',
                    travel_persons_name: item.travel_persons_name,
                    travel_persons: item.travel_persons,
                    to_area_code: item.to_area_code,
                    approve_rent_fee: '',
                    is_peer: '',
                    lodging_days: '',
                    rent_id: '',
                  };
                  rentObj = Object.assign({}, rentObj, commObj);
                  rentList.push(rentObj);
                });
              }
              if (rep.data && rep.data.bzList) {
                const standardTypeDict = [{
                    label: '市内交通费',
                    value: 'SNJTF',
                  }, {
                    label: '餐费',
                    value: 'CF',
                  }
                ];
                rep.data.bzList.forEach((item) => {
                  if (item.standard_type) {
                    item.standardType = standardTypeDict.filter((i) => i.value === item.standard_type)[0];
                  }
                  let assistantObj = {
                    assistant_fee: item.assistant_fee,
                    to_area_name: item.to_area_name || '',
                    to_area_id: item.to_area_id || '',
                    attribute2: item.to_area_code || '',
                    end_date: item.end_date || '',
                    start_date: item.start_date || '',
                    assistant_persons_name: item.travel_persons_name,
                    assistant_persons: item.travel_persons,
                    to_area_code: item.to_area_code,
                    approve_assistant_fee: '',
                    assistant_day: '',
                    id: '',
                  };
                  if (this.hasAssistantFeeType) {
                    assistantObj.standard_type = item.standard_type;
                    assistantObj.standardType = item.standardType;
                  }
                  assistantObj = Object.assign({}, assistantObj, commObj);
                  assistantList.push(assistantObj);
                });
              }
              this.reimburseList.rentDetails = rentList;
              this.reimburseList.assistantDetails = assistantList;
              this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, this.reimburseList));
              // this.autoFirstBudget();
              resolve();
            } else if (rep && rep.code) {
              this.showToast({ msg: rep.msg || '获取住宿费和补助费失败' });
            }
          },
        );
      });
    },
    // 下一步
    beforeNext() {
      const budgets = this.emsecfeereimh.emsEcFeeBudgets || [];
      const feeTravels = this.emsecfeereimh.feeTravels || [];
      let feeHappenedDate = 0;
      let feeHappenedDateStr = '';
      feeTravels.forEach((travel) => {
        if (feeHappenedDate < Date.parse(new Date(travel.end_date.split(' ')[0]))) {
          feeHappenedDate = Date.parse(new Date(travel.end_date.split(' ')[0])); // fix IOS new Date() bug
          feeHappenedDateStr = travel.end_date;
        }
      });
      budgets.forEach((budget) => {
        budget.fee_happened_date = feeHappenedDateStr;
      });
      this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, { emsEcFeeBudgets: budgets }));
      const _this = this;
      if (!this.feeStdExp && (this.emsecfeereimh.rentDetails.length || this.emsecfeereimh.assistantDetails.length)) {
        this.$store.commit('REIM_FEE_STD_EXP', true);
        this.$vux.confirm.show({
          title: '提示',
          content: '检测到行程发生变化，是否重新生成住宿及补助费用？',
          onConfirm() {
            _this.getStandard().then(() => {
              _this.$parent.goNext();
            });
          },
          onCancel() {
            _this.$parent.goNext();
          },
        });
      } else {
        this.$store.commit('REIM_FEE_STD_EXP', true);
        return this.openFeeBudget('next');
      }
    },
    // 打开“商旅系统已使用”
    openTravelSys() {
      this.$router.push('/fee/myReimburse/travelSysUsed');
    },
    // 校验报销单
    checkFeeReim() {
      const params = {
        fee_reim_id: this.reimInfoBySave.fee_reim_id, // this.reimInfoBySave.fee_reim_id
        order_current_status: 'EDIT',  // 获取当前单据状态, EDIT(提单)/APPROVE(审单)
      };
      this.showLoading();
      this.$store.dispatch('frCheckFeeReim', params)
        .then((rep) => {
          this.hideLoading();
          if (rep && rep.code) {
            let goNext = false; // 是否可以跳转到提交报销单页面
            const self = this;
            if (rep.code === '0000') {
              goNext = true;
            }
            if (rep.code !== '0000' && !rep.data) {
              this.$vux.confirm.show({
                content: rep.msg,
                onConfirm() {
                  goNext = false;
                },
              });
              return false;
            } else if (rep.data.checkBudgetResult) { // 预算校验结果，该对象为空，则该项校验通过
              if (rep.data.checkBudgetResult.code === '1') {
                goNext = true;
              } else if (rep.data.checkBudgetResult.code === '0' || rep.data.checkBudgetResult.code === '2') {
                this.$vux.confirm.show({
                  content: rep.data.checkBudgetResult.msgObjList[0].msg,
                  onConfirm() {
                    goNext = false;
                  },
                });
                return false;
              } else if (rep.data.checkBudgetResult.code === '3') {
                goNext = false;
                this.$vux.confirm.show({
                  content: rep.data.checkBudgetResult.msgObjList[0].msg,
                  onConfirm() {
                    goNext = true;
                  },
                });
                return false;
              }
            } else if (rep.data.checkHLResult) { // 头行校验结果，该对象为空，则该项校验通过
              this.$vux.confirm.show({
                content: rep.data.checkHLResult.msgNodeList[0].msg,
                onConfirm() {
                  goNext = false;
                },
              });
              return false;
            } else if (rep.data.checkStandardResult) { // 标准校验结果，该对象为空，则该项校验通过
              this.emsecfeereimh.is_over_standard = 'Y';
              goNext = false;
              this.$vux.confirm.show({
                content: rep.data.checkStandardResult.msgNodeList[0].msg,
                onConfirm() {
                  self.showReason = true;
                },
              });
              return false;
            } else if (rep.data.checkFeeDetailResult) { // 费用信息校验结果，该对象为空，则该项校验通过
              this.$vux.confirm.show({
                content: rep.data.checkFeeDetailResult.msgNodeList[0].msg,
                onConfirm() {
                  goNext = false;
                },
              });
              return false;
            } else if (rep.data.checkTravelResult) { // 差旅信息校验结果，该对象为空，则该项校验通过
              this.$vux.confirm.show({
                content: rep.data.checkTravelResult.msgNodeList[0].msg,
                onConfirm() {
                  goNext = false;
                },
              });
              return false;
            } else if (rep.data.checkFeeLoanResult) { // 核算明细校验结果，该对象为空，则该项校验通过
              this.$vux.confirm.show({
                content: rep.data.checkFeeLoanResult.msgNodeList[0].msg,
                onConfirm() {
                  goNext = false;
                },
              });
              return false;
            } else if (rep.data.checkApplyResult) { // 申请单校验结果，该对象为空，则该项校验通过
              this.$vux.confirm.show({
                content: rep.data.checkApplyResult.msgNodeList[0].msg,
                onConfirm() {
                  goNext = false;
                },
              });
              return false;
            } else if (rep.data.checkTaxResult) { // 税明细校验结果，该对象为空，则该项校验通过
              this.$vux.confirm.show({
                content: rep.data.checkTaxResult.msgNodeList[0].msg,
                onConfirm() {
                  goNext = false;
                },
              });
              return false;
            }
            if (!goNext) {
              this.next = false;
            }
            this.next = true;
          }
          if (!this.next) {
            return false;
          }
          if (this.emsecfeereimh.is_over_standard === 'Y') {
            if (!this.emsecfeereimh.over_standard_reason) {
              return false;
            }
            this.$router.push({ path: '/fee/myReimburse/invoiceBudget' });
            return true;
          }
          this.$router.push({ path: '/fee/myReimburse/invoiceBudget' });
          return true;
        }, () => {
          this.hideLoading();
          this.showToast({ msg: '页面开小差了', width: '12em' });
        });
    },
    watchDateStr(date1, date2) {
      return `${date1}/${date2}`;
    },
    hideCitiesPanel() {
      this.showCity = false;
    }
    // consumerRecordStr() {
    //   const recordStr = '';
    //   this.emsecfeereimh.feeTravels.forEach((item) => {

    //   });
    // },
  },
  activated() {
    // this.reimburseList = this.emsecfeereimh;
    this.travelRoute = this.feeTravels;
    this.persons.travel_person_count = this.feeTravels[0].travel_person_count;
    this.persons.travel_persons = this.feeTravels[0].travel_persons;
    this.persons.travel_persons_name = this.feeTravels[0].travel_persons_name;
    if (!this.feeTravels[0]) {
      this.addTravelRoute();
    }
  },
};
</script>
