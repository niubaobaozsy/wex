<!--
  describe：差旅报销（第1步）——“ 填写基础信息 & 关联申请单 ”
  created by：黄喆
  date：2017-11-20
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myReimburse/basicInformation.less';
</style>
<template>
  <div>
    <div class="wrap">
      <ul class="information">
        <li class="information-list border-bottom" @click="showSetTpl">
          <div class="list-between">
            <span class="type">类型</span>
          </div>
          <div class="list-between">
            <span class="choice randomly">{{reimburseTypeStr}}</span>
            <img v-if="tplCanModify" :src="r_Arrow" alt="" class="r-arrow">
          </div>
        </li>
        <!-- <li class="information-list border-bottom" @click="showRelated=true" v-edit :data-edit="relatedApplyIdStr"> -->
        <li class="information-list border-bottom" @click="changeShowRelated" v-edit :data-edit="relatedApplyIdStr">
          <div class="list-between">
            <span class="type">关联申请单</span>
          </div>
          <div class="list-between">
            <span :class="['choice', {'randomly': relatedApplyStr}]">{{relatedApplyStr || '请选择'}}</span>
            <img :src="r_Arrow" alt="" class="r-arrow">
          </div>
        </li>
        <li class="information-list border-bottom" @click="reimbursement" v-edit :data-edit="emsecfeereimh.apply_by">
          <div class="list-between">
            <span class="type">报销人</span>
          </div>
          <div class="list-between">
            <span :class="['choice', {'randomly': emsecfeereimh.apply_name}]">{{emsecfeereimh.apply_name || '请选择'}}</span>
            <img :src="r_Arrow" alt="" class="r-arrow">
          </div>
        </li>
        <li class="information-list border-bottom travle-type" v-if="reimburseType ==='CL' && myApplyMenuCfg[reimburseType].hasTravelType">
          <div class="list-between">
            <span class="type">出差类型</span>
          </div>
          <div class="list-between">
             <span class="choice randomly">{{selectTravle}}</span>
          </div>
        </li>

        <li class="international" v-if="isUrgentCfg">
          <group class="set-international">
            <x-switch title="是否加急" v-model="is_urgent" :value-map="['N','Y']"></x-switch>
          </group>
        </li>

        <li class="information-list border-bottom" @click="getTogether" v-if="reimburseCreate.reimburseType !== 'TY'" v-edit.feeStdExp.overStd :data-edit="feeTravels[0]?feeTravels[0].travel_persons:''">
          <div class="list-between">
            <span class="type" v-if="reimburseCreate.reimburseType === 'CL' && myApplyMenuCfg[reimburseCreate.reimburseType].compnayPayAir">出行人</span>
            <span class="type" v-else>出差人</span>
          </div>
          <div style="flex: 1">
            <div class="list-right">
              <span v-if="togetherNumber > 0">
                {{togetherNumber === 1 ? feeTravels[0].travel_persons_name : `共${togetherNumber}人`}}
              </span>
              <span class="message" v-if="togetherNumber == 0">请选择</span>
              <img :src="r_Arrow" alt="" class="r-arrow">
            </div>
            <div class="batch" v-if="togetherNumber > 1">
              <span class="go-name">{{feeTravels[0].travel_persons_name}}</span>
            </div>
          </div>
        </li>
        <li class="information-list border-bottom describe" :class="{'notice': notice && !reasonDescS}">
          <div class="list-between no-center">
            <span class="type">业务描述</span>
          </div>
          <div class="textarea-text">
            <div class="text">{{reasonDesc}}</div>
            <textarea class="textarea" :class="{'notice': notice && !reasonDescS}" placeholder="请填写 (必填)" maxlength="40" v-model="reasonDesc" v-edit></textarea>
          </div>
          <span class="wordlimit">{{reasonDesc?`${reasonDescS}/40`: "0/40"}}</span>
        </li>
        <li class="information-list border-bottom" @click="getPayer" v-edit :data-edit="receiverStr">
          <div class="list-between">
            <span class="type">收款方</span>
          </div>
          <div class="list-between">
            <span :class="['choice', {'randomly': receiverStr}]">{{receiverStr || '请选择'}}</span>
            <img :src="r_Arrow" alt="" class="r-arrow">
          </div>
        </li>
        <li class="information-list border-bottom" @click="getMoneyCompany" v-edit :data-edit="coId">
          <div class="list-between">
            <span class="type">入帐单位</span>
          </div>
          <div class="list-between">
            <span :class="['choice', {'randomly': coStr}]">{{coStr || '请选择'}}</span>
            <img :src="r_Arrow" alt="" class="r-arrow">
          </div>
        </li>
      </ul>
    </div>
    <actionsheet v-model="showAction" :menus="menus" :show-cancel="showCancel" @on-click-menu="setTpl">
    </actionsheet>
    <org v-model="orgnization" :show.sync="showOrg" :multi="multiUser" @confirm="onOrgConfirm" />
    <!-- <related-apply :type="reimburseType" ref="relatedApply" :list="requisition" @getDatalist="getRelatedlist" :show.sync="showRelated" @on-hide="showRelated=false" @getDatalistid="getidDatalist"></related-apply> -->
    <association-apply v-model="requisition" :show.sync="showRelated" :type="reimburseType" @confirm="onAssociationConfirm" :traveltype="travelTypeListData" />
    <receiver v-model="receiver" :show.sync="showReceiver" :coId="coId" />
    <co :show.sync="showCo" :defCo="defaultConfig.companys" @confirm="onSelectCo" />
  </div>
</template>
<script type="text/ecmascript-6">
import { Actionsheet, Group, XSwitch  } from 'vux';
import rArrow from '../../../assets/rt-arrow.png';
import org from '../../common/org';
import relatedApply from '../../common/relatedApply';
import receiver from '../../common/receiver';
import co from '../../common/company';
import associationApply from '../../common/associationApply';

export default {
  components: {
    Actionsheet,
    Group,
    XSwitch,
    org,
    relatedApply,
    receiver,
    co,
    associationApply,
  },
  data() {
    return {
      lengths: 0,
      r_Arrow: rArrow,
      showAction: false,
      showCancel: true, // 是否显示取消按钮
      orgnization: [],
      together: [],
      showOrg: false,
      showRelated: false,
      multiUser: false,
      newEmseaapplyh: {},
      showCo: false,
      menus: {
        menu0: '<span style="color: #666666;">差旅报销(国内)</span>',
        menu1: '<span style="color: #666666;">费用报销(个人)</span>',
      },
      dataList: [],
      showReceiver: false,
      emsecfeebudgets: [],
      notice: false,
      canModify: true,
      travelTypeListData: {}, // 显示出差类型的数据
    };
  },
  computed: {
    // 出差类型，根据引用申请单上的出差类型展示，不能修改
    selectTravle() {
      if (this.emsecfeereimh.attribute3) {
        return this.travelTypeListData[this.emsecfeereimh.attribute3];
      }
    },
    myApplyMenuCfg() {
      return this.$store.state.menuConfig.fee.children.myApply.children;
    },
    isUrgentCfg(){
       return this.$store.state.menuConfig.fee.children.myApply.isUrgent
    },
    is_urgent:{
      get() {
        if (this.isUrgentCfg) {
          return this.$store.state.myReimburse.emsecfeereimh.is_urgent || 'N';
        }
      },
      set(value) {
        if (this.isUrgentCfg) {
          this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, { is_urgent: value }));
        }
      },
    },
    tplCanModify() {
      if (!this.canModify) {
        return this.canModify;
      }
      return !this.emsecfeereimh.fee_reim_id;
    },
    defaultConfig() {
      return this.$store.state.login.defCfg;
    },
    // relatedList() {
    //   return this.$store.state.myReimburse.relatedList;
    // },
    requisition: {
      get() {
        // const budgets = this.emsecfeereimh.emsEcFeeBudgets;
        // const arr = [];
        // if (budgets.length) {
        //   budgets.forEach((budget) => {
        //     arr.push({
        //       fee_apply_id: budget.fee_apply_id,
        //       fee_apply_l_id: budget.fee_apply_l_id,
        //       approve_reim_amount: budget.approve_reim_amount,
        //       apply_reim_amount: budget.apply_reim_amount,
        //       // sensitive_info: budget.sensitive_info,
        //       // reason_desc: budget.reason_desc,
        //     });
        //   });
        // }
        // return arr;
        return this.$store.state.myReimburse.relatedList;
      },
      set(value) {
        this.getRelatedlist(value);
      },
    },
    emsecfeereimh() {
      return this.$store.state.myReimburse.emsecfeereimh;
    },
    // 模版类型，国内或者费用报销
    reimburseCreate() {
      return this.$store.state.myReimburse.reimburseCreate;
    },
    reimburseType() {
      return this.$store.state.myReimburse.reimburseCreate.reimburseType;
    },
    reimburseTypeStr() {
      switch (this.reimburseType) {
        case 'CL':
          this.orderTypeCode = 'EC_CL';
          if (this.myApplyMenuCfg.CL.hasTravelType) {
            return '差旅报销(确定行程)';
          }
          return '差旅报销(国内)';
        case 'TY':
          this.orderTypeCode = 'EC_TY';
          return '其它费用报销(个人)';
        default:
          return '';
      }
    },

    // 同行人信息
    feeTravels() {
      return this.$store.state.myReimburse.emsecfeereimh.feeTravels;
    },
    // 报销人
    applyer() {
      const emsecfeereimh = this.$store.state.myReimburse.emsecfeereimh;
      return [{ user_full_name: emsecfeereimh.apply_name, user_id: emsecfeereimh.apply_by }] || [];
    },
    // 同行人
    travelers() {
      const feeTravels = this.feeTravels[0];
      const travelPersons = (feeTravels && feeTravels.travel_persons) ? feeTravels.travel_persons.split(',') : [];
      const travelPersonsName = feeTravels ? feeTravels.travel_persons_name.split(',') : [];
      const users = [];
      travelPersons.forEach((person, index) => {
        if (person) {
          const user = {
            user_full_name: travelPersonsName[index],
            user_id: person,
          };
          users.push(user);
        }
      });
      return users;
    },
    // 计算同行人数量
    togetherNumber() {
      const travelPersons = this.feeTravels;
      return (travelPersons.length && travelPersons[0].travel_persons_name) ? travelPersons[0].travel_persons_name.split(',').length : 0;
    },
    // 计算业务描述字数
    reasonDescS() {
      return this.reasonDesc ? this.reasonDesc.length : 0;
    },
    reasonDesc: {
      get() {
        return this.emsecfeereimh.sensitive_info;
      },
      set(...rest) {
        const emsecfeereimh = Object.assign({}, this.emsecfeereimh, { sensitive_info: rest[0] });
        this.$store.commit('EMSEC_FEEREIMH', emsecfeereimh);
      },
    },
    receiver: {
      get() {
        const obj = {};
        if (this.emsecfeereimh.receiver) {
          obj.receiver = this.emsecfeereimh.receiver;
          obj.receiver_en = this.emsecfeereimh.receiver_en;
          obj.bank_name = this.emsecfeereimh.bank_name;
          obj.bank_code = this.emsecfeereimh.bank_code;
          obj.bank_account = this.emsecfeereimh.bank_account;
          obj.bank_adress = this.emsecfeereimh.bank_adress;
          this.createObjAttr(obj, 'vendor_type', this.emsecfeereimh.vendor_type);
          this.createObjAttr(obj, 'vendor_id', this.emsecfeereimh.vendor_id);
          this.createObjAttr(obj, 'vendor_code', this.emsecfeereimh.vendor_code);
          this.createObjAttr(obj, 'vendor_name', this.emsecfeereimh.vendor_name);
          this.createObjAttr(obj, 'vendor_site_id', this.emsecfeereimh.vendor_site_id);
          this.createObjAttr(obj, 'vendor_site_code', this.emsecfeereimh.vendor_site_code);
          this.createObjAttr(obj, 'vendor_site_name', this.emsecfeereimh.vendor_site_name);
        } else if (!this.emsecfeereimh.receiver && this.defaultConfig.cmEmsEmpReceiver) {
          const defaultReceiver = this.defaultConfig.cmEmsEmpReceiver;
          obj.receiver = defaultReceiver.receiver;
          obj.receiver_en = defaultReceiver.receiver_en;
          obj.bank_name = defaultReceiver.bank_name;
          obj.bank_code = defaultReceiver.bank_code;
          obj.bank_account = defaultReceiver.bank_account;
          obj.bank_adress = defaultReceiver.bank_adress;
          this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, obj));
        }
        return obj;
      },
      set(value) {
        const obj = {
          receiver: value.receiver,
          receiver_en: value.receiver_en,
          bank_name: value.bank_name,
          bank_code: value.bank_code,
          bank_account: value.bank_account,
          bank_adress: value.bank_adress,
        };
        this.createObjAttr(obj, 'vendor_type', value.vendor_type);
        this.createObjAttr(obj, 'vendor_id', value.vendor_id);
        this.createObjAttr(obj, 'vendor_code', value.vendor_code);
        this.createObjAttr(obj, 'vendor_name', value.vendor_name);
        this.createObjAttr(obj, 'vendor_site_id', value.vendor_site_id);
        this.createObjAttr(obj, 'vendor_site_code', value.vendor_site_code);
        this.createObjAttr(obj, 'vendor_site_name', value.vendor_site_name);
        this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, obj));
      },
    },
    // 收款方信息
    receiverStr() {
      if (Object.keys(this.receiver).length) {
        return `${this.receiver.receiver}[尾号${this.receiver.bank_account.slice(-4)}]`;
      }
      return '';
    },
    coId() {
      return this.$store.state.myReimburse.emsecfeereimh.company_id || '';
    },
    // 收款账户信息
    coStr() {
      let company = this.$store.state.myReimburse.emsecfeereimh.company_name;
      if (!company) {
        company = this.defaultConfig.company || {};
        this.onSelectCo(company);
        return company.company_name;
      }
      return company;
    },
    // 关联申请单
    relatedApplyStr() {
      let result = '';
      if (this.requisition.length) {
        let relatedAmount = 0;
        this.requisition.forEach((apply) => {
          relatedAmount += Number(apply.avail_amount);
        });
        result = `￥${relatedAmount.toFixed(2)}[共${this.requisition.length}张]`;
      }
      return result;
    },
    relatedApplyIdStr() {
      let result = '';
      if (this.requisition.length) {
        this.requisition.forEach((apply) => {
          result += `/${apply.fee_apply_l_id}`;
        });
      }
      return result;
    },
  },
  mounted() {
    console.log('lei', this.myApplyMenuCfg.CL);
    // 判断是否要显示可选类型
    if (this.$route.query.addType && (this.$route.query.addType === 'CL' || this.$route.query.addType === 'TY')) {
      // this.showAction = false;
      this.canModify = false;
    }
     if (this.myApplyMenuCfg.CL.hasTravelType) {
        this.menus.menu0 = '<span style="color: #666666;">差旅报销(确定行程)</span>';
     }
    // 保存原始的store数据
    const billId = this.$route.query.id;
    const reimburseType = this.$route.query.type;

    if (billId && reimburseType && !this.reimburseType) {
      this.$store.commit('REIMBURSE_CREATE', { reimburseType });
      this.getBillDetail();
    } else if (!billId && !reimburseType && !this.reimburseType) {
      this.showAction = true;
      this.$store.commit('REIMBURSE_CREATE', { reimburseType: 'CL' });
      this.$nextTick(() => {
        this.initNewReimburse();
        this.getFormTemplates();
      });
    } else if (!billId && !reimburseType && this.reimburseType) {
      this.initNewReimburse();
      this.getFormTemplates();
    }
    this.getDictData(); // 获取下拉数据
  },
  methods: {
    changeShowRelated() {
      this.showRelated = true;
    },
    // 批量获取业务字典编码对应的数据
    async getDictData() {
      if (this.reimburseType === 'CL' && this.myApplyMenuCfg[this.reimburseType].hasTravelType) {
        this.allTravelTypes = await this.$method.getDataFromDict('TRAVEL_TYPE'); // 获取所有出差类型数据
        this.travelTypeListData = {};
        this.allTravelTypes.forEach(item => {
          this.travelTypeListData[item.itemValue] = item.itemName;
        })
      }
    },
    initNewReimburse() {
      const userInfo = this.$store.state.userInfo.user;
      const orgId = Object.keys(userInfo.org)[0];
      const orgName = userInfo.org[orgId];
      const emseaapplyh = {
        tenant_id: userInfo.tenantId,
        created_by: userInfo.userId,
        created_name: userInfo.userName,
        apply_by: this.emsecfeereimh.apply_by ? this.emsecfeereimh.apply_by : userInfo.userId,
        apply_name: this.emsecfeereimh.apply_name ? this.emsecfeereimh.apply_name : userInfo.userName,
        org_id: orgId,
        org_name: orgName,
        reim_date: this.getCurTimeStr(),
        creation_date: this.getCurTimeStr(),
      };

      if (!this.feeTravels[0] || !this.feeTravels[0].travel_persons) {
        emseaapplyh.feeTravels = [{
          travel_persons: userInfo.userId,
          travel_persons_name: userInfo.userName,
        }];
      }
      if (this.reimburseType !== 'CL') {
        emseaapplyh.feeTravels = [];
      }
      this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, emseaapplyh));
    },
    // 路由有iD时候获取数据
    getBillDetail() {
      const params = {
        fee_reim_id: this.$route.query.id,
        is_myrun: 'N',
      };
      this.showLoading();
      this.$store.dispatch('getFeeReimByIdForApp', params)
        .then((rep) => {
          this.hideLoading();
          if (rep.code === '0000') {
            const emsecfeereimh = rep.data.order_msg.emsecfeereimh;
            const standardTypeDict = [{
                label: '市内交通费',
                value: 'SNJTF',
              }, {
                label: '餐费',
                value: 'CF',
              }
            ];
            if (emsecfeereimh.assistantDetails) {
              emsecfeereimh.assistantDetails.forEach((item) => {
                if (item.standard_type) {
                  item.standardType = standardTypeDict.filter((i) => i.value === item.standard_type)[0];
                }
              });
            }
            this.$store.commit('EMSEC_FEEREIMH', emsecfeereimh);
            if (emsecfeereimh.eaApplys.length) {
              this.$store.commit('RELATED_LIST', emsecfeereimh.eaApplys);
              this.travelSys(emsecfeereimh.eaApplys,'init');
            }
            this.consumeAmount(emsecfeereimh);
          } else {
            this.hideLoading();
            this.showToast({ msg: rep.msg });
          }
        });
    },
    fillFeeDetail(applyIdList) {
      this.showLoading();
      this.$store.dispatch('getFeeDetail', applyIdList)
        .then((rep) => {
          this.hideLoading();
          if (rep && rep.code === '0000' && rep.data) {
            let feeLoans = [];
            if (rep.data.feeLoans.length && Object.keys(rep.data.feeLoans[0]).length) {
              feeLoans = Object.assign([], rep.data.feeLoans);
            }

            // const assistantDetails = Object.assign([], this.emsecfeereimh.assistantDetails, rep.data.assistantDetails);
            // const rentDetails = Object.assign([], this.emsecfeereimh.rentDetails, rep.data.rentDetails);
            // const feeTravels = Object.assign([], this.emsecfeereimh.feeTravels, rep.data.feeTravels);
            // const ecOtherFeeDetails = Object.assign([], this.emsecfeereimh.ecOtherFeeDetails, rep.data.ecOtherFeeDetails);
            // this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, { assistantDetails, rentDetails, feeTravels, ecOtherFeeDetails, feeLoans }));
            const standardTypeDict = [{
                label: '市内交通费',
                value: 'SNJTF',
              }, {
                label: '餐费',
                value: 'CF',
              }
            ];
            if(rep.data.assistantDetails){
              rep.data.assistantDetails.forEach((item) => {
                if (item.standard_type) {
                  item.standardType = standardTypeDict.filter((i) => i.value === item.standard_type)[0];
                }
              })
            }
            this.emsecfeereimh.assistantDetails = Object.assign([], rep.data.assistantDetails);
            this.emsecfeereimh.rentDetails = Object.assign([], rep.data.rentDetails);
            if (this.emsecfeereimh.feeTravels.length && !rep.data.feeTravels.length) {
              // this.emsecfeereimh.feeTravels = Object.assign([], rep.data.feeTravels);
              const feeTravel = [{
                travel_persons: this.emsecfeereimh.feeTravels[0].travel_persons,
                travel_persons_name: this.emsecfeereimh.feeTravels[0].travel_persons_name,
                travel_person_count: this.emsecfeereimh.feeTravels[0].travel_person_count,
              }];
              this.emsecfeereimh.feeTravels = feeTravel;
            } else {
              this.emsecfeereimh.feeTravels = Object.assign([], rep.data.feeTravels);
            }
            this.emsecfeereimh.ecOtherFeeDetails = Object.assign([], rep.data.ecOtherFeeDetails);
            this.emsecfeereimh.feeLoans = feeLoans;
            this.$store.commit('EMSEC_FEEREIMH', this.emsecfeereimh);

            this.consumeAmount(this.emsecfeereimh);
            const arrBudgets = this.emsecfeereimh.emsEcFeeBudgets;
            // let date = 0;
            // arrBudgets.forEach((apply, index) => {
            //   const endDateStr = rep.data.feeTravels[index].end_date;
            //   const endDate = Date.parse(new Date(endDateStr));
            //   if (date < endDate) {
            //     date = endDate;
            //     apply.fee_happened_date = endDateStr;
            //   }
            // });
            this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, { emsEcFeeBudgets: arrBudgets }));
          } else if (rep && rep.code) {
            this.showToast({ msg: `请求异常[${rep.code}]` });
          }
        });
    },
    getRelatedlist(list) {
      // 选ea单后处理
      if (list.length) {
        const budgets = [];
        const applyIdList = [];
        list.forEach((apply) => {
          const budget = {
            fee_apply_id: apply.fee_apply_id,
            fee_apply_l_id: apply.fee_apply_l_id,
            currency_code: 'CNY',
            currency_name: '人民币',
            conversion_rate: 1,
            apply_reim_amount: apply.avail_amount,
            approve_reim_amount: apply.avail_amount,
            avail_amount: apply.avail_amount,
            created_by: apply.apply_by,
            created_name: apply.apply_name,
            fee_happened_date: apply.apply_date,
            fee_reim_id: this.emsecfeereimh.fee_reim_id,
            budget_headers_id: apply.budget_headers_id,
            budget_name: apply.budget_name,
            budget_node_desc: apply.budget_node_desc,
            budget_node_id: apply.budget_node_id,
            budget_node_name: apply.budget_node_name,
            busi_org_id: apply.busi_org_id,
            busi_org_name: apply.busi_org_name,
            fee_type_id: apply.bill_type_id,
            fee_type_name: apply.bill_type_name,
            bill_type_id: apply.bill_type_id,
            bill_type_name: apply.bill_type_name,
            is_last_reim: 'N',
            is_released_budget: 'N',
            sensitive_info: apply.reason_desc, // sensitive_info：引了ea单，取ea行预算的reason_desc，没有引ea单，则取'';
            mainorg_layer: 'COMPANY',
            product_line_id: '-1',
          };
          if (this.reimburseType === 'TY') {
            budget.fee_happened_date = '';
          }
          budgets.push(budget);
          applyIdList.push(apply.fee_apply_id);
        });
        this.$store.commit('RELATED_LIST', list);
        this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, { emsEcFeeBudgets: budgets }));
        this.fillFeeDetail({ applyIds: applyIdList, orderType: this.reimburseType });
      } else {
        this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, { emsEcFeeBudgets: [] }));
      }
    },
    //    草稿进入关联申请单
    getidDatalist() {
      // if (this.emsecfeereimh.fee_apply_id) {
      //   const arr = this.emsecfeereimh.fee_apply_id.split(',');
      //   let messages = 0;
      //   list.forEach((item) => {
      //     if (arr.indexOf(item.fee_apply_id) !== -1) {
      //       messages += item.approve_amount - 0;
      //     }
      //   });
      //   const emsecfeereimh = Object.assign({}, this.emsecfeereimh, { messages_apply: `共${arr.length}张，￥${messages.toFixed(2)}` });
      //   this.$store.commit('EMSEC_FEEREIMH', emsecfeereimh);
      // }
    },
    getCurTimeStr() {
      const time = new Date();
      return `${time.getFullYear()}-${time.getMonth() < 9 ? '0' : ''}${time.getMonth() + 1}-${time.getDate() <= 9 ? 0 : ''}${time.getDate()}`;
    },
    // 点击改变tpye类型
    showSetTpl() {
      if (this.tplCanModify) {
        this.showAction = true;
      } else if (!this.canModify) {
        this.showToast({ msg: '此单据不能修改类型', width: '9em' });
      } else {
        this.showToast({ msg: '单据已保存草稿，不能修改类型', width: '9em' });
      }
    },
    // 点击获取报销人同行人
    reimbursement() {
      if (this.emsecfeereimh.apply_by) {
        this.orgnization = this.applyer;
      } else {
        this.orgnization = [];
      }
      this.showOrg = true;
      this.multiUser = false;
    },
    // 点击获取同行人
    getTogether() {
      this.orgnization = this.travelers;
      this.showOrg = true;
      this.multiUser = true;
    },
    // 点击获取付款方
    getPayer() {
      this.showReceiver = true;
    },
    getMoneyCompany() {
      this.showCo = true;
    },
    setTpl(key) { // 点击弹出差旅单类型选择组件
      let reimburseType = '';
      if (key === 'menu0') {
        reimburseType = 'CL';
      } else if (key === 'menu1') {
        reimburseType = 'TY';
      } else if (!this.reimburseType) {
        reimburseType = 'CL';
      }
      if (reimburseType && reimburseType !== this.reimburseType) {
        this.$store.commit('REIMBURSE_CREATE', { reimburseType });
        this.$nextTick(() => {
          this.initNewReimburse();
          this.getFormTemplates();

        });
      }
    },
    // 获取必须属性
    getFormTemplates() {
      const params = {
        order_type: this.orderTypeCode,
      };
      this.showLoading();
      this.$store.dispatch('getFormTemplates', params)
        .then((rep) => {
          this.hideLoading();
          if (rep.code === '0000') {
            const info = rep.data.info[0];
            const formTemplate = {
              order_type: info.order_type,
              form_template_id: info.form_template_id,
              form_template_name: info.form_template_name,
              order_template_id: info.order_template_id,
              order_template_name: info.order_template_name,
            };
            this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, formTemplate));
          } else {
            this.showToast({ msg: `请求异常(${rep.code})` });
          }
        });
    },
    onSelectCo(selCo) {
      const emsecfeereimh = Object.assign({}, this.emsecfeereimh, { company_name: selCo.company_name }, { company_id: selCo.company_id });
      this.$store.commit('EMSEC_FEEREIMH', emsecfeereimh);
    },
    //      组织结构
    onOrgConfirm(users) {
      if (this.multiUser) {
        const obj = {
          travel_persons: '',
          travel_persons_name: '',
          travel_person_count: '',
        };
        users.forEach((user) => {
          obj.travel_persons += `${user.user_id},`;
          obj.travel_persons_name += `${user.user_full_name},`;
        });
        obj.travel_persons = obj.travel_persons.substr(0, obj.travel_persons.length - 1);
        obj.travel_persons_name = obj.travel_persons_name.substr(0, obj.travel_persons_name.length - 1);
        const travelPerson = obj.travel_persons_name.split(',');
        obj.travel_person_count = travelPerson.length;
        const emsecfeetravels = [];
        if (this.emsecfeereimh.feeTravels.length) {
          this.emsecfeereimh.feeTravels.forEach((travel) => {
            emsecfeetravels.push(Object.assign({}, travel, obj));
          });
        } else {
          emsecfeetravels.push(obj);
        }
        const emsecfeereimh = Object.assign({}, this.emsecfeereimh, { feeTravels: emsecfeetravels });
        this.$store.commit('EMSEC_FEEREIMH', emsecfeereimh);
      } else {
        const obj = Object.assign({}, this.emsecfeereimh, {
          apply_name: users[0].user_full_name,
          apply_by: users[0].user_id,
          feeTravels: [{
            travel_persons: users[0].user_id,
            travel_persons_name: users[0].user_full_name,
          }],
        });
        this.$store.commit('EMSEC_FEEREIMH', obj);
        this.orgnization = [];
      }
    },
    beforeNext() {
      let next = true;
      if (!this.emsecfeereimh.apply_name) {
        this.showToast({ msg: '请填写：报销人' });
        next = false;
      } else if (this.reimburseType === 'CL' && this.requisition.length === 0) {
        this.showToast({ msg: '请关联申请单' });
        next = false;
      } else if (!this.reasonDesc) {
        this.notice = true;
        this.showToast({ msg: '请填写：业务描述' });
        next = false;
      } else if (!this.receiverStr) {
        this.showToast({ msg: '请填写：收款方' });
        next = false;
      } else if (!this.coStr) {
        this.showToast({ msg: '请填写：入账单位' });
        next = false;
      } else if (this.receiver.receiver !== this.emsecfeereimh.apply_name) {
        this.showToast({ msg: '收款方要和报销请人名称一致' });
        next = false;
      } else {
        next = true;
      }
      return next;
    },
    travelSys(applyList,type) {
      if (this.reimburseType === 'CL' && this.myApplyMenuCfg[this.reimburseType].hasTravelType && type !=='init') {
        // 手动选申请单，ec出差类型，从申请单里获取的
        this.emsecfeereimh.attribute3 = applyList[0].attribute15 || null; // 选了EA单，取EA单的出差类型
        this.$store.commit('EMSEC_FEEREIMH', this.emsecfeereimh);
      }
      const feeApplyCodeList = [];
      applyList.forEach((apply) => {
        feeApplyCodeList.push(apply.fee_apply_code);
      });
      const params = {
        page_number: 1,
        page_size: 1000,
        fee_apply_code: feeApplyCodeList.join(','),
        // fee_apply_code: 'EA1705150211',
        travel_type: 'JP',
      };
      this.$store.dispatch('getTravelOrders', params).then((jpRes) => {
        params.travel_type = 'CAR';
        this.$store.dispatch('getTravelOrders', params).then((carRes) => {
          const travelSysUsed = {
            totalAmount: 0,
            airFeeAmount: 0,
            carFeeAmount: 0,
            hotelFeeAmount: 0,
            airFee: jpRes && jpRes.data && jpRes.data.data ? jpRes.data.data : [],
            carFee: carRes && carRes.data && carRes.data.data ? carRes.data.data : [],
            hotelFee: [],
          };

          travelSysUsed.airFee.forEach((fee) => {
            travelSysUsed.airFeeAmount += parseFloat(fee.amount);
          });
          travelSysUsed.carFee.forEach((fee) => {
            travelSysUsed.carFeeAmount += parseFloat(fee.amount);
          });
          travelSysUsed.totalAmount = travelSysUsed.airFeeAmount + travelSysUsed.carFeeAmount;
          this.$store.commit('TRAVEL_SYS_USED', travelSysUsed);
        });
      });
    },
    onAssociationConfirm(applyList) {
      this.travelSys(applyList);
    },
    consumeAmount(emsecfeereimh) {
      let total = 0;
      if (emsecfeereimh.feeTravels) {
        emsecfeereimh.feeTravels.forEach((item) => {
          if (item.transportDetails) {
            item.transportDetails.forEach((feeItem) => {
              total += parseFloat(feeItem.transport_fee) ? parseFloat(feeItem.transport_fee) : 0;
            });
          }
        });
      }
      if (emsecfeereimh.rentDetails) {
        emsecfeereimh.rentDetails.forEach((item) => {
          total += parseFloat(item.rent_fee) ? parseFloat(item.rent_fee) : 0;
        });
      }
      if (emsecfeereimh.assistantDetails) {
        emsecfeereimh.assistantDetails.forEach((item) => {
          total += parseFloat(item.assistant_fee) ? parseFloat(item.assistant_fee) : 0;
        });
      }
      if (emsecfeereimh.ecOtherFeeDetails) {
        emsecfeereimh.ecOtherFeeDetails.forEach((item) => {
          total += parseFloat(item.other_fee) ? parseFloat(item.other_fee) : 0;
        });
      }
      this.$store.commit('CONSUME_AMOUNT', total);
    },
    createObjAttr(obj, attr, val) {
      if (val !== undefined) obj[attr] = val;
    },
  },
};
</script>
