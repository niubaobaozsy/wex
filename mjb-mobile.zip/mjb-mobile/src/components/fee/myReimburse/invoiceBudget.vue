<!--
  describe:国内差旅报销 - 费用预估
  created by：欧倩伶
  date：2017-11-18
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myReimburse/invoiceBudget.less';
</style>
<template>
  <div>
    <div class="row border" @click="goRoute('/fee/myReimburse/addInvoice')">
      <div class="title">增值税专用发票</div>
      <div class="flexItem">
        <currency currency="¥" :value="taxSum" :precision="2" placeholder="暂无，请添加" :read-only="true"></currency>
        <span class="rightArrow"> <img :src="rightArrow" alt=""></span>
      </div>
    </div>
    <div class="row border" @click="goRoute('/fee/myReimburse/addBudget')">
      <div class="title">预算来源</div>
      <div class="flexItem">
        <currency currency="¥" :value="budgetAmount" :precision="2" placeholder="暂无，请添加" :read-only="true"></currency>
        <span class="rightArrow"><img :src="rightArrow" alt=""></span>
      </div>
    </div>
    <div class="row border" @click="goRoute('/fee/myReimburse/addLoan')" v-edit :data-edit="loanAmount">
      <div class="title">冲抵借款</div>
      <div class="flexItem">
        <currency currency="¥" :value="loanAmount" :precision="2" placeholder="暂无，请添加" :read-only="true"></currency>
        <span class="rightArrow"><img :src="rightArrow" alt=""></span>
      </div>
    </div>
  </div>
</template>
<script>
import MyHeader from '../../common/header';
import processBar from '../../common/processBar';
import currency from '../../common/currency';
import rightArrow from '../../../assets/rt-arrow.png';

export default {
  components: {
    MyHeader,
    processBar,
    currency,
  },
  data() {
    return {
      rightArrow,
      apply_reim_amount: 0,
      reimburseList: {},
    };
  },
  methods: {
    // 页面路由
    goRoute(router) {
      this.$router.push({ path: router });
    },
    // 合并/深复制
    extend(arr) {
      let des;
      if (arr === null) return arr;
      if (arr instanceof Array) {
        des = [];
        for (let i = 0, len = arr.length; i < len; i++) {
          des[i] = extend(arr[i]);
        }
        return des;
      }
      return null;
    },
    // 下一步
    beforeNext() {
      console.log('保存前', this.$store.state.myReimburse.emsecfeereimh.emsEcFeeBudgets);
      if (this.emsEcFeeBudgets.length === 0) {       // 预算数组为空
        this.showToast({ msg: '请添加预算信息', width: '12em' });
        return false;
      } else if (this.loanAmount > this.budgetAmount) {
        this.showToast({ msg: '本次冲抵金额不能大于申请金额', width: '12em' });
        return false;
      } else if (this.reimburseType === 'CL' && this.consumeAmount && this.consumeAmount !== (this.budgetAmount + this.taxSum)) {
        if (!this.taxSum) {
          this.showToast({ msg: '消费明细必须等于预算金额！', width: '12em' });
        } else {
          this.showToast({ msg: '消费明细必须等于预算金额加发票税额！', width: '12em' });
        }
        return false;
      }
      // this.saveDraft(true);
      return true;
    },
  },
  computed: {
    invoiceSum() {
      let sum = 0;
      this.emsecfeereimh.invoiceTaxRS.forEach((item) => {
        sum += parseFloat(item.invoice_amount) || 0;
      });
      return sum;
    },
    taxSum() {
      let sum = 0;
      this.emsecfeereimh.invoiceTaxRS.forEach((item) => {
        sum += parseFloat(item.tax_amount) || 0;
      });
      return sum;
    },
    budgetAmount() {
      // let sum = 0;
      // this.emsEcFeeBudgets.forEach((bgItem) => {
      //   sum += parseFloat(bgItem.apply_reim_amount) || 0;
      // });
      // return sum;
      return this.$store.getters.reimTotalBudget;
    },
    loanAmount() {
      let sum = 0;
      this.feeLoans.forEach((loanItem) => {
        sum += Number(loanItem.repay_amount || 0);
      });
      return sum;
    },
    // 发票信息
    emsecfeereimh() {
      console.log('报销信息', this.$store.state.myReimburse.emsecfeereimh);
      return this.$store.state.myReimburse.emsecfeereimh;
    },
    // 借款核销信息
    feeLoans() {
      return this.$store.state.myReimburse.emsecfeereimh.feeLoans;  // emsecfeeloans
    },
    // 报销申请单信息
    emsEcFeeBudgets: {
      get() {
        return this.$store.state.myReimburse.emsecfeereimh.emsEcFeeBudgets;  // emsecfeebudgets
      },
      set(newValue) {
        this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, { emsEcFeeBudgets: newValue }));
      },
    },
    consumeAmount() {
      return this.$store.getters.reimTotalFee;
    },
    reimburseType() {
      return this.$store.state.myReimburse.reimburseCreate.reimburseType;
    },
  },
  activated() {
    if (this.reimburseType === 'CL' && this.emsEcFeeBudgets.length === 1 && this.emsEcFeeBudgets[0].fee_apply_l_id) {
      const budget = Object.assign({}, this.emsEcFeeBudgets[0], {
        apply_reim_amount: this.consumeAmount - this.taxSum,
        approve_reim_amount: this.consumeAmount - this.taxSum,
      });
      this.$store.commit('EMSEC_FEEREIMH', Object.assign({}, this.emsecfeereimh, { emsEcFeeBudgets: [budget] }));
    }
  },
};
</script>
