<!--
  describe："报销主页"
  created by：panjm
  date：2017-11-20
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div class="mine-wrap">
    <div class="mine-content">
      <my-header title="我的报销" :rightItem="rightTitle" @previous="goBack" @on-click="edit"></my-header>
      <div class="has-header has-tab">
        <Tab :tabList="tabList"></Tab>
      </div>
      <div class="has-footer">
        <router-view></router-view>
      </div>

    </div>
  </div>
</template>

<script>
import MyHeader from '../../common/header';
import Tab from '../../common/Tab';

export default {
  components: {
    MyHeader,
    Tab,
  },
  data() {
    return {
      // checkboxStatus:false,
      tabList: [
        {
          name: '草稿',
          linkTo: 'draft',
        },
        {
          name: '审批中',
          linkTo: 'beingApproved',
        },
        {
          name: '已审批',
          linkTo: 'approved',
        },
      ],
    };
  },
  computed:{
    location(){
      return this.$route.path;
    },
    rightTitle() {
      return this.location.split('/').indexOf('draft') === -1 ? '' : '编辑';
    },
  },
  methods: {
    goBack() {
      this.$router.push('/fee');
      this.$store.commit('REC_CBSTATUS');
    },
    edit(){
      this.$store.commit('CHANGE_CBSTATUS')
    },
  },
  watch:{
    location (newValue,oldValue) {
      if (newValue.split('/').indexOf('draft') === -1) {
        this.$store.commit('CHANGE_CBSTATUS');
      } else {
        this.$store.commit('REC_CBSTATUS');
      }
    },
  }
};
</script>
