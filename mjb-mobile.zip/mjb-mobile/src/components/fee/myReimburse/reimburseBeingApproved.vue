<!--
  describe："报销-审批中"
  created by：panjm
  date：2017-11-20
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div infinite-scroll-immediate-check="true" infinite-scroll-listen-for-event="loadMoreFun" infinite-scroll-disabled="busy" infinite-scroll-distance="10" infinite-scroll-throttle-delay="500">
    <down-pull-loading @loading="refresh" v-if="orderList.length">
      <!-- <swipeout slot='list'>
        <swipeout-item v-for="(data, index) in orderList" :key="index" ref="swip">
          <div slot="right-menu">
            <swipeout-button @click.native="showPlugin(data.id, index)" style="font-size:17px;background:#FC4B4B;width: 66px;border-top:1px solid #DEDFE0;border-bottom:1px solid #DEDFE0;">撤回</swipeout-button>
          </div>
          <div slot="content" @click="goDetail(data.id, data.reimburse_type)">
            <div class="invoiceBox">
              <div class="invoiceLeft">
                <div :class="['invoiceType', data.logo_color]">
                  {{ data.order_type_name }}
                </div>
              </div>
              <div class="invoiceRight">
                <div class="invoiceSecondCol">
                  <p>{{ data.description}}</p>
                  <p>{{ data.last_update_date }}</p>
                  <p>单号：{{ data.order_code }}</p>
                </div>
                <div class="invoiceThirdCol">
                  <p class="invoicePrice">￥{{ data.approve_amount.toFixed(2) }}</p>
                  <span class="invoiceStatus tipRed" v-if="data.first_node_status=='未查检'">{{ data.first_node_status }}</span>
                </div>
              </div>
            </div>
          </div>
        </swipeout-item>
      </swipeout> -->
      <div slot="list" v-for="(data, index) in orderList" :key="index" @click="goDetail(data.id, data.reimburse_type)">
        <div class="invoiceBox">
          <div class="invoiceLeft">
            <div :class="['invoiceType', data.logo_color]">
              {{ data.order_type_name }}
            </div>
          </div>
          <div class="invoiceRight">
            <div class="invoiceSecondCol">
              <p>{{ data.description}}</p>
              <p>{{ data.last_update_date }}</p>
              <!-- <p>单号：{{ data.order_code }}</p> -->
            </div>
            <div class="invoiceThirdCol">
              <p class="invoicePrice" v-if="myMenuCfgCurreny">￥{{ data.approve_amount.toFixed(2) }}</p>
              <p class="invoicePrice" v-else>{{ data.currenySymbol }} {{ data.approve_amount.toFixed(2) }}</p>
              <span class="invoiceStatus tipRed" v-if="data.first_node_status=='未查检'">{{ data.first_node_status }}</span>
            </div>
          </div>
        </div>
      </div>
    </down-pull-loading>
    <load-more v-if="loadMore" :tip="'加载中...'" style="width: 100%;padding: 22px 0px;box-sizing: border-box;margin:0 auto"></load-more>
    <div v-if="!orderList.length && isloading" class="emptyBox">
      <img class="no_data_img" :src="noDataImg" alt="">
      <p class="no_data_text">暂无数据</p>
    </div>

  </div>
</template>

<script>
import { Swipeout, SwipeoutItem, SwipeoutButton, XButton, Confirm, XSwitch, LoadMore, TransferDomDirective as TransferDom } from 'vux';
import downPullLoading from '../../common/downPullLoading';
import noDataImg from '../../../assets/images/common/no_data.png';
import curreny from '../../../../static/curreny.json';

export default {
  components: {
    Swipeout,
    SwipeoutItem,
    SwipeoutButton,
    XButton,
    Confirm,
    XSwitch,
    LoadMore,
    TransferDom,
    downPullLoading,
  },
  data() {
    return {
      curreny,
      isloading: false,
      loadingFlag: 0,
      loadMore: false,
      busy: false,
      hasNextPage: true,
      noDataImg,
      pageInfo: {
        page_number: 1,
        page_size: 10,
        order_status: 'SUBMITED',
        module_types: 'EC',
      },
      orderList: [],
    };
  },
  methods: {
    getReimburseList(refresh) {
      return new Promise((resolve) => {
        this.$store.dispatch('myFeeOrderQuery', this.pageInfo).then((res) => {
          this.hideLoading();
          resolve();
          if (res && res.code === '0000') {
            this.isloading = true;
            if (res.data && res.data.datalist && res.data.datalist.length) {
              res.data.datalist.forEach((list) => {
                if (list.order_type === 'HW') {
                  list.order_type_name = '会务';
                  list.reimburse_type = 'nonsupport';
                  list.logo_color = 'grey';
                } else if (list.order_type === 'CL') {
                  list.order_type_name = '差旅';
                  list.reimburse_type = 'CL';
                  list.logo_color = 'blue';
                } else if (list.order_type === 'TY') {
                  list.order_type_name = '通用';
                  list.reimburse_type = 'TY';
                  list.logo_color = 'green';
                } else if (list.order_type === 'CAR') {
                  list.order_type_name = '用车';
                  list.reimburse_type = 'nonsupport';
                  list.logo_color = 'grey';
                } else if (list.order_type === 'EC_AIR') {
                  list.order_type_name = '机票';
                  list.reimburse_type = 'nonsupport';
                  list.logo_color = 'grey';
                }
                 // 币种
                let currenyName = list.currency_name;
                list.currenySymbol = this.curreny[currenyName];
              });
              this.orderList = refresh ? res.data.datalist : this.orderList.concat(res.data.datalist);
              this.pageInfo.page_number += 1;
              this.$nextTick(() => {
                this.vuxChangeWidth();
              });
            } else if (res.data && res.data.datalist && !res.data.datalist.length) {
              this.hasNextPage = false;
              this.loadMore = false;
            }
          } else if (res && res.code) {
            this.showToast({ msg: `请求异常(${res.code})` });
          }
        });
      });
    },
    loadMoreFun() {
      if (this.hasNextPage) {
        setTimeout(() => {
          this.loadMore = true;
          this.getReimburseList();
        }, 500);
      }
    },
    vuxChangeWidth() {
      // 修改vux-swiper-item距离content的宽
      if (this.$refs.swip) {
        this.$refs.swip.forEach((swip) => {
          const list = swip.$slots['right-menu'][0].children.filter(one => one.tag);
          list.forEach((one) => {
            one.componentOptions.propsData.width = 66;
          });
        });
      }
    },
    refresh() {
      this.isloading = false;
      this.pageInfo.page_number = 1;
      return new Promise((resolve) => {
        this.getReimburseList(true).then(() => {
          setTimeout(() => {
            resolve();
          }, 1000);
        });
      });
    },
    goDetail(reimburseId, reimburseType) {
      if (reimburseType === 'nonsupport') {
        this.showToast({ msg: '移动端暂不支持该类型操作，请移步PC端' });
      } else if (reimburseId && reimburseType) {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/myReimburse/checkReimburse', query: { id: reimburseId, type: reimburseType },
          });
        }, 500);
      } else {
        setTimeout(() => {
          this.$router.push({
            path: '/fee/myReimburse/checkReimburse',
          });
        }, 500);
      }
    },
    // showPlugin(formInstanceId, modelId, templateFormId) {
    //   const self = this;
    //   this.$vux.confirm.show({
    //     title: '撤回',
    //     content: '确定撤回该申请单吗？',
    //     onConfirm() {
    //       // self.reimburseDrafter(formInstanceId, modelId, templateFormId);
    //     },
    //   });
    // },
    // reimburseDrafter(formInstanceId, modelId, templateFormId) {
    //   const params = {
    //     auditNote: '撤回',
    //     formInstanceId,
    //     model_id: modelId,
    //     template_form_id: templateFormId,
    //   };
    //   this.$store.dispatch('myBillBack', params).then((res) => {
    //     if (res.code === '0000') {
    //       this.orderList.splice(index, 1);
    //       this.showToast({ msg: '操作成功！' });
    //       setTimeout(() => {
    //         this.$router.replace('/fee/myApply/applyHome/beingApproved');
    //       }, 800);
    //     } else if (res && res.code) {
    //       this.showToast({ msg: `请求异常(${res.code})` });
    //     }
    //   });
    // },
  },
  mounted() {
    this.showLoading();
    this.getReimburseList();
  },
  computed: {
    myMenuCfgCurreny() {
      return this.$store.state.menuConfig.fee.curreny;
    },
  }
};
</script>

