<!--
  describe：发票详情页面
  Author: 欧倩伶
	Create: 2017-11-04
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoiceDetail.less';
</style>
<template>
  <div>
    <my-header :title="top.title" :rightItem="'删除'" @on-click="del" :showBack="true" :showRedDot="true" @previous="goBack"></my-header>
    <div class="invoice-main has-header">
      <div class="header-title borderBottom">{{listData.invoice_type_name}}</div>
      <div class="wallet-detail-wrap borderBottom">
        <div class="invoice-header">
          <div class="row columns is-mobile">
            <span class="row-title">发票代码：</span>
            <span class="row-data">{{listData.invoice_code}}</span>
          </div>
          <div class="row columns is-mobile">
            <span class="row-title">检验码：</span>
            <span class="row-data">{{listData.check_code}}</span>
          </div>
          <div class="row columns is-mobile">
            <span class="row-title">发票号码：</span>
            <span class="row-data">{{listData.invoice_num}}</span>
          </div>
          <div class="row columns is-mobile">
            <span class="row-title">开票日期：</span>
            <span class="row-data">{{formatDate(listData.invoice_date)}}</span>
          </div>
        </div>
        <div class="invoice-purchase borderTop">
          <div class="row columns is-mobile">
            <span class="row-title">购买方：</span>
            <span class="row-name">{{listData.purchase_unit_name || '未知'}}</span>
          </div>
          <div v-if="isshow">
            <div class="row columns is-mobile">
              <span class="row-title">纳税人识别号：</span>
              <span class="row-data">{{listData.purchase_unit_tax_num || '未知'}}</span>
            </div>
            <div class="row columns is-mobile">
              <span class="row-title">地址及电话：</span>
              <span class="row-data">{{listData.purchase_unit_address}}</span>
            </div>
            <div class="row columns is-mobile">
              <span class="row-title">开户行及账号：</span>
              <span class="row-data">{{listData.purchase_unit_bank}}</span>
            </div>
          </div>
        </div>
        <div class="invoice-sales borderTop">
          <div class="row columns is-mobile">
            <span class="row-title">销售方：</span>
            <span class="row-name">{{listData.sales_unit_name || '未知'}}</span>
          </div>
          <div v-if="isshow">
            <div class="row columns is-mobile">
              <span class="row-title">纳税人识别号：</span>
              <span class="row-data">{{listData.sales_unit_tax_num || '未知'}}</span>
            </div>
            <div class="row columns is-mobile">
              <span class="row-title">地址及电话：</span>
              <span class="row-data">{{listData.sales_unit_address}}</span>
            </div>
            <div class="row columns is-mobile">
              <span class="row-title">开户行及账号：</span>
              <span class="row-data">{{listData.sales_unit_bank}}</span>
            </div>
          </div>
        </div>
        <div v-if="isshow">
          <div class="invoice-item borderTop" v-for="(unit,index) in listData.details" :key="index">
            <div class="row columns is-mobile">
              <span class="row-title">发票详情：</span>
              <span class="row-name">{{unit.item}}</span>
            </div>
            <div class="row columns is-mobile">
              <span class="row-title">税率：</span>
              <span class="row-data blue">{{unit.tax_rate}}{{!unit.tax_rate?'':'%'}}</span>
            </div>
            <div class="row columns is-mobile">
              <span class="row-title">税前金额：</span>
              <span class="row-data">{{!unit.unit_price?'':'¥'}}{{unit.unit_price}}</span>
            </div>
            <div class="row columns is-mobile">
              <span class="row-title">税额：</span>
              <span class="row-data">{{!unit.tax_amount?'':'¥'}}{{unit.tax_amount}}</span>
            </div>
          </div>
        </div>
      </div>
      <div class="check-details borderBottom" @click="detailInvoice">
        <p :class="[isshow?'textup':'textdown']">查看详情</p>
      </div>
    </div>
    <div class="invoice-amount  border">
      <div class="columns is-mobile">
        <div class="column is-4">
          <p>总金额</p>
          <span class="invoice-price" style="color:#FC4B4C">{{!listData.total_amount?'':'¥'}}{{listData.total_amount}}</span>
        </div>
        <div class="column is-4">
          <p>税额</p>
          <span class="invoice-price">{{!listData.tax_amount?'':'¥'}}{{listData.tax_amount}}</span>
        </div>
        <div class="column is-4">
          <p>不含税金额</p>
          <span class="invoice-price">{{!listData.amount_sum?'':'¥'}}{{listData.amount_sum}}</span>
        </div>
      </div>
    </div>
    <div class="invoice-img border has-footer">
      <div class="textBox"> 发票附件</div>
      <div style="display: inline-flex;flex-wrap: wrap;">
        <div v-if="imgList.length" style="display: inline-flex;flex-wrap: wrap;">
          <div class="imgBox" v-for="(item, index) in imgList" :key="index">
            <img :src="item.thumbnail_content" @click="showBigImgFuc(index)" @load="setImgSize(index)">
            <div class="del" @click="delImg(index)"></div>
          </div>
        </div>
        <img :src="addBtnUrl" @click="showSheet" v-if="!usedFlag && !imgList.length">
      </div>
    </div>
    <div class="invoice-btn" v-if="!usedFlag">
      <div class="save_btn" v-if="!saveFlag" @click="saveData">保存</div>
      <div class="new_btn" v-if="!saveFlag" @click="saveData">保存并新增</div>
      <div class="save_btn_big" @click.stop.prevent="saveData" v-if="saveFlag===true">保存</div>
    </div>
    <Actionsheet v-model="showAction" :menus="menus" @on-click-menu="addImg" :show-cancel="showCancel"></Actionsheet>
    <Gallery :show="showBigImg" :index="bigImgIndex" :list="imgList" :hasDel="hasDel" @on-hide="hideImgView" @download="download" @on-del="delImg"></Gallery>
  </div>
</template>

<script>
import { Actionsheet } from 'vux';
import MyHeader from '../../common/header';
import addBtnUrl from '../../../assets/images/fee/myInvoice/add_on.png';
import deleteUrl from '../../../assets/images/fee/myInvoice/delete2x.png';
import { platform } from '../../../platform';
import Gallery from '../../common/gallery';

export default {
  components: {
    MyHeader,
    Actionsheet,
    Gallery,
  },
  data() {
    return {
      addBtnUrl,
      deleteUrl,
      isshow: false,
      showAction: false,
      showCancel: true,
      saveFlag: false,
      confirmShow: false,
      curIndex: '',
      usedFlag: '',
      tempType: '',
      menus: {
        menu1: '拍照',
        menu2: '相册',
      },
      top: {
        title: '发票详情页',
      },
      listData: {
        invoice_type_name: '',
        details: [],
      },
      bigImgIndex: 0,       // 当前点击的图片的索引
      showBigImg: false, // 是否显示大图列表
      hasDel: false,
    };
  },
  methods: {
    detailInvoice() {
      this.isshow = !this.isshow;
    },
    formatDate(time) {
      if (!time) return null;
      if (time.indexOf('/') !== -1) return time;
      const temp1 = time.substr(0, 4);
      const temp2 = time.substr(5, 2);
      const temp3 = time.substr(8, 2);
      return `${temp1}/${temp2}/${temp3}`;
    },
    showSheet() {
      this.showAction = true;
    },
    goBack() {
      if (!this.saveFlag) {
        window.history.back();
      } else if (this.$route.query.type === 'scan' || this.$route.query.type === 'auto') {
        this.saveFlag = true;
        window.history.back();
      } else {
        this.saveFlag = false;
      }
    },
    // 点击关闭查看大图
    hideImgView() {
      this.showBigImg = false;
    },
    // 点击下载图片
    download() { },
    // 点击图片查看大图
    showBigImgFuc(index) {
      this.showLoading();
      if (!this.saveFlag) {
        this.hasDel = false;
      } else {
        this.hasDel = true;
      }
      this.bigImgIndex = index;
      setTimeout(() => {
        this.hideLoading();
        this.showBigImg = true;
      }, 500);
    },
    // 加载图片时设置图片显示的位置
    setImgSize(index) {
      const el = event.srcElement;
      const showImg = this.imgList[index];
      console.log(index, el.naturalWidth, el.naturalHeight);
      if (showImg) {
        showImg.el = el;
        showImg.src = el.src;
        showImg.w = el.naturalWidth;
        showImg.h = el.naturalHeight;
        this.imgList[index] = showImg;
      }
    },
    del() {
      const self = this;
      self.$vux.confirm.show({
        title: '删除该发票？',
        onConfirm() {
          self.$store.dispatch('myiInvoiceDelete', { id: self.curIndex }).then((res) => {
            console.log(res);
            if (res.code === '0000') {
              setTimeout(() => {
                self.$router.replace('/fee/myInvoice');
              }, 800);
              self.$store.commit('PJ_BACKMARK', 'delOk');
              self.showToast({ msg: '删除成功', width: '14em', time: 800 });
            }
          });
        },
      });
    },
    delImg(index) {
      // 删除拍照或相册上传的照片
      this.imgList.splice(index, 1);
      this.$store.commit('MY_UPLOAD_FILE_LIST', this.imgList);
      this.showToast({ msg: '删除成功', width: '14em', time: 800 });
      this.listData.file_id = '';
      this.hideImgView();
    },
    addImg(key) {
      const self = this;
      if (key === 'menu1') { // 拍照
        self.takePhoto();
      } else if (key === 'menu2') { // 从相册选择
        self.selectFromAlbum();
      }
    },
    takePhoto() {
      const self = this;
      platform.getPicture({
        sourceType: Camera.PictureSourceType.CAMERA,
      }).then((data) => {
        self.addAttachMent(data);
      }, () => {
        self.showToast({ msg: '拍照失败' });
      });
    },
    selectFromAlbum() {
      // window.Camera = {
      //   PictureSourceType: {
      //     SAVEDPHOTOALBUM: 'album',
      //     CAMERA: 'camera',
      //   },
      // };
      const self = this;
      platform.getPicture({
        sourceType: Camera.PictureSourceType.SAVEDPHOTOALBUM,
      }).then((data) => {
        self.addAttachMent(data);
        console.log(data);
      }, () => {
        self.showToast({ msg: '选择图片失败' });
      });
    },
    addAttachMent(data) {
      const params = {
        source_filename: this.imgRandom(),
        content: data,
      };
      // this.showLoading('图片上传中');
      this.$store.dispatch('myiUploadImg', params).then((res) => {
        // this.hideLoading();
        if (res.code === '0000') {
          // let img = null,
          const list = res.data;
          const imgList = this.imgList;
          const obj = {
            url: `data:image/png;base64,${list.thumbnail_content}`,
            file_id: list.file_id,
            source_filename: list.source_filename,
            thumbnail_content: `data:image/png;base64,${list.thumbnail_content}`,
          };
          imgList.push(obj);
          this.$store.commit('MY_UPLOAD_FILE_LIST', imgList);
          this.listData.file_id = list.file_id;
        }
      });
    },
    imgRandom() {
      return `${Date.now()}${Math.floor(Math.random() * 10000000)}.png`;
    },
    saveData() {
      const params = {
        file_id: this.listData.file_id || '',
        version_no: this.listData.version_no || '',
        invoice_type: this.listData.invoice_type || '',
        invoice_type_name: this.listData.invoice_type_name || '',
        invoice_code: this.listData.invoice_code || '',
        invoice_num: this.listData.invoice_num || '',
        total_amount: Number(this.listData.total_amount) || 0,
        tax_amount: this.listData.tax_amount ? this.listData.tax_amount - 0 : 0,
        amount_sum: this.listData.amount_sum ? this.listData.amount_sum - 0 : 0,
        invoice_date: this.formatDate(this.listData.invoice_date),
        check_code: this.listData.check_code || '',
        crc: this.listData.crc || '',
        check_times: Number(this.listData.check_times) || null,
        machine_number: this.listData.machine_number || '',
        valid: this.listData.valid || null,
        remark: this.listData.remark || '',
        purchase_unit_name: this.listData.purchase_unit_name || '',
        purchase_unit_tax_num: this.listData.purchase_unit_tax_num || '',
        purchase_unit_address: this.listData.purchase_unit_address || '',
        purchase_unit_bank: this.listData.purchase_unit_bank || '',
        sales_unit_name: this.listData.sales_unit_name || '',
        sales_unit_tax_num: this.listData.sales_unit_tax_num || '',
        sales_unit_address: this.listData.sales_unit_address || '',
        sales_unit_bank: this.listData.sales_unit_bank || '',
        details: this.listData.details,
      };
      if (this.$route.query.id && this.$store.state.myInvoice.myInvoiceType === 'get') {
        params.invoice_id = this.$route.query.id;
      }
      this.$store.dispatch('myiSaveInvoice', params).then((res) => {
        if (res.code === '0000') {
          this.showToast({ msg: '保存成功', width: '10em', time: 1000 });
          setTimeout(() => {
            this.$router.replace({ path: '/fee/myInvoice/' });
          }, 800);
        } else if (res && res.msg) {
          this.showToast({ msg: `请求异常[${res.code}]:${res.msg}` });
        }
      });
    },
    // 请求图片
    getImgMethod(id) {
      this.$store.dispatch('myiGetImg', id).then((res) => {
        if (res.code === '0000') {
          this.listData.img = `data:${res.data.mime_type};base64,${res.data.content}`;
          const list = res.data;
          const imgList = this.imgList;
          const obj = {
            url: `data:${res.data.mime_type};base64,${res.data.content}`,
            file_id: list.file_id,
            source_filename: list.source_filename,
            thumbnail_content: `data:${res.data.mime_type};base64,${res.data.content}`,
          };
          imgList.push(obj);
          this.$store.commit('MY_UPLOAD_FILE_LIST', imgList);
        }
      });
    },
    getInvoiceType() {
      // 请求发票类型
      this.$store.dispatch('myiGetInvoiceType', '').then((res) => {
        if (res.code === '0000') {
          const dataType = res.data;
          for (let i = 0; i < dataType.length; i++) {
            if (dataType[i].itemValue === this.tempType) {
              this.listData.invoice_type_name = dataType[i].itemName;
              this.$forceUpdate();
            }
          }
        }
      });
    },
    init() {
      const self = this;
      this.$store.commit('MY_UPLOAD_FILE_LIST', []);
      if (this.$route.query.id) {
        this.curIndex = this.$route.query.id;
        this.usedFlag = this.$store.state.myInvoice.myMainFlag;
        this.$store.dispatch('myInvoiceDetail', this.curIndex).then((res) => {
          if (res.code === '0000') {
            self.listData = res.data;
            self.tempType = self.listData.invoice_type;
            self.getInvoiceType();
            if (self.listData.file_id) {
              self.getImgMethod(self.listData.file_id);
            }
          }
        });
        // this.$store.commit('PJ_BACKMARK', null);
      } else if (this.$route.query.type === 'auto' || this.$route.query.type === 'scan') {
        this.saveFlag = true;
        this.listData = this.$store.state.myInvoice.invoice;
      }
    },
  },
  mounted() {
    this.init();
  },
  computed: {
    imgList() { // 拍照和相册上传的图片
      return this.$store.state.myInvoice.myFileList || [];
    },
    // 附件大图图片数组
    bigImgList() {
      return this.$store.state.myInvoice.bigImgList;
    },
  },
};
</script>
