 <!--
  describe："手工录入发票" 页面
  created by：Yim Lee
  date：2017-11-02
-->
 <template>
  <div>
    <my-header :title="'新增发票'" :showBack="true" :showRedDot="true" @previous="goBack"></my-header>
    <div class="invoice-main has-header">
      <div class="invoice columns is-mobile is-gapless" v-for="(item,  index) in invoiceList" :key="index" v-if="index === 3 ? showAmount : show" v-show="index === 4 ? showCheckCode : show">
        <span class="invoice-title">{{ item.text }}</span>
        <img :src="calendarImg" alt="calendarImg" v-if="index !==2 ? false : true" @click="onCellClick">
        <input-box :placeholder="'请输入'" :textCenter="false" :isreadOnly="false" @on-focus="onfocus(index)" @on-blur="onblur" @get-value="getValue" v-if="index !==2">
        </input-box>
        <input-box :placeholder="'请选择'" :textCenter="false" :isreadOnly="true" :pickValue="pick_date" @select="onCellClick" v-else></input-box>
        <span class="invoice-type" v-if="showCheckCode && index === 0">普通发票</span>
      </div>
      <div class="footer-btn columns is-mobile is-gapless">
        <button class="btn column" :class="ischeck === true ? 'btn-on' : 'btn-off'" @click="checkData">查验</button>
      </div>
    </div>
    <calendar @pickDate="onPickDate" :show.sync="showCalendar" v-model="pick_date"></calendar>
  </div>
</template>

<script>
import MyHeader from '../../common/header';
import InputBox from '../../common/input.vue';
import calImg from '../../../assets/calendar.png';
import calendar from '../../common/myCalendar';

export default {
  components: {
    MyHeader,
    InputBox,
    calendar,
  },
  data() {
    return {
      invoiceList: [
        {
          text: '发票代码',
          value: '',
        },
        {
          text: '发票号码',
          value: '',
        },
        {
          text: '开票日期',
          value: '',
        },
        {
          text: '金额(不含税)',
          value: '',
        },
        {
          text: '校验码后6位',
          value: '',
        },
      ],
      invoice: {
        invoice_code: '',
        invoice_num: '',
        invoice_date: '',
        check_code: '',
        amount_sum: '',
        total_amount: '',
      },
      index: 0,
      showCheckCode: false,  // 是否显示检验码和'普通发票'的标志
      showAmount: false,      // 显示金额项
      show: true,            // 显示列表
      ischeck: false,        // 是否可以点击检查发票类型
      cancheck: false,       // 是否可以点击查验发票
      calendarImg: calImg,   // 日历的图片
      isahm: false,
      fplx: '99',
      code: ['144031539110', '131001570151', '133011501118', '111001571071'],
      showCalendar: false,
      pick_date: '',
    };
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    // 点击选择时间
    onPickDate() {
      this.invoice.invoice_date = this.pick_date;
    },
    onCellClick() {
      this.showCalendar = true;
    },
    // input获得焦点
    onfocus(index) {
      this.index = index;
    },
    // input失去焦点时获取输入框的值, 而且是格式化之后的值
    onblur(value) {
      if (this.index === 0) {
        this.testCode(value);
        if (value) {
          this.ischeck = true;
        } else {
          this.ischeck = false;
        }
      }
      if (this.index === 1) {
        this.testNumber(value);
      }
    },
    getValue(value) {
      switch (this.index) {
        case 0:
          this.invoice.invoice_code = value;
          break;
        case 1:
          this.invoice.invoice_num = value;
          break;
        case 3:
          this.invoice.amount_sum = value;
          break;
        case 4:
          this.invoice.check_code = value;
          break;
        default:
          break;
      }
    },
    /* eslint-disable */
    ahm(a) {
      const b = /^\d{8}$/;
      const c = /^0{8}$/;
      // const d = /^0{11}-?[1-9]*\w\d*$/;
      const e = b.test(a);
      const f = c.test(a);
      if (e === true && f === false) {
        return true;
      } else if (e !== true || f !== false) {
        return false;
      }
    },
    bc(a) {
      let b;
      const d = new Date();
      const e = d.getFullYear();
      const f = e.toString();
      const g = f.substring(2);
      if (a.length === 12) {
        b = a.substring(5, 7);
      } else {
        b = a.substring(4, 6);
      }
      if (b <= 0 || b > g) {
        return false;
      }
      return true;
    },
    adm(a) {
      const b = /^1|0\d{11}$|^\d{6}[1-9]\d{2}0$/;
      // const c = /^0{8}[1-9]?\w[1-9]\d*$/;
      const e = b.test(a);
      // const f = c.test(a);
      if (e === true && this.bc(a) && this.alxd(a) !== '99') return true;
      return false;
    },
    alxd(a) {
      let b = '99';
      let c = '99';
      if (a.length === 12) {
        b = a.substring(7, 8);
        for (let i = 0; i < this.code.length; i++) {
          if (a === this.code[i]) {
            c = '10';
            break;
          }
        }
        // 增加判断，判断是否为新版电子票
        if (c === '99') {
          if (a.charAt(0) === '0' && a.substring(10, 12) === '11') {
            c = '10';
          }
          if (a.charAt(0) === '0' && (a.substring(10, 12) === '04' || a.substring(10, 12) === '05')) {
              c = '04';
          }
          // 判断是否为卷式发票  第1位为0且第11-12位为06或07
          if (a.charAt(0) === '0' && (a.substring(10, 12) === '06' || a.substring(10, 12) === '07')) {
            c = '11';
          }
          if (a.charAt(0) && a.substring(10, 12) === '12') {
              c = '14';
          }
        }
        // 如果还是99，且第8位是2，则是机动车发票
        if (c === '99') {
          if (a.substring(10, 12) === '17' && a.charAt(0) === '0') {
            c = '15';
          }
          if (b == 2 && a.charAt(0) !== '0') {
            c = '03';
          }
        }
      } else if (a.length === 10) {
        b = a.substring(7, 8);
        if (b == 1 || b == 5) {
          c = '01';
        } else if (b == 6 || b == 3) {
          c = '04';
        } else if (b == 7 || b == 2) {
          c = '02';
        }
      }
      return c;
    },
    getSwjg(val, ckflag) {
      console.log(ckflag);
      const flag = '';
      const citys = [
        { code: '1100', sfmc: '北京', Ip: 'https://zjfpcyweb.bjsat.gov.cn: 443', address: 'https://zjfpcyweb.bjsat.gov.cn: 443' },
        { code: '1200', sfmc: '天津', Ip: 'https://fpcy.tjsat.gov.cn: 443', address: 'https://fpcy.tjsat.gov.cn: 443' },
        { code: '1300', sfmc: '河北', Ip: 'https://fpcy.he-n-tax.gov.cn: 82', address: 'https://fpcy.he-n-tax.gov.cn: 82' },
        { code: '1400', sfmc: '山西', Ip: 'https://fpcy.tax.sx.cn: 443', address: 'https://fpcy.tax.sx.cn: 443' },
        { code: '1500', sfmc: '内蒙古', Ip: 'https://fpcy.nm-n-tax.gov.cn: 443', address: 'https://fpcy.nm-n-tax.gov.cn: 443' },
        { code: '2100', sfmc: '辽宁', Ip: 'https://fpcy.tax.ln.cn: 443', address: 'https://fpcy.tax.ln.cn: 443' },
        { code: '2102', sfmc: '大连', Ip: 'https://fpcy.dlntax.gov.cn: 443', address: 'https://fpcy.dlntax.gov.cn: 443' },
        { code: '2200', sfmc: '吉林', Ip: 'https://fpcy.jl-n-tax.gov.cn: 4432', address: 'https://fpcy.jl-n-tax.gov.cn: 4432' },
        { code: '2300', sfmc: '黑龙江', Ip: 'https://fpcy.hl-n-tax.gov.cn: 443', address: 'https://fpcy.hl-n-tax.gov.cn: 443' },
        { code: '3100', sfmc: '上海', Ip: 'https://fpcyweb.tax.sh.gov.cn: 1001', address: 'https://fpcyweb.tax.sh.gov.cn: 1001' },
        { code: '3200', sfmc: '江苏', Ip: 'https://fpdk.jsgs.gov.cn: 80', address: 'https://fpdk.jsgs.gov.cn: 80' },
        { code: '3300', sfmc: '浙江', Ip: 'https://fpcyweb.zjtax.gov.cn: 443', address: 'https://fpcyweb.zjtax.gov.cn: 443' },
        { code: '3302', sfmc: '宁波', Ip: 'https://fpcy.nb-n-tax.gov.cn: 443', address: 'https://fpcy.nb-n-tax.gov.cn: 443' },
        { code: '3400', sfmc: '安徽', Ip: 'https://fpcy.ah-n-tax.gov.cn: 443', address: 'https://fpcy.ah-n-tax.gov.cn: 443' },
        { code: '3500', sfmc: '福建', Ip: 'https://fpcyweb.fj-n-tax.gov.cn: 443', address: 'https://fpcyweb.fj-n-tax.gov.cn: 443' },
        { code: '3502', sfmc: '厦门', Ip: 'https://fpcy.xm-n-tax.gov.cn', address: 'https://fpcy.xm-n-tax.gov.cn' },
        { code: '3600', sfmc: '江西', Ip: 'https://fpcy.jxgs.gov.cn: 82', address: 'https://fpcy.jxgs.gov.cn: 82' },
        { code: '3700', sfmc: '山东', Ip: 'https://fpcy.sd-n-tax.gov.cn: 443', address: 'https://fpcy.sd-n-tax.gov.cn: 443' },
        { code: '3702', sfmc: '青岛', Ip: 'https://fpcy.qd-n-tax.gov.cn: 443', address: 'https://fpcy.qd-n-tax.gov.cn: 443' },
        { code: '4100', sfmc: '河南', Ip: 'https://fpcy.ha-n-tax.gov.cn', address: 'https://fpcy.ha-n-tax.gov.cn' },
        { code: '4200', sfmc: '湖北', Ip: 'https://fpcy.hb-n-tax.gov.cn: 443', address: 'https://fpcy.hb-n-tax.gov.cn: 443' },
        { code: '4300', sfmc: '湖南', Ip: 'https://fpcy.hntax.gov.cn: 8083', address: 'https://fpcy.hntax.gov.cn: 8083' },
        { code: '4400', sfmc: '广东', Ip: 'https://fpcy.gd-n-tax.gov.cn: 443', address: 'https://fpcy.gd-n-tax.gov.cn: 443' },
        { code: '4403', sfmc: '深圳', Ip: 'https://fpcy.szgs.gov.cn: 443', address: 'https://fpcy.szgs.gov.cn: 443' },
        { code: '4500', sfmc: '广西', Ip: 'https://fpcy.gxgs.gov.cn: 8200', address: 'https://fpcy.gxgs.gov.cn: 8200' },
        { code: '4600', sfmc: '海南', Ip: 'https://fpcy.hitax.gov.cn: 443', address: 'https://fpcy.hitax.gov.cn: 443' },
        { code: '5000', sfmc: '重庆', Ip: 'https://fpcy.cqsw.gov.cn: 80', address: 'https://fpcy.cqsw.gov.cn: 80' },
        { code: '5100', sfmc: '四川', Ip: 'https://fpcy.sc-n-tax.gov.cn: 443', address: 'https://fpcy.sc-n-tax.gov.cn: 443' },
        { code: '5200', sfmc: '贵州', Ip: 'https://fpcy.gz-n-tax.gov.cn: 80', address: 'https://fpcy.gz-n-tax.gov.cn: 80' },
        { code: '5300', sfmc: '云南', Ip: 'https://fpcy.yngs.gov.cn: 443', address: 'https://fpcy.yngs.gov.cn: 443' },
        { code: '5400', sfmc: '西藏', Ip: 'https://fpcy.xztax.gov.cn: 81', address: 'https://fpcy.xztax.gov.cn: 81' },
        { code: '6100', sfmc: '陕西', Ip: 'https://fpcyweb.sn-n-tax.gov.cn: 443', address: 'https://fpcyweb.sn-n-tax.gov.cn: 443' },
        { code: '6200', sfmc: '甘肃', Ip: 'https://fpcy.gs-n-tax.gov.cn: 443', address: 'https://fpcy.gs-n-tax.gov.cn: 443' },
        { code: '6300', sfmc: '青海', Ip: 'https://fpcy.qh-n-tax.gov.cn: 443', address: 'https://fpcy.qh-n-tax.gov.cn: 443' },
        { code: '6400', sfmc: '宁夏', Ip: 'https://fpcy.nxgs.gov.cn: 443', address: 'https://fpcy.nxgs.gov.cn: 443' },
        { code: '6500', sfmc: '新疆', Ip: 'https://fpcy.xj-n-tax.gov.cn: 443', address: 'https://fpcy.xj-n-tax.gov.cn: 443' },
      ];
      let dqdm = null;
      const swjginfo = [];
      if (val.length === 12) {
        dqdm = val.substring(1, 5);
      } else {
        dqdm = val.substring(0, 4);
      }
      if (dqdm !== '2102' && dqdm !== '3302' && dqdm !== '3502' && dqdm !== '3702' && dqdm !== '4403') {
        dqdm = `${dqdm.substring(0, 2)}00`;
      }
      for (let i = 0; i < citys.length; i++) {
        if (dqdm === citys[i].code) {
          swjginfo[0] = citys[i].sfmc;
          if (flag === 'debug') {   // 如果是开发调试模式或测试模式
            swjginfo[1] = 'http://127.0.0.1:7001/WebQuery';
          } else {
            swjginfo[1] = `${citys[i].Ip}/WebQuery`;
          }
          break;
        }
      }
      return swjginfo;
    },
    testCode(val) {
      if (val.length === 10 || val.length === 12) {
        const c = /^[0-9]*$/;
        const f = c.test(val);
        if (f === false) {
          this.showAmount = false;
          this.invoice.amount_sum = '';
          this.showCheckCode = false;
          this.invoice.check_code = '';
          this.cancheck = false;
          this.showToast({ msg: '发票代码有误!', width: '18em', time: 800 });
          return false;
        } else {
          const swjginfo = this.getSwjg(val, 0);
          if (swjginfo.length === 0) {
            this.showAmount = false;
            this.invoice.amount_sum = '';
            this.showCheckCode = false;
            this.invoice.check_code = '';
            this.cancheck = false;
            this.showToast({ msg: '发票代码有误!', width: '18em', time: 800 });
            return false;
          } else {
            console.log('');
            if (!this.adm(val) || swjginfo.length === 0) {
              this.showAmount = false;
              this.invoice.amount_sum = '';
              this.showCheckCode = false;
              this.invoice.check_code = '';
              this.cancheck = false;
              this.showToast({ msg: '发票代码有误!', width: '18em', time: 800 });
              return false;
            } else {
              this.fplx = this.alxd(val);
              if ((this.fplx === '01' || this.fplx === '02' || this.fplx === '03')) {
                return true;
              } else if ((this.fplx === '04' || this.fplx === '10' || this.fplx === '11')) {
                return true;
              }
            }
          }
        }
      } else if (val !== '') {
        this.showAmount = false;
        this.invoice.amount_sum = '';
        this.showCheckCode = false;
        this.invoice.check_code = '';
        this.cancheck = false;
        this.showToast({ msg: '发票代码格式有误!', width: '18em', time: 800 });
        return false;
      } else if (val === '' && this.showCheckCode === true) {
        this.showCheckCode = false;
        this.invoice.check_code = '';
        this.cancheck = false;
      } else if (val === '' && this.showAmount === true) {
        this.showAmount = false;
        this.invoice.amount_sum = '';
      }
    },
    testNumber(val) {
      if (!this.ahm(val) && val !== '') {
        this.showToast({ msg: '发票号码格式有误!', width: '18em', time: 800 });
        return false;
      }
      return true;
    },
    checkData() {
      if ((this.fplx === '04' || this.fplx === '10' || this.fplx === '11') && !this.showCheckCode && !this.cancheck) {
        this.showToast({
          msg: '您添加的发票为普通发票，请输入验证码',
          width: '20em',
          time: 800,
        });
        setTimeout(() => {
          this.showCheckCode = true;
          this.cancheck = true;
        }, 900);
      } else if ((this.fplx === '01' || this.fplx === '02' || this.fplx === '03')) {
        this.showAmount = true;
        this.showCheckCode = false;
        this.cancheck = true;
      }
      const params = {
        invoice_number: (this.invoice.invoice_num).toString(),
        invoice_code: (this.invoice.invoice_code).toString(),
        invoice_date: (this.invoice.invoice_date.split('-').join('')).toString(),
        // tenant_id: this.$store.login.state.user.tenant_id,   // jiebaoyun: 81920358843678720   jver : 143616744011111111
        // 'request_type': 'taxweb'
      };
      if (this.cancheck) {
        if (this.showAmount) {
          params.amount = (this.invoice.amount_sum).toString();
        }
        if (this.showCheckCode) {
          params.check_code = (this.invoice.check_code).toString();
        }
        if (this.showAmount) {
          if (params.invoice_code === '' || params.invoice_number === '' || params.invoice_date === '' || params.amount === '') {
            this.showToast({ msg: '请填写完毕!', width: '18em', time: 800 });
            return false;
          }
        }
        if (this.showCheckCode) {
          // if (params.invoice_code === '' || params.invoice_number === '' || params.invoice_date === '' || params.check_code === '') {
          if (params.invoice_code === '' || params.invoice_number === '' || params.invoice_date === '') {
            this.showToast({ msg: '请填写完毕!', width: '18em', time: 800 });
            return false;
          }
        }

        if (params.invoice_code === '' || params.invoice_number === '') {
          this.showToast({ msg: '请填写完毕!', width: '18em', time: 800 });
          return false;
        }
        // 验证校验码
        if (params.check_code !== '' && this.showCheckCode === true) {
          if (params.check_code.length !== 6) {
            this.showToast({ msg: '检验码格式有误!', width: '18em', time: 800 });
            return false;
          }
        }
        this.$store.dispatch('getInvoice', params).then((res) => {
          if (res.code === '0000') {
            console.log('发票', res);
            if (!res.data.verify_code_pic && res.data.invoice) {
              this.$route.meta.keepAlive = true;
              this.$store.commit('INVOICE', res.data.invoice);
              this.$store.commit('MY_INVOICE_DETAIL', res.data.invoice);
              setTimeout(() => {
                this.$router.push({
                  path: 'invoiceDetail', query: { type: 'auto' },
                });
              }, 800);
            } else if (res.data.verify_code_pic && !res.data.invoice) {
              this.$route.meta.keepAlive = true;
              this.$store.commit('VERIFY_CODE_PIC', res.data.verify_code_pic);
              this.invoice.invoice_date = this.invoice.invoice_date.split('-').join('');
              this.$store.commit('INVOICE', this.invoice);
              setTimeout(() => {
                this.$router.push({
                  path: 'addInvoice', query: { type: 'auto' },
                });
              }, 800);
            } else {
              this.showToast({ msg: res.msg, width: '17em', time: 700 });
            }
          } else {
            this.showToast({ msg: res.msg, width: '17em', time: 700 });
          }
        });
      } else {
        // 验证发票代码
        if (params.invoice_code !== '') {
          const flag = this.testCode(params.invoice_code);
          if (!flag) {
            this.showToast({ msg: '发票代码有误!', width: '18em', time: 800 });
            return false;
          }
        }
        // 验证发票号码
        if (params.invoice_number !== '') {
          const flag = this.testNumber(params.invoice_number);
          if (!flag) {
            this.showToast({ msg: '发票号码有误!', width: '18em', time: 800 });
            return false;
          }
        }
      }
    },
  },
};
</script>
<style lang="less" scoped>
@import "~@/assets/css/theme.less";

@white: #FFFFFF;
@border-grey: #DEDFE0;
.scale {
  content: "";
  position: absolute;
  left: 0px;
  right: 0px;
  transform: scaleY(.3);
  transform-origin: 0 0;
}

.bottom-border {
  position: relative;
  &:after {
    .scale;
    bottom: 0px;
    border-bottom: 1px solid @border-grey;
  }
}

.btn-on {
  background: @color-main;
}
.btn-off {
  background: #C1C1C1;
}
.invoice-main {
  background: @white;
  .invoice {
    height: 50px;
    margin: 0;
    margin-left: 15px;
    .bottom-border;
    .invoice-title {
      display: block;
      width: 100px;
      font-size: 16px;
      padding: 14px 0; // margin-right: 18px;
      line-height: 22px;
      color: #000000;
    }
    img {
      width: 24px;
      height: 24px;
      padding: 13px 10px;
    }
    .inputBox {
      color: #858585;
    }
    .readonly-input{
      // display: flex;
      border: none;
      background: none;
      outline:none;
      height: 100%;
      font-size: 16px;
      line-height: 22px;
      text-shadow: 0px 0px 0px #858585 ; // 字体颜色
      -webkit-text-fill-color: transparent; // 模拟让placeholder成镂空状态
      &::-webkit-input-placeholder{
        color: #C3C3C3;
        opacity: 0.5;
      }
    }
    .invoice-type {
      font-size: 12px;
      color: @color-main;
      line-height: 17px;
      padding: 16px 15px;
    }
  }
  .footer-btn {
    position: fixed;
    bottom: 0;
    width: 100%;
    .btn {
      bottom: 0;
      height: 50px;
      font-size: 18px;
      color: @white;
      box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.10);
      border: none;
      outline: none;
    }
  }
}
</style>
