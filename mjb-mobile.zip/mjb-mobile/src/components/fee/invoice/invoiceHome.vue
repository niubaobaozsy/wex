<!--
  describe："发票主页-已使用"
  created by：panjm
  date：2017-11-6
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div class="mine-wrap">
    <div class="mine-content">
      <my-header :title="top.title" @previous="goBack"></my-header>
      <div class="has-header has-tab">
        <Tab :tabList="tabList"></Tab>
      </div>
      <div class="has-footer">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
import { platform } from '@/platform';
import MyHeader from '../../common/header';
import Tab from '../../common/Tab';

export default {
  components: {
    MyHeader,
    Tab,
  },
  data() {
    return {
      top: {
        title: '我的发票',
      },
      tabList: [
        {
          name: '未使用',
          linkTo: 'notUsed',
        },
        {
          name: '已使用',
          linkTo: 'used',
        },
      ],
    };
  },
  methods: {
    goBack() {
      if (this.$store.state.extCall) {
        platform.exit();
      } else {
        this.$router.push('/fee');
      }
    },
  },
  beforeRouteUpdate (to, from, next) {
    if (!this.$router.isInnerNavigate) {
      this.goBack();
    } else {
      next();
    }
  },
};
</script>
