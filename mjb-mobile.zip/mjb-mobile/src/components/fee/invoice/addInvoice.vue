<!--
  describe：“新增发票” 页面
  created by：Yim Lee
  date：2017-11-02
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/addInvoice.less';
</style>
<template>
  <div class="addinvoice-wrap">
    <my-header :title="'新增发票'" :showBack="true" :redDotCount="2" @previous="goBack"></my-header>
    <!-- 页面列表 -->
    <div class=" has-header addinvoice">
      <div v-for="(item,index) in addInvoiceList" :key="index" class="addinvoice-list" v-if="index === 4 ? showAmount : true">
        <ul :class="['columns', 'is-mobile', 'is-gapless', 'list-item', {'bottom-border': index == 4}]">
          <span :class="['item-text', {'bottom-border': index !== 4}]">{{ item.text }}</span>
          <li :class="['column', 'item-value', {'bottom-border': index !== 4, 'red-text': index == 4, 'black-text': index !== 4}]">
            <span v-if="index !== 4">{{ item.value }}</span>
            <span v-else>{{ item.value }}</span>
          </li>
        </ul>
      </div>
      <div class="identify-wrap">
        <div class="identify columns is-mobile is-gapless">
          <div class="tips column">
            <span>请输入下方图片中的</span>
            <span :class="verCodeImgTip[vertifyCodeImg.key4]?verCodeImgTip[vertifyCodeImg.key4].color:''">{{ verCodeImgTip[vertifyCodeImg.key4]?verCodeImgTip[vertifyCodeImg.key4].text:'' }}</span>
          </div>
          <div class="column identify-code">
            <div class="identify-in columns is-mobile is-gapless">
              <input-box :placeholder="placeholder" :textCenter="false" :isreadOnly="false" :inputValue="inputValue" @on-focus="isshowDel = true" @on-blur="onblur" @get-value="getValue"></input-box>
              <div class="delImg" @click="delText" v-show="isshowDel == true"><img :src="delImg" alt="deleteImg"></div>
              <div class="code" @click="changeImg"><img :src="`data:image/png;base64,${vertifyCodeImg.key1}`" alt="vertifyCodeImg"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <button @click="verify">确定</button>
  </div>
</template>
<script>
import { mapState } from 'vuex';
import MyHeader from '../../common/header';
import del from '../../../assets/input-delete.png';
import InputBox from '../../common/input.vue';

export default {
  components: {
    MyHeader,
    InputBox,
  },
  data() {
    return {
      addInvoiceList: [
        {
          text: '发票代码',
          value: '',
        },
        {
          text: '发票号码',
          value: '',
        },
        {
          text: '校验码',
          value: '',
        },
        {
          text: '开票日期',
          value: '',
        },
        {
          text: '金额（不含税）',
          value: '',
        },
      ],
      invoiceObj: {},
      qrcode: '',             // 二维码
      delImg: del,
      placeholder: '请输入',
      isshowDel: false,
      showAmount: true,       // 判断是否显示金额
      inputValue: '',
      type: '',
      ischangeImg: false,    // 是否请求切换新的验证码图片
      vertifyCodeImg: {},  // 验证码图片
      verCodeImgTip: {
        '00': { text: '所有文字', color: 'code-black'},
        '01': { text: '红色文字', color: 'code-red'},
        '02': { text: '黄色文字', color: 'code-yellow'},
        '03': { text: '蓝色文字', color: 'code-blue'},
      },
    };
  },
  computed: mapState({
    invoice: state => state.myInvoice.invoice,
    verify_code_pic: state => state.myInvoice.verify_code_pic,
  }),
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    // input失去焦点时获取输入框的值,而且是格式化之后的值
    onblur(value) {
      this.isshowDel = false;
      this.inputValue = value.trim();
      this.vertifyCodeImg.answer = this.inputValue;
    },
    // 在没失去焦点的时候就获取输入的值
    getValue(value) {
      this.inputValue = value;
    },
    // 清空输入框内容
    delText() {
      this.inputValue = '';
      this.isshowDel = false;
    },
    // 点击切换验证码图片
    changeImg() {
      this.ischangeImg = true;
      this.getFullInvoice();
    },
    // 获取新增发票的所有数据
    // 01,10,044001633111,00008800,876.92,20160914,17176143639459344921,75C4
    // 01,04,4400171320,15995898,187.38,20170514,03690714020284530770,9178
    // 01,04,4400163320,75279610,194.00,20170513,03433339586355775320,8F74
    getFullInvoice() {
      const params = {
        invoice_code: (this.invoiceObj.invoice_code).toString() || '',
        invoice_number: (this.invoiceObj.invoice_num).toString() || '',
        invoice_date: (this.invoiceObj.invoice_date.split('-').join('')).toString() || '',
        check_code: (this.invoiceObj.check_code).toString() || '',
        // tenant_id: '143616744011111111', // jtest
        // tenant_id: '81920358843678720',  // jiebaoyun
      };
      if (this.type === 'scan' || this.ischangeImg) {
        if (this.type === 'scan') {
          params.qrcode = this.qrcode;
        } else if (this.showAmount) {
          params.amount = this.invoiceObj.amount_sum;
        }
        this.showLoading();
        this.$store.dispatch('getInvoice', params)
          .then((rep) => {
            if (rep.code === '0000') {
              this.hideLoading();
              this.$store.commit('VERIFY_CODE_PIC', rep.data.verify_code_pic);
              this.vertifyCodeImg = rep.data.verify_code_pic;
            } else {
              this.hideLoading();
            }
          });
      }
    },
    // 获取新增发票的发票代码、发票号码、校验码、开票时间和金额（不含税）的信息
    getInvoiceInfo(obj) {
      if (obj) {
        const date = obj.invoice_date;
        const year = date.slice(0, 4);
        const month = date.slice(4, 6);
        const day = date.slice(6, 8);
        this.addInvoiceList[0].value = obj.invoice_code;
        this.addInvoiceList[1].value = obj.invoice_num;
        this.addInvoiceList[2].value = obj.check_code;
        this.addInvoiceList[3].value = `${year}年${month}月${day}日`;
        this.addInvoiceList[4].value = `¥${obj.amount_sum}`;
      }
    },
    // 点击确认查验发票
    verify() {
      const params = {
        data: {
          invoice_code: (this.invoiceObj.invoice_code).toString(),
          invoice_number: (this.invoiceObj.invoice_num).toString(),
          invoice_date: (this.invoiceObj.invoice_date).toString() || '',
          check_code: (this.invoiceObj.check_code).toString(),
          // tenant_id: '81920358843678720',
          key1md5: this.vertifyCodeImg.key1md5,
          key2: this.vertifyCodeImg.key2,
          key3: this.vertifyCodeImg.key3,
          key5: this.vertifyCodeImg.key5,
          areacode: this.vertifyCodeImg.areacode,
          answer: this.vertifyCodeImg.answer,
        },
      };
      if (this.showAmount) {
        params.amount = this.invoiceObj.amount_sum;
      }
      if (this.type === 'scan') {
        params.qrcode = this.qrcode;
      }
      this.showLoading();
      this.$store.dispatch('vertifyInvoice', params)
        .then((rep) => {
          if (rep.code === '0000') {
            this.hideLoading();
            this.$store.commit('INVOICE', rep.data.invoice);
            setTimeout(() => {
              this.$router.push({
                path: 'invoiceDetail', query: { type: this.type },
              });  // 查验成功跳到发票详情页
            }, 800);
          } else if (rep.msg === '校验码不正确') {
            this.hideLoading();
            this.$vux.confirm.show({
              title: rep.msg,
            });
          } else {
            this.hideLoading();
            this.showToast({ msg: '查验失败!', width: '18em', time: 800 });
            this.$store.commit('WRONG_MSG', rep.msg);
            setTimeout(() => {
              this.$router.push({ path: 'invoiceFail', query: { type: this.type } });   // 查验失败跳到查验失败页
            }, 850);
          }
        });
    },
    // 初始化
    init() {
      this.type = this.$route.query.type;
      this.vertifyCodeImg = this.verify_code_pic;
      if (this.type === 'scan') {
        this.qrcode = this.$route.query.qrcode;
        const temp = this.$route.query.qrcode.split(',');
        this.invoiceObj.invoice_code = temp[2];
        this.invoiceObj.invoice_num = temp[3];
        this.invoiceObj.check_code = temp[6].slice(-6);
        this.invoiceObj.invoice_date = temp[5];
        this.invoiceObj.amount_sum = temp[4];
        this.$store.commit('INVOICE', this.invoiceObj);
        this.getInvoiceInfo(this.invoiceObj);
        this.getFullInvoice();
      } else if (this.type === 'auto') {
        this.invoiceObj = this.invoice;
        this.getInvoiceInfo(this.invoiceObj); // 获取手工录入发票信息
        // this.getFullInvoice();
      }
      if (!this.invoice.amount_sum) {
        this.showAmount = false;
      }
    },
  },
  mounted() {
    this.init();
  },
};
</script>
