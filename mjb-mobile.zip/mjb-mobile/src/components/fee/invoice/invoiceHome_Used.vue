<!--
  describe："发票主页-未使用"
  created by：panjm
  date：2017-11-2
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div infinite-scroll-immediate-check="true" v-infinite-scroll="loadMoreFun" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
    <!-- <div class="invoiceBox" v-for="(data, index) in views.invoiceList" :key="index" @click="goDetail(data.invoice_id,data.related)">
        <div class="invoiceLeft">
          <div :class="['invoiceType',{'blue':tempType[data.invoice_type_name]=='专票'},{'green':tempType[data.invoice_type_name]=='普票'},{'pink':tempType[data.invoice_type_name]=='电子'}]">
            {{ tempType[data.invoice_type_name] }}
          </div>
          <div class="invoiceSecondCol">
            <p>发票号码：{{ data.invoice_num }}</p>
            <p>{{ data.sales_unit_name }}</p>
            <p>{{ data.invoice_date }}</p>
          </div>
        </div>
        <div class="invoiceThirdCol">
          <p class="invoicePrice">￥{{ data.total_amount.toFixed(2) }}</p>
        </div>
      </div> -->
    <div class="invoiceBox" v-for="(data, index) in views.invoiceList" :key="index" @click="goDetail(data.invoice_id,data.related)">
      <div class="invoiceLeft">
        <div :class="['invoiceType',{'blue':tempType[data.invoice_type_name]=='专票'},{'green':tempType[data.invoice_type_name]=='普票'},{'pink':tempType[data.invoice_type_name]=='电子'}]">
          {{ tempType[data.invoice_type_name] }}
        </div>
      </div>
      <div class="invoiceRight">
        <div class="invoiceSecondCol">
          <p>发票号码：{{ data.invoice_num }}</p>
          <p>{{ data.sales_unit_name }}</p>
          <p>{{ data.invoice_date }}</p>
        </div>
        <div class="invoiceThirdCol">
          <p class="invoicePrice">￥{{ data.total_amount.toFixed(2) }}</p>
          <span class="invoiceStatus" v-if="data.first_node_status=='未查检'">{{ data.first_node_status }}</span>
        </div>
      </div>
    </div>
    <load-more v-if="loadMore" :tip="'加载中...'" style="width: 100%;padding: 22px 0px;box-sizing: border-box;margin:0 auto"></load-more>
    <div v-if="!views.invoiceList.length && isloading" class="emptyBox">
      <img class="no_data_img" src="../../../assets/images/common/no_data.png" alt="">
      <p class="no_data_text">暂无数据</p>
    </div>
  </div>
</template>

<script>
import { LoadMore } from 'vux';

export default {
  components: {
    LoadMore,
  },
  data() {
    return {
      loadMore: false,
      isloading: false,
      loadingFlag: 0,
      busy: false,
      hasNextPage: true,
      pageInfo: {
        page_number: 1,
        page_size: 10,
      },
      tempType: {
        1: '专票',
        2: '专票',
        3: '普票',
        4: '普票',
        10: '电子',
        11: '普票',
      },
      views: {
        tabIndex: 1, // 0: 未用   1: 已用
        invoiceList: [],
      },
    };
  },
  methods: {
    goDetail(invoiceId, tabIndex) {
      setTimeout(() => {
        this.$router.push({
          path: '/fee/myInvoice/invoiceDetail', query: { id: invoiceId },
        });
      }, 800);
      this.$store.commit('MY_INVOICE_TYPE', 'get');
      this.$store.commit('MY_RELATED', tabIndex);
    },
    getInvoiceList() {
      const params = {
        query_param: {
          pageSize: this.pageInfo.page_size,
          pageNumber: this.pageInfo.page_number,
          related: this.views.tabIndex,
        },
      };
      this.$store.dispatch('myInvoiceQuery', params).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          this.isloading = true;
          if (res.data && res.data.list && res.data.list.length) {
            this.views.invoiceList = this.views.invoiceList.concat(res.data.list);
            this.views.invoiceList.forEach((item) => {
              item.invoice_type_name = item.invoice_type_name ? parseInt(item.invoice_type_name, 10) : '';
            });
            this.pageInfo.page_number += 1;
          } else if (res.data && res.data.list && !res.data.list.length) {
            this.hasNextPage = false;
            this.loadMore = false;
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    loadMoreFun() {
      if (this.hasNextPage) {
        setTimeout(() => {
          this.loadMore = true;
          this.getInvoiceList();
        }, 500);
      }
    },
  },
  mounted() {
    this.showLoading();
    this.getInvoiceList();
  },
};
</script>
