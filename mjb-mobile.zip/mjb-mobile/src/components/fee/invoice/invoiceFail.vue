 <!--
  describe：“新增发票失败原因” 页面
  created by：邓莹莹
  date：2017-11-02
-->
<template>
  <div>
    <my-header :title="'失败原因'" :showBack="true" :showRedDot="true" @previous="goBack"></my-header>
    <div class="msg has-header">
      <div class="msg-title">
        <img :src="failImg" alt="failImg" class="icon-fail">
        <span class="fail-title">检验失败</span>
      </div>
      <div class="sug-text column">{{ wrongMsg }}</div>
    </div>
    <div class="invoice-detail-wrap">
      <span class="invoice-title">发票信息</span>
      <div class="invoice-detail">
        <div class="row columns is-mobile is-gapless" v-for="(item, index) in invoiceList" :key="index" v-if="index === 4 ? isshowTotalAmount  : true" v-show="index === 5 ? isshowAmount : true">
          <span class="row-title">{{ item.text }}</span>
          <span class="row-value column">{{ item.value }}</span>
        </div>
      </div>
    </div>
    <div class="footer-btn columns is-mobile is-gapless">
      <button class="try_btn column is-6" @click.stop.prevent="goBack">重试</button>
      <button class="input_btn column is-6" @click.stop.prevent="reEntry">{{ other }}</button>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex';
import { platform } from '@/platform';
import MyHeader from '../../common/header';
import warn from '../../../assets/images/fee/warn.png';

export default {
  components: {
    MyHeader,
  },
  data() {
    return {
      failImg: warn,
      wrongMsg: '',
      isshowAmount: false,
      isshowTotalAmount: false,
      other: '', // '录入其他发票' 或 '扫描其他发票'
      type: '',
      invoiceList: [
        {
          text: '发票代码：',
          value: '',
        },
        {
          text: '发票号码：',
          value: '',
        },
        {
          text: '校验码：',
          value: '',
        },
        {
          text: '开票日期：',
          value: '',
        },
        {
          text: '总金额：',
          value: '',
        },
        {
          text: '不含税金额：',
          value: '',
        },
      ],
    };
  },
  computed: mapState({
    invoice: state => state.myInvoice.invoice,
    wrong_msg: state => state.myInvoice.wrong_msg,
  }),
  methods: {
    // 返回 或 点击重试
    goBack() {
      this.$router.go(-1);
    },
    // 点击重试
    // tryAgain() {
    //   this.$router.push({ path: 'addInvoice', query: { type: this.type } });
    // },
    getInvoiceInfo(obj) {
      if (obj) {
        const date = obj.invoice_date;
        const year = date.slice(0, 4);
        const month = date.slice(4, 6);
        const day = date.slice(6, 8);
        this.invoiceList[0].value = obj.invoice_code;
        this.invoiceList[1].value = obj.invoice_num;
        this.invoiceList[2].value = obj.check_code;
        this.invoiceList[3].value = `${year}/${month}/${day}`;
        if (obj.total_amount) {
          this.isshowTotalAmount = true;
          this.invoiceList[4].value = `¥${obj.total_amount}`;
        }
        if (obj.amount_sum) {
          this.isshowAmount = true;
          this.invoiceList[5].value = `¥${obj.amount_sum}`;
        }
      }
    },
    // 初始化
    init() {
      this.type = this.$route.query.type;
      if (this.type === 'scan') {
        this.other = '扫描其他发票';
      } else if (this.type === 'auto') {
        this.other = '录入其他发票';
      }
      this.wrongMsg = this.wrong_msg;
      this.getInvoiceInfo(this.invoice);
    },
    // 点击录入其他发票
    reEntry() {
      if (this.type === 'scan') {
        platform.scan().then((data) => {
          // 判断扫描的是文本还是链接
          if (data.text) {
            const params = {
              qrcode: data.text,
            };
            this.qrCodeQuery(params);
          } else {
            this.showToast({ msg: '二维码扫描失败', width: '12em' });
          }
        }, () => this.showToast({ msg: '二维码扫描失败', width: '12em' }));
      } else if (this.type === 'auto') {
        this.$router.replace('invoiceManually');
      }
    },
    qrCodeQuery(params) {
      const reg = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-.,@?^=%&:/~+#]*[\w\-@?^=%&/~+#])?/;
      if (reg.test(params.qrcode)) {
        this.showToast({ msg: '二维码扫描失效' });
        return false;
      }
      if (params.qrcode.indexOf(',') !== '-1') {
        const tempArr = params.qrcode.split(',');
        if (tempArr.length < 8) {
          this.showToast({ msg: '二维码扫描失效' });
          return false;
        }
      }
      this.showLoading('查询中…');
      this.$store.dispatch('getInvoice', params).then((res) => {
        this.hideLoading();
        if (res.code === '0000') {
          this.$router.push({
            path: '/fee/myInvoice/addInvoice', query: { type: 'scan' },
          });
          this.$store.commit('MY_INVOICE_DETAIL', res.data.invoice);
        } else {
          this.showToast({ msg: `二维码扫描失效(${res.code}):${res.msg}` });
        }
      });
      return true;
    },
  },
  mounted() {
    this.init();
  },
};
</script>
<style lang="less" scoped>
@import "~@/assets/css/theme.less";

@white: #FFFFFF;
@border-grey: #DEDFE0;
.scale {
  content: "";
  position: absolute;
  left: 0px;
  right: 0px;
  transform: scaleY(.3);
  transform-origin: 0 0;
}

.msg {
  background: @white;
  position: relative;
  padding: 20px 15px;
  &:after {
    .scale;
    bottom: 0px;
    border: 1px solid @border-grey;
  }
  .msg-title {
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    text-align: center;
    .icon-fail {
      width: 19px;
      height: 19px;
    }
    .fail-title {
      color: #000000;
      font-size: 16px;
      line-height: 16px;
      margin-left: 5px;
    }
  }
  .sug-text {
    font-size: 14px;
    line-height: 20px;
    color: #666666;
    letter-spacing: -0.09px;
    margin-top: 18px;
    padding: 0 !important;
  }
}

.invoice-detail-wrap {
  background: @white;
  position: relative;
  &:after {
    .scale;
    bottom: 0px;
    border: 1px solid @border-grey;
  }
  padding: 10px 0;
  .invoice-title {
    margin: 5px 15px;
    font-size: 16px;
    line-height: 22px;
    color: #858585;
    margin-bottom: 5px;
  }
  .invoice-detail {
    padding: 5px 0px;
    .row {
      font-size: 12px;
      color: #9B9B9B;
      line-height: 12px;
      padding: 5px 15px;
      margin: 0 !important;
      .row-title {
        width: 72px;
        margin-right: 27px;
      }
      .row-value {
        display: flex;
        align-items: center;
      }
    }
  }
}

.footer-btn {
  position: fixed;
  width: 100%;
  bottom: 0;
  box-shadow: 0 -2px 8px 0 rgba(0, 0, 0, 0.10);
  font-size: 18px;
  height: 50px;
  .try_btn {
    background: @white;
    color: @color-main;
    line-height: 25px;
    border: none;
    outline: none;
  }
  .input_btn {
    background: @color-main;
    color: @white;
    line-height: 25px;
    padding: 13px;
    border: none;
    outline: none;
  }
}
</style>
