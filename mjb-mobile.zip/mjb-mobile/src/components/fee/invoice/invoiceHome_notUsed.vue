<!--
  describe："发票主页-未使用"
  created by：panjm
  date：2017-11-2
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
  <div infinite-scroll-immediate-check="true" v-infinite-scroll="loadMoreFun" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
    <swipeout>
      <swipeout-item v-for="(data, index) in views.invoiceList" :key="index" ref="swip">
        <div slot="right-menu">
          <swipeout-button @click.native="showPlugin(data.invoice_id, index)" style="font-size:17px;background:#FC4B4B;width: 66px;border-top:0.5px solid #DEDFE0;border-bottom:1px solid #DEDFE0;">删除</swipeout-button>
        </div>
        <div slot="content" @click="goDetail(data.invoice_id,data.related)">
          <!-- <div class="invoiceBox">
              <div class="invoiceLeft">
                <div :class="['invoiceType',{'blue':tempType[data.invoice_type_name]=='专票'},{'green':tempType[data.invoice_type_name]=='普票'},{'pink':tempType[data.invoice_type_name]=='电子'}]">
                  {{ tempType[data.invoice_type_name] }}
                </div>
                <div class="invoiceSecondCol">
                  <p>发票号码：{{ data.invoice_num }}</p>
                  <p>{{ data.sales_unit_name }}</p>
                  <p>{{ data.invoice_date }}</p>
                </div>
              </div>
              <div class="invoiceThirdCol">
                <p class="invoicePrice">￥{{ data.total_amount.toFixed(2) }}</p>
                <span class="invoiceStatus" v-if="data.first_node_status=='未查检'">{{ data.first_node_status }}</span>
              </div>
            </div> -->
          <div class="invoiceBox">
            <div class="invoiceLeft">
              <div :class="['invoiceType',{'blue':tempType[data.invoice_type_name]=='专票'},{'green':tempType[data.invoice_type_name]=='普票'},{'pink':tempType[data.invoice_type_name]=='电子'}]">
                {{ tempType[data.invoice_type_name] }}
              </div>
            </div>
            <div class="invoiceRight">
              <div class="invoiceSecondCol">
                <p>发票号码：{{ data.invoice_num }}</p>
                <p>{{ data.sales_unit_name }}</p>
                <p>{{ data.invoice_date }}</p>
              </div>
              <div class="invoiceThirdCol">
                <p class="invoicePrice">￥{{ data.total_amount.toFixed(2) }}</p>
                <span class="invoiceStatus" v-if="data.first_node_status=='未查检'">{{ data.first_node_status }}</span>
              </div>
            </div>
          </div>
        </div>
      </swipeout-item>
    </swipeout>
    <load-more v-if="loadMore" :tip="'加载中...'" style="width: 100%;padding: 22px 0px;box-sizing: border-box;margin:0 auto"></load-more>
    <div v-if="!views.invoiceList.length && isLoading" class="emptyBox">
      <img class="no_data_img" src="../../../assets/images/common/no_data.png" alt="">
      <p class="no_data_text">暂无数据</p>
    </div>

    <div class="footerBtn">
      <div class="item manualInput" @click.stop.prevent="add">手工录入</div>
      <div class="item scanInput" @click.stop.prevent="scanInv">扫描录入</div>
    </div>
  </div>
</template>

<script>
import { platform } from '@/platform';
import { Swipeout, SwipeoutItem, SwipeoutButton, XButton, Confirm, LoadMore, XSwitch, TransferDomDirective as TransferDom } from 'vux';


export default {
  components: {
    Swipeout,
    SwipeoutItem,
    SwipeoutButton,
    XButton,
    Confirm,
    XSwitch,
    TransferDom,
    LoadMore,
  },
  data() {
    return {
      isLoading: false,
      loadMore: false,
      loadingFlag: 0,
      busy: false,
      hasNextPage: false,
      pageInfo: {
        page_number: 1,
        page_size: 10,
      },
      tempType: {
        1: '专票',
        2: '专票',
        3: '普票',
        4: '普票',
        10: '电子',
        11: '普票',
      },
      views: {
        tabIndex: 0, // 0: 未用   1: 已用
        invoiceList: [],
      },
    };
  },
  methods: {
    getInvoiceList() {
      const params = {
        query_param: {
          pageSize: this.pageInfo.page_size,
          pageNumber: this.pageInfo.page_number,
          related: this.views.tabIndex,
        },
      };
      this.showLoading();
      this.$store.dispatch('myInvoiceQuery', params).then((res) => {
        this.hideLoading();
        if (res && res.code === '0000') {
          this.isLoading = true;
          if (res.data && res.data.list && res.data.list.length) {
            this.views.invoiceList = this.views.invoiceList.concat(res.data.list);
            this.views.invoiceList.forEach((item) => {
              item.invoice_type_name = item.invoice_type_name ? parseInt(item.invoice_type_name, 10) : '';
            });
            if (res.data.totalPage > this.pageInfo.page_number) {
              this.hasNextPage = true;
              this.loadMore = true;
              this.pageInfo.page_number += 1;
            } else {
              this.hasNextPage = false;
              this.loadMore = false;
            }
            this.$nextTick(() => {
              this.vuxChangeWidth();
            });
          }
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    goBack() {
      this.$router.go(-1);
    },
    goDetail(invoiceId, tabIndex) {
      setTimeout(() => {
        this.$router.push({
          path: '/fee/myInvoice/invoiceDetail', query: { id: invoiceId },
        });
      }, 800);
      this.$store.commit('MY_INVOICE_TYPE', 'get');
      this.$store.commit('MY_RELATED', tabIndex);
    },
    deleteInvoice(invoiceId, index) {
      this.$store.dispatch('myiInvoiceDelete', { id: invoiceId }).then((res) => {
        if (res.code === '0000') {
          this.views.invoiceList.splice(index, 1);
          setTimeout(() => {
            this.$router.replace('/fee/myInvoice/invoiceHome/notUsed');
          }, 800);
          this.$store.commit('PJ_BACKMARK', 'delOk');
        } else if (res && res.code) {
          this.showToast({ msg: `请求异常(${res.code})` });
        }
      });
    },
    add() {
      setTimeout(() => {
        this.$router.push({ path: '/fee/myInvoice/invoiceManually' });
      }, 800);
    },
    scanInv() {
      platform.scan().then((data) => {
        // 判断扫描的是文本还是链接
        if (data.text) {
          const params = {
            qrcode: data.text,
          };
          this.qrCodeQuery(params);
        } else {
          this.showToast({ msg: '请扫描发票上二维码', width: '12em' });
        }
      }, () => this.showToast({ msg: '二维码扫描失败', width: '12em' }));
      // const params = { qrcode: '01,10,044001507111,26534233,12.0,20180305,07649398106228546966' };
      // const params = { qrcode: '01,10,012001700211,03930760,29.59,20180113,02789595113299606146,9E45,' };
      // this.qrCodeQuery(params);
    },
    qrCodeQuery(params) {
      const reg = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-.,@?^=%&:/~+#]*[\w\-@?^=%&/~+#])?/;
      if (reg.test(params.qrcode)) {
        this.showToast({ msg: '二维码扫描失效' });
        return false;
      }
      if (params.qrcode.indexOf(',') !== '-1') {
        const tempArr = params.qrcode.split(',');
        if (tempArr.length < 7) {
          this.showToast({ msg: '二维码扫描失效' });
          return false;
        } else if (tempArr.length > 8 && !tempArr[tempArr.length - 1]) {
          params.qrcode = params.qrcode.slice(0, -1);
        }
      }
      this.showLoading('查询中…');
      this.$store.dispatch('getInvoice', params).then((res) => {
        this.hideLoading();
          if (res.code === '0000') {
            if (!res.data.verify_code_pic && res.data.invoice) {
              this.$route.meta.keepAlive = true;
              this.$store.commit('INVOICE', res.data.invoice);
              this.$store.commit('MY_INVOICE_DETAIL', res.data.invoice);
              setTimeout(() => {
                this.$router.push({
                  path: '/fee/myInvoice/invoiceDetail', query: { type: 'scan' },
                });
              }, 800);
            } else if (res.data.verify_code_pic && !res.data.invoice) {
              this.$route.meta.keepAlive = true;
              this.$store.commit('VERIFY_CODE_PIC', res.data.verify_code_pic);
              setTimeout(() => {
                this.$router.push({
                  path: '/fee/myInvoice/addInvoice', query: { type: 'scan', qrcode:  params.qrcode},
                });
              }, 800);
            } else {
              this.showToast({ msg: `发票查验失效:${res.msg}`, width: '17em', time: 700 });
            }
          } else {
            this.showToast({ msg: `发票查验失效(${res.code}):${res.msg}`, width: '17em', time: 700 });
          }
        });
      return true;
    },
    loadMoreFun() {
      if (this.hasNextPage) {
        setTimeout(() => {
          this.loadMore = true;
          this.getInvoiceList();
        }, 500);
      }
    },
    showPlugin(invoiceId, index) {
      console.log(invoiceId);
      const self = this;
      this.$vux.confirm.show({
        title: '删除',
        content: '确定删除该发票吗？',
        onConfirm() {
          console.log(2);
          self.deleteInvoice(invoiceId, index);
          console.log(invoiceId);
        },
      });
    },
    vuxChangeWidth() {
      // 修改vux-swiper-item距离content的宽
      if (this.$refs.swip) {
        this.$refs.swip.forEach((swip) => {
          const list = swip.$slots['right-menu'][0].children.filter(one => one.tag);
          list.forEach((one) => {
            one.componentOptions.propsData.width = 66;
          });
        });
      }
    },

  },
  mounted() {
    this.getInvoiceList();
  },


};
</script>

