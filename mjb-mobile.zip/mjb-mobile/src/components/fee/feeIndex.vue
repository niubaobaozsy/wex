<!--
  describe：费用页面
  created by：欧倩伶
  date：2017-10-19
-->
<template>
  <div class="main" @touchmove="noMove">
    <my-header title="费用" :showScan="false" :showBack="false" :showRedDot="true" :redDotCount="2" @previous="goBack"></my-header>
    <div class="has-header has-footer">
      <cellBox v-for="(menu, index) in feeMenus" :key="index" :list="menu"></cellBox>
      <approving />
    </div>
    <footerBar :index="0" :tabName="'fee'"></footerBar>
  </div>
</template>

<script>
import { platform } from '@/platform';
import myReimburse from '../../assets/images/fee/home/myReimburse2x.png';
import myApply from '../../assets/images/fee/home/myApply2x.png';
import expenseRecord from '../../assets/images/fee/home/expenseRecord2x.png';
import approve from '../../assets/images/fee/home/approve2x.png';
import myInvoice from '../../assets/images/fee/home/myInvoice2x.png';
// import underDevIcon from '../../assets/images/fee/home/underDev2x.png';
import cellBox from '../common/cellBox.vue';
import footerBar from '../common/footerBar.vue';
import MyHeader from '../common/header';
import approving from './approve/approving';

export default {
  components: {
    cellBox,
    footerBar,
    MyHeader,
    approving,
  },
  data() {
    return {
      icons: {
        myReimburse,
        myApply,
        approve,
        myInvoice,
        expenseRecord,
      },
      feeMenus: [],
    };
  },
  computed: {
    baseConfig() {
      return this.$store.state.baseConfig;
    },

    feeMenuCfg() {
      return this.$store.state.menuConfig.fee.children;
    },

    // hasDefaultConfig() {
    //   return this.$store.state.hasDefaultConfig;
    // },
  },
  methods: {
    noMove(e) {
      // e.preventDefault();
      // e.stopPropagation();
    },
    goRoute(name) {
      this.$router.push(name);
    },
    goBack() {
      platform.exitApp();
    },
    // getDefaultConfig() {
    //   if (this.hasDefaultConfig) return;
    //   const _this = this;
    //   this.showLoading('正在加载页面');
    //   this.$store.dispatch('getDefaultConfig').then((rep) => {
    //     this.hideLoading();
    //     if (rep) {
    //       if (!(rep.data && rep.data.busiOrg && rep.data.busiOrg.config_id && rep.data.company && rep.data.company.company_id)) {
    //         this.$vux.confirm.show({
    //           content: '使用美捷报需填写报销基础信息，前往填写？',
    //           confirmText: '好',
    //           cancelText: '退出',
    //           onConfirm() {
    //             _this.$router.push({ path: '/mine/reimburseTitle' });
    //           },
    //           onCancel() {
    //             platform.exit();
    //           },
    //         });
    //       } else {
    //         this.$store.commit('HAS_DEFAULT_CONFIG', true);
    //       }
    //     }
    //   });
    // },
    getApprovalCnt(group, index) {
      this.$store.dispatch('getApprovalCnt').then((rep) => {
        if (rep && rep.code === '0000') {
          const nVal = Object.assign([], this.feeMenus[group]);
          nVal[index].msgCnt = rep.data.number;
          this.feeMenus.splice(group, 1, nVal)
        }
      });
    },
  },
  created() {
    Object.keys(this.feeMenuCfg).forEach((item, index) => {
      const value = this.feeMenuCfg[item];
      if (!this.feeMenus[value.group]) {
        this.feeMenus[value.group] = [];
      }
      if (!value.hidden) {
        const menuCopy = Object.assign({}, value);
        const menusArr = this.feeMenus[value.group];
        menuCopy.icon = this.icons[value.icon];
        menuCopy.msgCnt = 0;
        menuCopy.unreadCnt = 0;
        menusArr.push(menuCopy);
        if (item === 'approve') {
          this.getApprovalCnt(value.group, menusArr.length - 1);
        }
      }
    });
  },
};
</script>

<style lang="less" scoped>
.main {
  position: absolute;
  width: 100%;
  top: 0;
  bottom: 0;
}
</style>
