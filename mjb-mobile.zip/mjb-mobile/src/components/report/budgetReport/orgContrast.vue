<!--
  describe：报表 “部门对比” 模块
  created by：Yim Lee
  date：2017-10-31
-->
<template>
  <div class="wrap">
    <div class="selectOpt">
      <selectOption :List="selectOptions" @on-select="selectedTime"></selectOption>
    </div>
    <!-- 条形图组件 -->
    <barGraph ref="chart" class="echart-container" :cusOpt="cusOpt"></barGraph>
    <!-- 图表明细组件 -->
    <collationTable :budgetType="budgetType" :tabType="tabType" :graphTable="graphTable"
      :busy="busy" :hasNextPage="hasNextPage" :isLoading="isLoading" @loadMore="loadMore">
    </collationTable>
  </div>
</template>

<script>
import barGraph from '../../common/barGraph';
import collationTable from '../../common/collationTable';
import selectOption from '../../common/selectOption';
import footerBar from '../../common/footerBar';

export default {
  components: {
    barGraph,
    collationTable,
    footerBar,
    selectOption,
  },
  data() {
    return {
      tabType: 'orgContrast', // 判断是变动分析还是部门对比的标志
      budgetType: '',         // 判断是预算占用还是预算执行的标志
      titleType: '',          // 判断选择的时间条件是本月、上月、本季度还是本年
      hasNextPage: true,      // 判断判断是否还有下一页
      busy: false,            // 判断是否可以滚动屏幕加载更多数据
      isLoading: true,        // 判断是否在加载数据
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate(),
      pageNumber: 1,          // 当前要显示的页码
      pageSize: 5,            // 每页加载的数据量
      startDate: '',          // 开始时间（如果为空，后台会自动以当月的第一天作为开始时间）
      endDate: '2017-12-31',            // 结束时间
      busiMainOrgId: '',      // 预算主体ID(非必须)
      feeTypeId: '',          // 预算科目(非必须)
      cusOpt: {
        title: '',
        xAxis: [],
        series: {
          backgroundSeries: {
            name: '预算总额',
            data: [],
          },
          foregroundSeries: {
            name: '',
            data: [],
          },
        },
      },
      graphTable: [],         // 预算执行或预算占用报表明细的所有数据
      selectOptions: [{ text: '上月', value: 'last_month' }, { text: '本月', value: 'this_month' }, { text: '本季度', value: 'this_season' }, { text: '本年', value: 'this_year' }],
    };
  },
  methods: {
    // 加载更多
    loadMore() {
      const self = this;
      this.busy = true;
      if (this.hasNextPage) {
        setTimeout(() => {
          self.getBudgetData();
        }, 200);
      }
    },
    // 获取查看哪一个时间的费用预算明细
    selectedTime(val) {
      console.log(this.year);
      this.startDate = '';
      this.endDate = '';
      const lastMonth = this.month - 1;                                        // 获取上个月的月份
      // 获取当前月份（月份的参数是从0开始的，因此要-1）的第0天即为上个月的最后一天，从而判断上个月有多少天（免去了做是否是闰年或者是否是2月的判断）
      const lastDay = new Date(this.year, this.month - 1, 0).getDate();             // 获取上个月的最后一天
      // 每选择一次时间都要把上次选择的时间的数据清空
      this.graphTable = [];
      this.cusOpt.xAxis = [];
      this.cusOpt.series.foregroundSeries.data = [];
      this.cusOpt.series.backgroundSeries.data = [];
      // 判断选择是时间条件是上月、本月、本季度还是本年，从而相应地修改图表Y轴的标题、开始时间和结束时间
      switch (val) {
        case 'last_month':
          this.endDate = `${this.year}-${lastMonth}-${lastDay}`;
          this.cusOpt.title = `各部门上月预算${this.titleType}比率(%)`;
          break;
        case 'this_month':
          this.endDate = `${this.year}-${this.month}-${this.day}`;
          this.cusOpt.title = `各部门本月预算${this.titleType}比率(%)`;
          break;
        // 如果选择的是本季度，还得判断当前是哪个季度
        case 'this_season':
          if (this.month in [1, 2, 3]) {
            this.startDate = `${this.year}-01-01`;
            this.endDate = `${this.year}-${this.month}-${this.day}`;
          } else if (this.month in [4, 5, 6]) {
            this.startDate = `${this.year}-04-01`;
            this.endDate = `${this.year}-${this.month}-${this.day}`;
          } else if (this.month in [7, 8, 9]) {
            this.startDate = `${this.year}-07-01`;
            this.endDate = `${this.year}-${this.month}-${this.day}`;
          } else {
            this.startDate = `${this.year}-10-01`;
            this.endDate = `${this.year}-${this.month}-${this.day}`;
          }
          this.cusOpt.title = `各部门本季度预算${this.titleType}比率(%)`;
          break;
        case 'this_year':
          this.startDate = `${this.year}-01-01`;
          this.endDate = `${this.year}-${this.month}-${this.day}`;
          this.cusOpt.title = `各部门本年预算${this.titleType}比率(%)`;
          break;
        default:
          this.endDate = `${this.year}-${this.month}-${this.day}`;
          this.cusOpt.title = `各部门本月预算${this.titleType}比率(%)`;
      }
      this.getBudgetData();
    },
    // 获取报表明细
    getBudgetData() {
      let path = '';
      // this.cusOpt.xAxis = [];
      // this.cusOpt.series.foregroundSeries.data = [];
      // this.cusOpt.series.backgroundSeries.data = [];
      const params = {
        pageNumber: this.pageNumber,                             // 分页页码
        pageSize: this.pageSize,                                 // 分页大小
        queryParam: {
          startDate: this.startDate || '',                       // 开始时间
          endDate: this.endDate || `${this.year}-${this.month}-${this.day}`,    // 结束时间，YYYY-MM-DD
          // busiMainOrgId: this.busiMainOrgId,                  // 预算主体ID
          // feeTypeId: this.feeTypeId || '',                    // 预算科目
        },
      };
      this.showLoading();
      this.isLoading = true;
      if (this.budgetType === 'occupy') {
        path = 'getOccupyContrast';
      } else if (this.budgetType === 'excuted') {
        path = 'getExcuteContrast';
      }
      this.$store.dispatch(path, params)
        .then((rep) => {
          this.hideLoading();
          this.busy = false;
          this.isLoading = false;
          if (rep.code === '0000') {
            this.busy = false;
            this.isLoading = false;
            if (rep.data.pages > this.pageNumber) {
              this.hasNextPage = true;
              this.pageNumber ++;
            } else {
              this.hasNextPage = false;
            }
            console.log(rep.data.records)
            rep.data.records=[{
                budgetAmount: 0,
                budgetAmountAdjusted: 0,
                budgetOccupyRate: 0,
            },{
                budgetAmount: 0,
                budgetAmountAdjusted: 0,
                budgetOccupyRate: 0,
            },{
                budgetAmount: 0,
                budgetAmountAdjusted: 0,
                budgetOccupyRate: 0,
            },{
                budgetAmount: 0,
                budgetAmountAdjusted: 0,
                budgetOccupyRate: 0,
            },{
                budgetAmount:  0,
                budgetAmountAdjusted: 0,
                budgetOccupyRate: 0,
            },{
                budgetAmount: 0,
                budgetAmountAdjusted: 0,
                budgetOccupyRate: 0,
            },{
                budgetAmount: 0,
                budgetAmountAdjusted: 0,
                budgetOccupyRate: 0,
            },{
                budgetAmount: 0,
                budgetAmountAdjusted: 0,
                budgetOccupyRate: 0,
            },{
                budgetAmount: 0,
                budgetAmountAdjusted: 0,
                budgetOccupyRate: 0,
            },]
            for(let ii = 0; ii < rep.data.records.length; ii++){
                rep.data.records[ii].budgetAmount = parseInt(Math.random()*100000000, 10);
                rep.data.records[ii].budgetAmountAdjusted = parseInt(Math.random()*100000000, 10);
                rep.data.records[ii].budgetOccupyRate = parseInt(Math.random()*100000000, 10);
            }
            if (rep.data.records) {
              this.graphTable = this.graphTable.concat(rep.data.records);
            } else {
              this.graphTable = [];
            }
            // this.graphTable = rep.data.records;
            for (let i = 0; i < this.graphTable.length; i++) {
              this.cusOpt.xAxis.push(this.graphTable[i].budgetOrgName);
              if (this.budgetType === 'occupy') {
                this.cusOpt.series.foregroundSeries.data.push(
                  parseInt((this.graphTable[i].budgetAmount / 10000000).toFixed(0), 10));
              } else if (this.budgetType === 'excuted') {
                this.cusOpt.series.foregroundSeries.data.push(
                  parseInt((this.graphTable[i].invoiceAmount / 10000000).toFixed(0), 10));
              }
              this.cusOpt.series.backgroundSeries.data.push(
                parseInt((this.graphTable[i].budgetAmountAdjusted / 10000000).toFixed(0), 10));
            }
            this.$refs.chart.drawBarGraph();
          }
        });
    },
  },
  mounted() {
    this.budgetType = this.$route.query.budgetType;
    // 判断是预算占用还是预算执行
    if (this.budgetType === 'occupy') {
      this.titleType = '占用';
      this.cusOpt.title = '各部门本月预算占用比率(%)';
      this.cusOpt.series.foregroundSeries.name = '已占用';
    } else if (this.budgetType === 'excuted') {
      this.titleType = '执行';
      this.cusOpt.title = '各部门本月预算执行比率(%)';
      this.cusOpt.series.foregroundSeries.name = '已执行';
    }
    // 异步加载
    this.getBudgetData();
  },
};
</script>

<style lang="less" scoped>
.scale {
  content: "";
  position: absolute;
  left: 0px;
  right: 0px;
  transform: scaleY(.3);
  transform-origin: 0 0;
}

.wrap {
  position: relative;
  .selectOpt {
    z-index: 2;
    position: absolute;
    top: 20px;
    right: 16px;
  }
  .echart-container {
    height: 284px;
    background: #FFFFFF;
    position: relative;
    padding-bottom: 15px;
    padding-top: 20px;
    &:after {
      .scale;
      bottom: 0px;
      border-bottom: 1px solid #DEDFE0;
    }
  }
}
</style>
