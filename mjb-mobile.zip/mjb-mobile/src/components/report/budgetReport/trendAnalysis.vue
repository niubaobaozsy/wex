<!--
  describe：报表 “变动分析” 模块
  created by：Yim Lee
  date：2017-10-31
-->
<template>
  <div class="wrap">
    <!-- 折线图组件 -->
    <lineGraph ref="chart" class="echart-container" :cusOpt="cusOpt"></lineGraph>
    <!-- 图表明细组件 -->
    <collationTable :budgetType="budgetType" :tabType="tabType" :graphTable="graphTable"
      :busy="busy" :hasNextPage="hasNextPage" :isLoading="isLoading" @loadMore="loadMore">
    </collationTable>

  </div>
</template>

<script>
import lineGraph from '../../common/lineGraph';
import collationTable from '../../common/collationTable';
import footerBar from '../../common/footerBar';

export default {
  components: {
    lineGraph,
    collationTable,
    footerBar,
  },
  data() {
    return {
      tabType: 'trendAnalysis',
      budgetType: '',
      hasNextPage: true,
      busy: false,
      isLoading: true,
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate(),
      pageNumber: 1,
      pageSize: 5,
      startDate: '',
      endDate: '',
      busiMainOrgId: '',
      feeTypeId: '',
      cusOpt: {
        title: '每月预算总额(百万)',
        xAxis: [],
        series: [],
        // xAxis: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
        // series: [943, 851, 1020, 785, 960, 888, 980, 910, 750, 830, 230, 900],
      },
      // 占用或执行数据
      graphTable: [],
    };
  },
  methods: {
    // 加载更多
    loadMore() {
      const self = this;
      this.busy = true;
      if (this.hasNextPage) {
        setTimeout(() => {
          self.getBudgetData();
        }, 200);
      }
    },
    // 获取报表明细
    getBudgetData() {
      let path = '';
      // this.cusOpt.xAxis = [];
      // this.cusOpt.series = [];
      const params = {
        pageNumber: this.pageNumber,        // 分页页码
        pageSize: this.pageSize,          // 分页大小
        queryParam: {
          startDate: `${this.year}-01-01` || '',       // 开始时间
          endDate: this.endDate || `${this.year}-${this.month}-${this.day}`,         // 结束时间，YYYY-MM-DD
          // busiMainOrgId: this.busiMainOrgId,   // 预算主体ID
          // feeTypeId: this.feeTypeId || '',       // 预算科目
        },
      };
      if (this.budgetType === 'occupy') {
        path = 'getOccupyAnalysis';
      } else if (this.budgetType === 'excuted') {
        path = 'getExcuteAnalysis';
      }
      this.showLoading();
      this.isLoading = true;
      this.$store.dispatch(path, params)
        .then((rep) => {
          this.hideLoading();
          this.busy = false;
          this.isLoading = false;
          if (rep.code === '0000') {
            if (rep.data.pages > this.pageNumber) {
              this.hasNextPage = true;
              this.pageNumber ++;
            } else {
              this.hasNextPage = false;
            }
            if (rep.data.records) {
              this.graphTable = this.graphTable.concat(rep.data.records);
            } else {
              this.graphTable = [];
            }
            // this.graphTable = rep.data.records;
            for (let i = 0; i < this.graphTable.length; i++) {
              this.cusOpt.xAxis.push(this.graphTable[i].month);
              this.cusOpt.series.push(
                parseInt((this.graphTable[i].budgetAmountAdjusted / 10000000).toFixed(0), 10));
            }
            this.$refs.chart.drawLineGraph();
          }
        });
    },
  },
  mounted() {
    this.budgetType = this.$route.query.budgetType;
    this.getBudgetData();
  },
};
</script>

<style lang="less" scoped>
.scale {
  content: "";
  position: absolute;
  left: 0px;
  right: 0px;
  transform: scaleY(.3);
  transform-origin: 0 0;
}

.wrap {
  position: relative;
  margin-bottom: 60px;
  .echart-container {
    height: 284px;
    background: #FFFFFF;
    position: relative;
    padding-bottom: 15px;
    padding-top: 20px;
    &:after {
      .scale;
      bottom: 0px;
      border-bottom: 1px solid #DEDFE0;
    }
  }
}
</style>
