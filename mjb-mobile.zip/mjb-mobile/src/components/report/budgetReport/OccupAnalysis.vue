<template>
  <div>
    <my-header :title="top.title" :showBack="true"  :redDotCount="2" @previous="goBack"></my-header>
    <feeTab :tabList="tabList" :budgetType="budgetType"></feeTab>
    <div class="has-header has-tab">
      <router-view></router-view>
    </div>
  </div>
</template>
<script>
import { platform } from '@/platform';
import feeTab from '../../common/Tab';
import MyHeader from '../../common/header';

export default {
  components: {
    feeTab,
    MyHeader,
  },
  data() {
    return {
      top: {
        img: 'src/assets/images/trade/back.png',
        title: '预算占用分析',
      },
      tabIndex: 0,
      budgetType: '',
      tabList: [
        {
          name: '变动分析',
          linkTo: 'trendAnalysis',
        },
        {
          name: '部门对比',
          linkTo: 'orgContrast',
        },
      ],
    };
  },
  mounted() {
    this.budgetType = this.$route.query.budgetType;
  },
  methods: {
    goBack() {
      platform.exitApp('report');
    },
  },
};
</script>
<style lang="less" scoped>

</style>
