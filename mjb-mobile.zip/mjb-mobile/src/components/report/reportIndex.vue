<template>
  <div class="main">
    <my-header :title="top.title" :showBack="false" :redDotCount="2" @previous="goBack"></my-header>
    <div class="has-header" v-if="!unavailale">
      <div v-for="(item,index) in cellList" :key="index" class="cell border columns is-mobile" @click="goRoute(item.path)">
        <div class="column is-6">
          <div class="font16">{{item.name}}</div>
          <div class="font14">本月：￥{{item.monthlySum}}</div>
          <div class="font14">本年：￥{{item.annualAmount}}</div>
        </div>
        <div class="column is-6">
          <div class="flr font16">￥{{item.money}}</div>
        </div>
      </div>
      <router-link class="cell border columns is-mobile" to="/activity/footprint">
        <div class="column">
          <div class="font16">我的足迹 👣</div>
          <div class="font14">2017我的年度出行报告</div>
        </div>
      </router-link>
    </div>
    <under-dev v-if="unavailale"></under-dev>
    <footerBar :index="3" :tabName="'report'"></footerBar>
  </div>
</template>
<script>
import { platform } from '@/platform';
import footerBar from '../common/footerBar';
import MyHeader from '../common/header';
import underDev from '../common/underDevTip';

export default {
  components: {
    footerBar,
    MyHeader,
    underDev,
  },
  data() {
    return {
      top: {
        title: '报表',
      },
      budgetType: '',
      cellList: [
        // {
        //   path: 'occupy',
        //   name: '费用预算占用分析',
        //   monthlySum: '5900.00',
        //   annualAmount: '8620.00',
        //   money: '5900.00',
        // },
        // {
        //   path: 'excuted',
        //   name: '费用预算执行分析',
        //   monthlySum: '1314.00',
        //   annualAmount: '52000.00',
        //   money: '6800.00',
        // },
      ],
      unavailale: false,
    };
  },
  computed: {
    bdType() {
      this.budgetType = this.$store.state.budgetType;
      return this.budgetType;
    },
  },
  methods: {
    goRoute(type) {
      if (type === 'occupy') {
        this.$router.push({ path: '/report/OccupAnalysis', query: { budgetType: type } });
      } else if (type === 'excuted') {
        this.$router.push({ path: '/report/ExcutedAnalysis', query: { budgetType: type } });
      }
    },
    goBack() {
      platform.exitApp();
    },
  },
};
</script>
<style lang="less" scoped>
@import "../../assets/css/base.less";

.main{
  .cell {
    padding: 12px 16px;
    -webkit-box-sizing: border-box;
    background: #fff;
    .font16 {
      color: #000000;
      font-size: 16px;
    }
    .flr {
      float: right;
    }
    .font14 {
      color: #9B9B9B;
      font-size: 14px;
    }
  }

  .columns {
    margin: 0 0 10px 0;
    .column {
      padding: 0;
    }
  }
}
</style>
