<!--
  describe：五种勋章（第四个页面）
  created by：
  date：
-->
<template>
  <div class="background">
    <div class="main" v-if="flyManShow">
      <div class="textTop">
        <p class="one">2017年您被誉为</p>
        <p class="two">空中小飞人</p>
        <p class="three">飞行次数超过<span>{{flightPrecent}}</span>%的小伙伴</p>
      </div>
      <div class="textBottom">
        <p>天空不是我的极限</p>
        <p>扶我起来，我还要飞</p>
      </div>
      <div class="upArrows animated flash infinite">
        <img :src="upArrows" alt="">
      </div>
      <div class="ray">
        <img :src="ray" alt="">
      </div>
      <div class="flyinMan">
        <img :src="flyinMan" alt="">
      </div>
    </div>
    <div class="main" v-if="ironManShow">
      <div class="textTop">
        <p class="one">2017年您被誉为</p>
        <p class="two">钢铁侠</p>
        <p class="three">飞行次数&用车次数皆超过80%的小伙伴</p>
      </div>
      <div class="ray">
        <img :src="ray" alt="">
      </div>
      <div class="flyinMan">
        <img :src="ironMan" alt="">
      </div>
      <div class="textBottom">
        <p>还有百分之一的能量？</p>
        <p>那就继续战斗吧</p>
      </div>
      <div class="upArrows animated flash infinite">
        <img :src="upArrows" alt="">
      </div>
    </div>
    <div class="main" v-if="OTManShow">
      <div class="textTop">
        <p class="one">2017年您被誉为</p>
        <p class="two">加班狂魔</p>
        <p class="three">用车次数超过<span>{{ddPrecent}}</span>%的小伙伴</p>
      </div>
      <div class="ray">
        <img :src="ray" alt="">
      </div>
      <div class="flyinMan">
        <img :src="OTMan" alt="">
      </div>
      <div class="textBottom">
        <p>睁眼闭眼只有工作</p>
        <p>工作使我快乐</p>
      </div>
      <div class="upArrows animated flash infinite">
        <img :src="upArrows" alt="">
      </div>
    </div>
    <div class="main" v-if="almostManShow">
      <div class="textTop">
        <p class="one">2017年您被誉为</p>
        <p class="two">差不多先生</p>
      </div>
      <div class="ray">
        <img :src="ray" alt="">
      </div>
      <div class="flyinMan">
        <img :src="almostMan" alt="">
      </div>
      <div class="textBottom">
        <p>工作生活两不误</p>
        <p>我就是那么酷</p>
      </div>
      <div class="upArrows animated flash infinite">
        <img :src="upArrows" alt="">
      </div>
    </div>
    <div class="main" v-if="hermitShow">
      <div class="textTop">
        <p class="one">2017年您被誉为</p>
        <p class="two">隐士</p>
      </div>
      <div class="ray">
        <img :src="ray" alt="">
      </div>
      <div class="flyinMan">
        <img :src="hermit" alt="">
      </div>
      <div class="textBottom">
        <p>枯藤老树昏鸦</p>
        <p>晚饭有鱼有虾</p>
      </div>
      <div class="upArrows animated flash infinite">
        <img :src="upArrows" alt="">
      </div>
    </div>
  </div>
</template>
<script>
import ray from '../../../assets/images/activity/footprint/ray.png';
import upArrows from '../../../assets/images/activity/footprint/upArrows.png';
import flyinMan from '../../../assets/images/activity/footprint/flyinMan.png';
import ironMan from '../../../assets/images/activity/footprint/IronMan.png';
import OTMan from '../../../assets/images/activity/footprint/OTMan.png';
import almostMan from '../../../assets/images/activity/footprint/almostMan.png';
import hermit from '../../../assets/images/activity/footprint/hermit.png';

export default {
  data() {
    return {
      flyManShow: false,
      ironManShow: false,
      OTManShow: false,
      almostManShow: false,
      hermitShow: false,
      third: false,
      forth: false,
      fifth: false,
      flyinMan,
      ray,
      upArrows,
      ironMan,
      OTMan,
      almostMan,
      hermit,
      requestParms: {
        pageNumber: 1,
        pageSize: 20,
        queryParam: {},
      },
      flightPrecent: 0,
      ddPrecent: 0,
      musicPlay: false,
      rotateStyle: {
        animationName: '',
        animationDuration: '',
        animationIterationCount: '',
      },
    };
  },
  methods: {
    getUserTitle() {
      return new Promise((resolve) => {
        this.$store.dispatch('userTitle', this.requestParms).then((res) => {
          resolve();
          if (res && res.code === '0000') {
            switch (res.data ? res.data.userTitle : '4') {
              case '1':
                this.ironManShow = true;
                break;
              case '2':
                this.flyManShow = true;
                break;
              case '3':
                this.OTManShow = true;
                break;
              case '4':
                this.almostManShow = true;
                break;
              case '5':
                this.hermitShow = true;
                break;
              default:
                this.almostManShow = true;
                break;
            }
            this.ddPrecent = res.data ? res.data.ddPrecent : 0;
            this.flightPrecent = res.data ? res.data.flightPrecent : 0;
          } else {
            this.almostManShow = true;
          }
        });
      });
    },
  },
  mounted() {
    this.getUserTitle();
  },
};
</script>
<style lang="less" scoped>
.background{
  position: absolute;
  width: 100%;
  height: 100%;
  background-image:url('../../../assets/images/activity/footprint/bg.png');
  background-repeat:no-repeat;
  background-attachment:fixed;
  background-position:center;
  background-size: 100% 100%;
  .main {
    position: absolute;
    width: 100%;
    height: 100%;
    // background-image:url('../../../assets/images/activity/footprint/bg.png');
    // background-repeat:no-repeat;
    // background-attachment:fixed;
    // background-position:center;
    // background-size: 100% 100%;
    .noSound {
      background-image: url("../../../assets/images/activity/footprint/noSound.png");
      background-size: 50px 50px;
      height: 50px;
      width: 50px;
      position: absolute;
      top: 3%;
      right: 6%;
      z-index: 10;
    }
    .sound {
      background-image: url("../../../assets/images/activity/footprint/sound.png");
      background-size: 50px 50px;
      height: 50px;
      width: 50px;
      position: absolute;
      top: 3%;
      right: 6%;
      z-index: 10;
    }
    .flyinMan {
      img {
        // background-image: url("../../../assets/images/activity/footprint/OTMan.png");
        // background-size: 200px 200px;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        height: 200px;
        width: 200px;
        animation-name: "zoomIn";
        animation-duration: 1.5s;
        animation-fill-mode: both;
      }
    }
    .ray {
      img {
        // background-image: url("../../../assets/images/activity/footprint/ray.png");
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        height: 100%;
        width: 100%;
        animation-name: "zoomIn";
        animation-duration: 1.5s;
        animation-fill-mode: both;
      }
    }
    .textBottom {
      position: absolute;
      text-align: center;
      left: 0;
      right: 0;
      margin: auto;
      bottom: 20%;
      font-size: 16px;
      color: white;
      animation-name: "fadeInUp";
      animation-duration: 1.5s;
      animation-fill-mode: both;
    }
    .upArrows {
      img {
        position: absolute;
        bottom: 10%;
        left: 0;
        right: 0;
        margin: auto;
        height: 20px;
        width: 40px;
      }
    }
    .textTop {
      position: absolute;
      text-align: left;
      margin: 40px 20px;
      width: auto;
      font-family: "NSimSun";
      animation-name: "fadeInDown";
      animation-duration: 1.5s;
      animation-fill-mode: both;
      p.one {
        font-size: 20px;
        color: white;
      }
      p.two {
        font-size: 30px;
        color: yellow;
      }
      p.three {
        font-size: 15px;
        color: white;
      }
    }
  }
}
</style>
