<!--
  describe："Homepage of footprint"
  created by：Guanxj
  date：2017-12-26
-->
<style lang="less" scoped>
@import '../../../assets/css/fee/myInvoice/invoice.less';
</style>
<template>
    <div @touchstart="ontouchStart($event)" @touchmove="ontouchMove($event)">
      <div v-if="ismusic" class="music" :style="rotateStyle" @click="song">
        <img src="../../../assets/images/activity/footprint/sound.png" alt="">
      </div>
      <div v-if="!ismusic" class="music" @click="song">
        <img src="../../../assets/images/activity/footprint/noSound.png" alt="">
      </div>
      <audio id="myAudio" src="./static/bgm.mp3" autoplay loop="loop" paused="isPaused"></audio>
      <router-view></router-view>
    </div>
</template>

<script>
// import { platform } from '@/platform';

export default {
  data() {
    return {
      pageList: [
        {
          name: '飞行',
          procRt: 'flight',
        },
        {
          name: '用车',
          procRt: 'car',
        },
        {
          name: '费用',
          procRt: 'cost',
        },
        {
          name: '勋章',
          procRt: 'fiveMedal',
        },
        {
          name: '结语',
          procRt: 'end',
        },
      ],
      msg: '',
      touchStart: 0,  // 手指触摸屏幕的起点
      distance: 0,    //
      style: '',
      scrollTop: 0,
      currentPage: 0,
      ismusic: true,
      isPaused: false,
      rotateStyle: {
        animationName: 'circle',
        animationDuration: '3s',
        animationIterationCount: 'infinite',
      },
    };
  },
  methods: {
    getScrollTop() {
      if (document.body.scrollTop) return document.body.scrollTop;
      if (document.documentElement.scrollTop) return document.documentElement.scrollTop;
      return 0;
    },
    ontouchStart(e) {
      this.touchStart = e.targetTouches[0].clientY;
      this.scrollTop = this.getScrollTop();
    },
    ontouchMove(e) {
      if (!this.touchStart) {
        return;
      }
      // 刷新页面后判断位于那一页，防止页面顺序错乱
      const procRt = this.$router.app.$children['0'].$route.fullPath.split('/');
      switch (procRt[procRt.length - 1]) {
        case 'flight':
          this.currentPage = 0;
          break;
        case 'car':
          this.currentPage = 1;
          break;
        case 'cost':
          this.currentPage = 2;
          break;
        case 'fiveMedal':
          this.currentPage = 3;
          break;
        case 'end':
          this.currentPage = 4;
          break;
        default: break;
      }
      const touch = e.targetTouches[0];
      if (this.scrollTop === 0) {
        this.distance = touch.clientY - this.touchStart;
        if (this.distance > 0) {
          e.preventDefault();
          if (this.distance < 130) {
            if (this.distance > 50) {
              if (this.currentPage > 0) {
                this.currentPage--;
                this.$router.push(this.pageList[this.currentPage].procRt);
              }
            }
          }
        } else {
          e.preventDefault();
          if (this.distance > -130) {
            if (this.distance < -50) {
              if (this.currentPage < 4) {
                this.currentPage++;
                this.$router.push(this.pageList[this.currentPage].procRt);
              }
            }
          }
        }
      }
    },
    song() {
      this.ismusic = !this.ismusic;
      const audio = document.getElementById('myAudio');
      if (this.isPaused) {
        this.rotateStyle = {
          animationName: 'circle',
          animationDuration: '3s',
          animationIterationCount: 'infinite',
        };
        this.isPaused = false;
        audio.play();
      } else {
        this.rotateStyle = {
          animationName: '',
          animationDuration: '',
          animationIterationCount: '',
        };
        this.isPaused = true;
        audio.pause();
      }
    },
  },
  // beforeRouteLeave(to, from, next) {
  //   if (to.path !== '/') {
  //     platform.exit();
  //     next(false);
  //   } else {
  //     next();
  //   }
  // },
};
</script>
<style lang="less" scoped>
.music {
  width: 38px;
  height: 38px;
  z-index: 10000;
  position: absolute;
  top: 40px;
  left: 85%;
  img{
    height: 38px;
  }
}
@keyframes circle{
  0% { transform:rotate(0deg); }
  100% { transform:rotate(-360deg); }
}
</style>
