<!--
  describe：不忘初心大总结（第五个页面）
  created by：
  date：
-->
<template>
  <div class="main">
    <div class="bg">
      <div class="text animated zoomIn">
        <p>美捷报已陪您走过</p>
        <p><span>{{count}}</span>天</p>
        <p class="small">时光匆匆</p>
        <p class="small">而我</p>
        <p class="small">始终在您身边</p>
        <p class="small">2018年</p>
        <p class="small">伴您随行</p>
      </div>
      <div class="bu">
        <img :src="bu" alt="">
      </div>
      <div class="wang">
        <img :src="wang" alt="">
      </div>
      <div class="chu">
        <img :src="chu" alt="">
      </div>
      <div class="xin">
        <img :src="xin" alt="">
      </div>
      <div class="global">
        <img :src="global" alt="">
      </div>
      <div class="person">
        <img :src="person" alt="">
      </div>
      <div class="operate animated flash infinite" >
        <div class="replay" @click="replay">
          <img :src="rePlay" alt="">
          <span>重新阅览</span>
        </div>
        <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
        <div class="goBack" @click="back">
          <img :src="goBack" alt="">
          <span>返回</span>
        </div>
      </div>
      <div class="textBottom">
        <p>数据来源于美捷报商旅系统</p>
      </div>
    </div>
  </div>
</template>
<script>
import { platform } from '@/platform';
import person from '../../../assets/images/activity/footprint/person.png';
import bu from '../../../assets/images/activity/footprint/bu.png';
import wang from '../../../assets/images/activity/footprint/wang.png';
import chu from '../../../assets/images/activity/footprint/chu.png';
import xin from '../../../assets/images/activity/footprint/xin.png';
import global from '../../../assets/images/activity/footprint/global.png';
import rePlay from '../../../assets/images/activity/footprint/replay.png';
import goBack from '../../../assets/images/activity/footprint/goBack.png';

export default {
  data() {
    return {
      person,
      bu,
      wang,
      chu,
      xin,
      global,
      rePlay,
      goBack,
      count: 0,
      requestParms: {
        queryParam: {},
      },
      musicPlay: false,
      rotateStyle: {
        animationName: '',
        animationDuration: '',
        animationIterationCount: '',
      },
    };
  },
  methods: {
    replay() {
      this.$router.push('/activity/footprint/flight');
    },
    back() {
      if (this.$store.state.extCall) {
        platform.exit();
      } else {
        this.$router.push('/report');
      }
    },
    getJoinTime() {
      this.$store.dispatch('joinTime', this.requestParms).then((res) => {
        if (res && res.code === '0000' && res.data) {
          this.count = res.data.join_time || 0;
        } else {
          this.count = 0;
        }
      });
    },
  },
  mounted() {
    this.getJoinTime();
  },
};
</script>
<style lang="less" scoped>
.main {
  .bg {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    bottom: 0;
    background-image: url("../../../assets/images/activity/footprint/bg2.png");
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-position: center;
    background-size: 100% 100%;
    .text{
      color: #fff;
      margin: 40px 20px;
      text-align: center;
      font-family: "NSimSun";
      p{
        font-size: 20px;
        display: flex;
        align-items: center;
        letter-spacing: 2px;
        span{
          font-size: 32px;
          color: #ffd200;
        }
      }
      p.small {
        font-size: 12px;
        display: flex;
        align-items: center;
        letter-spacing: 2px;
        margin: 10px 0px;
      }
    }
    .bu {
      img {
        position: absolute;
        top: 22%;
        left: 110px;
        height: 90px;
        width: 90px;
      }
    }
    .wang {
      img {
        position: absolute;
        top: 33%;
        left: 180px;
        height: 55px;
        width: 55px;
      }
    }
    .chu {
      img {
        position: absolute;
        top: 41%;
        left: 120px;
        height: 60px;
        width: 60px;
      }
    }
    .xin {
      img {
        position: absolute;
        top: 48%;
        left: 160px;
        height: 80px;
        width: 80px;
      }
    }
    .person {
      img {
        position: absolute;
        top: 66%;
        left: 50%;
        padding-left: 50px;
        height: 185px;
        width: 130px;
      }
    }
    .global {
      img {
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0px;
        margin: auto;
        height: 160px;
        width: 100%;
      }
    }
    .operate {
      position: absolute;
      bottom: 13%;
      left: 0;
      right: 0;
      margin: auto;
      text-align: center;
      color: #fff;
      .replay {
        display: inline;
        img {
          height: 16px;
          width: 16px;
          border-color: #fff;
        }
      }
      .goBack {
        display: inline;
        img {
          height: 16px;
          width: 16px;
          border-color: #fff;
        }
      }
    }
    .textBottom {
      position: absolute;
      text-align: right;
      left: 0;
      right: 6%;
      margin: auto;
      bottom: 2%;
      font-size: 12px;
      color: #F7F7F7;
    }
    .text.animated {
      animation-delay: 0s;
      animation-duration: 2s;
      animation-fill-mode: both;
    }
    // .bu.animated, .wang.animated, .chu.animated, .xin.animated {
    //   animation-delay: 0s;
    //   animation-duration: 2s;
    //   animation-fill-mode: both;
    // }
    .operate.animated {
      animation-delay: 2s;
      animation-duration: 5s;
      animation-fill-mode: both;
    }
  }
}
</style>
