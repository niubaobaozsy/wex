<!--
  describe：费用信息总结（第三个页面）
  created by：oql
  date：2017-12-22
-->
<template>
  <div class="main">
    <div class="bg">
      <div class="text animated fadeInLeft">
        <p>这一年您已在美捷报花费</p>
        <p><span>{{count}}</span>元</p>
      </div>
      <div class="wallet animated fadeInDown">
        <div class="glod animated fadeInRight"></div>
        <div class="ticket animated fadeInLeft"></div>
      </div>
      <p class="contect animated fadeInRight">公司月结，再也不用担心吃土了</p>
      <div class="arrow animated flash infinite"></div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      count: 0,
      requestParms: {
        pageNumber: 1,
        pageSize: 20,
        queryParam: {},
      },
      musicPlay: false,
      rotateStyle: {
        animationName: '',
        animationDuration: '',
        animationIterationCount: '',
      },
    };
  },
  methods: {
    getTotalExpense() {
      return new Promise((resolve) => {
        this.$store.dispatch('totalExpense', this.requestParms).then((res) => {
          resolve();
          if (res && res.code === '0000') {
            this.count = res.data || 0;
          }
        });
      });
    },
  },
  mounted() {
    this.getTotalExpense();
  },
};
</script>
<style lang="less" scoped>
.main {
  .bg {
    position: absolute;
    width: 100%;
    height: 100%;
    background-image: url("../../../assets/images/activity/footprint/bg.png");
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-position: center;
    background-size: 100% 100%;
    .text{
      color: #fff;
      margin: 40px;
      p{
        font-size: 20px;
        display: flex;
        align-items: baseline;
        letter-spacing: 2px;
        span{
          font-size: 32px;
          color: #ffd200;
        }
      }
    }
    .wallet {
      background-image: url("../../../assets/images/activity/footprint/wallet.png");
      background-size: 200px 200px;
      position: absolute;
      height:200px;
      width: 200px;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
      margin: auto;
      .glod{
        background-image: url("../../../assets/images/activity/footprint/glod.png");
        background-repeat: no-repeat;
        background-size: 54px 96px;
        height:96px;
        width: 54px;
        top: -31px;
        left: 26px;
        position: relative;
      }
      .ticket{
        background-image: url("../../../assets/images/activity/footprint/ticket.png");
        background-size: 92px 52px;
        height:52px;
        width: 92px;
        position: relative;
        top: 44px;
      }
    }
    .contect{
      position: absolute;
      color: #fff;
      font-size: 16px;
      letter-spacing: 2px;
      text-align: center;
      margin: auto;
      top: 75%;
      left: 0;
      right: 0;
    }
    .arrow{
      background-image: url("../../../assets/images/activity/footprint/upArrows.png");
      background-size: 30px 17px;
      width: 30px;
      height: 17px;
      margin: auto;
      position: absolute;
      top: 90%;
      right: 0;
      left: 0;
    }
    .animated {
      animation-duration: 1.5s;
      animation-fill-mode: both;
    }
  }
}
</style>
