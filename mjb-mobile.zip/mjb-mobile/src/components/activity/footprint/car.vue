<!--
  describe：用车信息总结（第二个页面）
  created by：oql
  date：2017-12-22
-->
<template>
  <div class="main">
    <div class="bg">
      <div class="text animated fadeInDown">
        <p>回望2017您因<span>{{reason}}</span>用车最多</p>
        <p>共用车<span>{{count}}</span>次</p>
        <p>超过<span>{{percent}}%</span>小伙伴</p>
      </div>
      <div class="city animated fadeInLeft">
        <div class="car animated fadeInRight">
          <div class="pageket animated fadeInRight"></div>
        </div>
      </div>
      <p class="contect animated fadeInUp">{{contectText}}</p>
      <div class="arrow animated flash infinite"></div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      reason: '',
      count: 0,
      percent: 0,
      requestParms: {
        queryParam: {},
      },
      musicPlay: false,
      rotateStyle: {
        animationName: '',
        animationDuration: '',
        animationIterationCount: '',
      },
      contectText: '英雄请留步，车券可以付',
    };
  },
  methods: {
    getvehicleUsedInfo() {
      return new Promise((resolve) => {
        this.$store.dispatch('vehicleUsed', this.requestParms).then((res) => {
          resolve();
          if (res && res.code === '0000') {
            this.reason = res.data ? res.data.reason : '**';
            this.count = res.data ? res.data.usedCount : 0;
            if (this.count === 0) {
              this.contectText = '我骑单车，我骄傲，我为公司省钞票';
            }
            this.percent = parseInt(res.data ? res.data.beyondNum : 0, 0);
          }
        });
      });
    },
  },
  mounted() {
    this.getvehicleUsedInfo();
  },
};
</script>
<style lang="less" scoped>
.main {
  .bg {
    position: absolute;
    width: 100%;
    height: 100%;
    background-image: url("../../../assets/images/activity/footprint/bg.png");
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-position: center;
    background-size: 100% 100%;
    .text{
      color: #fff;
      margin: 50px 20px;
      p{
        font-size: 20px;
        display: flex;
        align-items: baseline;
        letter-spacing: 2px;
        span{
          font-size: 32px;
          color: #ffd200;
        }
      }
    }
    .city {
      background-image: url("../../../assets/images/activity/footprint/city.png");
      background-size: 100% 309px;
      height:309px;
      width: 100%;
      position: absolute;
      margin: auto;
      top: 28%;
      .car{
        background-image: url("../../../assets/images/activity/footprint/car.png");
        background-repeat: no-repeat;
        background-size: 256px 111px;
        height:111px;
        width: 256px;
        top: 106px;
        position: relative;
        margin: auto;
        .pageket{
          background-image: url("../../../assets/images/activity/footprint/package.png");
          background-size: 36px 72px;
          height:72px;
          width: 36px;
          position: relative;
          top: 44px;
          left: 210px;
        }
      }
    }
    .contect{
      position: absolute;
      color: #fff;
      font-size: 16px;
      letter-spacing: 2px;
      text-align: center;
      margin: auto;
      top: 75%;
      left: 0;
      right: 0;
    }
    .arrow{
      background-image: url("../../../assets/images/activity/footprint/upArrows.png");
      background-size: 30px 17px;
      width: 30px;
      height: 17px;
      margin: auto;
      position: absolute;
      top: 90%;
      right: 0;
      left: 0;
    }
    .animated {
      animation-duration: 2s;
      animation-fill-mode: both;
    }
  }
}
</style>
