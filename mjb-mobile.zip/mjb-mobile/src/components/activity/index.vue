<!--
  describe：活动
  created by: 欧倩伶
  date：2017-12-22
-->
<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>
