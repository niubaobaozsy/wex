import Promise from 'promise';
// import util from '../js/util';

const _MIDEA_COMMON = 'MideaCommon';
const _MIDEA_USER = 'MideaUser';
const _MIDEA_BARCODE = 'MideaBarcode';
const _MIDEA_MAP = 'MideaMap';
const _MIDEA_ANNTO = 'MideaAnnto';
const _MIDEA_SALE = 'MideaSale';
const _MIDEA_PDF = 'MideaPdf';

/**
 * @alias widgetFactory
 * @namespace
 * @type
 * {{
 * callApi: functions.callApi, password: functions.password,
 * showMenu: functions.showMenu, showNav: functions.showNav, hideNav: functions.hideNav,
 * exit: functions.exit, goBack: functions.goBack, shake: functions.shake,
 * shakeStop: functions.shakeStop, showFloat: functions.showFloat, hideFloat: functions.hideFloat,
 * language: functions.language, getUser: functions.getUser, getUserMap: functions.getUserMap,
 * scan: functions.scan, scanNow: functions.scanNow, getScanExtra: functions.getScanExtra,
 * location: functions.location, startUpdatingLocation: functions.startUpdatingLocation,
 * stopUpdatingLocation: functions.stopUpdatingLocation, navigation: functions.navigation,
 * startOrder: functions.startOrder, stopOrder: functions.stopOrder,
 * getPicture: functions.getPicture, getContact: functions.getContact,
 * orgChoose: functions.orgChoose, orgMuChoose: functions.orgMuChoose,
 * changeColor: functions.changeColor, logout: functions.logout, webview: functions.webview,
 * screen: functions.screen, getExtra: functions.getExtra, getDeviceInfo: functions.getDeviceInfo,
 * openUrl: functions.openUrl, statistics: functions.statistics, share: functions.share,
 * showAppView: functions.showAppView, showPicker: functions.showPicker,
 * getPhoneMan: functions.getPhoneMan, goPersonalSet: functions.goPersonalSet,
 * goMyView: functions.goMyView, showWidget: functions.showWidget, showInput: functions.showInput,
 * hideInput: functions.hideInput, showMessageView: functions.showMessageView,
 * showFeedback: functions.showFeedback,
 * getBase64CodeFromPictures: functions.getBase64CodeFromPictures,
 * gotoSystemSetting: functions.gotoSystemSetting, showPdf: functions.showPdf,
 * showTxt: functions.showTxt
 * }}
 */
const functions = {
  /**
   * 调用cordova的方法
   * @param name {string} 方法组、类别
   * @param method {string} 方法名称
   * @param params {Array} 参数
   * @return {promise}
   */
  callApi: (name, method, params) => {
    const p = new Promise((resolve, reject) => {
      if (window.cordova) {
        try {
          window.cordova.exec((msg) => {
            resolve(msg);
          }, (msg) => {
            reject(msg);
          }, name, method, params || []);
        } catch (e) {
          console.log('_error', 'widget error:', e);
          reject(e);
        }
      } else {
        console.log('_debug', 'Cordova is not exist');
        reject('Cordova is not exist');
      }
    });
    return p;
  },
  /**
   * 验证密码，主要用于hr自助认证
   * @return {promise}
   */
  password: () => {
    functions.callApi(_MIDEA_COMMON, 'authPassword').then(angular.noop,
      (message) => {
        if (message === 0) {
          functions.password();
        } else if (message === -1) {
          functions.exit();
        }
      });
  },
  /**
   * 显示菜单
   * @return {*|promise}
   */
  showMenu: () => functions.callApi(_MIDEA_COMMON, 'showMenu', null),
  /**
   * 显示导航
   * @return {*|promise}
   */
  showNav: () => functions.callApi(_MIDEA_COMMON, 'showNav', null),
  /**
   * 隐藏导航
   * @return {*|promise}
   */
  hideNav: () => functions.callApi(_MIDEA_COMMON, 'hideNav', null),
  /**
   * 退出应用
   * @return {*|promise}
   */
  exit: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userInfo');
    localStorage.removeItem('redirectUrl');
    functions.callApi(_MIDEA_COMMON, 'exit', null);
  },
  /**
   * 退出子应用
   */
  // exitApp: (path) => {
  //   window.location.hash = path ? `#/${path}` : '#/';
  // },
  /**
   * 后退
   * @return {*|promise}
   */
  goBack: () => functions.callApi(_MIDEA_COMMON, 'goBack', null),
  /**
   * 开始监听手机摇动
   * @return {*|promise}
   */
  shake: () => functions.callApi(_MIDEA_COMMON, 'shake', null),
  /**
   * 停止监听手机摇动
   * @return {*|promise}
   */
  shakeStop: () => functions.callApi(_MIDEA_COMMON, 'shakeStop', null),
  /**
   * 显示悬浮菜单
   * @return {*|promise}
   */
  showFloat: () => functions.callApi(_MIDEA_COMMON, 'showFloat', null),
  /**
   * 隐藏悬浮菜单
   * @return {*|promise}
   */
  hideFloat: () => functions.callApi(_MIDEA_COMMON, 'hideFloat', null),
  /**
   * 获取当前语言
   * @return {*|promise}
   */
  language: () => functions.callApi(_MIDEA_COMMON, 'language', null),
  /**
   * 获取用户信息
   * @return {*|promise}
   */
  getUser: () => functions.callApi(_MIDEA_USER, 'getUser', null),
  /**
   * 获取用户信息-直通宝
   * @return {*|promise}
   */
  getUserMap: () => functions.callApi(_MIDEA_USER, 'getUserMap', null),
  /**
   * 启动扫码
   * @return {*|promise}
   */
  scan: () => functions.callApi(_MIDEA_BARCODE, 'scan', null),
  /**
   * 启动扫码
   * @return {*|promise}
   */
  scanNow: () => functions.callApi(_MIDEA_BARCODE, 'scanNow', null),
  /**
   * 获取扫码结果
   * @return {*|promise}
   */
  getScanExtra: () => functions.callApi(_MIDEA_BARCODE, 'getScanExtra', null),
  /**
   * 获取位置信息
   * @param arr {array} 参数
   * @return {*|promise}
   */
  location: arr => functions.callApi(_MIDEA_MAP, 'location', arr),
  /**
   * 开始更新位置信息
   * @param arr {array} 参数
   * @return {*|promise}
   */
  startUpdatingLocation: arr => functions.callApi(_MIDEA_MAP, 'startUpdatingLocation', arr),
  /**
   * 停止更新位置信息
   * @return {*|promise}
   */
  stopUpdatingLocation: arr => functions.callApi(_MIDEA_MAP, 'stopUpdatingLocation', arr),

  // locationForIOS: () => {
  //   const p = new Promise((resolve, reject) => {
  //     functions.startUpdatingLocation([5000]).then((res) => {
  //       functions.stopUpdatingLocation([]).then(() => {}, err => console.log(`Error: ${err}`));
  //       resolve(res);
  //     }, err => reject(err));
  //   });
  //   return p;
  // },

  // location: () => new Promise((resolve, reject) => {
  //   if (util.isIOSEnviron()) return functions.locationForIOS().then(res => resolve(res), err => reject(err));
  //   return functions.locationForAndriod().then(res => resolve(res), err => reject(err));
  // }),
  /**
   * 导航
   * @param arr {array} 参数
   * @return {*|promise}
   */
  navigation: arr => functions.callApi(_MIDEA_MAP, 'navTo', arr),
  /**
   * 开启订单跟踪-直通宝
   * @param p {array} 参数
   * @return {*|promise}
   */
  startOrder: p => functions.callApi(_MIDEA_ANNTO, 'startOrder', p),
  /**
   * 结束订单跟踪-直通宝
   * @param p {array} 参数
   * @return {*|promise}
   */
  stopOrder: p => functions.callApi(_MIDEA_ANNTO, 'stopOrder', p),
  /**
   * 拍照或选择图片
   * @param params {array} 参数
   * @return {*}
   */
  getPicture: (params) => {
    const p = new Promise((resolve, reject) => {
      if (navigator.camera) {
        try {
          const cameraOptions = params || {};
          cameraOptions.sourceType = params.sourceType; // 设置打开相机还是相册
          // 返回的图片数据格式  FILE_URI    DATA_URL
          cameraOptions.destinationType = navigator.camera.DestinationType.DATA_URL;
          cameraOptions.allowEdit = false; // 是否允许编辑
          cameraOptions.quality = params.quality || 50; // 照片压缩比例 [1, 100]
          // cameraOptions.mediaType = Camera.MediaType.PICTURE;
          // cameraOptions.correctOrientation = true;
          // cameraOptions.cameraDirection = Camera.Direction.BACK;
          // cameraOptions.encodingType = Camera.EncodingType.JPEG;
          // cameraOptions.saveToPhotoAlbum = true;
          navigator.camera.getPicture((msg) => {
            resolve(msg);
          }, (msg) => {
            reject(msg);
          }, cameraOptions);
        } catch (e) {
          console.log('_error', 'widget error:', e);
          reject(e);
        }
      } else {
        console.log('_debug', 'Cordova is not exist');
        reject('Cordova is not exist');
      }
    });
    return p;
  },
  /**
   * 获取通讯录
   * @param fields {string} 查找内容
   * @param options {array} 参数
   * @return {*}
   */
  getContact: (fields, options) => {
    const defer = $q.defer();
    try {
      navigator.service.contacts.find(fields,
        (msg) => {
          defer.resolve(msg);
        }, (msg) => {
          defer.reject(msg);
        }, options);
    } catch (e) {
      $log.error(e);
      defer.reject(e);
    }
    return defer.promise;
  },
  /**
   * 组织架构单选
   * @return {*|promise}
   */
  orgChoose: () => functions.callApi(_MIDEA_USER, 'orgChoose', null),
  /**
   * 组织架构多选
   * @param p {array} 参数
   * @return {*|promise}
   */
  orgMuChoose: p => functions.callApi(_MIDEA_USER, 'orgMuChoose', p),
  /**
   * 改变状态栏颜色-仅IOS
   * @param p {array} 参数 [r, g, b]
   * @return {*|promise}
   */
  changeColor: p => functions.callApi(_MIDEA_COMMON, 'statusBarColor', p),
  /**
   * 登出，注销用户
   * @return {*|promise}
   */
  logout: () => functions.callApi(_MIDEA_COMMON, 'logout', null),
  /**
   * 获取webview信息
   * @return {*|promise}
   */
  webview: () => functions.callApi(_MIDEA_COMMON, 'webview', null),
  /**
   * 获取屏幕信息
   * @return {*|promise}
   */
  screen: () => functions.callApi(_MIDEA_COMMON, 'screen', null),
  /**
   * 获取额外启动参数
   * @param params {array} 参数
   * @return {*|promise}
   */
  getExtra: params => functions.callApi(_MIDEA_COMMON, 'getExtra', params),
  /**
   * 获取设备信息
   * @return {*|promise}
   */
  getDeviceInfo: () => functions.callApi(_MIDEA_COMMON, 'getDeviceInfo', null),
  /**
   * 用外部浏览器打开链接
   * @param url {string} 链接地址url
   * @return {*|promise}
   */
  openUrl: url => functions.callApi(_MIDEA_COMMON, 'openSysBrowser', [url]),
  /**
   * h5事件监听
   * @param params {array} 参数
   * @return {*|promise}
   */
  statistics: params => functions.callApi(_MIDEA_COMMON, 'onEvent', params),
  /**
   * 分享
   * @param params {array} 参数
   * @return {*|promise}
   */
  share: params => functions.callApi(_MIDEA_COMMON, 'share', params),
  /**
   * 打开应用页面
   * @return {*|promise}
   */
  showAppView: () => functions.callApi(_MIDEA_COMMON, 'showAppView', ['messageView']),
  /**
   * 打开时间日期选择
   * @param params {array} 参数
   * @return {*}
   */
  showPicker: (params) => {
    const defer = $q.defer();
    if (window.datePicker) {
      params = angular.extend({
        date: new Date(),
        mode: 'date',
        type: 'day',
      }, params);

      datePicker.show(params, (date) => {
        defer.resolve(date);
      });
    } else {
      defer.reject();
    }

    return defer.promise;
  },
  /**
   * 打开通讯录
   * @return {*|promise}
   */
  getPhoneMan: () => functions.callApi(_MIDEA_USER, 'getContact', null),
  /**
   * 打开个人设置页面
   * @return {*|promise}
   */
  goPersonalSet: () => functions.callApi(_MIDEA_COMMON, 'showSetView', null),
  /**
   * 打开“我的”页面
   * @return {*|promise}
   */
  goMyView: () => functions.callApi(_MIDEA_COMMON, 'showMyView', null),
  /**
   * 打开widget
   * @param params {array} 参数
   * @return {*|promise}
   */
  // showWidget: params => functions.callApi(_MIDEA_COMMON, 'showWidget', params),
  // showWidget: (identifier, type) => { functions.callApi(_MIDEA_COMMON, 'showWidget', [identifier, { subModuleName: type }]); },
  showWidget: (identifier, params) => { functions.callApi(_MIDEA_COMMON, 'showWidget', [identifier, params]); },

  /**
   * 显示键盘
   * @return {*|promise}
   */
  showInput: () => functions.callApi(_MIDEA_COMMON, 'showInput', null),
  /**
   * 隐藏键盘
   * @return {*|promise}
   */
  hideInput: () => functions.callApi(_MIDEA_COMMON, 'hideInput', null),
  /**
   * 打开消息页面
   * @return {*|promise}
   */
  showMessageView: () => functions.callApi(_MIDEA_COMMON, 'showAppView', ['messageView']),
  /**
   * 打开美的通导购的意见反馈
   * @return {*|promise}
   */
  showFeedback: () => functions.callApi(_MIDEA_SALE, 'showFeedback', null),
  /**
   * 批量将图片转换成base64码
   * @param pictureList {array} 图片列表
   * @return {*|promise}
   */
  getBase64CodeFromPictures: pictureList => functions.callApi(_MIDEA_COMMON, 'getBase64s', pictureList),
  /**
   * 跳转到系统设置页面，
   * @param arr arr[0]为要跳转的对应的设置页面，暂时支持  蜂窝网络：CellularNetWork，WIFI：WIFI
   * @returns {*}
   */
  gotoSystemSetting: arr => functions.callApi(_MIDEA_COMMON, 'gotoSystemSetting', arr),
  /**
   * 附件展示
   * @param param {array} 附件链接url列表
   * @return {Promise}
   */
  showPdf: param => functions.callApi(_MIDEA_PDF, 'showPdf', param),
  /**
   * 附件txt展示
   * @param param {array} 参数
   * @return {Promise}
   */
  showTxt: param => functions.callApi(_MIDEA_PDF, 'showTxt', param),
  /**
   * 打开文档
   * @param param {array} 参数
   * @return {Promise}
   */
  openMimeType: param => functions.callApi(_MIDEA_COMMON, 'openMimeType', param),
  /**
   * @description c4a对称加密
   * @param params {string} 字符串
   * @returns {Promise}
   */
  financeAesEncrypt: params => functions.callApi('MideaFinancePlugin', 'AESEncrypt', [params]),
  /**
   * @description c4a对称解密
   * @param params {string} 字符串
   * @returns {Promise}
   */
  financeAesDecrypt: params => functions.callApi('MideaFinancePlugin', 'AESDecrypt', [params]),
  /**
   * @description c4a非对称加密
   * @param params {string} 字符串
   * @returns {Promise}
   */
  financeRsaEncrypt: params => functions.callApi('MideaFinancePlugin', 'RSAEncrypt', [params]),
  /**
   * @description c4a非对称解密
   * @param params {string}
   * @returns {Promise}
   */
  financeRsaDecrypt: params => functions.callApi('MideaFinancePlugin', 'RSADecrypt', [params]),
  /**
   * @description 返回c4a获取密钥的url
   * @param params {object} 对象，{baseUrl，keygroup，keyversion}
   * @returns {Promise}
   */
  financeSecurityKey: params => functions.callApi('MideaFinancePlugin', 'getSecurityKeyUrl', [params]),
  /**
   * @description 获取底座密码
   * @returns {Promise}
   */
  financeUserPassWord: () => functions.callApi(_MIDEA_USER, 'getUserPassword', []),
  /**
   * @description 美的金融保存json
   * @param key {string}
   * @param value {string}
   * @returns {Promise}
   */
  financeSaveJson: (key, value) => functions.callApi('MideaFinancePlugin', 'saveJson', [key, value]),
  /**
   * @description 美的金融读取json
   * @param key {string}
   * @returns {Promise}
   */
  financeGetJson: key => functions.callApi('MideaFinancePlugin', 'getJson', [key]),
  /**
   * @description 打电话（底座有bug）
   * @param phoneNumber {string}
   * @returns {Promise}
   */
  financeCall: phoneNumber => functions.callApi(_MIDEA_COMMON, 'callPhone', [phoneNumber]),
  /**
   * @description 获取美的金融底座版本信息
   * @param params {string}
   * @returns {Promise}
   */
  financeGetVersionInfo: params => functions.callApi('MideaFinancePlugin', 'getVersionInfo', [params]),
  /**
   * @description 更新美的金融底座版本
   * @param params {string}
   * @returns {Promise}
   */
  financeUpdateApp: params => functions.callApi('MideaFinancePlugin', 'updateApp', [params]),

  locationForIOS: () => {
    /**
     * 逆地理编码
     * @param {array lnglatXY} lnglatXY
     * @return {promise}
     */
    const _reGeocoder = (lnglatXY) => {
      const p = new Promise((resolve, reject) => {
        AMap.service('AMap.Geocoder', () => { // 回调函数
          const geocoder = new AMap.Geocoder(); // 实例化Geocoder
          geocoder.getAddress(lnglatXY, (status, result) => {
            if (status === 'complete' && result.info === 'OK') {
              const adaptRes = {};
              adaptRes.address = result.regeocode.formattedAddress;
              adaptRes.city = result.regeocode.addressComponent.city;
              adaptRes.citycode = result.regeocode.addressComponent.citycode;
              adaptRes.district = result.regeocode.addressComponent.district;
              adaptRes.latitude = lnglatXY[1];
              adaptRes.longitude = lnglatXY[0];
              adaptRes.province = result.regeocode.addressComponent.province;
              adaptRes.street = result.regeocode.addressComponent.street;
              resolve(adaptRes);
            } else {
              reject({ msg: '逆地理编码失败' });
            }
          });
        });
      });
      return p;
    };
    return new Promise((resolve, reject) => {
      functions.startUpdatingLocation([5000]).then((res) => {
        functions.stopUpdatingLocation([]);
        const pattern = /[();]/g;
        let str = res.substring(19);
        str = str.replace(pattern, '');
        str = JSON.parse(str);
        const latitude = str.latitude;
        const longitude = str.longitude;
        _reGeocoder([longitude, latitude]).then((adaptRes) => {
          resolve(adaptRes);
        }).catch((msg) => {
          reject(msg);
        });
      }, err => reject(err));
    });
  },
  /**
   * 注册推送服务
   */
  registerPushService: params => functions.callApi('MideaPush', 'registerPushService', [params]),
  /**
   * 解绑推送服务
   */
  untiePushService: params => functions.callApi('MideaPush', 'untiePushService', [params]),
  /**
   * 获取推送服务内容
   */
  getPush: () => functions.callApi('MideaPush', 'getPush', []),
};

// if (util.isIOSEnviron()) functions.location = functions.locationForIOS;

export default functions;
