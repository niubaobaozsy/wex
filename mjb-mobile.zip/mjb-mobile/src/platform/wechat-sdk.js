/**
 * Created by zhuangyh on 2017/07/13.
 */
import Promise from 'promise';
import wx from 'wx';

const functions = {
  /**
   * JS-SDK权限验证配置
   * @param appId {string} 企业微信的cropID
   * @param nonceStr {string} 随机串
   * @param signature {string} 签名
   * @param timestamp {string} 生成签名的时间戳
   * @param jsApiList {array} 需要使用的JS接口列表
   */
  wxconfig: (appId, nonceStr, signature, timestamp, jsApiList) => {
    window.Camera = {
      PictureSourceType: {
        SAVEDPHOTOALBUM: 'album',
        CAMERA: 'camera',
      },
    };
    window.imgInput = 'imgInput';
    return wx.config({
      debug: false,
      appId, // 必填，企业微信的cropID
      timestamp, // 必填，生成签名的时间戳
      nonceStr, // 必填，生成签名的随机串
      signature, // 必填，签名
      jsApiList: jsApiList || [ // 必填，需要使用的JS接口列表
        'checkJsApi',
        'onMenuShareTimeline',
        'onMenuShareAppMessage',
        'onMenuShareQQ',
        'onMenuShareWeibo',
        'onMenuShareQZone',
        'hideMenuItems',
        'showMenuItems',
        'hideAllNonBaseMenuItem',
        'showAllNonBaseMenuItem',
        'translateVoice',
        'startRecord',
        'stopRecord',
        'onVoiceRecordEnd',
        'playVoice',
        'onVoicePlayEnd',
        'pauseVoice',
        'stopVoice',
        'uploadVoice',
        'downloadVoice',
        'chooseImage',
        'previewImage',
        'uploadImage',
        'downloadImage',
        'getNetworkType',
        'openLocation',
        'getLocation',
        'hideOptionMenu',
        'showOptionMenu',
        'closeWindow',
        'scanQRCode',
        'chooseWXPay',
        'openProductSpecificView',
        'addCard',
        'chooseCard',
        'openCard',
      ],
    });
  },
  wxready: func => wx.ready(func),
  wxerror: func => wx.error(func),
  getUser: () => console.log('platform:接口未实现'),
  /**
   * 企业微信扫一扫
   */
  scan: () => {
    const p = new Promise((resolve, reject) => {
      wx.scanQRCode({
        desc: 'scanQRCode desc',
        needResult: 1, // 默认为0，扫描结果由企业微信处理，1则直接返回扫描结果，
        scanType: ['qrCode', 'barCode'], // 可以指定扫二维码还是一维码，默认二者都有
        success: (res) => {
          const reg = /^(https?:\/\/)/;
          const adaptRes = {};
          adaptRes.text = res.resultStr;
          if ((!reg.test(res.resultStr)) && (res.resultStr.slice(-1) === ',')) {
            adaptRes.text = res.resultStr.slice(0, -1); // 去掉最后的逗号
          }
          adaptRes.msg = res.errMsg;
          // alert(JSON.stringify(adaptRes));
          resolve(adaptRes);// 回调
        },
        error: (res) => {
          if (res.errMsg.indexOf('function_not_exist') > 0) {
            console.log('版本过低请升级');
          }
          const adaptRes = {};
          adaptRes.msg = res.errMsg;
          // alert(JSON.stringify(res));
          reject(adaptRes);
        },
      });
    });
    return p;
  },
  /**
   * 定位
   */
  location: () => {
    /**
     * 逆地理编码
     * @param {array lnglatXY} lnglatXY
     * @return {promise}
     */
    const _reGeocoder = (lnglatXY) => {
      const p = new Promise((resolve, reject) => {
        AMap.service('AMap.Geocoder', () => { // 回调函数
          const geocoder = new AMap.Geocoder(); // 实例化Geocoder
          geocoder.getAddress(lnglatXY, (status, result) => {
            if (status === 'complete' && result.info === 'OK') {
              const adaptRes = {};
              adaptRes.address = result.regeocode.formattedAddress;
              adaptRes.city = result.regeocode.addressComponent.city;
              adaptRes.citycode = result.regeocode.addressComponent.citycode;
              adaptRes.district = result.regeocode.addressComponent.district;
              adaptRes.latitude = lnglatXY[1];
              adaptRes.longitude = lnglatXY[0];
              adaptRes.province = result.regeocode.addressComponent.province;
              adaptRes.street = result.regeocode.addressComponent.street;
              resolve(adaptRes);
            } else {
              reject({ msg: '逆地理编码失败' });
            }
          });
        });
      });
      return p;
    };
    return new Promise((resolve, reject) => {
      wx.ready(() => {
        wx.getLocation({
          type: 'gcj02', // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的火星坐标，可传入'gcj02'
          success: (res) => {
            const latitude = res.latitude; // 纬度，浮点数，范围为90 ~ -90
            const longitude = res.longitude; // 经度，浮点数，范围为180 ~ -180。
            // let speed = res.speed, // 速度，以米/每秒计
            //     accuracy = res.accuracy; // 位置精度
            _reGeocoder([longitude, latitude]).then((adaptRes) => {
              console.log(adaptRes);
              resolve(adaptRes);
            }).catch((msg) => {
              reject(msg);
            });
            console.log(res);
          },
          error: (res) => {
            const adaptRes = {};
            adaptRes.msg = res.errMsg;
            reject(adaptRes);
          },
        });
      });
    });
  },
  startUpdatingLocation: () => {
    console.log('企业微信版本不需要该方法');
  },
  stopUpdatingLocation: () => {
    console.log('企业微信版本不需要该方法');
  },
  /**
   * 拍照或从相册中选图片--基于JS_SDK：图片转base64有安全错误，无法使用
   */
  _getPicture: (params) => {
    /**
     * 将图片url转为base64
     * @param {string url} 图片的本地url
     */
    const _getBase64 = (url) => {
      const p = new Promise((resolve, reject) => {
        const img = new Image();
        let dataUrl = null;
        img.src = url;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.height = img.height;
          canvas.width = img.width;
          canvas.getContext('2d').drawImage(img, 0, 0, img.width, img.height);
          dataUrl = canvas.toDataURL('image/jpeg');
          resolve(dataUrl);
        };
        img.onerror = () => {
          reject({ msg: 'img onerror' });
        };
      });
      return p;
    };
    return new Promise((resolve, reject) => {
      wx.chooseImage({
        count: 1, // 默认9
        sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
        sourceType: [params.sourceType], // 可以指定来源是相册还是相机，默认二者都有
        success: (res) => {
          _getBase64(res.localIds[0]).then((dataUrl) => {
            resolve(dataUrl);
          }, (msg) => {
            reject(msg);
          });
        },
        error: (res) => {
          const adaptRes = {};
          adaptRes.msg = res.errMsg;
          reject(adaptRes);
        },
      });
    });
  },
  /**
   * 拍照或从相册中选图片--基于H5 input控件的polyfill方案
   */
  getPicture: (param) => {
    const p = new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.multiple = 'multiple';
      if (param.sourceType === 'camera') {
        input.capture = 'camera';
      }
      input.onchange = () => {
        const imgList = [];
        const errorMsg = [];
        let cnt = 0;
        Object.keys(input.files).forEach((key, index) => {
          if (!isNaN(parseInt(key, 10))) {
            const imgFile = new FileReader();
            imgFile.readAsDataURL(input.files[key]);
            imgFile.onload = () => {
              cnt += 1;
              imgList[parseInt(key, 10)] = imgFile.result.slice(22, -1);
              if (cnt === input.files.length) {
                resolve(imgList, errorMsg);
                console.log(imgList);
              }
            };
            imgFile.onerror = () => {
              cnt += 1;
              errorMsg[parseInt(key, 10)] = `第${index}`;
              if (cnt === input.files.length) {
                resolve(imgList, errorMsg);
                console.log(errorMsg);
              }
            };
          }
        });
        // input.files.forEach((file, index) => {
        //   const imgFile = new FileReader();
        //   imgFile.readAsDataURL(file);
        //   imgFile.onload = () => {
        //     cnt += 1;
        //     imgList[index] = imgFile.result.slice(22, -1);
        //     if (cnt === input.files.length) {
        //       resolve(imgList);
        //     }
        //   };
        //   imgFile.onerror = (e) => {
        //     cnt += 1;
        //     imgList[index] = `第${index}张图片打开失败:${e}`;
        //     if (cnt === input.files.length) {
        //       resolve(imgList);
        //       resolve(imgList);
        //     }
        //   };
        // });
      };
      window.imgInput = input;
      window.imgInput.click();
    });
    return p;
  },
  /**
   * 退出美捷报并关闭窗口
   */
  exit: () => {
    wx.closeWindow();
    console.log('platform exit');
  },
  /**
   * 退出子应用
   */
  // exitApp: (path) => {
  //   window.location.hash = path ? `#/${path}` : '#/';
  // },
};

functions.locationForIOS = functions.location;

export default functions;
