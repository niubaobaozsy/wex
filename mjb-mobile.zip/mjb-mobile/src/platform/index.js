import { isIOSEnviron } from '@/js/util';
import store from '@/store';
import vue from '../main';
import meixin from './meixin-api';
import wechat from './wechat-sdk';

const functions = {};
functions.exitApp = (path) => {
  const toPath = path ? `#/${path}` : '#/';
  vue.prototype.setInnerNavigateFlag(toPath);
  window.location.hash = toPath;
}
function setPlatform(platform) {
  if (platform.indexOf('meixin') > -1) {
    Object.assign(functions, meixin);
    if (platform === 'meixinBase' && isIOSEnviron()) {
      functions.exit = (force) => {
        if (force) {
          store.commit('ROOT_LOGOUT');
          vue.prototype.setInnerNavigateFlag('/');
          window.location.hash = '/';
        } else {
          functions.exitApp();
        }
      };
    }
  } else {
    Object.assign(functions, wechat);
  }
}
window.platform = functions;

export {
  functions as platform,
  setPlatform,
};
