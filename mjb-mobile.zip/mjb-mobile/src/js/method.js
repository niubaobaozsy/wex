/*
** by luoyimei
** 2018-7-21
*/
import Vue from 'vue';
import store from '../store';

/*
** 获取数据字典,如果缓存有，直接从缓存拿，如果没有直接获取
*/
export const getDataFromDict = async (dictCode) => {
  const dictStr = localStorage.getItem('dictData'); // 获取缓存的字典数据
  const dictData = dictStr ? JSON.parse(dictStr) : {};
  let result = null;
  if (dictData && dictData[dictCode] && dictData[dictCode].length) {
    result = dictData[dictCode];
  } else {
    await store.dispatch('getItemsByCode', dictCode)
      .then((rep) => {
        if (rep && rep.code === '0000' && rep.data) {
          dictData[dictCode] = rep.data;
          localStorage.setItem('dictData', JSON.stringify(dictData));
          result = rep.data;
        }
      });
  }
  return result;
}

/**
*  用于根据属性名、值查找返回数据字典值
* @param keyValue 用来查找的属性值
* @param inputArray 查询的数组
* @param keyProp 用来查询的属性名
* @param valueProp 返回值对应的属性名
* @returns {{}}  返回对应属性的值
*/
export const getValueInArray = (keyValue, inputArray, keyProp, valueProp) => {
  if (inputArray === undefined) {
    return;
  }
  if (typeof inputArray === 'string') {
    inputArray = JSON.parse(inputArray);
  }
  let searchValue = '';
  if (inputArray && inputArray.length > 0) {
    for (let i = 0; i < inputArray.length; i++) {
      let nowObj = inputArray[i];
      if (nowObj[keyProp] === keyValue) {
        searchValue = nowObj[valueProp];
        break;
      }
    }
  }
  return searchValue;
}

const method = {
  getDataFromDict,
  getValueInArray
}
export default method
