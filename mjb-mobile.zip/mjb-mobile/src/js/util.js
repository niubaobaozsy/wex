var snakeCase = require('lodash/snakeCase');
var cloneDeep = require('lodash/cloneDeep');

/**
 * 传入毫秒，格式化时间
 * @param second 毫秒数
 * @param fmt 格式，常见：'yyyy-MM-dd hh:mm:ss'、'yyyy-M-d h:m:s、yyyy/MM/dd'
 * @returns {*}
 */
function formatDate(second, fmt) {
  const date = new Date(second); // 后台时间转javascript时间戳
  if (second && Object.prototype.toString.call(date).slice(8, -1) === 'Date') {
    const o = {
      'M+': date.getMonth() + 1, // 月份
      'd+': date.getDate(), // 日
      'h+': date.getHours() % 24 === 0 ? 0 : date.getHours() % 24, // 小时
      'H+': date.getHours(), // 小时
      'm+': date.getMinutes(), // 分
      's+': date.getSeconds(), // 秒
      'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
      S: date.getMilliseconds(), // 毫秒
    };
    if (/(y+)/.test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (date.getFullYear().toString()).substr(4 - RegExp.$1.length));
    }
    Object.keys(o).forEach((key) => {
      if (new RegExp(`(${key})`).test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[key]) : ((`00${o[key]}`).substr((o[key].toString()).length)));
      }
    });
    return fmt;
  }
  return '';
}

function addDays(dateObj, days2add) {
  return new Date(dateObj.valueOf() + (864E5 * days2add));
}

function addMinutes(date, minutes) {
    return new Date(date.getTime() + (minutes * 60000));
}

function isIOSEnviron() {
  return window.navigator.userAgent.indexOf('iPhone') > -1;
}

/**
 * convert object's props to snakeCase format
 *
 * @param  {Object}   obj    object to convert
 * @return {Object}   converted object
 *
 * @author wukl
 * @date   2018-03-13
 */
function convertToSnakeCase(obj = {}) {
  obj = cloneDeep(obj);
  Object.keys(obj).forEach((fieldName) => {
    obj[snakeCase(fieldName)] = obj[fieldName];
    delete obj[fieldName];
  });

  return obj;
}

/**
 * format seconds to mm:ss
 *
 * @param  {Number}   seconds
 * @return {String}
 *
 * @author wukl
 * @date   2018-03-20
 */
function formatSecondsToMinutes(seconds) {
  const mm = parseInt(seconds/60, 10);
  const ss = seconds % 60;
  return `${(mm > 10 ? mm : `0${mm}`)}:${(ss > 10 ? ss : `0${ss}`)}`;
}

/**
 * 计数器
 */
function createCounter() {
  let count = 0;
  return {
    getCount: () => {
      return count;
    },
    setCount: (value) => {
      count = value;
      return count;
    },
    increase: () => {
      count ++;
      return count;
    },
    decrease: () => {
      count --;
      return count;
    },
    clear: () => {
      count = 0;
      return count;
    },
  };
}

/**
 * 计时器
 * @param {function} cb
 * @param {number} millisec
 */
function createTimerObj(cb, millisec) {
  let timer = null;
  return {
    getTimer: () => {
      return timer;
    },
    setTimeout: () => {
      timer = setTimeout(() => {
        cb();
        timer = null;
      }, millisec);
      return timer;
    },
    clearTimeout: () => {
      clearTimeout(timer);
      timer = null;
      return timer;
    },
  }
}
/**
 * 解析目标URL的query参数
 * @param {String} target
 */
function getUrlQueryParam(target) {
  const href = location.href;
  if (href.indexOf('?') !== -1) {
    const search = href.split('?')[1];
    const param = {};
    const strs = search.split('&');
    for (let i = 0; i < strs.length; i++) {
      param[strs[i].split('=')[0]] = unescape(strs[i].split('=')[1]);
    }
    return param[target];
  }
  return '';
}

/**
 * 函数装饰器/函数劫持
 * @param {Function} fn
 * @param {Function} beforefn
 */
function decorator(fn, beforefn) {
  return function beforeDecorator(...arg) {
    beforefn.apply(this, arg);
    return fn.apply(this, arg);
  }
}

export {formatDate, addDays, addMinutes, isIOSEnviron, convertToSnakeCase, formatSecondsToMinutes, createCounter, createTimerObj, getUrlQueryParam, decorator};
export default {formatDate, addDays, addMinutes, isIOSEnviron, convertToSnakeCase, formatSecondsToMinutes, createCounter, createTimerObj, getUrlQueryParam, decorator};
