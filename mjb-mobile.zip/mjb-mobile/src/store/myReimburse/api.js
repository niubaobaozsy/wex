const api = {
  invoiceQuery: 'sdatt/invoice/query',                     // 票夹发票查询
  saveFeeReim: 'smart-expense-web/ec/feeReim/saveFeeReim',  // 保存报销单信息
  getAttachment: 'sdatt/attach/getFileByOrderMsg',       // 获取附件
  getReimBudgetSource: 'smart-expense-web/bm/EmsBmBudgetNode/getBudgetNode',  // 获得预算来源
  getReimEconomicsEvent: 'smart-expense-web/bm/EmsBmBudgetNode/getFeeType', // 获得经济事务
  attachmentUpload: 'sdatt/file/uploadAndBindOrderForApp', // 上传附件
  attachemntDelete: 'sdatt/attach/deleteFile',             // 删除附件
  getBigImg: 'sdatt/file/image/base64/',         // 获取附件Base64图片
  checkFeeReim: 'smart-expense-web/ec/feeReim/checkFeeReim', // 校验报销单
  selectMyRepayLoan: 'smart-expense-web/lm/loan/selectMyRepayLoan', // 借款单列表
  getAvaliableFeeApply: 'smart-expense-web/ea/feeApply/getAvaliableFeeApply',
  getFeeApplyByIdForApp: 'smart-expense-web/ea/feeApply/getFeeApplyByIdForApp',  // 差旅申请单单据信息
  getFeeReimByIdForApp: 'smart-expense-web/ec/feeReim/getFeeReimByIdForApp',  // 费用申请单单据信息
  getReimBursement: 'smart-expense-web/ec/feeReim/getFeeReimByIdForApp', // 获取报销单单据
  submit: 'smart-expense-web/wf/process/submit', // 提交报销单流程
  deleteFeeReim: 'smart-expense-web/ec/feeReim/deleteFeeReim',  // 删除单据接口
  getQueryIsTax: 'jiebao-docker-web/docker/feetype/foundation/queryIsTax',  // 查询税科目
  getFeeDetail: 'smart-expense-web/ec/feeReim/getEaDetailsById', // 自动生成行程明细，住宿明细，补助明细和其他费用
  getTravelOrders: 'smart-expense-web/ea/feeApply/getTravelOrders', // 查询申请单商旅系统使用情况
};

module.exports = {
  api,
};
