import actions from './actions';
import mutations from './mutations';
import getters from './getters';

const stateInit = {
  emsecfeereimh: {
    emsEcHtLS: [], // 国内报销扩展字段
    feeReimHExts: [], // 国内报销扩展字段
    emsecfeereimhexts: [], // 通用报销扩展字段
    totalBudget: 0, // 消费记录数

    // 国内报销与费用报销通用字段
    fee_reim_id: null,
    apply_by: null,
    apply_name: null,
    org_id: null,
    org_name: null,
    currency_name: '人民币元',
    order_type: null,
    form_template_id: '',
    form_template_name: '',
    sensitive_info: null,
    biz_flag: 0,
    need_app_loan: 'N',
    need_input_tax: 'N',
    order_status: 'DRAFT',
    order_template_id: null,
    order_template_name: null,
    apply_reim_amount: 0,
    // approve_reim_amount: 0,
    // pay_amount: 0,
    company_id: null,
    company_name: null,
    bank_account: null,
    bank_name: null,
    bank_code: null,
    receiver: null,
    receiver_en: null,
    bank_adress: null,
    payment_method: 'WIRE',
    reim_date: null,
    pay_type: 'NORMAL_PAY',
    currency_code: 'CNY',
    emsEcFeeBudgets: [],  // emsecfeebudgets
    feeLoans: [],  // emsecfeeloans
    invoiceTaxRS: [],  // emsecinvoicetaxrs

    // 通用报销
    fee_reim_code: null,
    formInstanceId: null,
    apply_date: null,
    need_app_loan_flag: false,
    is_need_contract: 'N',
    is_need_contract_flag: false,
    is_instalments_pay: 'N',
    is_relate_research: 'N',
    assistance_fee: 0,
    totalRepayAmount: 0,
    totalBudgetFee: 0,
    totalTaxFee: 0,

    // 差旅报销
    accessories_amount: 0,
    biz_status: 'UNCREATE',
    created_by: null,
    created_name: null,
    creation_date: null,
    ou_id: null,
    proxy_user: null,
    source_amount: 0,
    split_amount: 0,
    tenant_id: null,
    to_section_amount: 0,
    assistantDetails: [],
    ecOtherFeeDetails: [],
    feeTravels: [
      {
        travel_person_count: 0,
        travel_persons: '',
        travel_persons_name: '',
      },
    ],
    rentDetails: [],
    source_system: 'MOBILE',
  },

  // 第一次保存,后台返回的数据.之后更新带上此数据
  reimInfoBySave: {
    fee_reim_id: null,            // 报销单主键id,新加时不用传，更新时需传
    fee_reim_code: null,          // 报销单单号，第一次保存可不填，保存之后数据返回单号
    formInstanceId: null,         // 表单实例id, 第一次保存时后台生成返回
  },

  // 报销单默认申请数据
  // defaultReimInfo: {
  //   order_status: 'DRAFT',         // 草稿状态，默认写死
  //   pay_type: 'NORMAL_PAY',        // 支付类型,默认NORMAL_PAY写死
  //   is_month_pay: 'N',             // 是否工资付款, 非必填
  //   assistance_fee: 0,             // 补助费 非必填
  //   source_system: 'MOBILE',       // 来源系统，固定MOBILE
  //   order_type: 'CL',              // 单据类型
  //   payment_method: 'CASH',        // 付款方式,默认CASH
  //   need_input_tax: 'Y',           // 是否含税，Y/N,非必填
  //   need_app_loan: 'N',            // 是否核销借款，Y/N,非必填
  //   biz_status: 'UNCREATE',        // 业务状态编码，默认UNCREATE
  //   biz_flag: 0,                   // 公私标识（0：个人业务 1：对公业务） 非必填
  //   reason_desc: null,               // 摘要
  //   is_instalments_pay: 'N',       // 是否分期付款,默认N
  // },

  enclosureList: [], // 附件缩略图片数组
  bigImg: [],

  fee: [],

  // 入账单位信息
  companyInfo: {
    company_name: null,    // 入账单位
    company_id: null,      // 入账单位id
  },

  // 其他信息
  otherInfo: {
    tenant_id: null,       // 租户id
    apply_name: null,      // 申请人名称
    apply_by: null,        // 申请人id
    org_name: null,        // 申请人行政组织名称
    org_id: null,          // 申请人行政组织id
    sensitive_info: null,  // 业务描述
    reim_date: null,       // 报销日期, 默认等于当前日期
    busi_org_id: null,     // 预算部门id
    busi_org_name: null,   // 预算部门名称
  },

  reimburseCreate: {
    ableNext: true,
    currentStep: 0,
    reimburseType: '',
    isSave: true,
  },

  travelSysUsed: {
    totalAmount: 0,
    airFeeAmount: 0,
    carFeeAmount: 0,
    hotelFeeAmount: 0,
    airFee: [],
    carFee: [],
    hotelFee: [],
  },

  relatedList: [],
  cbStatus:false,
  persons: [],
  flowNode: {},
  consumeAmount: 0,  // 消费明细金额

  feeStdExp: true,
  overStdExp: true,
};
const state = JSON.parse(JSON.stringify(stateInit));

export default {
  stateInit,
  actions,
  mutations,
  state,
  getters,
};
