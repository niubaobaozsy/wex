const getters = {
  reimTravelFee(state) {
    const travelSum = [];
    if (state.emsecfeereimh.feeTravels) {
      state.emsecfeereimh.feeTravels.forEach((item) => {
        if (item.transportDetails) {
          let travelItem = 0;
          item.transportDetails.forEach((feeItem) => {
            if (feeItem.attribute1 === 'COMPANY') {
              travelItem +=  0;
            } else {
              travelItem += parseFloat(feeItem.transport_fee) ? parseFloat(feeItem.transport_fee) : 0;
            }
          });
          travelSum.push(travelItem);
        }
      });
    }
    return travelSum;
  },
  reimHotelFee(state) {
    let hotelSum = 0;
    if (state.emsecfeereimh.rentDetails) {
      state.emsecfeereimh.rentDetails.forEach((item) => {
        hotelSum += parseFloat(item.rent_fee) ? parseFloat(item.rent_fee) : 0;
      });
    }
    return hotelSum;
  },
  reimSubsidyFee(state) {
    let subsidySum = 0;
    if (state.emsecfeereimh.assistantDetails) {
      state.emsecfeereimh.assistantDetails.forEach((item) => {
        subsidySum += parseFloat(item.assistant_fee) ? parseFloat(item.assistant_fee) : 0;
      });
    }
    return subsidySum;
  },
  reimOtherFee(state) {
    let otherSum = 0;
    if (state.emsecfeereimh.ecOtherFeeDetails) {
      state.emsecfeereimh.ecOtherFeeDetails.forEach((item) => {
        otherSum += parseFloat(item.other_fee) ? parseFloat(item.other_fee) : 0;
      });
    }
    return otherSum;
  },
  reimTotalFee: (state, getter) => {
    let travelFeeSum = 0;
    getter.reimTravelFee.forEach((item) => {
      travelFeeSum += parseFloat(item);
    });
    let sum = parseFloat(travelFeeSum + getter.reimHotelFee + getter.reimSubsidyFee + getter.reimOtherFee);
    return Number(sum.toFixed(2));
  },
  reimTotalBudget: (state) => {
    let totalFee = 0;
    state.emsecfeereimh.emsEcFeeBudgets.forEach((item) => {
      totalFee += parseFloat(item.apply_reim_amount);
    });
    return totalFee;
  },
};

export default getters;
