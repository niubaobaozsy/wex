const mutations = {
  MY_REIMBURSE: (state, data) => {
    state.emsecfeereimh = data.emsecfeereimh;
    state.reimInfoBySave = data.reimInfoBySave;
    state.enclosureList = data.enclosureList;
    state.reimburseCreate = data.reimburseCreate;
    state.flowNode = data.flowNode;
    state.travelSysUsed = data.travelSysUsed;
    state.consumeAmount = data.consumeAmount;
    state.relatedList = data.relatedList;
    state.feeStdExp = data.feeStdExp;
    state.overStdExp = data.overStdExp;
  },
  // 发票数组信息
  INVOICE_TAXRS_INFO: (state, data) => {
    state.emsecinvoicetaxrs = data;
  },
  // 保存草稿信息
  SAVE_FEE_REIM_INFO: (state, data) => {
    state.saveFeeReimInfo = data;
  },
  // 第一次保存返回的数据信息
  REIM_INFO_BY_SAVA: (state, data) => {
    state.reimInfoBySave = data;
  },
  // 行程明细数组信息
  FEE_TRAVELS_INFO: (state, data) => {
    state.emsecfeetravels = data;
  },
  // 预算明细数组信息
  FEE_BUDGETS_INFO: (state, data) => {
    state.emsecfeebudgets = data;
  },
  // 消费明细数组信息
  FEE_DETAILS_INFO: (state, data) => {
    state.emsecfeedetails = data;
  },
  // 消费明细数组信息
  FEE_REIM_HEXTS: (state, data) => {
    state.emsecfeereimhexts = data;
  },
  // 消费记录总数
  TOTAL_BUDGET: (state, num) => {
    state.totalBudget = num;
  },
  // 报销申请单
  EMSEC_FEEREIMH: (state, obj) => {
    state.emsecfeereimh = obj;
  },
  // 检测行程信息是否已经保存
  IS_SAVE: (state, save) => {
    state.isSave = save;
  },
  // 附件缩略图片数组
  TR_ENCLOSURE_LIST: (state, data) => {
    state.enclosureList = data;
  },
  // 附件大图Base64
  TR_BIG_IMG_LIST: (state, data) => {
    state.bigImg = data;
  },
  FEE: (state, fee) => {
    state.fee = fee;
  },
  // 借款明细数组
  EMS_EC_FEE_LOANS: (state, data) => {
    state.emsecfeeloans = data;
  },
  REIMBURSE_CREATE: (state, obj) => {
    state.reimburseCreate = Object.assign(state.reimburseCreate, obj);
  },
  PERSONS: (state, arr) => {
    state.persons = arr;
  },
  COMPANYINFO: (state, obj) => {
    state.companyInfo = obj;
  },
  REIM_FLOWNODE: (state, obj) => {
    state.flowNode = obj;
  },
  CONSUME_AMOUNT: (state, obj) => {
    state.consumeAmount = obj;
  },
  TRAVEL_SYS_USED: (state, obj) => {
    state.travelSysUsed = obj;
  },
  RELATED_LIST: (state, arr) => {
    state.relatedList = arr;
  },
  REIM_FEE_STD_EXP: (state, obj) => {
    state.feeStdExp = obj;
  },
  REIM_OVER_STD_EXP: (state, obj) => {
    state.overStdExp = obj;
  },
  CHANGE_CBSTATUS:(state) => {
    state.cbStatus = true;
  },
  REC_CBSTATUS:(state) => {
    state.cbStatus = false;
  }

};

export default mutations;
