import http from '../http';
import { api } from './api';

const actions = {
  // 发票查询
  reimInvoiceQuery({ commit, rootState }, param) {
    return http.request({
      url: api.invoiceQuery,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      data: param,
    }).then(res => res.data);
  },
  // 保存报销单信息
  saveReimInfo({ commit, rootState }, param) {
    return http.request({
      url: api.saveFeeReim,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 获取预算来源
  getReimBudgetSource({ commit, rootState }, param) {
    return http.request({
      url: api.getReimBudgetSource,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 获取经济事项
  getReimEconomicsEvent({ commit, rootState }, param) {
    return http.request({
      url: api.getReimEconomicsEvent,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 获取附件
  getAttachment({ commit, rootState }, param) {
    return http.request({
      url: api.getAttachment,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      data: param,
    }).then(res => res.data);
  },
  // 上传附件
  attachmentUpload({ commit, rootState }, param) {
    return http.request({
      url: api.attachmentUpload,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      data: param,
    }).then(res => res.data);
  },
  // 删除附件
  attachemntDelete({ commit, rootState }, param) {
    return http.request({
      url: api.attachemntDelete,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      data: param,
    }).then(res => res.data);
  },
  // 获取附件大图
  getBigImg({ commit, rootState }, param) {
    return http.request({
      url: api.getBigImg + param,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      data: param,
    }).then(res => res.data);
  },
  // 校验报销单
  frCheckFeeReim({ commit, rootState }, param) {
    return http.request({
      url: api.checkFeeReim,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 借款单列表数据
  selectMyRepayLoan({ commit, rootState }, param) {
    return http.request({
      url: api.selectMyRepayLoan,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 差旅申请单单列表数据
  getAvaliableFeeApply({ commit, rootState }, param) {
    return http.request({
      url: api.getAvaliableFeeApply,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 差旅申请单详情
  getFeeApplyByIdForApp({ commit, rootState }, param) {
    return http.request({
      url: api.getFeeApplyByIdForApp,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  getFeeReimByIdForApp({ commit, rootState }, param) {
    return http.request({
      url: api.getFeeReimByIdForApp,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 获取报销单详情
  getReimBursement({ commit, rootState }, param) {
    return http.request({
      url: api.getReimBursement,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  submit({ commit, rootState }, param) {
    return http.request({
      url: api.submit,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  deleteFeeReim({ commit, rootState }, param) {
    return http.request({
      url: api.deleteFeeReim,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 查询税科目
  getQueryIsTax({ commit, rootState }, param) {
    return http.request({
      url: api.getQueryIsTax,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
      method: 'get',
    }).then(res => res.data);
  },
  // 自动生成行程明细，住宿明细，补助明细和其他费用
  getFeeDetail({ commit, rootState }, param) {
    return http.request({
      url: api.getFeeDetail,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 查询申请单商旅系统使用情况
  getTravelOrders({ commit, rootState }, param) {
    return http.request({
      url: api.getTravelOrders,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
};

export default actions;
