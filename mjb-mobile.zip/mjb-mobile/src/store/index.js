import Vue from 'vue';
import Vuex from 'vuex';
import mutations from './mutations.js';
import login from './login';
import report from './report';
import myInvoice from './myInvoice';
import myApply from './myApply';
import myReimburse from './myReimburse';
import common from './common';
import mine from './mine';
import approve from './approve';
import travel from './travel';
import activity from './activity';

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    login,
    report,
    myInvoice,
    myApply,
    myReimburse,
    common,
    mine,
    approve,
    travel,
    activity,
  },
  state: {
    token: '', // 美捷报token
    smartBuyToken: '', // 美捷报慧消费环境token
    ssoToken: '', // 美信MAS token
    mipId: '',
    deviceInfo: {},
    baseConfig: {}, // 基础配置信息
    menuConfig: {}, // 菜单配置信息
    userInfo: { // 用户信息
      user: {
        userName: '',
        mobile: '',
      },
    },
    smartBuyUserInfo: { // 美捷报慧消费环境用户信息
      user: {
        userName: '',
        mobile: '',
      },
    },
    popupCfg: {
      show: false,
      msg: '',
    },
    hasDefaultConfig: false,
    extCall: false,
    appVisibility: true,
  },
  mutations,
});
