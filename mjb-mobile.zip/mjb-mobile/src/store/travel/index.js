import actions from './actions';
import mutations from './mutations';

const state = {
  travelIndexMsgFeed: [],
  car: {
    // 状态 nonCall: 无法叫车、 canCall: 可以叫车、 toCall：下一步准备叫车、calling: 正在叫车、 waitOrder：等待接单、takeOrder：已接单,等待司机到达、takeCar：司机到达，等待上车、
    // onTheWay：上车，行程中、 cancelling：取消订单、cancelled：取消订单成功、endTrip:行程结束、
    // evaluating：评价中、evaluated：评价完成、notEvaluate：未评价、paying：付款中、paid: 付款成功、payFail：付款失败、orderEnd: 订单结束
    // toDetail: 准备前往查看详情， detail: 查看详情
    // orderstate: {
    //   300: '等待应答',
    //   311: '订单超时',
    //   400: '等待接驾',
    //   410: '司机已到达',
    //   500: '行程中',
    //   600: '行程结束',
    //   610: '行程异常结束',
    //   700: '已支付',
    // },
    state: '',
    beforeState: '',
    selectedCity: {},
    enableCall: false, // 不可叫车的标志,false为可叫车
    reasonList: [], // 乘车事由列表
    selectReason: {}, // 被选中的乘车事由
    departure_time: '', // 起程时间
    startArea: {}, // 出发地
    endArea: {}, // 目的地
    passenger_phone: '', // 乘车人电话号码
    mipPhone: '', // 当前登录的用户电话
    evaluatePrice: '', // 估价
    voucherList: [], // 打车券列表
    selectVoucher: {},  // 选中的打车券
    user: {}, // 用户信息
    rule: '301', // 快车 or 专车（默认快车）
    specialCar: [
      {
        name: '舒适型',
        price: 0,
        code: 100,
      }, {
        name: '豪华型',
        price: 0,
        code: 200,
      }, {
        name: '商务型',
        price: 0,
        code: 400,
      },
    ],
    specialCarType: 100, // 专车的类型，100为舒适型， 200为豪华型， 400为商务型（默认为舒适型）
    fastCar: {}, // 快车的信息
    nowCalling: true, // 现在叫车 or 预约叫车（默认现在叫车）
    historyCallers: [], // 叫车电话历史记录
    order_id: '', // 叫车请求id（也是订单号）
    order: {}, // 正在进行的订单，里面包括订单号和其他信息
    totalPrice: {}, // 最终需要付的总价格信息
    commentOrComplaint: '', // 评价或投诉
    level: 0, // 五星好评，最低和默认为1
  },
  searchTicket: {  // 航班搜索参数
    departureCity: '',
    departureText: '',
    arrivalCity: '',
    arrivalText: '',
    departureDate: '',
    tripType: '1',
    tripNum: '0',
  },
  ticketInfo: [],
  selectedTicketInfo: {},
  bookingTicketInfo: {},
  plane: {
    // orderListType: 1,
    // 旅客信息
  },
  travelMsg: {
    certNumber: '',
    certType: '',
    cnName: '',
    commPassengerId: '',
    mobile: '',
    types: '',
  },
  passenger: [], // 乘机人列表
  passengerList: {}, // 编辑乘机人
  endorse: {
    orderNo: '',
    contact: '',
    endorseReason: '',
    flightInfo: '',
    passengers: '',
    priceInfo: '',
    ticket: '',
  }, // 机票改签
  ticketFilter: null,
};

export default {
  actions,
  mutations,
  state,
};
