import http from '../http';
import { api } from './api';

const actions = {
  /**
   *  商旅用车
   */
  /**
   * 获取用户最后的订单
   */
  getLastOrder({ rootState }, params) {
    return http.request({
      url: api.getLastOrder,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: params
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        // DO something while success
      }
      return rep.data;
    })());
  },
  /**
   *
   */
  getUnPaidOrder({ rootState }) {
    return http.request({
      url: api.getUnPaidOrder,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: { mipAccount: rootState.userInfo.employeeNumber}
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        // DO something while success
      }
      return rep.data;
    })());
  },
  /**
   * 获取叫车用户基本信息
   */
  getCarUserInfo({ commit, rootState }, param) {
    return http.request({
      url: api.getCarUserInfo,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 获取乘车事由
   */
  getReason({ commit, rootState }, param) {
    return http.request({
      url: api.getReason,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 获取打车券列表
   */
  getCard({ commit, rootState }, param) {
    return http.request({
      url: api.card,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 获取打车券列表_确认支付的时候
   */
  getTicketsAfterTrip({ commit, rootState }, param) {
    return http.request({
      url: api.endTrip_getCarTickets,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 获取预估价格
   */
  getEvaluatePrice({ commit, rootState }, param) {
    return http.request({
      url: api.getEvaluatePrice,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 获取叫车请求id
   */
  getCallId({ commit, rootState }, param) {
    return http.request({
      url: api.getCallId,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 发起叫车请求
   */
  calling({ commit, rootState }, param) {
    return http.request({
      url: api.calling,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 获取订单详情
   */
  getOrderDetail({ commit, rootState }, param) {
    return http.request({
      url: api.getOrderDetail,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 取消订单
   */
  cancelOrder({ commit, rootState }, param) {
    return http.request({
      url: api.cancelOrder,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 获取订单
   */
  getOrder({ commit, rootState }, param) {
    return http.request({
      url: api.order,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 确认支付
   */
  ensurePay({ commit, rootState }, param) {
    return http.request({
      url: api.ensurePay,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 对司机进行评分
   */
  rateTheDriver({ commit, rootState }, param) {
    return http.request({
      url: api.rateTheDriver,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 获取历史订单
   */
  getAllOrder({ commit, rootState }, param) {
    return http.request({
      url: api.getAllOrder,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 获取常用地址
   */
  getCommonAddress({ commit, rootState }, param) {
    return http.request({
      url: api.getCommonAddress,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * 设置常用地址
   */
  setCommonAddress({ commit, rootState }, param) {
    return http.request({
      url: api.setCommonAddress,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  /**
   * get base city 「查询常驻办公地」
   *
   * @param  {Object}   options.rootState
   * @param  {Object}   param             datas to post
   * @return {Promise}
   *
   * @author wukl
   * @date   2018-03-21
   */
  getBaseCity({ rootState }, param) {
    return http.request({
      url: api.setBaseCity,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(response => {
      return response.data;
    });
  },
  /**
   * set base city 「设置常驻办公城市」
   *
   * @param  {Object}   options.rootState
   * @param  {Object}   param             datas to post
   *
   * @author wukl
   * @date   2018-03-21
   */
  setBaseCity({ rootState }, param) {
    return http.request({
      url: api.setBaseCity,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(response => {
      if (response.data && response.data.code === '00000') return response.data;

      return Promise.reject({
        msg: '设置常驻地失败！'
      });
    });
  },
  /**
   *  机票
   */
  /**
   * 获取航空公司列表
   */
  getAirlines({ commit, rootState }, param) {
    return http.request({
      url: api.getAirlines,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
    }).then(res => res.data);
  },
    /**
   * 筛选航班信息
   */
  ticketFilterFlights({ commit, rootState }, param) {
    return http.request({
      url: `${api.ticketFilterFlights}?${param}`,
      baseURL: rootState.baseConfig.baseUrlPlane,
      method: 'get',
    }).then(res => res.data);
  },
  /**
   * 获取我的机票订单列表
   */
  getTicketOrders({ commit, rootState }, param) {
    return http.request({
      url: api.getTicketOrders,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
      method: 'get',
    }).then(res => res.data);
  },
  /**
   * 获取机票价格列表
   */
  getFlightPrice({ commit, rootState }, param) {
    return http.request({
      url: api.getFlightPrice,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
      method: 'get',
    }).then(res => res.data);
  },
  /**
   * 通过订单号获取机票订单详情
   */
  getOrderByOrderNo({ commit, rootState }, param) {
    return http.request({
      url: api.getOrderByOrderNo,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
      method: 'get',
    }).then(res => res.data);
  },
  /**
   * 选择消费券
   */
  chooseVouchers({ commit, rootState }, param) {
    return http.request({
      url: api.chooseVouchers,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
      method: 'post',
    }).then(res => res.data);
  },
  /**
   * 机票预订单创建
   */
  submitTicketOrders({ commit, rootState }, param) {
    return http.request({
      url: api.submitTicketOrders,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
      method: 'post',
    }).then(res => res.data);
  },
  /**
   * 机票退订单创建
   */
  createRefundApply({ commit, rootState }, param) {
    return http.request({
      url: api.createRefundApply,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
      method: 'post',
    }).then(res => res.data);
  },
  /**
   * 机票退订单确认
   */
  confirmRefundApply({ commit, rootState }, param) {
    return http.request({
      url: api.confirmRefundApply,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
      method: 'get',
    }).then(res => res.data);
  },
  /**
   * 机票退订单取消
   */
  cancelRefundApply({ commit, rootState }, param) {
    return http.request({
      url: api.cancelRefundApply,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
      method: 'get',
    }).then(res => res.data);
  },
  /**
   * 机票改签单创建
   */
  createEndorseOrder({ commit, rootState }, param) {
    return http.request({
      url: api.createEndorseOrder,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
      method: 'post',
    }).then(res => res.data);
  },
  /**
   * 机票改签单确认
   */
  confirmEndorse({ commit, rootState }, param) {
    return http.request({
      url: api.confirmEndorse,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
      method: 'post',
    }).then(res => res.data);
  },
  /**
   * 机票改签单取消
   */
  cancelEndorseOrder({ commit, rootState }, param) {
    return http.request({
      url: api.cancelEndorseOrder,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
      method: 'get',
    }).then(res => res.data);
  },

/* ******************************** 酒店接口 ************************************* */
  /**
   * 携程酒店获取登录参数
   */
  getAccessParamsForCtrip({ commit, rootState }, param) {
    return http.request({
      url: api.getAccessParamsForCtrip,
      baseURL: rootState.baseConfig.baseUrlSmartBuyPay,
      data: param,
      method: 'get',
    }).then(res => res.data);
  },
  /**
   * 携程酒店登录
   */
  ctripLogin({ dispatch, commit }, param) {
    const formCreate = (action, params) => {
      const form = document.createElement('form');
      form.action = action;
      form.method = 'post';
      Object.keys(params).forEach((name, index) => {
        const input = document.createElement('input');
        input.name = name;
        input.value = params[name];
        form.appendChild(input);
      });
      param.ele.appendChild(form);
      return {
        getForm: () => { return form },
        submit: () => {
          form.submit();
          return form;
        },
      }
    };
    return dispatch('getAccessParamsForCtrip').then((rep) => {
      if (rep && rep.code === '0000') {
        const ctrip = {
          action: 'https://ct.ctrip.com/m/SingleSignOn/H5SignInfo',
          params: {
            accessuserid: '',
            employeeid: '',
            signature: '',
            initpage: param.initpage || 'HotelSearch',
            appid: '',
            token: '',
            onerror: 'errorcode',
            callback: window.location.href.replace('file://', 'mclh://'),
          },
        };
        ctrip.params = Object.assign({}, ctrip.params, rep.data);
        formCreate(ctrip.action, ctrip.params).submit();
      } else {
        return { msg: `请求异常[${rep.code}]:${rep.msg}` };
      }
    });
  },
};

export default actions;
