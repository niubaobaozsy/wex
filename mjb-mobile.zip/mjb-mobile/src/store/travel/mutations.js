const mutations = {
  TRAVELINDEXMSGFEED: (state, arr) => {
    state.travelIndexMsgFeed = arr;
  },
  CAR: (state, data) => {
    state.car = data;
  },
  SEARCHTICKET: (state, data) => {
    state.searchTicket = data;
  },
  TICKETINFO: (state, data) => {
    state.ticketInfo = data;
  },
  SELECTEDTICKETINFO: (state, data) => {
    state.selectedTicketInfo = data;
  },
  BOOKINGTICKETINFO: (state, data) => {
    state.bookingTicketInfo = data;
  },
  PLANE: (state, data) => {
    state.plane = data;
  },
  // 旅客列表信息
  TRAVELMSG: (state, msg) => {
    state.travelMsg = msg;
  },
  // 乘机人
  PASSENGER: (state, data) => {
    state.passenger = data;
  },
  PASSENGERLIST: (state, data) => {
    state.passengerList = data;
  },
  ENDORSE: (state, data) => {
    state.endorse = Object.assign({}, state.endorse, data);
  },
  TICKETFILTER: (state, data) => {
    state.ticketFilter = data;
  },
};

export default mutations;
