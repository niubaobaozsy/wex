const didiUrl = 'vehicle-dd-web/public-access/taxi/data/taxiservice.do';
const api = {
  // 滴滴
  getLastOrder: `${didiUrl}?operation=12`, // 获取用户最后的订单
  getUnPaidOrder: `${didiUrl}?operation=15`,
  getReason: `${didiUrl}?operation=29`, // 获取乘车事由
  card: `${didiUrl}?operation=25`, // 查询打车券
  getCarUserInfo: `${didiUrl}?operation=14`, // 获取用户信息（id、电话、mip账号和地址）
  getEvaluatePrice: `${didiUrl}?operation=1`, // 预估价格
  getCallId: `${didiUrl}?operation=5`, // 获取叫车请求id
  calling: `${didiUrl}?operation=6`, // 发起叫车请求
  getOrderDetail: `${didiUrl}?operation=8`, // 获取订单详情
  cancelOrder: `${didiUrl}?operation=9`, // 取消订单
  order: `${didiUrl}?operation=10`, // 获取订单详情
  ensurePay: `${didiUrl}?operation=24`,
  rateTheDriver: `${didiUrl}?operation=23`,
  getAllOrder: `${didiUrl}?operation=10`, // 获取历史订单
  getCommonAddress: `${didiUrl}?operation=26`, // 获取常用地址
  setCommonAddress: `${didiUrl}?operation=31`, // 设置常用地址
  didi_confirmOrder: `${didiUrl}?operation=24`,
  endTrip_getCarTickets: `${didiUrl}?operation=36`,
  setBaseCity: `${didiUrl}?operation=13`,
  getBaseCity: 'vehicle-dd-web/public-access/admin/data/queryStafffWorkCity.do',

  // 机票
  getAirlines: 'smart-buy-center-web/data/flight/getFlights.do', // 获取航空公司
  ticketFilterFlights: 'smart-buy-center-web/data/flight/filterFlights.do', // 航班筛选
  getTicketOrders: 'smart-buy-center-web/data/flight/myAdvanceOrdersData.do', // 获取我的订单列表
  getFlightPrice: 'smart-buy-center-web/data/flight/getFlightPrice.do', // 获取机票价格列表
  getOrderByOrderNo: 'smart-buy-center-web/data/flight/getOrdersByOrderNo.do', // 获取订单详情
  chooseVouchers: 'smart-buy-center-web/data/flight/queryEaVouchers', // 选择消费券
  submitTicketOrders: 'smart-buy-center-web/data/flight/create.do', // 机票预订单创建
  createRefundApply: 'smart-buy-center-web/data/flight/createRefundApply.do', // 退订单创建
  confirmRefundApply: 'smart-buy-center-web/data/flight/confirmRefundApply.do', // 机票退订单确认
  cancelRefundApply: 'smart-buy-center-web/data/flight/cancelRefundApply.do', // 机票退订单取消
  createEndorseOrder: 'smart-buy-center-web/data/flight/createEndorseOrderData.do', // 机票改签单创建
  confirmEndorse: 'smart-buy-center-web/data/flight/confirmEndorseOrderData.do', // 机票改签单确认
  cancelEndorseOrder: 'smart-buy-center-web/data/flight/cancelEndorseOrderData.do', // 机票改签单取消

  // 酒店
  getAccessParamsForCtrip: 'smart-buy-pay-war/user/getAccessParams/200', // 携程酒店获取登录参数
};

module.exports = {
  api,
};
