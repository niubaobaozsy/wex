const api = {
  attachmentSave: 'sdatt/file/base64/upload',         // 发票附件上传,
  queryByTypeAndModule: 'cdp-docker-web/docker/param/queryByTypeAndModule',  //
  getinvoicebyqrcoder: 'inv-vrf/invoice-verify/getinvoicebyqrcoder',   // 通过二维码获取发票信息（二维码扫描识别信息接口）
  verify: 'inv-vrf/invoice-verify/getinvoicebyverifycodepic', // 查验发票
  walletItemDetail: 'sdatt/invoice/get',           // 票夹里的item详细
  invoiceType: 'cdp-docker-web/docker/dictitem/getItemsByCode?code=DOC_INVOICE_TYPE',  // 获取发票类型
  walletItemSave: 'sdatt/invoice/add',                      // 保存发票
  walletItemDel: 'sdatt/invoice/del',                      // 票夹里的item删除
  getImg: 'sdatt/file/download/base64/',                  // 获取发票图片
  invoiceQuery: 'sdatt/invoice/query',                   // 票夹发票查询
};

module.exports = {
  api,
};
