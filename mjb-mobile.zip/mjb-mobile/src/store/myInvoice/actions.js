import http from '../http';
import { api } from './api';

const actions = {
  // 保存附件的地址
  myiUploadImg({ commit, rootState }, param) {
    return http.request({
      url: api.attachmentSave,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      data: param,
    }).then(res => res.data);
  },
  // 获取发票查验特征值
  queryByTypeAndModule({ state, commit, rootState }, param) {
    if ((JSON.parse(localStorage.getItem('advancedSetting') || '{}').invQueryMode || 'normal') === 'forceFree') {
      commit('INVVERCODE', '0');
    } else if (state.invVerCode === '0') {
      commit('INVVERCODE', '');
    }
    if (state.invVerCode) {
      return state.invVerCode;
    }
    const _param = Object.assign({ type: 'invoice-verify-code', module: 'jiebao-docker' }, param || {});
    return http.request({
      url: api.queryByTypeAndModule,
      baseURL: rootState.baseConfig.baseUrlCdp,
      data: _param,
      method: 'get',
    }).then((res) => {
      if (res && res.data && res.data.data && res.data.data.info && res.data.data.info[0] && res.data.data.info[0].param_value){
        commit('INVVERCODE', res.data.data.info[0].param_value);
        return res.data.data.info[0].param_value;
      }
      commit('INVVERCODE', '');
      return '';
    });
  },
  /**
  * 获取手工录入或扫码录入后的发票信息
  */
  getInvoice({ dispatch, commit, rootState }, param) {
    return dispatch('queryByTypeAndModule').then((resp) => {
      if (resp) {
        param.tenant_id = resp;
        return http.request({
          url: api.getinvoicebyqrcoder,
          baseURL: rootState.baseConfig.invUrl,
          data: param,
        }).then(res => res.data);
      }
      return { code: 'err', msg: '获取发票查验特征值失败' };
    });
  },
  /**
  * 查验发票
  */
  vertifyInvoice({ commit, rootState }, param) {
    param.tenant_id = rootState.userInfo.user.tenantId;
    return http.request({
      url: api.verify,
      baseURL: rootState.baseConfig.invUrl,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        // const signature = rep.data.data;
        // commit('SIGNATURE', signature);
      }
      return rep.data;
    })());
  },
  // 展示当前发票详情
  myInvoiceDetail({ commit, rootState }, param) {
    return http.request({
      url: `${api.walletItemDetail}/${param}`,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      method: 'get',
    }).then(res => res.data);
    // .then(res => (() => {
    //   if (res && res.status === 200 && res.data) {
    //     commit('PJ_INVOICE_DETAIL', res.data.data);
    //   }
    //   return res.data;
    // })());
  },
  // 展示详细发票时获取当前发票图片
  myiGetImg({ commit, rootState }, param) {
    return http.request({
      url: `${api.getImg}/${param}`,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      method: 'get',
    }).then(res => res.data);
  },
  // 获取编辑或增加时的发票类型
  myiGetInvoiceType({ commit, rootState }, param) {
    return http.request({
      url: api.invoiceType,
      baseURL: rootState.baseConfig.baseUrlCdp,
      data: param,
      method: 'get',
    }).then(res => res.data);
  },
  // 保存发票
  myiSaveInvoice({ commit, rootState }, param) {
    return http.request({
      url: api.walletItemSave,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      data: param,
    }).then(res => res.data);
  },
  // 删除发票
  myiInvoiceDelete({ commit, rootState }, param) {
    return http.request({
      url: api.walletItemDel,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      data: param,
    }).then(res => res.data);
  },
  // 展示详细发票时获取当前发票图片

  // 发票查询
  myInvoiceQuery({ commit, rootState }, param) {
    return http.request({
      url: api.invoiceQuery,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      data: param,
    }).then(res => res.data);
  },
  // 发票删除
  myInvoiceDelete({ commit, rootState }, param) {
    return http.request({
      url: api.walletItemDel,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      data: param,
    }).then(res => res.data);
  },

};

export default actions;
