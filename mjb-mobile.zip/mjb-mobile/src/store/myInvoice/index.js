import actions from './actions';
import mutations from './mutations';

const state = {
  invVerCode: '',  // 发票查验特征值
  invoice: {},
  wrong_msg: '',         // 校验失败的原因
  verify_code_pic: {},  // 验证码图片
  myMainFlag: '',       // 票夹列表数据缓存时的状态区分
  myInvoiceType: '',
  pjBackMarkFlag: '',   // 发票编辑删除保存标识
  myFileList: [],       // 附件列表
  // 附件大图图片数组
  bigImgList: [],
};

export default {
  actions,
  mutations,
  state,
};
