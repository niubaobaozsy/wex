const mutations = {
  // 发票查验特征值
  INVVERCODE: (state, invVerCode) => {
    state.invVerCode = invVerCode;
  },
  // 发票信息
  INVOICE: (state, invoice) => {
    state.invoice = invoice;
  },
  // 校验失败信息
  WRONG_MSG: (state, msg) => {
    state.wrong_msg = msg;
  },
  MY_INVOICE_TYPE: (state, msg) => {
    state.myInvoiceType = msg;
  },
  // 当前发票详细信息
  MY_INVOICE_DETAIL: (state, data) => {
    state.myInvoiceData = data;
  },
  // 已上传附件列表
  MY_UPLOAD_FILE_LIST: (state, msg) => {
    state.myFileList = msg;
  },
  // 当前发票详细信息
  PJ_INVOICE_DETAIL: (state, data) => {
    data.amount_sum = data.amount_sum || 0;
    state.pjInvoiceDetailInfo = data;
  },
  // 发票删除或者保存标识
  PJ_BACKMARK: (state, msg) => {
    state.pjBackMarkFlag = msg;
  },
  // 验证码图片
  VERIFY_CODE_PIC: (state, img) => {
    state.verify_code_pic = img;
  },
  // 发票已用或未用
  MY_RELATED: (state, msg) => {
    state.myRelated = msg;
  },
  // 附件缩略图片数组
  TR_BIG_IMG_LIST: (state, data) => {
    state.bigImgList = data;
  },
};

export default mutations;
