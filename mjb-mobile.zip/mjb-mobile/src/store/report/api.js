const api = {
  excuteContrast: 'report/yf/budgetExecute/statAnalysis', // 费用预算（报销）执行分析(条形图)
  excuteAnalysis: 'report/yf/budgetExecute/statTrend', // 费用预算（报销）执行分析（折线图）
  occupyContrast: 'report/yf/budgetOccupy/statAnalysis', // 费用预算（报销）占用分析(条形图)
  occupyAnalysis: 'report/yf/budgetOccupy/statTrend', // 费用预算（报销）占用分析（折线图）
};

module.exports = {
  api,
};
