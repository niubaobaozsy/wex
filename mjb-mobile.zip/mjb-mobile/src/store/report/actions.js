import http from '../http';
import { api } from './api';

const actions = {
  /**
  * 获取费用预算（报销）执行分析部门对比数据
  */
  getExcuteContrast({ commit, rootState }, param) {
    return http.request({
      url: api.excuteContrast,
      baseURL: rootState.baseConfig.baseUrlReport,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        // const signature = rep.data.data;
        // commit('SIGNATURE', signature);
      }
      return rep.data;
    })());
  },
  /**
  * 获取费用预算（报销）执行分析变动分析数据
  */
  getExcuteAnalysis({ commit, rootState }, param) {
    return http.request({
      url: api.excuteAnalysis,
      baseURL: rootState.baseConfig.baseUrlReport,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        // const signature = rep.data.data;
        // commit('SIGNATURE', signature);
      }
      return rep.data;
    })());
  },
  /**
  * 获取费用预算（报销）占用分析部门对比数据
  */
  getOccupyContrast({ commit, rootState }, param) {
    return http.request({
      url: api.occupyContrast,
      baseURL: rootState.baseConfig.baseUrlReport,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        // const signature = rep.data.data;
        // commit('SIGNATURE', signature);
      }
      return rep.data;
    })());
  },
  /**
  * 获取费用预算（报销）占用分析变动分析数据
  */
  getOccupyAnalysis({ commit, rootState }, param) {
    return http.request({
      url: api.occupyAnalysis,
      baseURL: rootState.baseConfig.baseUrlReport,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        // const signature = rep.data.data;
        // commit('SIGNATURE', signature);
      }
      return rep.data;
    })());
  },
};

export default actions;
