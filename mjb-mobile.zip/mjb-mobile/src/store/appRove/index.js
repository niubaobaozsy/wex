import actions from './actions';
import mutations from './mutations';

const state = {
  approveMsgFeed: [],
  fdStatus: false,
};

export default {
  actions,
  mutations,
  state,
};
