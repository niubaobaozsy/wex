import http from '../http';
import { api } from './api';

const actions = {
  // 获取费用申请单单据信息
  myReQuest({ commit, rootState }, param) {
    return http.request({
      url: api.myReQuest,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        // const signature = rep.data.data;
      }
      return rep.data;
    })());
  },
  // 获取报销单单据信息
  myFeeReim({ commit, rootState }, param) {
    return http.request({
      url: api.myFeeReim,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        // const signature = rep.data.data;
      }
      return rep.data;
    })());
  },
  mygetReimbursement({ commit, rootState }, param) {
    return http.request({
      url: api.mygetReimbursement,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        // const signature = rep.data.data;
      }
      return rep.data;
    })());
  },
  // 单据沟通接口
  getCommunicate({ commit, rootState }, param) {
    return http.request({
      url: api.getCommunicate,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 获取历史单据-已审批
  myHistoryOrder({ commit, rootState }, param) {
    return http.request({
      url: api.myHistoryOrder,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 获取待审列表-未审批
  myGetMessage({ commit, rootState }, param) {
    return http.request({
      url: api.myGetMessage,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 单据驳回
  myRefuse({ commit, rootState }, param) {
    return http.request({
      url: api.myRefuse,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 单据通过
  myPass({ commit, rootState }, param) {
    return http.request({
      url: api.myPass,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 单据回复沟通
  reCommunicate({ commit, rootState }, param) {
    return http.request({
      url: api.reCommunicate,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 撤回沟通
  celCommunicate({ commit, rootState }, param) {
    return http.request({
      url: api.celCommunicate,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 单据转办
  commiss({ commit, rootState }, param) {
    return http.request({
      url: api.commiss,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  getFileByOrderMsg({ commit, rootState }, param) {
    return http.request({
      url: api.getFileByOrderMsg,
      baseURL: rootState.baseConfig.baseUrlSdatt,
      data: param,
    }).then(res => res.data);
  },
  // 借款单审批
  getLoan({ commit, rootState }, param) {
    return http.request({
      url: api.getLoan,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
//  借款单审批节点信息
  getLog({ commit, rootState }, param) {
    return http.request({
      url: api.getLog,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  //  借款审当前批节点信息
  getCur({ commit, rootState }, param) {
    return http.request({
      url: api.getcur,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
//  借款单获取待审批未审批的信息节点
  grtFlowt({ commit, rootState }, param) {
    return http.request({
      url: api.grtFlowt,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
//  获取审批-通用费用申请详情信息
  getFee({ commit, rootState }, param) {
    return http.request({
      url: api.getFee,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
   // 获取审批-通用费用申请详情信息
  getAdjustApply({ commit, rootState }, param) {
    return http.request({
      url: api.getAdjustApply,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  getOplist({ commit, rootState }, param) {
    return http.request({
      url: api.getOplist,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  getFeeapply({ commit, rootState }, param) {
    return http.request({
      url: api.getFeeapply,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
//  获取取消沟通节点
  cancelOpparam({ commit, rootState }, param) {
    return http.request({
      url: api.cancelOpparam,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 取消沟通
  celcommunicate({ commit, rootState }, param) {
    return http.request({
      url: api.celcommunicate,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 获取审批调账申请信息
  adjustAccount({ commit, rootState }, param) {
    return http.request({
      url: `${api.adjustAccount}/${param}`,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
      method: 'get',
    }).then(res => res.data);
  },
  // 获取付款审批信息
  getEmspareqh({ commit, rootState }, param) {
    return http.request({
      url: `${api.getEmspareqh}/${param}`,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
      method: 'get',
    }).then(res => res.data);
  },
  // 获取首页在审单据列表
  queryFeeOrderFlowStepForApp({ commit, rootState }, param) {
    return http.request({
      url: api.queryFeeOrderFlowStepForApp,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
};

export default actions;
