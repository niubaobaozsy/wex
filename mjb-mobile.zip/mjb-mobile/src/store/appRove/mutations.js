const mutations = {
  APPROVEMSGFEED: (state, arr) => {
    state.approveMsgFeed = arr;
  },
  CHANGE_FDSTATUS:(state) => {
    state.fdStatus = true;
  },
  REC_FDSTATUS:(state) => {
    state.fdStatus = false;
  }
};

export default mutations;
