const api = {
  myReQuest: 'smart-expense-web/ea/feeApply/getFeeApplyByIdForApp', // 获取费用申请单单据信息
  myFeeReim: 'smart-expense-web/ec/feeReim/getFeeReimByIdForApp', // 获取报销单单据信息
  mygetReimbursement: 'smart-expense-web/lm/loan/getLoanForApp',
  getCommunicate: 'smart-expense-web/wf/process/communicate', // 单据沟通接口
  reCommunicate: 'smart-expense-web/wf/process/recommunicate', // 单据回复沟通接口
  // myHistoryOrder: 'smart-expense-web/uc/userCenter/queryMyFeeOrderForApp',  // 获取历史单据-已审批
  myGetMessage: 'smart-expense-web/wf/pro/myrun',  // 获取待审批列表
  myHistoryOrder: 'smart-expense-web/wf/pro/mywork',  // 获取历史单据-已审批
  myRefuse: 'smart-expense-web/wf/process/refuse',  // 单据驳回
  myPass: 'smart-expense-web/wf/process/approve',   // 单据通过
  commiss: 'smart-expense-web/wf/process/commiss', // 单据转办
  celCommunicate: 'smart-expense-web/wf/process/celCommunicate', // 取消沟通
  getFileByOrderMsg: 'sdatt/attach/getFileByOrderMsg',
  getLoan: 'smart-expense-web/lm/loan/getLoan', // 借款单审批借款单信息
  getLog: 'smart-expense-web/wf/pro/getLog', //  借款单审批审批已经通过的节点信息
  getcur: 'smart-expense-web/wf/pro/getcur',
  grtFlowt: 'smart-expense-web/wf/process/flowt', //  借款单获取待审批未审批节点信息
  getFee: 'smart-expense-web/ec/feeReim/getFeeReimById', //  获取通用费用报销审批详情
  getAdjustApply: 'smart-expense-web/bm/EmsBmAdjustApplyH/getAdjustApply',
  getOplist: 'smart-expense-web/wf/process/oplist',
  getFeeapply: 'smart-expense-web/ea/feeApply/getFeeApplyById', // 获取通用费用申请单单据信息
  cancelOpparam: 'smart-expense-web/wf/process/opparam', // 获取取消沟通节点
  celcommunicate: 'smart-expense-web/wf/process/celcommunicate',  // 取消沟通
  adjustAccount: 'smart-expense-web/ca/EmsCaApportionH/get',  // 获取调账申请信息
  getEmspareqh: 'smart-expense-web/pa/EmsPaReqH/get/',  // 获取付款审批信息
  queryFeeOrderFlowStepForApp: 'smart-expense-web/uc/userCenter/queryFeeOrderFlowStepForApp',  // 获取首页在审单据列表
};
module.exports = {
  api,
};
