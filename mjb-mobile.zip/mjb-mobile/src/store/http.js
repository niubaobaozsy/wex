/**
 * Created by zhuangyh on 2017/07/10.
 */
import axios from 'axios';
import vue from '../main';
import store from './index';

const http = axios.create();

/**
 * http request interceptor
 */
http.interceptors.request.use(
  (config) => {
    let appName = '';
    try {
      if (store.state.baseConfig.passMAS) {
        appName = new URL(config.url).pathname.split('/')[3];
      } else {
        appName = new URL(config.url).pathname.split('/')[1];
      }
    } catch (err) {
      appName = '';
    }
    if (appName &&
      store.state.baseConfig.multiLogin &&
      store.state.baseConfig.multiLogin.length &&
      store.state.baseConfig.multiLogin.indexOf(appName) !== -1 && store.state.smartBuyToken) {
      config.headers['x-auth-token'] = store.state.smartBuyToken;
    } else if (store.state.token) {
      config.headers['x-auth-token'] = store.state.token;
    }
    return config;
  }, err => Promise.reject(err));

/**
 * http response interceptor
 */
http.interceptors.response.use(
  (response) => {
    const stateCode = response.data.code;
    const passMAS = store.state.baseConfig.passMAS;
    if (stateCode === '0401' || (passMAS && stateCode === '40001') || (passMAS && stateCode === '40002')) {
      vue.prototype.hideLoading();
      if (store.state.userInfo && store.state.userInfo.employeeNumber) {
        vue.prototype.untiePushService(store.state.userInfo.employeeNumber);
      }
      store.commit('ROOT_LOGOUT');
      const redirectUrl = location.hash;
      if (redirectUrl !== '#/') {
        localStorage.setItem('redirectUrl', redirectUrl);
      }
      // 判断是否在微信浏览器
      const isInWeChat = store.state.baseConfig.platform === 'wechat';
      if (isInWeChat) {
        window.location.href = store.state.baseConfig.wechatOAuthUrl;
      } else {
        vue.prototype.setInnerNavigateFlag('/');
        window.location.hash = '/';
      }
      return false;
    }
    return response;
  },
  (error) => {
    let msg = '';
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      const status = error.response.status;
      if (status >= 300 && status < 400) {
        msg = `请求已被重定向(${status})`;
      } else if (status >= 400 && status < 500) {
        msg = `服务器拒绝该请求(${status})`;
      } else {
        msg = `服务器异常,请稍后再试(${status})`;
      }
    } else if (error.request) {
      // The request was made but no response was received
      // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
      // http.ClientRequest in node.js
      msg = '请求超时';
    } else {
      // Something happened in setting up the request that triggered an Error
      msg = `请求时发生错误(${error.message})`;
    }
    vue.prototype.hideLoading();
    vue.prototype.showToast({ msg });
    return Promise.reject(error);
  });

/**
 * @param url
 */
function _formatUrl(url) {
  let _url = url;
  if (store.state.baseConfig.passMAS && store.state.ssoToken) {
    if (url.indexOf('?') > -1) {
      _url = `${url}&${store.state.baseConfig.ssoTokenName}=${store.state.ssoToken}`;
    } else {
      _url = `${url}?${store.state.baseConfig.ssoTokenName}=${store.state.ssoToken}`;
    }
  }
  return _url;
}

/**
 * @param { baseURL, url, data, contentType } params
 */
function get(params) {
  return http({
    url: _formatUrl(params.url),
    method: 'get',
    baseURL: params.baseURL || store.state.baseConfig.baseUrl,
    headers: {
      'Content-Type': params.contentType || 'application/json',
    },
    params: params.data || {},
  });
}

/**
 * @param { baseURL, url, data, contentType } params
 */
function post(params) {
  return http({
    url: _formatUrl(params.url),
    method: 'post',
    baseURL: params.baseURL || store.state.baseConfig.baseUrl,
    headers: {
      'Content-Type': params.contentType || 'application/json',
    },
    data: params.data || {},
  });
}

/**
 * @param { baseURL, url, data, contentType } params
 */
function del(params) {
  return http({
    url: _formatUrl(params.url),
    method: 'delete',
    baseURL: params.baseURL || store.state.baseConfig.baseUrl,
    headers: {
      'Content-Type': params.contentType || 'application/json',
    },
    data: params.data || {},
  });
}

/**
 * @param { baseURL, url, data, contentType, method } params
 */
function request(params) {
  const _data = params.data || {};
  const option = {
    url: _formatUrl(params.url),
    method: params.method || 'post',
    baseURL: params.baseURL || store.state.baseConfig.baseUrl,
    headers: {
      'Content-Type': params.contentType || 'application/json',
    },
  };
  if (params.method === 'get') {
    option.params = _data;
  } else {
    option.data = _data;
  }
  return http(option);
}

export default {
  get,
  post,
  del,
  request,
};
