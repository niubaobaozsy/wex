const mutations = {
  BASECONFIG: (state, obj) => {
    state.baseConfig = obj;
  },
  MENUCONFIG: (state, obj) => {
    state.menuConfig = obj;
  },
  USERINFO: (state, obj) => {
    state.userInfo = obj;
  },
  ROOT_LOGIN: (state, obj) => {
    state.token = obj;
  },
  ROOT_LOGOUT: (state) => {
    if (localStorage.loginOption) {
      const loginOption = JSON.parse(localStorage.loginOption);
      loginOption.autoLogin = false;
      localStorage.setItem('loginOption', JSON.stringify(loginOption));
    }
    localStorage.removeItem('token');
    localStorage.removeItem('userInfo');
    localStorage.removeItem('smartBuyToken');
    localStorage.removeItem('smartBuyUserInfo');
    // localStorage.removeItem('redirectUrl');
    state.token = '';
    state.userInfo = null;
    state.smartBuyToken = '';
    state.smartBuyUserInfo = null;
  },
  SMART_BUY_LOGIN: (state, obj) => {
    state.smartBuyToken = obj;
  },
  SMART_BUY_USERINFO: (state, obj) => {
    state.smartBuyUserInfo = obj;
  },
  SSOTOKEN: (state, obj) => {
    state.ssoToken = obj;
  },
  MIP: (state, obj) => {
    state.mipId = obj;
  },
  DEVICEINFO: (state, obj) => {
    state.deviceInfo = obj;
  },
  SHOW_POPUP: (state, obj) => {
    state.popupCfg = Object.assign(state.popupCfg, obj);
  },
  HAS_DEFAULT_CONFIG: (state, boo) => {
    state.hasDefaultConfig = boo;
  },
  EXTCALL: (state, boolean) => {
    state.extCall = boolean;
  },
  APP_VISIBILITY: (state, boolean) => {
    state.appVisibility = boolean;
  },
};

export default mutations;
