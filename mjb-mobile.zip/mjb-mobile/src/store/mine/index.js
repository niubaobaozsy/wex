import actions from './actions';
import mutations from './mutations';

const state = {
  // 用户信息
  userMsg: {},
  // 个人收款信息删除
  collectFlag: '',
  // 开户银行信息
  getbank: {},
  // 个人收款信息
  collectMsg: {
    bank_address: '',
    bank_category: '',
    bank_code: '',
    bank_name: '',
  },
  // 保存预算部门
  companyName: {
    busi_org_name: '',
  },
  // 预算主体
  subjuct: {
    busi_org_name: '',
  },
  // 预算树名称
  budgetName: {
    budget_name: '',
    busi_org_name: '',
  },
  // 选择入账单位
  getCampany: {
    company_name: '',
  },
  // 默认发票信息
  invoiceMsg: {},
  // 旅客信息
  travelMsg: {
    certNumber: '',
    certType: '',
    cnName: '',
    commPassengerId: '',
    mobile: '',
    types: '',
  },
  // 获取默认入账单位Id
  companyId: '',
  // 获取默认预算部门
  defaultMain: {},
};

export default {
  actions,
  mutations,
  state,
};
