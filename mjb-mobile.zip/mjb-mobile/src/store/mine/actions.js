import http from '../http';
import { api } from './api';

const actions = {
  /**
  * 获取用户信息
  */
  getUserInfo({ rootState }, param) {
    return http.get({
      url: api.getUserInfo + param.id,
      baseURL: rootState.baseConfig.baseUrlCdp,
    }).then(rep => (() => {
      if (rep && rep.data) {
        return rep.data;
      }
      return false;
    })());
  },
  //  删除个人收款信息
  deleteCollect({ commit, rootState }, param) {
    return http.post({
      url: api.deleteCollect,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(res => res.data);
  },
  //  保存个人收款信息
  mineSaveCollect({ commit, rootState }, param) {
    return http.post({
      url: api.mineSaveCollect,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(res => res.data);
  },
  //  常用收款方设置默认
  mineSetDefaultReceiver({ commit, rootState }, param) {
    return http.post({
      url: api.mineSetDefaultReceiver,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(res => res.data);
  },
  //  常用收款方挑选银行信息
  mineGetBankInfo({ commit, rootState }, param) {
    return http.post({
      url: api.mineGetBankInfo,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(res => res.data);
  },
  //  保存发票信息
  saveDefalutInvoice({ commit, rootState }, param) {
    return http.post({
      url: api.saveDefalutInvoice,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(res => res.data);
  },
  //  删除发票信息
  deletInvoice({ commit, rootState }, param) {
    return http.del({
      url: `${api.deletInvoice}/${param}`,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(res => res.data);
  },
  //  旅客信息列表
  mineTravelMsg({ commit, rootState }, param) {
    return http.get({
      url: api.mineTravelMsg,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
    }).then(res => res.data);
  },
  //  删除旅客信息
  deleteTravel({ commit, rootState }, param) {
    return http.get({
      url: api.deleteTravel,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
    }).then(res => res.data);
  },
  //  添加旅客信息
  addTravelMsg({ commit, rootState }, param) {
    return http.post({
      url: api.addTravelMsg,
      baseURL: rootState.baseConfig.baseUrlPlane,
      data: param,
    }).then(res => res.data);
  },
  //  获取银行地址信息
  mineGetBankAdress({ commit, rootState }, param) {
    return http.post({
      url: api.mineGetBankAdress,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(res => res.data);
  },
};
export default actions;
