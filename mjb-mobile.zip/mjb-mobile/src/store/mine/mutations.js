const mutations = {
  // 用户信息
  USERMSG: (state, obj) => {
    state.userMsg = obj;
  },
   // 收款信息
  COLLECT_MSG: (state, msg) => {
    state.collectMsg = msg;
  },
   // 发票删除或者保存标识
  COLLECT_FLAG: (state, msg) => {
    state.collectFlag = msg;
  },
  // 预算部门
  COMPANY_NAME: (state, msg) => {
    state.companyName = msg;
  },
  // 预算主体
  SUBJUCT: (state, msg) => {
    state.subjuct = msg;
  },
  // 预算树名称
  BUDGETNAME: (state, msg) => {
    state.budgetName = msg;
  },
  // 选择入账单位
  GETCAMPANY: (state, msg) => {
    state.getCampany = msg;
  },
  // 开户行信息
  GETBANK: (state, msg) => {
    state.getbank = msg;
  },
  // 发票默认信息
  INVOICEMSG: (state, msg) => {
    state.invoiceMsg = msg;
  },
  // 旅客列表信息
  TRAVELMSG: (state, msg) => {
    state.travelMsg = msg;
  },
  // 获取个人默认入账单位id
  COMPANYID: (state, msg) => {
    state.companyId = msg;
  },
  // 获取个人默认入账单位id
  DEFAULTMAIN: (state, msg) => {
    state.defaultMain = msg;
  },
};

export default mutations;
