const api = {
  getUserInfo: 'cdp-docker-web/docker/userinfo/getUserById/', // 获取用户信息
  mineSetDefaultReceiver: 'jiebao-docker-web/cm/userCenter/setDefaultReceiver', // 常用收款方设置默认
  mineSaveCollect: 'jiebao-docker-web/cm/userCenter/saveReceiver', // 保存收款方
  mineGetBankAdress: 'jiebao-docker-web/docker/ubankcode/select',   // 获取银行地址
  deleteCollect: 'jiebao-docker-web/cm/userCenter/deleteReceiver', // 删除收款信息
  mineGetBankInfo: 'jiebao-docker-web/docker/ubankcode/getBankInfo', // 常用收款方挑选银行信息
  saveDefalutInvoice: 'jiebao-docker-web/cm/userCenter/saveDefaultConfig', // 设置默认保存发票信息
  deletInvoice: 'jiebao-docker-web/cm/userCenter/delete', // 删除发票
  mineTravelMsg: 'smart-buy-center-web/data/flight/getCommonPassengers.do', // 旅客信息列表
  deleteTravel: 'smart-buy-center-web/data/flight/deleteCommonPassenger.do', // 删除旅客信息
  addTravelMsg: 'smart-buy-center-web/data/flight/createOrUpdatePassenger.do', // 保存旅客信息
};

module.exports = {
  api,
};
