const mutations = {
  // EMSEAAPPLYH: (state, data) => {
  //   state.emseaapplyh = data;
  // },
  CITY_LIST: (state, arr) => {
    state.views.cityList = arr;
  },
  LETTER_LIST: (state, arr) => {
    state.views.letterList = arr;
  },
  CURRENT_CITY: (state, arr) => {
    state.views.currentCity = arr;
  },
  APPLY_ARR: (state, arr) => {
    state.applyArr = arr;
  },
};

export default mutations;
