import http from '../http';
import { api } from './api';

const actions = {
  // 差旅获取所有地点
  searchArea({ commit, rootState }, param) {
    return http.request({
      url: api.searchArea,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
      method: 'post',
    }).then(res => res.data);
  },
  // 滴滴搜索城市
  getCities({ commit, rootState }, param) {
    return http.request({
      url: api.getCities,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  // 联想地点
  getSearchAddress({ commit, rootState }, param) {
    return http.request({
      url: api.getSearchAddress,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
      method: 'post',
    }).then(res => res.data);
  },
  // 获取热门、常用、历史地点
  getAddress({ commit, rootState }, param) {
    return http.request({
      url: api.getAddress,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },

  // 设置热门、常用、历史地点
  setAddress({ commit, rootState }, param) {
    return http.request({
      url: api.setAddress,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
    }).then(res => res.data);
  },
  // 匹配高德与后台的cityId获取到cityId
  getCityId({ commit, rootState }, param) {
    return http.request({
      url: api.getCityId,
      baseURL: rootState.baseConfig.baseUrlCar,
      data: param,
      method: 'post',
    }).then(res => res.data);
  },
};

export default actions;

