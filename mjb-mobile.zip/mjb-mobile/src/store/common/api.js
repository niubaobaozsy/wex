const api = {
  searchArea: 'jiebao-docker-web/docker/area/page', // 差旅获取所有地点
  // searchArea: 'jiebao-docker-web/docker/area/queryByParentIdAndRegionCode',
  getCities: 'vehicle-dd-web/public-access/taxi/data/taxiservice.do?operation=21', // 城市列表
  getAddress: 'vehicle-dd-web/public-access/taxi/data/taxiservice.do?operation=26', // 获取常用、热门和历史城市
  setAddress: 'vehicle-dd-web/public-access/taxi/data/taxiservice.do?operation=31', // 设置常用、热门和历史城市
  getCityId: 'vehicle-dd-web/public-access/taxi/data/taxiservice.do?operation=33', // 匹配高德与后台的cityId params: cityCode, 获取到cityId
  getSearchAddress: 'vehicle-dd-web/public-access/taxi/data/taxiservice.do?operation=4', // 地址联想
};

module.exports = {
  api,
};
