import actions from './actions';
import mutations from './mutations';

const state = {
  // 保存城市列表
  views: {
    cityList: [],
    letterList: [],
    currentCity: {},
  },
  // 保存申请单所需参数
  // emseaapplyh: {
  //   fee_apply_id: null,
  //   fee_apply_code: null,
  //   apply_by: '',
  //   apply_name: '',
  //   formInstanceId: null,
  //   org_id: '',
  //   org_name: '',
  //   apply_date: '',
  //   apply_amount: 0,
  //   currency_code: 'CNY', // 默认为人民币
  //   currency_name: '人民币',
  //   order_type: '',
  //   form_template_id: '',
  //   form_template_name: '',
  //   sensitive_info: '',
  //   need_loan: 'N',
  //   order_status: 'DRAFT',
  //   emseaapplyhexts: [],
  //   order_template_id: '',
  //   order_template_name: '',
  //   emseaapplytravels: [],
  //   emseaapplyls: [],
  //   emslmloan: {},
  //   emseaapplyrefs: [],
  //   main_fee: 0,
  //   rent_fee: 0,
  //   assistance_fee: 0,
  //   other_fee: 0,
  //   flight_fee: 0,
  //   city_fee: 0,
  //   eat_fee: 0,
  //   total_fee: 0,
  //   approve_amount: 0,
  //   need_visa: 'N',
  //   other_fee_desc: '',
  //   source_system: 'MOBILE',
  // },
  // 关联申请单效果辅助数据
  applyArr: [],
  canModify: true,
};

export default {
  actions,
  mutations,
  state,
};
