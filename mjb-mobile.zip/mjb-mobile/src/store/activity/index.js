import actions from './actions';
import mutations from './mutations';

const stateInit = {

};
const state = JSON.parse(JSON.stringify(stateInit));

export default {
  stateInit,
  actions,
  mutations,
  state,
};
