import http from '../http';
import { api } from './api';

const actions = {
  // 获取飞行次数
  flightCount({ commit, rootState }, param) {
    return http.request({
      url: api.flightCount,
      baseURL: rootState.baseConfig.baseUrlActive,
      data: param,
    }).then(res => res.data);
  },
  // 获取用车统计
  vehicleUsed({ commit, rootState }, param) {
    return http.request({
      url: api.vehicleUsed,
      baseURL: rootState.baseConfig.baseUrlActive,
      data: param,
    }).then(res => res.data);
  },
  // 获取总花费
  totalExpense({ commit, rootState }, param) {
    return http.request({
      url: api.totalExpense,
      baseURL: rootState.baseConfig.baseUrlActive,
      data: param,
    }).then(res => res.data);
  },
  // 获取使用时间
  joinTime({ commit, rootState }, param) {
    return http.request({
      url: api.joinTime,
      baseURL: rootState.baseConfig.baseUrlActive,
      data: param,
    }).then(res => res.data);
  },
  // 获取用户称号
  userTitle({ commit, rootState }, param) {
    return http.request({
      url: api.userTitle,
      baseURL: rootState.baseConfig.baseUrlActive,
      data: param,
    }).then(res => res.data);
  },
};
export default actions;
