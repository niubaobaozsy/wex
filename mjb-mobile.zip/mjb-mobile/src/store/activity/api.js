const api = {
  flightCount: 'report/yf/myFootPrint/flightCount', // 获取飞行次数
  vehicleUsed: 'report/yf/myFootPrint/vehicleUsed', // 获取用车统计
  totalExpense: 'report/yf/myFootPrint/jiebaoExpense', // 获取总花费
  joinTime: 'report/yf/myFootPrint/joinTime', // 获取使用时间
  userTitle: 'report/yf/myFootPrint/userTitle', // 获取用户称号
};

module.exports = {
  api,
};
