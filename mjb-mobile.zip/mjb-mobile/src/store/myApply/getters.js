const getters = {
  travelTotalFee: (state) => {
    const travelSumList = [];
    const travelAirSumList = [];
    let travelSum = 0;  // 行程中普通费
    let travelAirSum = 0; // 行程中对公飞机票
    if (state.emseaapplyh.emseaapplytravels) {
      state.emseaapplyh.emseaapplytravels.forEach((item) => {
        if (item.emseatransportdetails) {
          let travelItem = 0;
          let travelAirItem = 0;
          item.emseatransportdetails.forEach((feeItem) => {
            feeItem.approve_conversion_rate = '1';
            if (state.emseaapplyh.order_type && state.applyCreate.myApplyMenuCfg && state.applyCreate.myApplyMenuCfg[state.emseaapplyh.order_type].compnayPayAir && feeItem.attribute1 && feeItem.attribute1 === 'COMPANY' && feeItem.transport && feeItem.transport === 'AIRPLANE') {
              travelAirItem += parseFloat(feeItem.transport_fee) ? parseFloat(feeItem.transport_fee) : 0;
            } else {
              travelItem += parseFloat(feeItem.transport_fee) ? parseFloat(feeItem.transport_fee) : 0;
            }
          });
          travelSumList.push(travelItem);
          travelAirSumList.push(travelAirItem);
        }
      });
      travelSumList.forEach((item) => {
        travelSum += parseFloat(item);
      });

      travelAirSumList.forEach((item) => {
        travelAirSum += parseFloat(item);
      });
    }
    return { travelSum: travelSum, travelAirSum: travelAirSum };
  },

  travelFee: (state, getter) => parseFloat(getter.travelTotalFee.travelSum + getter.travelTotalFee.travelAirSum),

  // 行程上的对公飞机票预算来源
  airTicketBudget: (state, getter) => parseFloat(getter.travelTotalFee.travelAirSum),

  hotelFee: (state) => {
    let hotelSum = 0;
    if (state.emseaapplyh.emsearentdetails) {
      state.emseaapplyh.emsearentdetails.forEach((item) => {
        hotelSum += parseFloat(item.rent_fee) ? parseFloat(item.rent_fee) : 0;
      });
    }
    return hotelSum;
  },
  subsidyFee: (state) => {
    let subsidySum = 0;
    if (state.emseaapplyh.emseaassistantdetails) {
      state.emseaapplyh.emseaassistantdetails.forEach((item) => {
        subsidySum += parseFloat(item.assistant_fee) ? parseFloat(item.assistant_fee) : 0;
      });
    }
    return subsidySum;
  },
  otherFee: (state) => {
    let otherSum = 0;
    if (state.emseaapplyh.emseaotherfeedetails) {
      state.emseaapplyh.emseaotherfeedetails.forEach((item) => {
        item.happend_date = state.emseaapplyh.emseaapplytravels[0].start_date || null;
        otherSum += parseFloat(item.other_fee) ? parseFloat(item.other_fee) : 0;
      });
    }
    return otherSum;
  },

  totalFee: (state, getter) => parseFloat(getter.travelFee + getter.hotelFee + getter.subsidyFee + getter.otherFee),

  allBudgetFee: (state) => {
    let totalBudget = 0; // 不含对公飞机票预算行金额总和
    let totalAirFee = 0;// 对公飞机票预算行金额总和
    // 存在对公飞机票配置
    if (state.emseaapplyh.order_type && state.applyCreate.myApplyMenuCfg &&
      state.applyCreate.myApplyMenuCfg[state.emseaapplyh.order_type] &&
      state.applyCreate.myApplyMenuCfg[state.emseaapplyh.order_type].compnayPayAir) {
      state.emseaapplyh.emseaapplyls.forEach((item) => {
        if (!item.attribute1 || (item.attribute1 && item.attribute1 !== 'COMPANY')) {
          totalBudget += parseFloat(item.apply_amount);
        } else {
          totalAirFee += parseFloat(item.apply_amount);
        }
      });
    } else {
      state.emseaapplyh.emseaapplyls.forEach((item) => {
        totalBudget += parseFloat(item.apply_amount);
      });
    }

    return { totalBudget: totalBudget, totalAirFee: totalAirFee };
  },

  // 不含对公飞机票预算行金额总和
  totalCommonBudget: (state, getter) => parseFloat(getter.allBudgetFee.totalBudget),

  // 预算上的对公飞机票预算行金额总和
  totalAirFee: (state, getter) => parseFloat(getter.allBudgetFee.totalAirFee),

  // 预算的总和 = 预算上的对公飞机票预算行金额总和 + 不含对公飞机票预算行金额总和
  totalBudget: (state, getter) => parseFloat(getter.allBudgetFee.totalBudget + getter.allBudgetFee.totalAirFee),

  autoFillAdvanceDate: (state) => {
    const travels = state.emseaapplyh.emseaapplytravels || [];
    let feeAdvanceDate = 0;
    let feeAdvanceDateStr = '';
    travels.forEach((travel) => {
      if (travel.end_date && (feeAdvanceDate < Date.parse(new Date(travel.end_date.split(' ')[0])))) {
        feeAdvanceDate = Date.parse(new Date(travel.end_date.split(' ')[0]));
        feeAdvanceDateStr = travel.end_date;
      }
    });
    return feeAdvanceDateStr;
  },
};

export default getters;
