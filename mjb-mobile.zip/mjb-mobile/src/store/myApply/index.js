import actions from './actions';
import mutations from './mutations';
import getters from './getters';

const stateInit = {
  checkResult: null,
  detailMessage: { // 默认配置信息
    busi_org_name: null,
    busi_org_id: null,
  },
  // 保存申请单所需参数
  emseaapplyh: {
    fee_apply_id: null,
    fee_apply_code: null,
    tenant_id: '',
    created_by: '',
    created_name: '',
    apply_by: '',
    apply_name: '',
    org_id: '',
    org_name: '',
    apply_date: '',
    creation_date: '',
    apply_amount: 0,
    currency_code: 'CNY', // 默认为人民币
    currency_name: '人民币',
    order_type: '',
    form_template_id: '',
    form_template_name: '',
    need_loan: 'N',
    order_status: 'DRAFT',
    order_template_id: '',
    order_template_name: '',
    main_fee: 0,
    rent_fee: 0,
    assistance_fee: 0,
    meeting_fee: 0,
    flight_fee: 0, // midea版无该字段
    city_fee: 0, // midea版无该字段
    eat_fee: 0, // midea版无该字段
    other_fee: 0,
    other_fee_desc: '',
    total_fee: 0,
    // approve_amount: 0,
    reason_desc: '',
    budget_fee: 0,
    need_visa: 'N',
    is_over_standard: '',
    over_standard_reason: '',
    biz_status: '',
    is_travel_sure: true,
    is_international_travel: 'N',
    is_need_contract: false,
    is_realate_project: 'N',
    release_by: '',
    release_name: '',
    release_reason: '',
    io_ea_apply_h_id: '',
    loan_info_id: '',
    formInstanceId: null,
    source_system: 'MOBILE',
    emseaapplytravels: [      // 之前是这个字段 emseaapplytravelds
      {
        attribute1: 0,
        attribute2: 0.0,
        isclose: false,       // 非接口所有
        tenant_id: 0,
        travel_persons_name: '',
        travel_person_count: 0,
        travel_persons: '',
        start_date: '',
        end_date: '',
        from_area_name: '',
        from_area_id: '',
        to_area_id: '',
        to_area_names: '',
        travel_days: 0,
        created_by: '',
        created_name: '',
        creation_date: '',
        last_updated_by: '',
        last_updated_name: '',
        last_update_date: '',
        emseatransportdetails: [
          {
            label: true,    // 非接口所有
            transport: 'AIRPLANE',
            transport_fee: '',
            currency_code: '',
            conversion_rate: '1',
          },
        ],
      },
    ],
    emsearentdetails: [],  // 住宿明细
    emseaassistantdetails: [],  // 补助明细
    emseaapplyrefs: [], // 指定引用人列表
    emseaapplyls: [], // 预算明细
    emseaotherfeedetails: [], // 其他费用明细
    emslmloan: {}, // 借款头表
    emseaapplyhexts: [], // 扩展参数表
  },
  applyCreate: {
    ableNext: true,
    currentStep: 0,
    applyType: '',
    isSave: true,
    isCreateAirBudget: false, // 是否重新生成对公飞机票预算行
    myApplyMenuCfg:{},
  },
  companyName: '',
  emslmloan: {
    loan_info_id: '', // 主键id，第一次保存不用传，编辑必传
    loan_info_code: '', // 编码，第一次保存不用传，编辑必传
    fee_apply_id: '', // 费用申请单id
    order_type: 'PERSONPAY_PUBLIC', // 规则类型
    biz_flag: 0, // 0：对私；1：对公
    order_template_id: '8', // 规则模板id
    order_template_name: '个人因公借款', // 规则模板名称
    apply_by: '', // 申请人id
    apply_name: '', // 申请人名称
    org_id: '', // 申请人部门id
    org_name: '', // 申请人部门名称
    form_template_id: '32618327448748032', // 表格模板id
    form_template_name: '借款申请表单', // 表格模板名称
    amount: '', // 借款金额
    currency_code: 'CNY', // 币种类型
    currency_name: '人民币', // 币种中文名称
    expected_repay_date: '', // 预计还款日期
    receiver: '', // 收款方
    bank_name: '', // 银行名称
    bank_code: '', // 银行编号
    bank_account: '', // 银行账号
    bank_adress: '', // 银行地址
    city: null, // 城市
    provice: null, // 省
    receiver_en: '', // 收款人名称拼音
    vendor_type: null,
    sensitive_info: '', // 借款事由
    is_instalments_pay: 'N', // 是否分期付款，N：不分期；Y：分期
    company_id: '', // 入账单位id
    company_name: '', // 入账单位名称
    ou_id: '',
    proxy_user: '', // 代理用户
    apply_date: '', // 申请日期
    source_system: 'MOBILE',
  },
  loanObj: {
    data: '',
    show: false,
  },
  applyaList: [],
  flowNode: {},
  // getStandardReqParam: {
  //   travels: {},
  //   travel_persons: '',
  // },
  feeStdExp: true,
  overStdExp: true,
  checkboxStatus:false,
  travelTypeList:[]  // 出差类型下拉数据保存
};
const state = JSON.parse(JSON.stringify(stateInit));

export default {
  stateInit,
  actions,
  mutations,
  state,
  getters,
};
