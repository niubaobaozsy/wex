import http from '../http';
import { api } from './api';

const actions = {
  // 根据申请人id 获取所在OU报销标准的出差类型
  getTravelTypeById({ commit, rootState }, param) {
    return http.request({
      url: api.getTravelTypeById,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },

  //  获取字典数据
  getItemsByCode({ commit, rootState }, param) {
    return http.request({
      method: 'get',
      url: api.getItemsByCode + param,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: '',
    }).then(res => res.data);
  },

  //  获取表单模版信息
  getFormTemplates({ commit, rootState }, param) {
    return http.request({
      url: api.getFormTemplates,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 保存费用申请单
  saveFeeApply({ commit, rootState }, param) {
    return http.request({
      url: api.saveFeeApply,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 释放预算
  releaseBudget({ commit, rootState }, param) {
    return http.request({
      url: api.releaseBudget,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 获取预算来源
  getBudgetSource({ commit, rootState }, param) {
    return http.request({
      url: api.getBudgetSource,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 获取经济事项
  getEconomicsEvent({ commit, rootState }, param) {
    return http.request({
      url: api.getEconomicsEvent,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 申请报销标准
  getStand({ commit, rootState }, param) {
    return http.request({
      url: api.getStand,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 校验费用申请单
  CheckmyApply({ commit, rootState }, param) {
    return http.request({
      url: api.CheckmyApply,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
 // 获取费用申请单单据信息
  myFeeReQuest({ commit, rootState }, param) {
    return http.request({
      url: api.myFeeReQuest,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(rep => rep.data);
  },
// 单据撤回
  myBillBack({ commit, rootState }, param) {
    return http.request({
      url: api.myBillBack,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(rep => rep.data);
  },
// 单据催办
  myReminDers({ commit, rootState }, param) {
    return http.request({
      url: api.myReminDers,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(rep => rep.data);
  },
  submitFeeApply({ commit, rootState }, param) {
    return http.request({
      url: api.submitFeeApply,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(rep => rep.data);
  },
  //  审批节点信息
  getlog({ commit, rootState }, param) {
    return http.request({
      url: api.getlog,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 差旅申请票据
  myFeeOrderQuery({ commit, rootState }, param) {
    return http.request({
      url: api.myFeeOrderQuery,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 删除申请单
  deleteFeeApply({ commit, rootState }, param) {
    return http.request({
      url: api.deleteFeeApply,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  //  差旅申请借款列表
  selectAvaliableFeeApply({ commit, rootState }, param) {
    return http.request({
      url: api.selectAvaliableFeeApply,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  //  差旅申请借款详情信息
  getLoanForApp({ commit, rootState }, param) {
    return http.request({
      url: api.getLoanForApp,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
   //  获取审批单数量
  getApprovalCnt({ commit, rootState }, param) {
    return http.request({
      url: api.getApprovalCnt,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  //  保存借款申请单草稿
  saveLoan({ commit, rootState }, param) {
    return http.request({
      url: api.saveLoan,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 获取我的申请单(新接口)
  pageApplyList({ commit, rootState }, param) {
    return http.request({
      url: api.pageApplyList,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  //  获取住宿费和补助费
  getRentAndAssistant({ commit, rootState }, param) {
    return http.request({
      url: api.getRentAndAssistant,
      baseURL: rootState.baseConfig.baseUrl,
      data: param,
    }).then(res => res.data);
  },
  //  获取流程表格
  getFlowTable({ commit, rootState }, param) {
    return http.request({
      url: api.getFlowTable,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  //  获取可操作列表
  getCanHandleList({ commit, rootState }, param) {
    return http.request({
      url: api.getCanHandleList,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 校验借款申请单
  checkLoan({ commit, rootState }, param) {
    return http.request({
      url: api.checkLoan,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
  // 删除借款申请单
  deleteLoan({ commit, rootState }, param) {
    return http.request({
      url: api.deleteLoan,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(res => res.data);
  },
};

export default actions;

