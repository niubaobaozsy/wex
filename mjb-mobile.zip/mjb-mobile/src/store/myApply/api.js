const api = {
  getTravelTypeById: 'smart-expense-web/ea/feeApply/queryTravelType',  // 根据申请人id 获取所在OU报销标准的出差类型
  getItemsByCode: 'cdp-docker-web/docker/dictitem/getItemsByCode?code=',  // 获取字典数据
  myFeeOrderQuery: 'smart-expense-web/uc/userCenter/queryMyFeeOrderForApp',    // 我的申请票据
  saveFeeApply: 'smart-expense-web/ea/feeApply/saveFeeApply', // 保存费用申请单
  getlog: 'smart-expense-web/wf/pro/getLog', // 获取审批流程
  getBudgetSource: 'smart-expense-web/bm/EmsBmBudgetNode/getBudgetNode',  // 获得预算来源
  getEconomicsEvent: 'smart-expense-web/bm/EmsBmBudgetNode/getFeeType', // 获得经济事务
  CheckmyApply: 'smart-expense-web/ea/feeApply/checkFeeApply', // 校验费用申请单
  getApprovalCnt: 'smart-expense-web/uc/userCenter/myFeeOrderNumberForApp', // 获取审批单数量
  myFeeReQuest: 'smart-expense-web/ea/feeApply/getFeeApplyById', // 获取费用申请单单据信息
  myBillBack: 'smart-expense-web/wf/process/drafter',  // 单据撤回接口
  myReminDers: 'smart-expense-web/wf/process/press',   // 单据催办
  getStand: 'smart-expense-web/ea/feeApply/selectRentAndAssistant', // 获取报销标准
  deleteFeeApply: 'smart-expense-web/ea/feeApply/deleteFeeApply',     // 删除费用申请单
  submitFeeApply: 'smart-expense-web/wf/process/submit',  // 申请单提交接口
  getFormTemplates: 'smart-expense-web/cm/formTemplate/getFormTemplates',  // 获取表单模版信息
  selectAvaliableFeeApply: 'smart-expense-web/ea/feeApply/selectAvaliableFeeApply',  // 获取差旅申请借款列表
  getLoanForApp: 'smart-expense-web/lm/loan/getLoanForApp',  // 查看借款单详情信息
  saveLoan: 'smart-expense-web/lm/loan/saveLoan', // 保存借款申请单草稿
  pageApplyList: 'smart-expense-web/ea/feeApply/pageApplyList', // 我的申请单(新接口)
  getFlowTable: 'smart-expense-web/wf/process/flowt', // 获取流程表格
  getCanHandleList: 'smart-expense-web/wf/process/oplist', // 获取可操作列表
  checkLoan: 'smart-expense-web/lm/loan/checkLoan', // 校验借款申请单
  deleteLoan: 'smart-expense-web/lm/loan/deleteLoan', // 借款单删除
  releaseBudget: 'smart-expense-web/ea/feeApply/updateFeeApplyToRelease', // 释放预算
};

module.exports = {
  api,
};
