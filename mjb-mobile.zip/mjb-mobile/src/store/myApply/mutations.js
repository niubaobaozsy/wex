const mutations = {
  MY_APPLY: (state, data) => {
    state.detailMessage = data.detailMessage;
    state.emseaapplyh = data.emseaapplyh;
    state.checkResult = data.checkResult;
    state.applyCreate = data.applyCreate;
    state.companyName = data.companyName;
    state.enclosureList = data.enclosureList;
    state.emslmloan = data.emslmloan;
    // state.getStandardReqParam = data.getStandardReqParam;
    state.feeStdExp = data.feeStdExp;
    state.overStdExp = data.overStdExp;
    state.travelTypeList = data.travelTypeList;
  },

  // 出差类型下拉数据保存
  TRAVEL_TYPE_LIST: (state, data) => {
    state.travelTypeList = data;
  },

  // 获得默认信息
  DETAIL_MESSAGE: (state, data) => {
    state.detailMessage = data;
  },
  EMSEAAPPLYH: (state, data) => {
    state.emseaapplyh = data;
  },
  CHECK_RESULT: (state, data) => {
    state.checkResult = data;
  },
  APPLY_CREATE: (state, obj) => {
    state.applyCreate = Object.assign(state.applyCreate, obj);
  },
  EMSLMLOAN: (state, obj) => {
    state.emslmloan = obj;
  },
  LOANOBJ: (state, obj) => {
    state.loanObj = obj;
  },
  APPLYALIST: (state, obj) => {
    state.applyaList = obj;
  },
  FLOWNODE: (state, obj) => {
    state.flowNode = obj;
  },
  // GET_STANDARD_REQ_PARAM: (state, obj) => {
  //   state.getStandardReqParam = Object.assign(state.getStandardReqParam, obj);
  // },
  FEE_STD_EXP: (state, obj) => {
    state.feeStdExp = obj;
  },
  OVER_STD_EXP: (state, obj) => {
    state.overStdExp = obj;
  },
  CHANGE_CHECKBOXSTATUS:(state) => {
    state.checkboxStatus = true;
  },
  REC_CHECKBOXSTATUS:(state) => {
    state.checkboxStatus = false;
  }

};

export default mutations;
