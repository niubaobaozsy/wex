const mutations = {
  SIGNATURE: (state, msg) => {
    state.signature = msg;
  },
  DEFCFG: (state, obj) => {
    state.defCfg = obj;
  },
};

export default mutations;
