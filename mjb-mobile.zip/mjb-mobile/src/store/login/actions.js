import axios from 'axios';
import http from '../http';
import { api } from './api';

const actions = {
  getBaseConfig({ commit }) {
    return http.get({ url: api.getBaseConfig })
      .then((res) => {
        const envConfig = res.data;
        const defaultCfg = envConfig.defaultCfg;
        const currentConfig = {};
        Object.keys(defaultCfg).forEach((item) => {
          if (Object.prototype.toString.call(defaultCfg[item]) !== '[object Object]') {
            currentConfig[item] = defaultCfg[item];
          }
        });
        const advancedSetting = JSON.parse(localStorage.getItem('advancedSetting') || '{}');
        const envName = advancedSetting.env || envConfig.currentEnv;
        Object.assign(currentConfig, envConfig[envName]);
        const isHybridApp = currentConfig.isHybridApp;
        const webAppPlatform = () => {
          const isInWeChat = /(micromessenger|webbrowser)/.test(navigator.userAgent.toLocaleLowerCase());
          if (isInWeChat) {
            return 'wechat';
          } else if (currentConfig.hybridAppPlatform) {
            return currentConfig.hybridAppPlatform;
          }
          return 'normal';
        };
        currentConfig.isHybridApp = isHybridApp;
        currentConfig.platform = currentConfig.hybridAppPlatform;
        currentConfig.isWebApp = !isHybridApp;
        if (!isHybridApp) currentConfig.platform = webAppPlatform();
        const platformConfig = defaultCfg[currentConfig.platform] || {};
        Object.assign(platformConfig, currentConfig);
        Object.assign(currentConfig, platformConfig);
        if (currentConfig.platform === 'wechat') {
          const wechatRedirectUri = encodeURIComponent(`${location.origin}${location.pathname}`);
          currentConfig.wechatOAuthUrl = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${currentConfig.appid}&redirect_uri=${wechatRedirectUri}&response_type=code&scope=${currentConfig.wechatScope}&agentid=${currentConfig.wechatAgentid}&state=${currentConfig.wechatState}#wechat_redirect`;
        }
        currentConfig.envName = envName;
        currentConfig.envConfig = envConfig;
        if (advancedSetting.menuConfig) currentConfig.menuConfig = advancedSetting.menuConfig;
        commit('BASECONFIG', currentConfig);
        console.log(currentConfig);
      });
  },
  /**
   * 获取菜单配置信息
   */
  getMenuConfig({ commit }, param) {
    return http.get({ url: `${api.getMenuConfig}${param}.json`, baseURL: './' })
      .then((res) => {
        commit('MENUCONFIG', res.data);
      });
  },
  /**
  * code换取Token
  */
  getToken({ commit, rootState }, param) {
    return http.request({
      url: api.getToken,
      baseURL: rootState.baseConfig.baseUrl,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        const token = rep.headers['x-auth-token'] || '';
        const userInfo = {};
        userInfo.user = rep.data.data;
        commit('ROOT_LOGIN', token);
        commit('USERINFO', userInfo);
        localStorage.setItem('token', token);
        localStorage.setItem('userInfo', JSON.stringify(userInfo));
      }
      return rep.data;
    })());
  },
  // 本地登录
  localLogin({ commit, dispathc, state, rootState }, param) {
    const loginType = param.loginType || 'localLogin';
    delete param.loginType;
    if (loginType === 'customLogin') {
      param.tenantId = param.tenant_id;
      delete param.tenant_id;
    }
    return http.request({
      url: api[loginType],
      baseURL: rootState.baseConfig.baseUrlCdp,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        const token = rep.headers['x-auth-token'] || '';
        const userInfo = rep.data.data;
        commit('ROOT_LOGIN', token);
        commit('USERINFO', userInfo);
        localStorage.setItem('token', token);
        localStorage.setItem('userInfo', JSON.stringify(userInfo));
      }
      return rep.data;
    })());
  },
  // 慧消费环境本地登录
  smartBuyLocalLogin({ commit, dispathc, state, rootState }, param) {
    return http.request({
      url: api.localLogin,
      baseURL: rootState.baseConfig.smartBuyCdp,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        const token = rep.headers['x-auth-token'] || '';
        const userInfo = rep.data.data;
        commit('SMART_BUY_LOGIN', token);
        commit('SMART_BUY_USERINFO', userInfo);
        localStorage.setItem('smartBuyToken', token);
        localStorage.setItem('smartBuyUserInfo', JSON.stringify(userInfo));
      }
      return rep.data;
    })());
  },
  // SSOTOKEN 换取 x-auth-token
  switchToken({ rootState }, param) {
    return axios({
      url: api.switchToken,
      baseURL: rootState.baseConfig.masUrl,
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
      },
      params: param || {},
    }).then(rep => (() => {
      if (rep && rep.data) {
        return rep.data;
      }
      return false;
    })());
  },
  // 设备登陆
  deviceLogin({ commit, rootState }, param) {
    return http.request({
      url: api.deviceLogin,
      baseURL: rootState.baseConfig.baseUrlCdp,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        const token = rep.headers['x-auth-token'] || '';
        const userInfo = rep.data.data;
        commit('ROOT_LOGIN', token);
        commit('USERINFO', userInfo);
        localStorage.setItem('token', token);
        localStorage.setItem('userInfo', JSON.stringify(userInfo));
      }
      return rep.data;
    })());
  },
  // 慧消费环境设备登陆
  smartBuyDeviceLogin({ commit, rootState }, param) {
    return http.request({
      url: api.deviceLogin,
      baseURL: rootState.baseConfig.smartBuyCdp,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        const token = rep.headers['x-auth-token'] || '';
        const userInfo = rep.data.data;
        commit('SMART_BUY_LOGIN', token);
        commit('SMART_BUY_USERINFO', userInfo);
        localStorage.setItem('smartBuyToken', token);
        localStorage.setItem('smartBuyUserInfo', JSON.stringify(userInfo));
      }
      return rep.data;
    })());
  },
  /**
  * 获取使用JS-SDK的验证签名
  */
  getWxSign({ commit, rootState }, param) {
    return http.request({
      url: api.signature,
      baseURL: rootState.baseConfig.baseUrl,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        const signature = rep.data.data;
        commit('SIGNATURE', signature);
      }
      return rep.data;
    })());
  },
  /**
  * 多租户用户选择对应租户ID
  */
  tenant({ commit, rootState }, param) {
    return http.request({
      url: api.tenant,
      baseURL: rootState.baseConfig.baseUrlCdp,
      data: param,
    }).then(rep => (() => {
      if (rep.data.code === '0000') {
        const userInfo = rep.data.data;
        commit('USERINFO', userInfo);
        localStorage.setItem('userInfo', JSON.stringify(userInfo));
      }
    })());
  },
  /**
  * 获取组织及人员
  */
  getOrgUsers({ commit, rootState }, param) {
    return http.get({
      url: api.queryOrgUsersByOrgId,
      baseURL: rootState.baseConfig.baseUrlCdp,
      data: param,
    }).then(rep => (() => {
      if (rep && rep.data) {
        return rep.data;
      }
      return false;
    })());
  },
  /**
  * 查询人员信息
  */
  queryUsersByName({ commit, rootState }, param) {
    return http.request({
      url: api.queryUsersByName,
      baseURL: rootState.baseConfig.baseUrlCdp,
      data: param,
    }).then(rep => (() => {
      if (rep && rep.data) {
        return rep.data;
      }
      return false;
    })());
  },

  /**
  * 获取常用预算部门列表
  */
  getDefaultConfig({ commit, rootState }) {
    return http.get({
      url: api.getDefaultConfig,
      baseURL: rootState.baseConfig.baseUrlDocker,
    }).then(rep => (() => {
      if (rep && rep.data && rep.data.code === '0000') {
        commit('DEFCFG', rep.data.data);
        return rep.data;
      }
      return false;
    })());
  },
  /**
  * 获取预算部门
  */
  getBusiOrg({ commit, rootState }, param) {
    return http.post({
      url: api.getBusiOrg,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(rep => (() => {
      if (rep && rep.data) {
        return rep.data;
      }
      return false;
    })());
  },

  /**
  * 选择入账单位
  */
  getCompany({ commit, rootState }, param) {
    return http.request({
      url: api.getCompany,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(rep => (() => {
      if (rep && rep.data) {
        return rep.data;
      }
      return false;
    })());
  },
  /**
  * 获取收款方列表
  */
  getReceiver({ commit, rootState }, param) {
    return http.request({
      url: api.getReceiver,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(rep => (() => {
      if (rep && rep.data) {
        return rep.data;
      }
      return false;
    })());
  },
  /**
  * 获取预算主体
  */
  getSbjuct({ commit, rootState }, param) {
    return http.request({
      url: api.getSbjuct,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(rep => (() => {
      if (rep && rep.data) {
        return rep.data;
      }
      return false;
    })());
  },
  // 获取预算树
  getBudent({ commit, rootState }, param) {
    return http.request({
      url: api.getBudent,
      baseURL: rootState.baseConfig.baseUrlExpense,
      data: param,
    }).then(rep => (() => {
      if (rep && rep.data) {
        return rep.data;
      }
      return false;
    })());
  },
  // 设置默认
  savaDefaultConfig({ commit, rootState }, param) {
    return http.request({
      url: api.savaDefaultConfig,
      baseURL: rootState.baseConfig.baseUrlDocker,
      data: param,
    }).then(rep => (() => {
      if (rep && rep.data) {
        return rep.data;
      }
      return false;
    })());
  },
};

export default actions;
