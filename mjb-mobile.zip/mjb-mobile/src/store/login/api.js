const api = {
  getBaseConfig: './EnvConfig.json',
  getMenuConfig: 'static/menuConfig/',
  getToken: 'jiebao-wechat/wechat/login', // 登陆
  tenant: 'cdp-docker-web/login/tenant', // 获取租户ID
  signature: 'jiebao-wechat/wechat/signature', // 获取使用JS-SDK的验证签名
  login: 'cdp-docker-web/login', // 模拟登陆
  switchToken: 'mas-api/proxy', // SSOTOKEN 换取 x-auth-token
  deviceLogin: 'cdp-docker-web/login/msg/login', // 设备登陆
  localLogin: 'cdp-docker-web/local/login', // 本地登录
  customLogin: 'cdp-docker-web/customLogin', // 用户定制登录统一接口
  queryOrgUsersByOrgId: 'cdp-docker-web/docker/tenantorg/queryOrgUsersByOrgId', // 获取组织及人员
  getUsersByOrgId: 'cdp-docker-web/docker/tenantorg/getUsersByOrgId', // 获取组织及人员(new)
  queryUsersByName: 'cdp-docker-web/docker/userinfo/queryUserListByNamePost', // 查询人员信息
  getBusiOrg: 'jiebao-docker-web/docker/busiorg/ys/select', // 获取预算部门
  getDefaultConfig: 'jiebao-docker-web/cm/userCenter/getDefaultConfig', // 常用预算部门列表
  getCompany: 'jiebao-docker-web/docker/company/select', // 选择入账单位
  getReceiver: 'jiebao-docker-web/cm/userCenter/listReceiver', // 获取收款方列表
  getSbjuct: 'jiebao-docker-web/docker/busiorg/queryMain', // 获取预算主体
  getBudent: 'smart-expense-web/bm/EmsBmBudgetH/pageQuery', // 获取预算树
  savaDefaultConfig: 'jiebao-docker-web/cm/userCenter/saveDefaultConfig', // 设置默认信息
};

module.exports = {
  api,
};
