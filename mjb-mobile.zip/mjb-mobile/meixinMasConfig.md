# 峰报2.0 美信man/mas配置说明
- 模块名称：峰报2.0
- 模块标识：com.midea.msd.meijiebao

RESTful接口代码 | 生产环境接口地址 | 接口描述
---|--- | ---
mjbCdp | http://j.infore.com | 美捷报2.0cdp地址
mjbExpense | http://j.infore.com | 美捷报2.0报销应用地址
mjbDocker | http://j.infore.com | 美捷报2.0jiebao-docker地址
mjbSdatt | http://j.infore.com | 美捷报2.0账柜应用地址
mjbCar | http://j.infore.com | 美捷报2.0商旅用车应用地址
mjbPlane | http://j.infore.com | 美捷报2.0商旅机票应用地址
mjbActive | http://j.infore.com | 美捷报2.0我的足迹应用地址
mjbReport | http://j.infore.com | 美捷报2.0报表应用地址
