# mjb-mobile

> 美捷报移动版2.0

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report

# run unit tests
npm run unit

# run e2e tests
npm run e2e

# run all tests
npm test
```
## 建议
* 开发工具建议使用 Visual Studio Code，并安装 EditorConfig for VS Code 和 Vetur 插件
* 公共组件的样式直接写到Vue文件里，不需要单独抽离出来，页面的样式可以根据需要抽离到单独的文件中
* 文件夹和文件的命名采用小驼峰

## 部分中英文对照
- 费用：fee
 - 我的报销：myReimburse
 - 我的申请：myApply
 - 消费记录：record
 - 票夹：invoice
 - 审批：approve
- 商旅：bizTrip
 - 行程预定：travel
  - 滴滴打车：didi
  - 神州租车：szzc
  - 火车：train
  - 飞机：plane
  - 京东：mall
 - 最近订单：tripOrder
- 报表：reports
 - 报销统计：reimburseReports
 - 预算统计：budgetReports
- 我的：mine
 - 个人消息：profile

## 缩略语对照
- 审批单据类型
 - EA: expense apply 费用申请
 - EC：expense claim 费用报销
 - CA：checking apply 调账申请
 - LM：loan 借款
 - PA：payment apply 付款申请
 - BAD：bugdet adjustment 预算调整

## 开发规范
- 功能定制需要坚持的原则
  - 不通过拉分支来实现定制化需求，就算万不得已需要拉分支解决，也要给出能够将分支回收的方案
  - 定制功能通过配置来实现，配置项粒度不能太小，需要从业务和需求的视角来设计，因此定制方案需要开发人员和产品经理一起协商设计
- 目前已有的定制能力（具体细节待补充）
  - 菜单定制
  - 皮肤定制
  - 平台定制
  - 打包定制
  - 业务定制

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
