# mei_aps

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

Date组件
属性require，Boolen类型，表示为必填项项，会有红色*号，默认没有；
属性isOne，Boolen类型，表示是否只有一个日期选择，默认为两个；
属性text，String类型，表示组件的左侧字符，默认“需求日期”；
属性type，String类型，日期种类，默认date,可选择date,time,datetime,year-month
showValue事件，确认选择时触发，返回值为对象，如{type: 'start/end', value: '当前选择的日期字符串'}，当有两个日期选择是，第一个类型为start，第二个为end；只有一个是类型为start，可以直接获取value值

NavBarSelect组件
属性绑定options，Array类型，数组中可包含对象{text: ***, value: ***},显示为text，选中返回值为value；直接为数组的话text和value都是同一个，
双向绑定获取值v-model,绑定时需要给一个默认值

CodeSearch组件
如果为必须输入选项，添加属性require
通过属性url绑定:url来传递搜索页面的请求接口连接
通过属性text输入组件左侧字符
通过属性type来控制搜索的类型，type取值material，plan，line分别为物料搜索，计划组和线体搜索
通过事件getCodeData来获取值，返回值为当前选择值

Picker组件
属性require，表示为必填项，会有红色*号，默认没有；
属性text，组件左侧字符，String类型，默认为空；
属性绑定pickValueList，Array类型，可选择的所有项的集合，默认为空；
事件getPickValue,获取当前选择的值，返回值为当前选择的值
