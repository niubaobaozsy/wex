<template>
  <div>
    <div class="material-code common-list-style" @click="toSearch">
      <span class="common-font-style">{{title}}<em v-if="isRequire">*</em></span>
      <span class="code">{{code}}</span>
      <span><van-icon name="arrow" size="20px"></van-icon></span>
    </div>
    <van-popup position="right" v-model="showSearchPage">
      <van-nav-bar left-arrow fixed @click-left="backToPage" right-text="搜索" @click-right="getSearchData">
        <form action="/" slot="title">
          <van-search v-model="keyword" placeholder="请输入内容搜索" background="#393A4C" @search="getSearchData"></van-search>
        </form>
      </van-nav-bar>
      <div style="padding-top: 46px; width: 100vw; height: 100vh; overflow: scroll; background-color: #313244">
        <div class="search-total">搜索结果({{total}})</div>
        <ul v-if="this.$attrs.type === 'material'">
          <li class="material-code-item" v-for="(item, index) in materialList" :key="index" @click="sendCodeToParentComponent(item)">
            <div class="material-code-number">{{item.materialCodeNumber}}</div>
            <div class="material-code-desc">{{item.materialCodeDesc}}</div>
          </li>
        </ul>
        <ul v-if="this.$attrs.type === 'plan'">
          <li class="plan-group-item" v-for="(item, index) in planList" :key="index" @click="sendCodeToParentComponent(item)">{{item.planGroup}}</li>
        </ul>
        <ul v-if="this.$attrs.type === 'line'">
          <li class="line-code-item" v-for="(item, index) in lineList" :key="index" @click="sendCodeToParentComponent(item)">{{item.lineBody}}</li>
        </ul>
      </div>
    </van-popup>
  </div>
</template>

<script>
  import * as methods from './module'
  export default {
      name: 'MaterialCode',
      data () {
          return {
            code: '',
            isRequire: false,
            title: '',
            showSearchPage: false,
            keyword: '',
            total: 6,
            materialList: [
              {
                materialCodeNumber: '11303125000074',
                materialCodeDesc: '十字槽盘头防松自攻螺钉 RoHS GBT845 ST3.9*10-C-H 1022A 无铬达克罗,三级 热处理'
              },
              {
                materialCodeNumber: '11303758934738',
                materialCodeDesc: '十字槽盘头防松自攻螺钉 RoHS GBT845 ST3.9*10-C-H 1022A 无铬达克罗,三级 热处理'
              },
              {
                materialCodeNumber: '11303182745153',
                materialCodeDesc: '十字槽盘头防松自攻螺钉 RoHS GBT845 ST3.9*10-C-H 1022A 无铬达克罗,三级 热处理'
              },{
                materialCodeNumber: '12235548830074',
                materialCodeDesc: '十字槽盘头防松自攻螺钉 RoHS GBT845 ST3.9*10-C-H 1022A 无铬达克罗,三级 热处理'
              },
              {
                materialCodeNumber: '11303125000074',
                materialCodeDesc: '十字槽盘头防松自攻螺钉 RoHS GBT845 ST3.9*10-C-H 1022A 无铬达克罗,三级 热处理'
              }
            ],
            planList: [
              { planGroup: '外协01-M50' },
              { planGroup: '总装01-M50' },
              { planGroup: '总装02-M50' },
              { planGroup: '注塑01-M50' },
              { planGroup: '钣金01-M50' }
            ],
            lineList: [
              { lineBody: 'PZSADN' },
              { lineBody: 'PZSADN' },
              { lineBody: 'PZSADN' },
              { lineBody: 'PZSADN' },
              { lineBody: 'PZSADN' }
            ]
          }
      },
      props: {
          url: String
      },
      created() {
          if(this.$attrs.hasOwnProperty('require')){
            this.isRequire = true;
          }
          this.title = this.$attrs.text;
      },
      methods
  }
</script>

<style>
  /*.van-cell{*/
    /*background-color: #f2f2f2 !important;*/
  /*}*/
  .van-nav-bar__title{
    max-width: 75% !important;
  }
</style>
<style lang="scss" scoped>
  @import "codeSearch";
</style>
