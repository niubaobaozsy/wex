import CodeSearch from './CodeSearch.vue'

export default CodeSearch
