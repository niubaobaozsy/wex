export function toSearch() {
  this.showSearchPage = true;
}
export function backToPage() {
  this.keyword = '';
  this.showSearchPage = false;
}

export function getSearchData() {
  console.log(this.url);
}

export function sendCodeToParentComponent(item) {
  switch (this.$attrs.type){
    case 'material':
      this.code = item.materialCodeNumber;
      this.$emit('getCodeData', item.materialCodeNumber);
      break;
    case 'plan':
      this.code = item.planGroup;
      this.$emit('getCodeData', item.planGroup);
      break;
    case 'line':
      this.code = item.lineBody;
      this.$emit('getCodeData', item.lineBody);
      break;
  }
  this.showSearchPage = false;
}
