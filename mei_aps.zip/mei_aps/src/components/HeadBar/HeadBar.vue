<template>
  <div>
    <van-nav-bar left-arrow fixed left-text="返回" @click-left="back" :title="barTitle">
      <slot slot="right"></slot>
    </van-nav-bar>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'HeadBar',
      props: {
          title: String
      },
      data() {
          return{
            barTitle: ''
          }
      },
      created() {
          this.barTitle = this.title;
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "headBar.scss";
</style>
