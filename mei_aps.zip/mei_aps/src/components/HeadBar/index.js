import HeadBar from './HeadBar.vue'

export default HeadBar
