import Picker from './Picker.vue'

export default Picker
