<template>
  <div>
    <div class="picker common-list-style" @click="showPickerPopup">
      <span class="common-font-style">{{text}}<em v-if="isRequire">*</em></span>
      <span class="code">{{pickValue}}</span>
    </div>
    <van-popup position="bottom" v-model="showPicker">
      <van-picker show-toolbar :visible-item-count="visibleTypeCount" :columns="values" @cancel="closePickerPopup" @confirm="selectPickerValue"></van-picker>
    </van-popup>
  </div>
</template>

<script>
  import * as methods from './module'
  export default {
      name: 'Picker',
      props: {
          pickValueList: Array
      },
      data() {
          return {
              isRequire: false,
              text: '',
              pickValue: this.pickValueList[0],
              showPicker: false,
              visibleTypeCount: 4,
              values: []
          }
      },
      created() {
          this.text = this.$attrs.text;
          if(this.$attrs.hasOwnProperty('require')){
              this.isRequire = true;
          }
          this.values = this.pickValueList;
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "picker";
</style>
