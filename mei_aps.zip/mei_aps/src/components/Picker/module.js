export function showPickerPopup() {
  this.showPicker = true;
}

export function closePickerPopup() {
  this.showPicker = false;
}

export function selectPickerValue(value, index) {
  this.pickValue = value;
  this.$emit('getPickValue', value)
  this.showPicker = false;
}
