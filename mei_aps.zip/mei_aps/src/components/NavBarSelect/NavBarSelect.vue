<template>
  <div>
    <div class="text-color" :value="value" @click="showSelectPopup">{{value}}</div>
    <van-popup position="bottom" v-model="showSelect">
      <van-picker show-toolbar :visible-item-count="visibleItemCount" :columns="options" @cancel="closeSelectPopup" @confirm="selectOption"></van-picker>
    </van-popup>
  </div>
</template>

<script>
  import * as methods from './module'
  export default {
      name: 'NavBarSelect',
      props: {
          options: Array,
          value: String,
      },
      data () {
          return {
              showSelect: false,
              visibleItemCount: 4
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "navBarSelect";
</style>
