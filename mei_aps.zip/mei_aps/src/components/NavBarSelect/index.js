import NavBarSelect from './NavBarSelect.vue'

export default NavBarSelect
