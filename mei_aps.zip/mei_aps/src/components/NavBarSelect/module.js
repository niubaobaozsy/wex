export function showSelectPopup() {
  this.showSelect = true;
}

export function closeSelectPopup() {
  this.showSelect = false;
}

export function selectOption(data) {
  if(typeof data === 'object'){
    this.$emit('input', data.value);
  }else{
    this.$emit('input', data);
  }
  this.showSelect = false;
}
