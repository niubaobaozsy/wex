<template>
  <div>
    <div class="text-color" @click="showSelectPopup">{{rightText}}</div>
    <van-popup position="bottom" v-model="showSelect">
      <van-picker show-toolbar :visible-item-count="visibleItemCount" :columns="columns" @cancel="closeSelectPopup" @confirm="selectOption"></van-picker>
    </van-popup>
  </div>
</template>

<script>
  import * as methods from './module'
  export default {
      name: 'SelectOptions',
      props: {
          options: Array
      },
      data () {
          return {
              rightText: '',
              showSelect: false,
              columns: [],
              visibleItemCount: 4
          }
      },
      created() {
          this.columns = this.options;
          this.rightText = this.$attrs.text;
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "selectOptions";
</style>
