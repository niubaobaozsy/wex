export function showSelectPopup() {
  this.showSelect = true;
}

export function closeSelectPopup() {
  this.showSelect = false;
}

export function selectOption(data) {
  if(typeof data === 'object'){
    this.rightText = data.value;
    this.$emit('getSelectedOption', data.value);
  }else{
    this.rightText = data;
    this.$emit('getSelectedOption', data);
  }
  this.showSelect = false;
}
