import SelectOptions from './SelectOptions.vue'

export default SelectOptions
