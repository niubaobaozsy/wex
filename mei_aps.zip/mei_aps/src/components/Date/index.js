import Date from './Date.vue'

export default Date
