export function formatter(type, value) {
  if (type === 'year') {
    return `${value}年`;
  } else if (type === 'month') {
    return `${value}月`
  } else if (type === 'day') {
    return `${value}日`
  }
  return value;
}

export function showPopup(item) {
  if(item === 'start'){
    this.sdShow = true;
  }else{
    this.edShow = true;
  }
}

export function formatDate(time) {
  var date = time == ''? new Date() : time;
  var year = date.getFullYear();
  var month = (date.getMonth() + 1) < 10? `0${date.getMonth() + 1}` : date.getMonth() + 1;
  var day = date.getDate() < 10? `0${date.getDate()}` : date.getDate();
  return `${year}/${month}/${day}`;
}

export function closePopup(item) {
  if(item === 'start'){
    this.sdShow = false;
  }else{
    this.edShow = false;
  }
}

export function setStartDate(value) {
  if(!this.$attrs.hasOwnProperty('isOne')){
    if(this.compareDate(this.formatDate(value), this.endDate) > 0){
      this.$toast('开始时间不能大于结束时间！');
      return;
    }
  }
  this.startDate = this.formatDate(value);
  this.sdShow = false;
  let data = {
    type: 'start',
    value: this.startDate
  }
  this.$emit('showValue', data);
}

export function setEndDate(value) {
  if(this.compareDate(this.startDate, this.formatDate(value)) > 0){
    this.$toast('开始时间不能大于结束时间！');
  }else{
    this.endDate = this.formatDate(value);
    this.edShow = false;
    let data = {
      type: 'end',
      value: this.endDate
    }
    this.$emit('showValue', data);
  }
}

export function compareDate(a, b) {
  if(new Date(a) > new Date(b)){
    return 1;
  }else if(new Date(a) < new Date(b)){
    return -1;
  }else{
    return 0;
  }
}
