<template>
  <div class="demand-date common-list-style">
    <span class="common-font-style">{{text}}<em v-if="isRequired">*</em></span>
    <van-popup v-model="sdShow" position="bottom">
      <van-datetime-picker v-model="sd" :type="dateType" :formatter="formatter" @cancel="closePopup('start')" @confirm="setStartDate"></van-datetime-picker>
    </van-popup>
    <span @click="showPopup('start')" style="text-align: center; width: calc((100vw - 110px)/2)">{{startDate}}</span>
    <van-popup v-if="isOne" v-model="edShow" position="bottom">
      <van-datetime-picker v-model="ed" :type="dateType" :formatter="formatter" @cancel="closePopup('end')" @confirm="setEndDate"></van-datetime-picker>
    </van-popup>
    <span v-if="isOne" @click="showPopup('end')" style="text-align: center; width: calc((100vw - 110px)/2)">{{endDate}}</span>
  </div>
</template>

<script>
  import * as methods from './module'
  export default {
    name: 'Date',
    data () {
        return {
          sd: new Date(),
          ed: new Date(),
          startDate: this.formatDate(''),
          endDate: this.formatDate(''),
          sdShow: false,
          edShow: false,
          text: '需求日期',
          isRequired: false,
          dateType: 'date',
          isOne: true
        }
    },
    created () {
        if(this.$attrs.text){
            this.text = this.$attrs.text
        }
        if(this.$attrs.type){
            this.dateType = this.$attrs.type;
        }
        if(this.$attrs.hasOwnProperty('require')){
            this.isRequired = true;
        }
        if(this.$attrs.hasOwnProperty('isOne')){
            this.isOne = false
        }
    },
    mounted () {

    },
    methods
  }
</script>

<style lang="scss" scoped>
  @import "./date";
</style>
