import Vue from 'vue'
import Vuex from 'vuex'
import mutations from './mutations'

Vue.use(Vuex)

const demandInterfaceInfo = {
  mterialCode: '',
  startDate: '',
  endDate: '',
  orderType: ''
}
const demandWorkbenchInfo = {
  marerialCode: '',
  orderNum: '',
  startDate: '',
  endDate: '',
  demandFrom: '',
  demandState: ''
}

const orderPerspectiveTrackingTabRecord = {
  jobPath: '',
  orderPath: '',
  queryPath: '',
  cyclePath: '',
  jobCurrent: true,
  orderCurrent: false,
  queryCurrent: false,
  cycleCurrrent: false
}

const state = {
  demandInterfaceInfo,
  demandWorkbenchInfo,
  list: [],
  workshopScheduleListTightText: '',
  backToHomeCount: 0,
  orderPerspectiveTrackingTabRecord
}

export default new Vuex.Store({
  state,
  mutations
})
