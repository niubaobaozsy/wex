import {
  DEMAND_INTERFACE_INFO,
  DEMAND_WORKBENCH_INFO,
  LIST,
  WORKSHOP_SCHEDULE_LIST_RIGHT_TEXT,
  BACK_TO_HOME_COUNT,
  RESET_BACK_TO_HOME_COUNT,
  ORDER_PERSPECTIVE_TRACKING_TAB_RECORD
} from './mutation-types'

const mutations = {
  [DEMAND_INTERFACE_INFO](state, demandInterfaceInfo) {
    state.demandInterfaceInfo = demandInterfaceInfo;
  },
  [DEMAND_WORKBENCH_INFO](state, demandWorkbenchInfo) {
    state.demandWorkbenchInfo = demandWorkbenchInfo;
  },
  [LIST](state, list){
    state.list = list;
  },
  [WORKSHOP_SCHEDULE_LIST_RIGHT_TEXT](state, resourceCode) {
    state.workshopScheduleListTightText = resourceCode;
  },
  [BACK_TO_HOME_COUNT](state){
    state.backToHomeCount++;
  },
  [RESET_BACK_TO_HOME_COUNT](state){
    state.backToHomeCount = 0
  },
  [ORDER_PERSPECTIVE_TRACKING_TAB_RECORD](state, obj) {
    state.orderPerspectiveTrackingTabRecord = obj;
  }
}

export default mutations
