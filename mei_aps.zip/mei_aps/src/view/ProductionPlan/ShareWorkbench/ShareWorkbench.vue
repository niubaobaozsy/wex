<template>
  <div style="padding: 47px 0 45px">
    <van-nav-bar left-arrow fixed title="共享件工作台查询" left-text="返回" @click-left="backToHome">
      <select-options text="M01" :options="options" @getSelectedOption="getFactoryCode" slot="right"></select-options>
    </van-nav-bar>
    <code-search require text="物料编码" :url="mUrl" type="material" @getCodeData="getMaterialCode"></code-search>
    <date require text="日期区间" @showValue="getDateData"></date>
    <div class="state common-list-style">
      <span class="common-font-style">状态<em>*</em></span>
      <span class="code"><input type="text" placeholder="请输入状态" v-model="state"></span>
    </div>
    <code-search require text="计划组" :url="pUrl" type="plan" @getCodeData="getPlanGroup"></code-search>
    <div class="query-button">
      <van-button type="primary" class="self-button-style" @click="toShareWorkbenchList">查询</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  import SelectOptions from '../../../components/SelectOptions'
  import CodeSearch from '../../../components/CodeSearch'
  import Date from '../../../components/Date'
  export default{
      name: 'ShareWorkbench',
      components: { SelectOptions, CodeSearch, Date },
      data() {
          return{
              options: [
                  {text: 'M01顺德工厂', value: 'M01'},
                  {text: 'M04芜湖工厂', value: 'M04'},
                  {text: 'M09南沙工厂', value: 'M09'}
              ],
              mUrl: '',
              materialCode: '',
              startDate: this.$common.formatDate(''),
              endDate: this.$common.formatDate(''),
              state: '',
              pUrl: '',
              planGroup: ''
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "shareWorkbench.scss";
</style>
