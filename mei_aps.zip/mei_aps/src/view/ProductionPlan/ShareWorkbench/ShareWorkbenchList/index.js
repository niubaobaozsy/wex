import ShareWorkbenchList from './ShareWorkbenchList.vue'

export default ShareWorkbenchList
