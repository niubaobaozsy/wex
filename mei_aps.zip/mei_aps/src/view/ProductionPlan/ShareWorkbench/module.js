export function backToHome() {
  this.$router.go(-1);
}

export function getFactoryCode(value) {
  console.log(value);
}

export function getMaterialCode(value) {
  this.materialCode = value;
}

export function getDateData(data) {
  if(data.type === 'start'){
    this.startDate = data.value;
  }else{
    this.endDate = data.value;
  }
}

export function getPlanGroup(value) {
  this.planGroup = value;
}

export function toShareWorkbenchList() {
  let data = {
    materialCode: this.materialCode,
    startDate: this.startDate,
    endDate: this.endDate,
    state: this.state,
    planGroup: this.planGroup
  }
  this.$router.push({ name: 'ShareWorkbenchList', params: data });
}
