import ShareWorkbench from './ShareWorkbench.vue'

export default ShareWorkbench
