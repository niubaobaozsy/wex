export function backToShareWorkbenchList() {
  this.$router.go(-1);
}
