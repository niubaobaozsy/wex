import ShareWorkbenchDetail from './ShareWorkbenchDetail.vue'

export default ShareWorkbenchDetail
