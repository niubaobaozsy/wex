import ManualWorkOrder from './ManualWorkOrder.vue'

export default ManualWorkOrder
