<template>
  <div style="padding: 47px 0 45px">
    <van-nav-bar left-arrow fixed left-text="返回" title="新建工单" @click-left="back">
      <nav-bar-select v-model="factoryCode" :options="list" slot="right"></nav-bar-select>
    </van-nav-bar>
  </div>
</template>

<script>
  import * as methods from './module'
  import NavBarSelect from '../../../components/NavBarSelect'
  export default{
      name: 'ManualWorkOrder',
      components: { NavBarSelect },
      data() {
          return{
              factoryCode: 'M01',
              list: [
                  {text: 'M01顺德工厂', value: 'M01'},
                  {text: 'M04芜湖工厂', value: 'M04'},
                  {text: 'M09南沙工厂', value: 'M09'}
              ]
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "manualWorkOrder.scss";
</style>
