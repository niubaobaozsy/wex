<template>
    <div style="padding: 47px 0 0">
      <van-nav-bar left-arrow fixed left-text="返回" title="跟单件详情" @click-left="backToDocumentaryWorkbenchDetailList"></van-nav-bar>
      <div class="order-num item-common">
        <span class="item-title">工单号：</span>
        <span class="item-value">MILPMO-486307011</span>
      </div>
      <div class="material-code item-common">
        <span class="item-title">物料编码：</span>
        <span class="item-value">17170000018546</span>
      </div>
      <div class="material-desc item-common">
        <span class="item-title">物料描述</span>
        <span class="item-value">MI组件 微波炉 ECLAAI4-S3-K(GE)</span>
      </div>
      <div class="state item-common">
        <span class="item-title">工单状态</span>
        <span class="item-value">未下达</span>
      </div>
      <div class="order-count item-common">
        <span class="item-title">工单数量</span>
        <span class="item-value">300</span>
      </div>
      <div class="plan-start-time item-common">
        <span class="item-title">计划开始时间</span>
        <span class="item-value">2018-11-19 16:16:16</span>
      </div>
      <div class="demand-date item-common">
        <span class="item-title">需求日期</span>
        <span class="item-value">2018-11-21</span>
      </div>
      <div class="plan-group item-common">
        <span class="item-title">计划组</span>
        <span class="item-value">FW-MD(US)</span>
      </div>
      <div class="resource item-common">
        <span class="item-title">资源</span>
        <span class="item-value">PZS1ZSA025</span>
      </div>
      <div class="warning-message item-common">
        <span class="item-title">警告信息</span>
        <span class="item-value">残缺BOM、无工艺路线</span>
      </div>
      <div class="final-order item-common">
        <span class="item-title">总装工单</span>
        <span class="item-value">LPMO-48630701</span>
      </div>
      <div class="final-start-time item-common">
        <span class="item-title">总装开始时间</span>
        <span class="item-value">2018-11-21 18:18:18</span>
      </div>
    </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'DocumentaryWorkbenchDetail',
      data() {
          return{

          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "documentaryWorkbenchDetail.scss";
</style>
