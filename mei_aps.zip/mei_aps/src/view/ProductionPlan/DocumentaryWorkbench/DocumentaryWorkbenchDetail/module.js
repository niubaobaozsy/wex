export function backToDocumentaryWorkbenchDetailList() {
  this.$router.go(-1)
}
