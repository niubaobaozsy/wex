import DocumentaryWorkbenchDetail from './DocumentaryWorkbenchDetail.vue'

export default DocumentaryWorkbenchDetail
