export function backToDocumentaryWorkbenchList() {
  this.$router.go(-1);
}

export function preventBubble(e) {
  e.cancelBubble = true;
}

export function onRefresh() {
  setTimeout(() => {
    this.$toast('刷新成功');
    this.downLoading = false;
  }, 500);
}

export function onLoad() {
  let item = {
    num: 'LPMO-47975001',
    status: '未下达',
    desc: '62759-67848101  N 批量整机 商用微波炉 EM025F-S0SA00 ',
    line: 'PZS1ZSA025',
    time: '11-19',
    count: 300
  }
  setTimeout(() => {
    for (let i = 0; i < 5; i++) {
      this.list.push(item);
    }
    // 加载状态结束
    this.upLoading = false;

    // 数据全部加载完成
    if (this.list.length >= 15) {
      this.finished = true;
    }
  }, 500);
}

export function toDetail() {
  this.$router.push({ name: 'DocumentaryWorkbenchDetail' })
}

export function showDialog() {
  if(this.result.length <= 0){
    this.$toast('请先选择需要下达的工单！')
  }else{
    this.show = true;
  }
}

export function beforeClose(action, done) {
  if (action === 'confirm') {
    setTimeout(done, 1000);
    setTimeout(() => {
      this.$toast.success('下达成功！');
      this.result = [];
    },1500)
  } else {
    done();
  }
}
