import DocumentaryWorkbenchDetailList from './DocumentaryWorkbenchDetailList.vue'

export default DocumentaryWorkbenchDetailList
