export function backToHome() {
  this.$router.go(-1)
}

export function getDocumentaryWorkbenchFactoryData(value) {
  console.log(value)
}

export function getMaterialCode(value) {
  this.materialCode = value;
}

export function getDocumentaryDate(data) {
  if(data.type === 'start'){
    this.startDate = data.value;
  }else{
    this.endDate = data.value;
  }
}

export function getPlanGroup(value) {
  this.planGroup = value;
}

export function toDocumentaryWorkbenchList() {
  let data = {
    materialCode: this.materialCode,
    orderNum: this.orderNum,
    startDate: this.startDate,
    endDate: this.endDate,
    state: this.state,
    planGroup: this.planGroup
  }
  this.$router.push({ name: 'DocumentaryWorkbenchList', params: data });
}
