import DocumentaryWorkbench from './DocumentaryWorkbench.vue'

export default DocumentaryWorkbench
