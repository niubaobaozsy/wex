import DocumentaryWorkbenchList from './DocumentaryWorkbenchList.vue'

export default DocumentaryWorkbenchList
