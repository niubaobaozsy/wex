<template>
  <div style="padding: 47px 0 0">
    <van-nav-bar left-arrow fixed left-text="返回" title="消息通知" @click-left="back"></van-nav-bar>
    <van-steps direction="vertical" :active="-1">
      <van-step><p>【2019-3-28 10:20:31】 aps_admin  非洲区域订单（业务员：黄婷）取消了客户订单，数量300套。</p></van-step>
      <van-step><p>【2019-3-28 10:01:31】 aps_admin  欧洲大区新引入订单103张，数量12500套。</p></van-step>
      <van-step><p>【2019-3-28 09:58:49】 luzw 因AB款塑料模具坏，正在检修中，4月1日总装排产全部调整到4月5日生产。</p></van-step>
      <van-step><p>【2019-3-28 09:30:35】 duanyn 计划组：总装01  工单已发放。</p></van-step>
      <van-step><p>【2019-3-28 09:30:00】 aps_admin 运行：PP.共享件下达程序，请求错误。</p></van-step>
    </van-steps>
  </div>
</template>

<script>
  export default{
      name: 'Message',
      data() {
          return{

          }
      },
      methods: {
          back: function () {
            this.$router.go(-1);
          }
      }
  }
</script>

<style lang="scss" scoped>
  .van-steps{
    background-color: #363652;
  }
  .van-step--vertical:not(:last-child)::after{
    border-bottom-width: 0 !important;
  }

</style>
