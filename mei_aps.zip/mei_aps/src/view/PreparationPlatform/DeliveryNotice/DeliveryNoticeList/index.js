import DeliveryNoticeList from './DeliveryNoticeList.vue'

export default DeliveryNoticeList
