<template>
  <div style="padding: 47px 0 45px">
    <van-nav-bar left-arrow fixed left-text="返回" title="送货通知下达列表" @click-left="back"></van-nav-bar>
    <van-pull-refresh v-model="downLoading" @refresh="onRefresh">
      <div class="item-list" style="min-height: calc(100vh - 47px - 45px)">
        <div class="item-card">
          <div>17400302000037</div>
          <div>201601300641电子膨胀阀线圈</div>
        </div>
        <div class="order-total">送货通知建议（{{total}}）</div>
        <van-checkbox-group v-model="result" :max="5">
          <van-list v-model="upLoading" :finished="finished" :offset="offset" finished-text="没有更多了" :error.sync="error" error-text="请求失败，点击重新加载" @load="onLoad">
            <div class="purchase-order-item" v-for="(item, index) in list" :key="index" @click="toDetail(item)">
              <div class="part-one">
                <div>
                  <span>P2Z1W津111804040009015</span>
                  <van-checkbox class="delivery-checkbox" :name="index" @click.native="preventBubble($event)"></van-checkbox>
                </div>
                <div>
                  <span>作业时间：2019-10-10 15:00</span>
                  <span>缺料量：20</span>
                </div>
              </div>
              <div class="part-two">
                <div v-for="(pitem, pindex) in item.lists" :key="pindex">
                  <span>{{pitem.name}}</span>
                  <span>{{pitem.type}}</span>
                  <input type="text" v-model="pitem.num">
                </div>
              </div>
            </div>
          </van-list>
        </van-checkbox-group>
      </div>
    </van-pull-refresh>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="release">下达</van-button>
    </div>
    <van-dialog v-model="show" :message="message" show-cancel-button @cancel="close" @confirm="onConfirm"></van-dialog>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'DeliveryNoticeList',
      data() {
          return{
              result: [],
              total: 2,
              downLoading: false,
              upLoading: false,
              finished: false,
              offset: 1,
              error: false,
              list: [],
              show: false,
              message: '确认下达选定的采购订单吗？'
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "deliveryNoticeList.scss";
</style>
