export function back() {
  this.$router.go(-1)
}

export function onRefresh() {
  setTimeout(() => {
    this.$toast('刷新成功');
    this.downLoading = false;
  }, 500);
}

export function onLoad() {
  let item = {
    title: 'P2Z1W津111804040009015',
    demandDate: '2019-10-10',
    count: 20,
    lists: [
      {
        name: '广州三菱(20%)',
        type: 900,
        num: 20
      },
      {
        name: '广州三菱(20%)',
        type: 900,
        num: 20
      },
      {
        name: '广州三菱(20%)',
        type: 900,
        num: 20
      }
    ]
  }
  setTimeout(() => {
    // for (let i = 0; i < 5; i++) {
    //   this.list.push(item);
    // }
    // 加载状态结束
    this.upLoading = false;

    // 数据全部加载完成
    if (this.list.length >= 3) {
      this.finished = true;
    }else{
      for (let i = 0; i < 3; i++) {
        this.list.push(item);
      }
    }
  }, 500);
}

export function preventBubble(e) {
  e.cancelBubble = true;
}

export function release() {
  if(this.result.length <= 0){
    this.$toast('请先选择采购单！')
  }else{
    this.show = true;
  }
}

export function close() {
  this.show = false;
}

export function onConfirm() {
  this.show = false;
  this.$toast.success('下达成功');
  this.result = [];
}

export function toDetail(item) {
  this.$router.push({ name: 'DeliveryNoticeDetail', params: item });
}
