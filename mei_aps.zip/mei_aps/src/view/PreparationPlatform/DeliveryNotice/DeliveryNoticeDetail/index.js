import DeliveryNoticeDetail from './DeliveryNoticeDetail.vue'

export default DeliveryNoticeDetail
