<template>
  <div style="padding: 47px 8px 0">
    <van-nav-bar left-arrow fixed left-text="返回" title="送货通知详情" @click-left="back"></van-nav-bar>
    <div class="top-card">
      <div class="delivery-code">17400302000037</div>
      <div class="delivery-desc">201601300641电子膨胀阀线圈</div>
      <div class="delivery-special">
        <span>缺料：20</span>
        <span>需求时间：2019-10-10 15:00</span>
      </div>
      <div class="gray-area">
        <div class="factory-area">
          <span>厂区：</span>
          <span>HR2230</span>
        </div>
        <div class="plan-arrival-time">
          <span>计划到货时间：</span>
          <span>2018-08-08 08:00:00</span>
        </div>
        <div class="job-start-time">
          <span>作业开始时间：</span>
          <span>2018-08-08 08:00:00</span>
        </div>
        <div class="workshop">
          <span>车间：</span>
          <span>配管02</span>
        </div>
        <div class="sublibrary">
          <span>子库：</span>
          <span>MA2151</span>
        </div>
        <div class="job-num">
          <span>作业号：</span>
          <span>P2Z1W津111804040009015</span>
        </div>
        <div class="perparation-type">
          <span>备料类型：</span>
          <span>作业</span>
        </div>
      </div>
    </div>
    <div style="padding-top: 0.16rem; padding-left: 0.2rem">供应商详细信息</div>
    <div class="supplier-card">
      <span>广州三菱</span>
      <span><strong style="color: #F96A42">-20%</strong>（偏差比例）</span>
    </div>
    <div class="supplier-card">
      <span>江阴夏邦</span>
      <span><strong style="color: #169BD5">40%</strong>（偏差比例）</span>
    </div>
    <div class="supplier-card">
      <span>广州日立</span>
      <span><strong style="color: #169BD5">40%</strong>（偏差比例）</span>
    </div>
    <div class="supplier-card">
      <span>丹佛斯</span>
      <span><strong style="color: #169BD5">40%</strong>（偏差比例）</span>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'DeliveryNoticeDetail',
      data() {
          return{

          }
      },
      created() {
          console.log(this.$route.params)
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "deliveryNoticeDetail.scss";
</style>
