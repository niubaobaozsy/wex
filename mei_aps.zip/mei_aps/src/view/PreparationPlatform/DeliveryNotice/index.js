import DeliveryNotice from './DeliveryNotice.vue'

export default DeliveryNotice
