export function back() {
  this.$router.go(-1);
}

export function getPickValue(data) {
  console.log(data)
}

export function getDate(data) {
  console.log(data)
}

export function getMaterialCode(data) {
  console.log(data)
}

export function toDeliveryNoticeList() {
  this.$router.push({ name: 'DeliveryNoticeList' })
}
