<template>
  <div style="padding: 47px 0 45px">
    <van-nav-bar left-arrow fixed left-text="返回" title="送货通知下达" @click-left="back"></van-nav-bar>
    <picker require text="缺料类型" :pickValueList="list" @getPickValue="getPickValue"></picker>
    <date @showValue="getDate"></date>
    <code-search require :url="url" text="物料编码" type="material" @getCodeData="getMaterialCode"></code-search>
    <picker text="计划组" :pickValueList="group" @getPickValue="getPickValue"></picker>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="toDeliveryNoticeList">查询</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  import Picker from '../../../components/Picker'
  import Date from '../../../components/Date'
  import CodeSearch from '../../../components/CodeSearch'
  export default{
      name: 'DeliveryNotice',
      components: { Picker, Date, CodeSearch },
      data() {
          return{
              list: ['普通', '特殊'],
              url: '',
              group: ['M42总二', 'M42总三', 'M43总二', 'M42总三']
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "deliveryNotice.scss";
</style>
