import DeliveryNoticeQuery from './DeliveryNoticeQuery.vue'

export default DeliveryNoticeQuery
