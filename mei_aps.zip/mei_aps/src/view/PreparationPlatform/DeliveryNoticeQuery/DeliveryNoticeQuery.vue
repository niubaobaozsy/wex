<template>
  <div style="padding: 47px 0 45px">
    <van-nav-bar left-arrow fixed left-text="返回" title="送货通知管理" @click-left="back"></van-nav-bar>
    <code-search :url="url" text="物料编码" type="material" @getCodeData="getCodeData"></code-search>
    <date text="下单日期" @showValue="getDate"></date>
    <picker text="供应商" :pickValueList="list" @getPickValue="getPickValue"></picker>
    <picker text="通知状态" :pickValueList="values" @getPickValue="getPickValue"></picker>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="toDeliveryNoticeQueryList">查询</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  import CodeSearch from '../../../components/CodeSearch'
  import Date from '../../../components/Date'
  import Picker from '../../../components/Picker'
  export default{
      name: 'DeliveryNoticeQuery',
      components: { CodeSearch, Date, Picker },
      data() {
          return{
              url: '',
              list: ['供应商A', '供应商B', '供应商C'],
              values: ['已确认', '未确认', '已关闭', '已完成']
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "deliveryNoticeQuery.scss";
</style>
