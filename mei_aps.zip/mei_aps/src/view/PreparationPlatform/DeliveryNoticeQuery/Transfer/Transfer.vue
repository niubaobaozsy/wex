<template>
  <div style="padding: 47px 0 45px">
    <van-nav-bar left-arrow fixed left-text="返回" title="送货通知转单" @click-left="back"></van-nav-bar>
    <picker require text="供应商" :pickValueList="list" @getPickValue="getPickValue"></picker>
    <div class="common-list-style">
      <span class="common-font-style">备注</span>
      <span class="code"><input type="text" placeholder="请输入备注" v-model="remarks"></span>
    </div>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="confirmTransfer">确认同时转单</van-button>
    </div>
  </div>
</template>

<script>
  import Picker from '../../../../components/Picker'
  export default{
      name: 'Transfer',
      components: { Picker },
      data() {
          return{
              list: ['供应商A', '供应商B', '供应商C'],
              remarks: ''
          }
      },
      methods:{
          back: function () {
            this.$router.go(-1)
          },
          getPickValue: function (data) {
            console.log(data)
          },
          confirmTransfer: function () {
            this.$toast.success('转单成功！');
            this.$router.go(-2);
          }
      }
  }
</script>

<style lang="scss" scoped>

</style>
