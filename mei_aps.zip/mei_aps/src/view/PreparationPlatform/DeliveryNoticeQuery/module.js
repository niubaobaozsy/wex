export function back() {
  this.$router.go(-1)
}

export function getCodeData(data) {
  console.log(data)
}

export function getDate(data) {
  console.log(data)
}

export function getPickValue(data) {
  console.log(data)
}

export function toDeliveryNoticeQueryList() {
  this.$router.push({ name: 'DeliveryNoticeQueryList' })
}
