<template>
  <div style="padding: 47px 0 0">
    <van-nav-bar left-arrow fixed left-text="返回" title="送货通知详情" @click-left="back"></van-nav-bar>
    <div class="code-status">
      <span>17400302000037</span>
      <span>未确认</span>
    </div>
    <div style="padding: 0.16rem 0.3rem">201601300641电子膨胀阀线圈</div>
    <div class="item-common" style="color: #F96A42">
      <span class="item-title">作业号：</span>
      <span class="item-value">P2Z1W津111804040009015</span>
    </div>
    <div class="item-common" style="color: #F96A42">
      <span class="item-title">备料类型：</span>
      <span class="item-value">we</span>
    </div>
    <div class="item-common" style="color: #F96A42">
      <span class="item-title">需求日期：</span>
      <span class="item-value">2018-4-21</span>
    </div>
    <div class="item-common" style="color: #F96A42">
      <span class="item-title">供应商：</span>
      <span class="item-value">三花商贸</span>
    </div>
    <div class="item-common" style="color: #F96A42">
      <span class="item-title">子库：</span>
      <span class="item-value">MA2151</span>
    </div>
    <div class="item-common" style="color: #F96A42">
      <span class="item-title">下单数量：</span>
      <span class="item-value">10</span>
    </div>
    <div class="item-common">
      <span class="item-title">在途中：</span>
      <span class="item-value">10</span>
    </div>
    <div class="item-common">
      <span class="item-title">总接收数：</span>
      <span class="item-value">10</span>
    </div>
    <div class="item-common">
      <span class="item-title">总退回给供应商数：</span>
      <span class="item-value">0</span>
    </div>
    <div class="item-common">
      <span class="item-title">入库量：</span>
      <span class="item-value">10</span>
    </div>
    <div class="item-common">
      <span class="item-title">计划组：</span>
      <span class="item-value">PAIS678</span>
    </div>
    <div class="item-common">
      <span class="item-title">装配件：</span>
      <span class="item-value">15427000000799</span>
    </div>
    <div class="item-common">
      <span class="item-title">装配件描述：</span>
      <span class="item-value">201695102625膨胀阀组件 RoHS</span>
    </div>
    <div class="button-area">
      <van-button class="transfer-button" type="primary" @click="transfer">同时转单</van-button>
      <van-button class="cancel-button" type="primary" @click="cancelNotice">取消送货通知</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'DeliveryNoticeQueryDetail',
      data() {
          return{

          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "deliveryNoticeQueryDetail.scss";
</style>
