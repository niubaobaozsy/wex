import DeliveryNoticeQueryDetail from './DeliveryNoticeQueryDetail.vue'

export default DeliveryNoticeQueryDetail
