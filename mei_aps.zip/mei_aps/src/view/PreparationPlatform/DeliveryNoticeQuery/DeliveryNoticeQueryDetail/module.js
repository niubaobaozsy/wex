export function back() {
  this.$router.go(-1)
}

export function cancelNotice() {
  this.$toast.success('取消成功!');
  this.$router.go(-1)
}

export function transfer() {
  this.$router.push({ name: 'Transfer' })
}
