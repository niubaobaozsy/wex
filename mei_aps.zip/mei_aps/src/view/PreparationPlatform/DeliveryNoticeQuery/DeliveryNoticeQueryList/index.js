import DeliveryNoticeQueryList from './DeliveryNoticeQueryList.vue'

export default DeliveryNoticeQueryList
