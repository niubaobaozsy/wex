<template>
  <div style="padding: 47px 0 45px">
    <van-nav-bar left-arrow fixed left-text="返回" title="送货通知列表" @click-left="back"></van-nav-bar>
    <van-pull-refresh v-model="downLoading" @refresh="onRefresh">
      <div class="item-list" style="min-height: calc(100vh - 47px); padding: 0 0.16rem">
        <van-checkbox-group v-model="result" :max="5">
          <van-list v-model="upLoading" :finished="finished" :offset="offset" finished-text="没有更多了" :error.sync="error" error-text="请求失败，点击重新加载" @load="onLoad">
            <div class="query-list-item" v-for="(item, index) in list" :key="index" @click="toDetail(item)">
              <div class="item-top">
                <span class="num">{{item.num}}</span>
                <van-checkbox class="query-list-checkbox" :name="index" @click.native="preventBubble($event)"></van-checkbox>
                <span class="status">{{item.status}}</span>
              </div>
              <div class="item-middle">{{item.desc}}</div>
              <div class="item-bottom">
                <span>{{item.supplier}}</span>
                <span>{{item.count}}</span>
                <span>{{item.date}}</span>
              </div>
            </div>
          </van-list>
        </van-checkbox-group>
      </div>
    </van-pull-refresh>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="cancelNotice">取消送货通知</van-button>
    </div>
    <van-dialog v-model="show" :message="message" show-cancel-button @cancel="close" @confirm="onConfirm"></van-dialog>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'DeliveryNoticeQueryList',
      data() {
          return{
              downLoading: false,
              result: [],
              upLoading: false,
              finished: false,
              offset: 1,
              error: false,
              list: [],
              show: false,
              message: '确认取消送货通知？'
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "deliveryNoticeQueryList.scss";
</style>
