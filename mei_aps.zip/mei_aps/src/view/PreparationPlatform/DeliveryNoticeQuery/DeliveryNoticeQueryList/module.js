export function back() {
  this.$router.go(-1);
}

export function onRefresh() {
  setTimeout(() => {
    this.$toast('刷新成功');
    this.downLoading = false;
  }, 500);
}

export function onLoad() {
  let item = {
    num: '17400302000037',
    status: '未确认',
    desc: '201601300641电子膨胀阀线圈',
    supplier: '杭州杰欣',
    count: 20,
    date: '8-28'
  }
  setTimeout(() => {
    // for (let i = 0; i < 5; i++) {
    //   this.list.push(item);
    // }
    // 加载状态结束
    this.upLoading = false;

    // 数据全部加载完成
    if (this.list.length >= 10) {
      this.finished = true;
    }else{
      for (let i = 0; i < 6; i++) {
        this.list.push(item);
      }
    }
  }, 500);
}

export function preventBubble(e) {
  e.cancelBubble = true;
}

export function cancelNotice() {
  if(this.result.length <= 0){
    this.$toast('请先选择订单！')
  }else{
    this.show = true;
  }
}

export function close() {
  this.show = false;
}

export function onConfirm() {
  this.show = false;
  this.result.forEach((item, index, arr) => {
    this.list.splice(item, 1);
  })
  this.result = [];
  this.$toast.success('取消成功');
}

export function toDetail(item) {
  this.$router.push({ name: 'DeliveryNoticeQueryDetail', params: item })
}
