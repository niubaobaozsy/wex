export function backToWorkshopSchedule() {
  this.$router.go(-1);
}

export function onRefresh() {
  setTimeout(() => {
    this.$toast('刷新成功');
    this.downLoading = false;
  }, 500);
}

export function toDetail() {
  this.$router.push({ name: 'WorkshopScheduleDetail' })
}

export function sortItem(item, e) {
  e.cancelBubble = true;
  if(e.target.innerText === '' && this.count < this.list.length){
    this.count += 1;
    e.target.innerText = this.count;
    this.serialList.push(item);
  }
}

export function saveChange() {
  if(this.serialList.length <= 0) return;
  if(this.serialList.length === this.list.length){
    this.list = [...this.serialList];
  }else{
    let tempList = [];
    let listCopy = JSON.parse(JSON.stringify(this.list));
    for(let m = 0, len1 = this.list.length; m < len1; m++){
      for(let n = 0, len2 = this.serialList.length; n < len2; n++){
        if(this.list[m] === this.serialList[n]){
          listCopy[m] = ''
        }
      }
    }
    tempList = listCopy.filter(item => { return item != ''});
    console.log('tempList', tempList);
    this.list = [...this.serialList, ...tempList];
  }
  let serialDomLength = this.$refs.serial.length;
  for(let i = 0; i < serialDomLength; i++){
    this.$refs.serial[i].innerText = '';
  }
  this.count = 0;
  this.serialList = [];
}

export function resetSequenceNum() {
  let serialDomLength = this.$refs.serial.length;
  for(let i = 0; i < serialDomLength; i++){
    this.$refs.serial[i].innerText = '';
  }
  this.count = 0;
  this.serialList = [];
}
