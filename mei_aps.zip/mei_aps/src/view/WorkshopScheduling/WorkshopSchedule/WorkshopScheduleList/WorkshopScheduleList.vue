<template>
  <div>
    <van-nav-bar left-arrow fixed title="车间排产" :right-text="rightText" left-text="返回" @click-left="backToWorkshopSchedule"></van-nav-bar>
    <van-pull-refresh v-model="downLoading" @refresh="onRefresh">
      <div class="item-list" style="margin: 57px 10px 55px; min-height: calc(100vh - 57px - 55px)">
        <div class="item" @click="toDetail()" v-for="(item, index) in list" :key="index">
          <div class="item-top">
            <div ref="serial" class="serial-num" @click="sortItem(item, $event)"></div>
            <div class="item-num">{{item.code}}</div>
            <div class="item-status">{{item.status}}</div>
          </div>
          <div class="item-middle">{{item.desc}}</div>
          <div class="item-bottom">
            <span>{{item.time}}</span>
            <span>{{item.workorderNum}}</span>
            <span>{{item.completeNum}}</span>
            <span class="schedule-num">{{item.scheduleNum}}</span>
          </div>
        </div>
      </div>
    </van-pull-refresh>
    <div class="button-area">
      <van-button class="save button-common-style" type="primary" @click="saveChange">保存</van-button>
      <van-button class="refresh button-common-style" type="primary" @click="resetSequenceNum">重置</van-button>
      <van-button class="release button-common-style" type="primary">发布</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'WorkshopScheduleList',
      data() {
          return{
              rightText: '',
              downLoading: false,
              list: [
                  {
                      code: 'LPMO-47975001',
                      status: '已完成',
                      desc: '62759-67848101  N 批量整机 商用微波炉 EM025F-S0SA00 ',
                      time: '2018-8-3 8:00',
                      workorderNum: 300,
                      completeNum: 300,
                      scheduleNum: 200
                  },
                  {
                      code: 'LPMO-48094101',
                      status: '已发放',
                      desc: '62759-67848101  N 批量整机 商用微波炉 EM025F-S0SA00 ',
                      time: '2018-8-3 12:00',
                      workorderNum: 350,
                      completeNum: 200,
                      scheduleNum: 350
                  },
                  {
                      code: 'LPMO-48108101',
                      status: '已发放',
                      desc: '62759-67848101  N 批量整机 商用微波炉 EM025F-S0SA00 ',
                      time: '2018-8-3 16:00',
                      workorderNum: 360,
                      completeNum: 0,
                      scheduleNum: 360
                  },
                  {
                      code: 'LPMO-48630701',
                      status: '未发放',
                      desc: '62759-67848101  N 批量整机 商用微波炉 EM025F-S0SA00 ',
                      time: '2018-8-3 21:00',
                      workorderNum: 400,
                      completeNum: 0,
                      scheduleNum: 200
                  }
              ],
              count: 0,
              serialList: []
          }
      },
      created() {
          console.log(this.$route.params);
          this.rightText = this.$store.state.resourceCode;
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "workshopScheduleList.scss";
</style>
