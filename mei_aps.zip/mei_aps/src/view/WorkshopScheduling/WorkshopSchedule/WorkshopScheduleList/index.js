import WorkshopScheduleList from './WorkshopScheduleList.vue'

export default WorkshopScheduleList
