export function backToHome() {
  this.$router.go(-1);
}

export function getPlanGroup(value) {
  this.planGroup = value;
}

export function getFactory(value) {
  console.log(value);
}

export function getResourceCode(value) {
  this.resourceCode = value
}

export function getSelectedDate(data) {
  if(data.type === 'start'){
    this.startDate = data.value;
  }else{
    this.endDate = data.value;
  }
}

export function toWorkshopScheduleList() {
  let data = {
    planGroup: this.planGroup,
    resourceCode: this.resourceCode,
    startDate: this.startDate,
    endDate: this.endDate
  }
  this.$store.commit('WORKSHOP_SCHEDULE_LIST_RIGHT_TEXT', this.resourceCode)
  this.$router.push({ name: 'WorkshopScheduleList', params: data });
}
