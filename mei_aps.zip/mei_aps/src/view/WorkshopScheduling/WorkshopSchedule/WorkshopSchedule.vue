<template>
  <div style="padding: 47px 0 45px">
    <van-nav-bar left-arrow fixed left-text="返回" title="排产查询" @click-left="backToHome">
      <select-options text="M01" :options="options" @getSelectedOption="getFactory" slot="right"></select-options>
    </van-nav-bar>
    <code-search require text="计划组" type="plan" :url="pUrl" @getCodeData="getPlanGroup"></code-search>
    <code-search require text="资源" type="line" :url="rUrl" @getCodeData="getResourceCode"></code-search>
    <date require text="时间范围"  @showValue="getSelectedDate"></date>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="toWorkshopScheduleList">查询</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  import CodeSearch from '../../../components/CodeSearch'
  import Date from '../../../components/Date'
  import SelectOptions from '../../../components/SelectOptions'
  export default{
      name: 'WorkshopSchedule',
      components: { CodeSearch, Date, SelectOptions },
      data() {
          return{
              pUrl: 'www',
              planGroup: '',
              options: [
                {text: 'M01顺德工厂', value: 'M01'},
                {text: 'M04芜湖工厂', value: 'M04'},
                {text: 'M09南沙工厂', value: 'M09'}
              ],
              rUrl: '',
              resourceCode: '',
              startDate: this.$common.formatDate(''),
              endDate: this.$common.formatDate('')
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "workshopSchedule.scss";
</style>
