import WorkshopSchedule from './WorkshopSchedule.vue'

export default WorkshopSchedule
