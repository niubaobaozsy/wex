import WorkshopScheduleDetail from './WorkshopScheduleDetail.vue'

export default WorkshopScheduleDetail
