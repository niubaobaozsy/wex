<template>
  <div style="padding: 47px 0 0">
    <van-nav-bar left-arrow fixed title="工单详情" left-text="返回" @click-left="backToWorkshopScheduleList" right-text="保存" @click-right="save"></van-nav-bar>
    <div class="item-common order-num">
      <span class="item-title">工单号：</span>
      <span class="item-value">MILPMO-486307011</span>
    </div>
    <div class="item-common material-code">
      <span class="item-title">物料编码：</span>
      <span class="item-value">17170000018546</span>
    </div>
    <div class="item-common material-desc">
      <span class="item-title">物料描述：</span>
      <span class="item-value">MI组件 微波炉 ECLAAI4-S3-K(GE)</span>
    </div>
    <div class="item-common order-status">
      <span class="item-title">工单状态：</span>
      <span class="item-value">未下达</span>
    </div>
    <div class="item-common order-count">
      <span class="item-title">工单数量：</span>
      <span class="item-value">300</span>
    </div>
    <div class="item-common complete-num">
      <span class="item-title">完工数量：</span>
      <span class="item-value">0</span>
    </div>
    <div class="item-common plan-start-time">
      <span class="item-title">计划开始时间：</span>
      <span class="item-value">2018-11-19 16:16:16</span>
    </div>
    <div class="item-common demand-date">
      <span class="item-title">需求日期：</span>
      <span class="item-value">2018-11-18</span>
    </div>
    <div class="item-common plan-group">
      <span class="item-title">计划组：</span>
      <span class="item-value">FW-MD(US)</span>
    </div>
    <div class="item-common resource">
      <span class="item-title">资源：</span>
      <span class="item-value">PZS1ZSA025</span>
    </div>
    <div class="item-common warn-message">
      <span class="item-title">警告信息：</span>
      <span class="item-value">不满足交期</span>
    </div>
    <div class="item-common final-assembly-order">
      <span class="item-title">总装工单：</span>
      <span class="item-value">LPMO-48630701</span>
    </div>
    <div class="item-common final-assembly-start-time">
      <span class="item-title">总装开始时间：</span>
      <span class="item-value">2018-11-21 18:18:18</span>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'WorkshopScheduleDetail',
      data() {
          return{

          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "workshopScheduleDetail.scss";
</style>
