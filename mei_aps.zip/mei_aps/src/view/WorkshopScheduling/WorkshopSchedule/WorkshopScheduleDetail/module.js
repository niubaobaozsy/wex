export function backToWorkshopScheduleList() {
  this.$router.go(-1);
}

export function save() {

}
