import SchedulingTable from './SchedulingTable.vue'

export default SchedulingTable
