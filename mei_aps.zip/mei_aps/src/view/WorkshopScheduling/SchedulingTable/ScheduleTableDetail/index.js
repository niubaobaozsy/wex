import ScheduleTableDetail from './ScheduleTableDetail.vue'

export default ScheduleTableDetail
