export function backToScheduleTableList() {
  this.$router.go(-1);
}
