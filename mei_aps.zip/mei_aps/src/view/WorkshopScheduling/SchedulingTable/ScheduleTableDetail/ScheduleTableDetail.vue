<template>
  <div style="padding: 47px 0 0">
    <van-nav-bar left-arrow fixed title="工单详情" left-text="返回" @click-left="backToScheduleTableList"></van-nav-bar>
    <div class="item-common order-num">
      <span class="item-title">工单号：</span>
      <span class="item-value">LPMO-47975001</span>
    </div>
    <div class="item-common material-code">
      <span class="item-title">物料编码：</span>
      <span class="item-value">62759-67848101</span>
    </div>
    <div class="item-common material-desc">
      <span class="item-title">物料描述：</span>
      <span class="item-value">N 批量整机 商用微波炉 EM025F-S0SA00</span>
    </div>
    <div class="item-common order-state">
      <span class="item-title">工单状态：</span>
      <span class="item-value">已完成</span>
    </div>
    <div class="item-common order-count">
      <span class="item-title">工单数量：</span>
      <span class="item-value">300</span>
    </div>
    <div class="item-common complete-count">
      <span class="item-title">完工数量：</span>
      <span class="item-value">300</span>
    </div>
    <div class="item-common schedule-count">
      <span class="item-title">排产数量：</span>
      <span class="item-value">200</span>
    </div>
    <div class="item-common plan-start-time">
      <span class="item-title">计划开始时间：</span>
      <span class="item-value">2018-08-03 08:00:00</span>
    </div>
    <div class="item-common demand-date">
      <span class="item-title">需求日期：</span>
      <span class="item-value">2018-08-01</span>
    </div>
    <div class="item-common plan-group">
      <span class="item-title">计划组：</span>
      <span class="item-value">注塑01-M01</span>
    </div>
    <div class="item-common resource">
      <span class="item-title">资源：</span>
      <span class="item-value">PZS1ZSA025</span>
    </div>
    <div class="item-common warn-message">
      <span class="item-title">警告信息：</span>
      <span class="item-value">不满足交期</span>
    </div>
    <div class="item-common final-assembly-order">
      <span class="item-title">总装工单：</span>
      <span class="item-value">LPMO-48630701</span>
    </div>
    <div class="item-common final-assembly-start-time">
      <span class="item-title">总装开始时间：</span>
      <span class="item-vaule">2018-11-21 18:18:18</span>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'ScheduleTableDetail',
      data() {
          return{

          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "scheduleTableDetail.scss";
</style>
