<template>
  <div style="padding: 47px 0 45px">
    <van-nav-bar left-arrow fixed title="排产表查询" left-text="返回" @click-left="backToHome">
      <select-options text="M01" :options="options" @getSelectedOption="getSelectedFactory" slot="right"></select-options>
    </van-nav-bar>
    <code-search require text="计划组" :url="pUrl" type="plan" @getCodeData="getPlanCode"></code-search>
    <code-search require text="资源" :url="rUrl" type="line" @getCodeData="getResourceCode"></code-search>
    <date require text="时间区间" @showValue="getDateData"></date>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="toScheduleTable">查询</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  import SelectOptions from '../../../components/SelectOptions'
  import CodeSearch from '../../../components/CodeSearch'
  import Date from '../../../components/Date'
  export default{
      name: 'SchedulingTable',
      components: { SelectOptions, CodeSearch, Date },
      data() {
          return{
              options: [
                {text: 'M01顺德工厂', value: 'M01'},
                {text: 'M04芜湖工厂', value: 'M04'},
                {text: 'M09南沙工厂', value: 'M09'}
              ],
              pUrl: '',
              rUrl: '',
              planGroupCode: '',
              resourceCode: '',
              startDate: this.$common.formatDate(''),
              endDate: this.$common.formatDate('')
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "schedulingTable.scss";
</style>
