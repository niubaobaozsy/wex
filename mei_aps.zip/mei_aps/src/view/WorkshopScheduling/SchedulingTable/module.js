export function backToHome() {
  this.$router.go(-1);
}

export function getSelectedFactory(value) {
  console.log(value);
}

export function getPlanCode(value) {
  this.planGroupCode = value;
}

export function getResourceCode(value) {
  this.resourceCode = value;
}

export function getDateData(data) {
  if(data.type === 'start'){
    this.startDate = data.value;
  }else{
    this.endDate = data.value;
  }
}

export function toScheduleTable() {
  let data = {
    planGroup: this.planGroupCode,
    resourceCode: this.resourceCode,
    startDate: this.startDate,
    endDate: this.endDate
  }
  this.$router.push({ name: 'ScheduleTableList', params: data });
}
