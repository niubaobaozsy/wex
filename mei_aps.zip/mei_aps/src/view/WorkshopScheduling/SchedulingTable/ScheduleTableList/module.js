export function backToScheduleTable() {
  this.$router.go(-1);
}

export function formatter(type, value) {
  if(type === 'year'){
    return `${value}年`;
  }else if(type === 'month'){
    return `${value}月`;
  }else if(type === 'day'){
    return `${value}日`
  }
  return value;
}

export function showPopup() {
  this.show = true;
}

export function closePopup() {
  this.show = false;
}

export function getDate(value) {
  this.date = this.$common.formatDate(value);
  this.show = false;
}

export function onRefresh() {
  setTimeout(() => {
    this.$toast('刷新成功');
    this.downLoading = false;
  }, 500);
}

export function toDetail(item) {
  this.$router.push({ name: 'ScheduleTableDetail', params: item })
}
