import ScheduleTableList from './ScheduleTableList.vue'

export default ScheduleTableList
