<template>
  <div>
    <van-nav-bar left-arrow fixed title="排产表" left-text="返回" @click-left="backToScheduleTable" :right-text="date" @click-right="showPopup"></van-nav-bar>
    <van-popup v-model="show" position="bottom">
      <van-datetime-picker v-model="currentDate" type="date" :formatter="formatter" @cancel="closePopup" @confirm="getDate"></van-datetime-picker>
    </van-popup>
    <van-pull-refresh v-model="downLoading" @refresh="onRefresh">
      <div class="item-list" style="margin: 57px 10px 0; min-height: calc(100vh - 57px)">
        <div class="item" @click="toDetail(item)" v-for="(item, index) in list" :key="index">
          <div class="item-top">
            <div class="item-num">{{item.code}}</div>
            <div class="item-status">{{item.status}}</div>
          </div>
          <div class="item-middle">{{item.desc}}</div>
          <div class="item-bottom">
            <span>{{item.time}}</span>
            <span class="work-type">{{item.workType}}</span>
            <span>{{item.workorderNum}}</span>
            <span>{{item.completeNum}}</span>
            <span class="schedule-num">{{item.scheduleNum}}</span>
          </div>
        </div>
      </div>
    </van-pull-refresh>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'ScheduleTableList',
      data() {
          return{
              date: this.$common.formatDate(''),
              show: false,
              currentDate: new Date(),
              downLoading: false,
              list: [
                  {
                      code: 'LPMO-47975001',
                      status: '已完成',
                      desc: '62759-67848101  N 批量整机 商用微波炉 EM025F-S0SA00',
                      time: '8:00',
                      workType: '白班',
                      workorderNum: 300,
                      completeNum: 300,
                      scheduleNum: 200
                  },
                  {
                      code: 'LPMO-48094101',
                      status: '已发放',
                      desc: '62759-67848101  N 批量整机 商用微波炉 EM025F-S0SA00',
                      time: '12:00',
                      workType: '白班',
                      workorderNum: 350,
                      completeNum: 200,
                      scheduleNum: 3500
                  },
                  {
                      code: 'LPMO-48108101',
                      status: '已发放',
                      desc: '62759-67848101  N 批量整机 商用微波炉 EM025F-S0SA00',
                      time: '16:00',
                      workType: '白班',
                      workorderNum: 360,
                      completeNum: 0,
                      scheduleNum: 360
                  },
                  {
                      code: 'LPMO-48630701',
                      status: '未发放',
                      desc: '62759-67848101  N 批量整机 商用微波炉 EM025F-S0SA00',
                      time: '21:00',
                      workType: '晚班',
                      workorderNum: 400,
                      completeNum: 0,
                      scheduleNum: 200
                  }
              ]
          }
      },
      created() {
          console.log(this.$route.params)
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "scheduleTableList";
</style>
