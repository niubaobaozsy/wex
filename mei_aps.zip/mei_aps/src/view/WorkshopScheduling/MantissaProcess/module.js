export function backToHome() {
  this.$router.go(-1);
}

export function getMantissaProcessData(value) {
  console.log(value);
}

export function getPlanCode(value) {
  this.planG = value;
}

export function getLineCode(value) {
  this.lineB = value;
}

export function getMaterialCode(value) {
  this.materialC = value;
}

export function getDate(data) {
  if(data.type === 'start'){
    this.SD = data.value;
  }else{
    this.ED = data.value;
  }
}

export function toMantissaMakeorderPage() {
  let queryParams = {
    planGroup: this.planG,
    lineBody: this.lineB,
    makeOrderNum: this.makeorderNum,
    materialCode: this.materialC,
    startDate: this.SD,
    endDate: this.ED
  }
  this.$router.push({ name: 'MantissaMakeorder', params: queryParams })
}

