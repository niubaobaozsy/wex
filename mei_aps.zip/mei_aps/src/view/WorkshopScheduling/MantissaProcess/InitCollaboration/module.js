export function backToMantissaMakeorder() {
  this.$router.go(-1);
}

export function getCollaborationType(value) {
  console.log(value);
  this.collaborationType = value;
}

export function getCode(value) {
  console.log(value)
  this.MCode = value;
}

export function getFixDate(data) {
  this.fixDate = data.value;
}

export function save() {

}
