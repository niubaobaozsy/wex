<template>
  <div style="padding: 47px 0 55px">
    <van-nav-bar left-arrow fixed :title="title" left-text="返回" @click-left="backToMantissaMakeorder"></van-nav-bar>
    <picker text="协同类型" require :pickValueList="collaborationTypeList" @getPickValue="getCollaborationType"></picker>
    <code-search text="物料编码" :url="url" type="material" @getCodeData="getCode"></code-search>
    <div class="material-desc common-list-style" >
      <span class="common-font-style">物料描述</span>
      <span class="code"><input type="text" placeholder="请输入物料描述" v-model="materialDesc"></span>
    </div>
    <date require text="解决日期" isOne @showValue="getFixDate"></date>
    <div class="collaboration-desc common-list-style">
      <span class="common-font-style">协同描述<em>*</em></span>
      <span class="code"><input type="text" placeholder="请输入协同描述" v-model="collaborationDesc"></span>
    </div>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="save">保存</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  import Picker from '../../../../components/Picker'
  import CodeSearch from '../../../../components/CodeSearch'
  import Date from '../../../../components/Date'
  export default{
      name: 'InitCollaboration',
      components: { Picker, CodeSearch, Date },
      data() {
          return {
              title: 'LMOP',
              collaborationTypeList: [ '缺料', '人员', '品质', '设备' ],
              collaborationType: '',
              url: 'www.baidu.com',
              MCode: '',
              materialDesc: '',
              fixDate: this.$common.formatDate(''),
              collaborationDesc: ''
          }
      },
      created() {
          console.log(this.$route.params)
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "initCollaboration";
</style>
