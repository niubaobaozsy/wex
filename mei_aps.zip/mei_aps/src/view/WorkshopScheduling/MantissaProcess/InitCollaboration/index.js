import InitCollaboration from './InitCollaboration.vue'

export default InitCollaboration
