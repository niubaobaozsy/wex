<template>
  <div>
    <van-nav-bar fixed left-arrow title="尾数工单" left-text="返回" @click-left="backToMantissaProcess" right-text="协同清单" @click-right="toCollaborativeList"></van-nav-bar>
    <van-pull-refresh v-model="downLoading" @refresh="onRefresh">
      <div class="item-list" style="margin: 57px 10px 45px; min-height: calc(100vh - 57px - 45px)">
        <van-checkbox-group v-model="result">
          <van-list v-model="upLoading" :finished="finished" :offset="offset" finished-text="没有更多了" :error.sync="error" error-text="请求失败，点击重新加载" @load="onLoad">
            <div class="item" @click="toDetail()" v-for="(item, index) in list" :key="index">
              <div class="item-top">
                <van-checkbox class="item-checkbox" :name="index" @click.native="preventBubble($event)"></van-checkbox>
                <div class="item-num">{{item.num}}</div>
                <div class="item-status">{{item.status}}</div>
              </div>
              <div class="item-middle">{{item.desc}}</div>
              <div class="item-bottom">
                <span>{{item.line}}</span>
                <span>{{item.time}}</span>
                <span>{{item.count}}</span>
                <span class="special">{{item.delay}}</span>
              </div>
            </div>
          </van-list>
        </van-checkbox-group>
      </div>
    </van-pull-refresh>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="initCollaboration">发起协同</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'MantissaMakeorder',
      data() {
          return {
              downLoading: false,
              result: [],
              upLoading: false,
              finished: false,
              offset: 1,
              error: false,
              list: []
          }
      },
      created() {
          console.log(this.$route.params)
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "mantissaMakeorder";
</style>
