export function backToMantissaProcess() {
  this.$router.go(-1);
}

export function toCollaborativeList() {
  this.$router.push({ name: 'CollaborativeList' })
}

export function initCollaboration() {
  console.log('result', this.result);
  this.$router.push({ name: 'InitCollaboration', params: this.result })
}

export function toDetail() {
  this.$router.push({ name: 'MantissaMakeorderDetail' })
}

export function preventBubble(e) {
  e.cancelBubble = true;
}

export function onRefresh() {
  setTimeout(() => {
    this.$toast('刷新成功');
    this.downLoading = false;
  }, 500);
}

export function onLoad() {
  let item = {
    num: 'LPMO-47975001',
    status: '更新',
    desc: '62759-67848101  N 批量整机 商用微波炉 EM025F-S0SA00 ',
    line: 'PZS1ZSA025',
    time: '11-19',
    count: 300,
    delay: 5
  }
  setTimeout(() => {
    for (let i = 0; i < 5; i++) {
      this.list.push(item);
    }
    // 加载状态结束
    this.upLoading = false;

    // 数据全部加载完成
    if (this.list.length >= 15) {
      this.finished = true;
    }
  }, 500);
}
