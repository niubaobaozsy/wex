import MantissaProcess from './MantissaProcess.vue'

export default MantissaProcess
