<template>
  <div style="padding-top: 47px">
    <van-nav-bar left-arrow fixed title="协同清单" left-text="返回" @click-left="backToMantissaMakeorder"></van-nav-bar>
    <ul style="padding: 0 10px">
      <li class="collaborative-list-item">
        <div class="list-item-top">
          <span class="fl">客户紧急订单，不能到货，将影响12388479347的KBHDN面板组件 金色，特工</span>
          <span class="fr" :class="[ isProcessed? 'processed' : 'unprocessed' ]">已处理</span>
        </div>
        <div class="list-item-bottom">
          <span class="fl">秦亚辉</span>
          <span class="fr">02-03</span>
        </div>
      </li>
      <li class="collaborative-list-item">
        <div class="list-item-top">
          <span class="fl">客户紧急订单，不能到货，将影响12388479347的KBHDN面板组件 金色，特工</span>
          <span class="fr unprocessed" >未处理</span>
        </div>
        <div class="list-item-bottom">
          <span class="fl">秦亚辉</span>
          <span class="fr">02-03</span>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'CollaborativeList',
      data (){
          return {
              isProcessed: true
          }
      },
      created() {

      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "collaborativeList";
</style>
