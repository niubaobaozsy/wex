import CollaborativeList from './CollaborativeList.vue'

export default CollaborativeList
