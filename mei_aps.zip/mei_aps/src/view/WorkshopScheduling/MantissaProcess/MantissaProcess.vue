<template>
  <div style="padding:47px 0 45px">
    <van-nav-bar title="尾数查询" left-arrow fixed left-text="返回" @click-left="backToHome">
      <select-options text="M01" :options="list" @getSelectedOption="getMantissaProcessData" slot="right"></select-options>
    </van-nav-bar>
    <code-search text="计划组" require :url="planU" type="plan" @getCodeData="getPlanCode"></code-search>
    <code-search text="线体" require :url="lineU" type="line" @getCodeData="getLineCode"></code-search>
    <div class="make-order-num common-list-style" >
      <span class="common-font-style">工单号</span>
      <span class="code"><input type="text" placeholder="请输入工单号" v-model="makeorderNum"></span>
    </div>
    <code-search text="物料编码" :url="materialU" type="material" @getCodeData="getMaterialCode"></code-search>
    <date text="生产时间" @showValue="getDate"></date>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="toMantissaMakeorderPage">查询</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  import SelectOptions from '../../../components/SelectOptions'
  import CodeSearch from '../../../components/CodeSearch'
  import Date from '../../../components/Date'
  export default{
      name: 'MantissaProcess',
      components: { SelectOptions, CodeSearch, Date },
      data() {
          return {
              planG: '',
              planU: 'http://www.baidu.com',
              lineB: '',
              lineU: 'http://www.baidu.com',
              makeorderNum: '',
              materialU: 'http://www.baidu.com',
              materialC: '',
              SD: this.$common.formatDate(''),
              ED: this.$common.formatDate(''),
              list: [
                  {text: 'M01顺德工厂', value: 'M01'},
                  {text: 'M04芜湖工厂', value: 'M04'},
                  {text: 'M09南沙工厂', value: 'M09'}
              ]
          }
      },
      created() {

      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "mantissaProcess";
</style>
