import MantissaMakeorderDetail from './MantissaMakeorderDetail.vue'

export default MantissaMakeorderDetail
