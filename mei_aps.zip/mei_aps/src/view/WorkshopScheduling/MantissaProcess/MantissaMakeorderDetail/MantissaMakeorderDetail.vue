<template>
  <div style="padding: 47px 0 0">
    <van-nav-bar left-arrow fixed title="工单详情" left-text="返回" @click-left="backToMantissaMakeorder"></van-nav-bar>
    <div class="makeorder-num item-common">
      <span class="item-title">工单号：</span>
      <span class="item-value">LPMO-47975001</span>
    </div>
    <div class="materials-code item-common">
      <span class="item-title">物料编码：</span>
      <span class="item-value">62759-67848101</span>
    </div>
    <div class="materials-description item-common">
      <span class="item-title">物料描述：</span>
      <span class="item-value">N 批量整机 商用微波炉 EM025F-SOSA00</span>
    </div>
    <div class="makeorder-status item-common">
      <span class="item-title">工单状态：</span>
      <span class="item-value">已下达</span>
    </div>
    <div class="makeorder-count item-common">
      <span class="item-title">工单数量：</span>
      <span class="item-value">300</span>
    </div>
    <div class="complete-order-count item-common">
      <span class="item-title">完工数：</span>
      <span class="item-value">295</span>
    </div>
    <div class="plan-start-time item-common">
      <span class="item-title">计划开始时间：</span>
      <span class="item-value">2019-02-11 14:14:14</span>
    </div>
    <div class="demand-date item-common">
      <span class="item-title">需求日期：</span>
      <span class="item-value">2019-02-22</span>
    </div>
    <div class="plan-groups item-common">
      <span class="item-title">计划组：</span>
      <span class="item-value">注塑01-M50</span>
    </div>
    <div class="resource item-common">
      <span class="item-title">资源：</span>
      <span class="item-value">PZS1ZSA025</span>
    </div>
    <div class="warning-message item-common">
      <span class="item-title">警告信息：</span>
      <span class="item-value">不满足交期</span>
    </div>
    <div class="zz-makeorder item-common">
      <span class="item-title">总装工单：</span>
      <span class="item-value">LPMO-48630701</span>
    </div>
    <div class="zz-start-time item-common">
      <span class="item-title">总装开始时间：</span>
      <span class="item-value">2019-01-22 18:18:18</span>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'MantissaMakeorderDetail',
      data() {
          return {

          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "mantissaMakeorderDetail";
</style>
