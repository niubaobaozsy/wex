/**
 * Created by ZONGHP on 2018-12-19.
 */
export function drawPie() {
  var echarts = this.$echarts.init(document.getElementById("pie"));
  var option = {
      tooltip: {
        trigger: 'item',
        formatter: params => {return `${params.seriesName}<br/>${params.name.split(" ")[0]} : ${params.value}(${params.percent}%)`}
      },
      series: [
        {
          name: '需求接口',
          type: 'pie',
          radius: '80%',
          center: ['52%', '52%'],
          data: [
            {value: 10, name: 'QMS 5%'},
            {value: 16, name: 'CSS 8%'},
            {value: 16, name: 'PLM 8%'},
            {value: 64, name: 'OMS 32%'},
            {value: 94, name: 'IMS 47%'}
          ],
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
  }
  echarts.setOption(option);
}

export function getDateData(data) {
  if(data.type === 'start'){
    this.startD = data.value;
  }else{
    this.endD = data.value;
  }
}

export function backToHome() {
  this.$router.go(-1);
}

export function getPickValue(value) {
  this.orderType = value;
  console.log(this.orderType);
}

export function getMaterialCode(value) {
  this.codeNum = value;
}

export function toDemandInterfaceList() {
  let data = {
    materialCode: this.codeNum,
    startDate: this.startD,
    endDate: this.endD,
    orderType: this.orderType
  }
  this.$store.commit('DEMAND_INTERFACE_INFO', data);
  this.$router.push({ name: 'DemandInterfaceList', params: data });
}
