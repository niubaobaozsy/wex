<template>
  <div style="padding:47px 0 45px">
    <van-nav-bar title="需求接口" left-arrow fixed left-text="返回" @click-left="backToHome">
      <nav-bar-select v-model="factoryCode" :options="list" slot="right"></nav-bar-select>
    </van-nav-bar>
    <div id="pie" style="height: 66.67vw; width: 100%"></div>
    <code-search text="物料编码" :url="url" type="material" @getCodeData="getMaterialCode"></code-search>
    <date require @showValue="getDateData"></date>
    <picker text="订单类型" require :pickValueList="values" @getPickValue="getPickValue"></picker>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="toDemandInterfaceList">查询</van-button>
    </div>
  </div>
</template>

<script>
import * as methods from './module'
import Date from '../../../components/Date'
import NavBarSelect from '../../../components/NavBarSelect'
import CodeSearch from '../../../components/CodeSearch'
import Picker from '../../../components/Picker'
export default{
    name: 'DemandInterface',
    components: { Date, NavBarSelect, CodeSearch, Picker },
    data() {
        return {
            startD: this.$common.formatDate(''),
            endD: this.$common.formatDate(''),
            codeNum: '',
            values: ['IMS', 'OMS', 'PLM', 'CSS', 'QMS'],
            orderType: '',
            url: 'http://www.baidu.com',
            list: [
                {text: 'M01顺德工厂', value: 'M01'},
                {text: 'M04芜湖工厂', value: 'M04'},
                {text: 'M09南沙工厂', value: 'M09'}
            ],
            factoryCode: 'M01'
        }
    },
    mounted() {
        this.drawPie();
    },
    methods
}
</script>

<style lang="scss" scoped>
@import "demandInterface.scss";
</style>
