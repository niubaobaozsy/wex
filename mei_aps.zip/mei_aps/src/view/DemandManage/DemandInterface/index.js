/**
 * Created by ZONGHP on 2018-12-19.
 */
import DemandInterface from './DemandInterface.vue'

export default DemandInterface
