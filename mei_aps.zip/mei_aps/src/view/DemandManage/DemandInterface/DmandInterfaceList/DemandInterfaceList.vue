<template>
  <div>
    <van-nav-bar left-arrow fixed left-text="返回" title="需求接口查询列表" @click-left="backToDemandInterface"></van-nav-bar>
    <van-pull-refresh v-model="downLoading" @refresh="onRefresh">
      <div class="item-list" style="margin: 57px 10px 45px; min-height: calc(100vh - 57px - 45px)">
        <van-checkbox-group v-model="result">
          <van-list v-model="upLoading" :finished="finished" :offset="offset" finished-text="没有更多了" :error.sync="error" error-text="请求失败，点击重新加载" @load="onLoad">
            <div class="item" @click="toDetail()" v-for="(item, index) in list" :key="index">
              <div class="item-top">
                <van-checkbox class="item-checkbox" :name="index" @click.native="preventBubble($event)"></van-checkbox>
                <div class="item-num">{{item.num}}</div>
                <div class="item-status">{{item.status}}</div>
                <div v-if="mult" class="item-status status-special">警告</div>
              </div>
              <div class="item-middle">{{item.desc}}</div>
              <div class="item-bottom">
                <span>{{item.line}}</span>
                <span>{{item.time}}</span>
                <span>{{item.count}}</span>
              </div>
            </div>
          </van-list>
        </van-checkbox-group>
      </div>
    </van-pull-refresh>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="showDialog">引入需求工作台</van-button>
    </div>
    <van-dialog v-model="show" show-cancel-button message="确认选定的订单引入吗？" :before-close="beforeClose"></van-dialog>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'DemandInterfaceList',
      data() {
          return{
              result: [],
              mult: false,
              downLoading: false,
              upLoading: false,
              finished: false,
              error: false,
              list: [],
              offset: 1,
              show: false
          }
      },
      created() {
          if(this.$store.state.list.length > 0) {
              this.list = this.$store.state.list;
          }else{
              console.log(this.$route.params)
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "demandInterfaceList";
</style>
