import DemandInterface from './DemandInterfaceList.vue'

export default DemandInterface
