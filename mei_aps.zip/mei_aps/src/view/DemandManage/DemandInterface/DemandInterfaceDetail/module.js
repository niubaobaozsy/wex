export function backToDemandInterfaceList() {
  this.$router.go(-1);
}
