<template>
  <div style="padding: 47px 0 0">
    <van-nav-bar title="需求接口订单详情" left-arrow fixed left-text="返回" @click-left="backToDemandInterfaceList"></van-nav-bar>
    <div class="order-num item-common">
      <span class="item-title">订单号：</span>
      <span class="item-value">MO-678481</span>
    </div>
    <div class="order-line-num item-common">
      <span class="item-title">订单行号：</span>
      <span class="item-value">1</span>
    </div>
    <div class="material-code item-common">
      <span class="item-title">物料编码：</span>
      <span class="item-value">62759-67848101</span>
    </div>
    <div class="material-desc item-common">
      <span class="item-title">物料描述：</span>
      <span class="item-value">N 批量整机 商用微波炉 EM025F-S0SA00 JT外观 TMO-1000E HH-KG 哥伦比亚 120V,1Ph 60Hz</span>
    </div>
    <div class="order-type item-common">
      <span class="item-title">订单类型：</span>
      <span class="item-value">样机订单</span>
    </div>
    <div class="demand-date item-common">
      <span class="item-title">需求日期：</span>
      <span class="item-value">2019-03-05</span>
    </div>
    <div class="customer item-common">
      <span class="item-title">客户：</span>
      <span class="item-value">FW-MD(US</span>
    </div>
    <div class="all-count item-common">
      <span class="item-title">数量：</span>
      <span class="item-value">300</span>
    </div>
    <div class="status item-common">
      <span class="item-title">状态：</span>
      <span class="item-value">更新</span>
    </div>
    <div class="sales-man item-common">
      <span class="item-title">业务员：</span>
      <span class="item-value">黄嘉伟</span>
    </div>
    <div class="from-system item-common">
      <span class="item-title">来源系统：</span>
      <span class="item-value">GOMS</span>
    </div>
    <div class="warn-msg item-common">
      <span class="item-title">警告信息：</span>
      <span class="item-value">已下达工单，更新失败1</span>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'DemandInterfaceDetail',
      data() {
          return{

          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "demandInterfaceDetail";
</style>
