import DemandInterfaceDetail from './DemandInterfaceDetail.vue'

export default DemandInterfaceDetail
