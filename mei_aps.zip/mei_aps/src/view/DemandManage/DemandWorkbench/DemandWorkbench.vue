<template>
  <div style="padding: 47px 0 45px;">
    <van-nav-bar left-arrow fixed title="需求工作台查询" left-text="返回" @click-left="backToHome">
      <nav-bar-select v-model="factoryCode" :options="list" slot="right"></nav-bar-select>
    </van-nav-bar>
    <code-search require text="物料编码" :url="url" type="material" @getCodeData="getMaterialCode"></code-search>
    <div class="order-num common-list-style">
      <span class="common-font-style">订单号</span>
      <span class="code"><input type="text" placeholder="请输入订单号" v-model="orderNum"></span>
    </div>
    <date require @showValue="getDemandDate"></date>
    <div class="demand-from common-list-style">
      <span class="common-font-style">需求来源<em>*</em></span>
      <span class="code"><input type="text" placeholder="请输入需求来源" v-model="demandFrom"></span>
    </div>
    <div class="demand-state common-list-style">
      <span class="common-font-style">需求状态</span>
      <span class="code"><input type="text" placeholder="请输入需求状态" v-model="demandState"></span>
    </div>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="toDemandWorkbenchList">查询</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  import NavBarSelect from '../../../components/NavBarSelect'
  import CodeSearch from '../../../components/CodeSearch'
  import Date from '../../../components/Date'
  export default{
      name: 'DemandWorkbench',
      components: { NavBarSelect, CodeSearch, Date },
      data() {
          return{
              list: [
                  {text: 'M01顺德工厂', value: 'M01'},
                  {text: 'M04芜湖工厂', value: 'M04'},
                  {text: 'M09南沙工厂', value: 'M09'}
              ],
              factoryCode: 'M01',
              url: 'www.baidu.com',
              orderNum: '',
              startDate: this.$common.formatDate(''),
              endDate: this.$common.formatDate(''),
              demandFrom: '',
              demandState: '',
              materialCode: ''
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "demandWorkbench";
</style>
