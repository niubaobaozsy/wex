export function backToHome() {
  this.$router.go(-1);
}

export function getMaterialCode(value) {
  this.materialCode = value;
}

export function getDemandDate(data) {
  if(data.type === 'start'){
    this.startDate = data.value;
  }else{
    this.endDate = data.value
  }
}

export function toDemandWorkbenchList() {
  let data = {
    materialCode: this.materialCode,
    orderNum: this.orderNum,
    startDate: this.startDate,
    endDate: this.endDate,
    demandFrom: this.demandFrom,
    demandState: this.demandState
  }
  this.$store.commit('DEMAND_WORKBENCH_INFO', data);
  this.$router.push({ name: 'DemandWorkbenchList', params: data })
}
