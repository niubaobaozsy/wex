export function backToDemandWorkbenchList() {
  this.$router.go(-1);
}

export function toHistoryRecord() {
  this.$router.push({ name: 'HistoryRecord' })
}
