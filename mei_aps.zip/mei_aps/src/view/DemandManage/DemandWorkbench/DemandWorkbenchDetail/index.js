import DemandWorkbenchDetail from './DemandWorkbenchDetail.vue'

export default DemandWorkbenchDetail
