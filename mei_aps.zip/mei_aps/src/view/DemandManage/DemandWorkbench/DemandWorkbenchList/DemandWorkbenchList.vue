<template>
  <div>
    <van-nav-bar left-arrow fixed title="需求工作台" left-text="返回" @click-left="backToDemandWorkbench"></van-nav-bar>
    <van-pull-refresh v-model="downLoading" @refresh="onRefresh">
      <div class="item-list" style="margin: 57px 10px 0; min-height: calc(100vh - 57px - 45px)">
          <van-list v-model="upLoading" :finished="finished" :offset="offset" finished-text="没有更多了" :error.sync="error" error-text="请求失败，点击重新加载" @load="onLoad">
            <div class="item" @click="toDetail()" v-for="(item, index) in list" :key="index">
              <div class="item-top">
                <div class="item-num">{{item.num}}</div>
                <div class="item-status">{{item.status}}</div>
                <div v-if="mult" class="item-status status-special">警告</div>
              </div>
              <div class="item-middle">{{item.desc}}</div>
              <div class="item-bottom">
                <span>{{item.line}}</span>
                <span>{{item.time}}</span>
                <span>{{item.count}}</span>
              </div>
            </div>
          </van-list>
      </div>
    </van-pull-refresh>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'DemandWorkbenchList',
      data() {
          return{
              downLoading: false,
              upLoading: false,
              finished: false,
              offset: 1,
              error: false,
              list: [],
              mult: false
          }
      },
      created() {
          console.log(this.$route.params)
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "demandWorkbenchList.scss";
</style>
