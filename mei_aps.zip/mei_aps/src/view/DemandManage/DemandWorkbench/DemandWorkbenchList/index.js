import DemandWorkbenchList from './DemandWorkbenchList.vue'

export default DemandWorkbenchList
