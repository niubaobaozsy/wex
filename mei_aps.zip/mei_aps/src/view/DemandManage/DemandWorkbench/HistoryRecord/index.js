import HistoryRecord from './HistoryRecord.vue'

export default HistoryRecord
