<template>
  <div style="padding: 47px 0 0">
    <van-nav-bar left-arrow fixed title="需求历史记录" left-text="返回" @click-left="backToDemandWorkbenchDetail"></van-nav-bar>
    <div class="item" style="margin-bottom: 10px">
      <div class="item-top">
        <div class="item-num">MO-678481</div>
        <div class="item-status">新增</div>
      </div>
      <div class="item-middle">62759-67848101  N 批量整机 商用微波炉 EM025F-S0SA00</div>
      <div class="item-bottom">
        <span>11-19</span>
        <span>FW-MD(US)</span>
        <span>300</span>
      </div>
    </div>
    <van-steps direction="vertical" :active="0" style="background-color: #29293c">
      <van-step>
        <p>【2018-11-21 14:21:15】   订单关闭</p>
      </van-step>
      <van-step>
        <p>【2018-11-20 14:21:15】   工单完成</p>
      </van-step>
      <van-step>
        <p>【2018-11-04 10:21:15】   发放工单</p>
      </van-step>
      <van-step>
        <p>【2018-11-03 17:21:15】   排产发布，计划开始时间为2018-11-21 14:21:15，生产线为PZZ0ZZ01</p>
      </van-step>
      <van-step>
        <p>【2018-11-03 15:21:15】   下达工单，工单号 JMO-67848101</p>
      </van-step>
      <van-step>
        <p>【2018-11-03 14:21:15】   引入跟单件工作台</p>
      </van-step>
      <van-step>
        <p>【2018-11-03 11:21:15】   需求拆分，项目号MO-678481.1-1 数量100，项目号MO-678481.1-2 数量200</p>
      </van-step>
      <van-step>
        <p>【2018-11-03 10:21:15】  订单引入需求工作台</p>
      </van-step>
      <van-step>
        <p>【2018-11-03 9:10:12】   订单引入需求接口</p>
      </van-step>
    </van-steps>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'HistoryRecord',
      data() {
          return{

          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "historyRecord.scss";
</style>
