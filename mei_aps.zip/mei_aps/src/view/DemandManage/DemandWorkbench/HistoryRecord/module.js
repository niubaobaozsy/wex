export function backToDemandWorkbenchDetail() {
  this.$router.go(-1)
}
