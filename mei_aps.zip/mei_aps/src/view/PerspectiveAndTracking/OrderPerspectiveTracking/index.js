import Index from './Index.vue'

export default Index
