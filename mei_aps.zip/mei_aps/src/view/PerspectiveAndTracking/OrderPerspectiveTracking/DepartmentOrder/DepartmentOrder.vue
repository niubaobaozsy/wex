<template>
  <div style="padding: 45px 0 0; background-color: #252736; min-height: 100vh">
    <van-nav-bar left-arrow fixed left-text="返回" title="部装工单" @click-left="back"></van-nav-bar>
    <div class="detail-common">
      <span>部装工单名称</span>
      <span>QNF007343307N01</span>
    </div>
    <div class="detail-common">
      <span>装配件</span>
      <span>1212321312321321</span>
    </div>
    <div class="detail-common">
      <span>装配件描述</span>
      <span>这里是装配件描述</span>
    </div>
    <div class="detail-common">
      <span>数量</span>
      <span>10件</span>
    </div>
    <div class="detail-common" :class="{'expand-none-border' : completedNumExpand}" @click="completedNumExpand=!completedNumExpand">
      <span>完工数量</span>
      <span :class="[completedNumExpand? 'detail-collapse' : 'detail-expand']">10件</span>
    </div>
    <div v-if="completedNumExpand" class="expand-item">
      <div>
        <span>交付时间</span>
        <span>交易数量</span>
      </div>
      <div>
        <span>2015-03-28</span>
        <span>8</span>
      </div>
      <div>
        <span>2015-05-04</span>
        <span>1</span>
      </div>
    </div>
    <div class="detail-common">
      <span>创建日期</span>
      <span>2015-03-28</span>
    </div>
    <div class="detail-common">
      <span>工单开始日期</span>
      <span>2015-03-28</span>
    </div>
    <div class="detail-common">
      <span>工单完成日期</span>
      <span>2015-04-12</span>
    </div>
    <div class="detail-common" style="border: none">采购单</div>
    <Table stripe :columns="columns" :data="data" @on-row-click="toPurchaseOrderDetail"></Table>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'DepartmentOrder',
      data() {
          return{
              completedNumExpand: false,
              columns: [
                  {
                      title: '采购编码',
                      key: 'purchaseCode',
                      align: 'center',
                      width: 180
                  },
                  {
                      title: '行号',
                      key: 'lineNum',
                      align: 'center',
                      width: 70
                  },
                  {
                      title: '物料编码',
                      key: 'materialCode',
                      align: 'center',
                      width: 140
                  },
                  {
                      title: '订单数量',
                      key: 'orderNum',
                      align: 'center',
                      width: 95
                  },
                  {
                      title: '接收数量',
                      key: 'receiveNum',
                      align: 'center',
                      width: 95
                  }
              ],
              data: [
                  {
                      purchaseCode: 'P4PQNF00734307011',
                      lineNum: 10,
                      materialCode: '1512300000412',
                      orderNum: 10,
                      receiveNum: 10
                  },
                  {
                      purchaseCode: 'P4PQNF00734307011',
                      lineNum: 10,
                      materialCode: '1512300000412',
                      orderNum: 10,
                      receiveNum: 10
                  },
                  {
                      purchaseCode: 'P4PQNF00734307011',
                      lineNum: 10,
                      materialCode: '1512300000412',
                      orderNum: 10,
                      receiveNum: 10
                  },
                  {
                      purchaseCode: 'P4PQNF00734307011',
                      lineNum: 10,
                      materialCode: '1512300000412',
                      orderNum: 10,
                      receiveNum: 10
                  }
              ]
          }
      },
      created() {
          console.log(this.$route.params)
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "departmentOrder.scss";
</style>
