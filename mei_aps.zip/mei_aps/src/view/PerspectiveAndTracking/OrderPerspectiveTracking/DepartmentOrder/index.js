import DepartmentOrder from './DepartmentOrder.vue'

export default DepartmentOrder
