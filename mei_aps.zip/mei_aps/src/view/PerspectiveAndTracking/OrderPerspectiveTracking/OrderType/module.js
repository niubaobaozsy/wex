export function back() {
  this.$router.go(-1);
}

export function getData() {

}
