import OrderType from './OrderType.vue'

export default OrderType
