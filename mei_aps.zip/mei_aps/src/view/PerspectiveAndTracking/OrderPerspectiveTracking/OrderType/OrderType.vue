<template>
  <div style="padding: 45px 0; background-color: #313244; min-height: 100vh">
    <van-nav-bar left-arrow fixed left-text="返回" :title="title" @click-left="back"></van-nav-bar>
    <div class="type-common" :class="[selfClass]">
      <span>{{text}}<strong>{{num}}</strong></span>
      <span>占比<strong>{{rate}}</strong></span>
    </div>
    <Table stripe :columns="columns" :data="data"></Table>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'OrderType',
      data() {
          return{
              title: '',
              selfClass: `${this.$route.params.type}-self`,
              text: '',
              num: 100,
              rate: '7.69%',
              columns: [
                  {
                      title: '需求单号',
                      key: 'demandOrderNum',
                      align: 'center',
                      width: 145
                  },
                  {
                      title: '行号',
                      key: 'lineNum',
                      align: 'center',
                      width: 65
                  },
                  {
                      title: '需求数量',
                      key: 'demandNum',
                      align: 'center',
                      width: 95
                  },
                  {
                      title: '需求日期',
                      key: 'demandDate',
                      align: 'center',
                      width: 110
                  }
              ],
              data: [
                  {
                      demandOrderNum: 'MO-1212323232',
                      lineNum: 5,
                      demandNum: 188,
                      demandDate: '2015-04-30'
                  },
                  {
                      demandOrderNum: 'MO-1212323232',
                      lineNum: 3,
                      demandNum: 188,
                      demandDate: '2015-04-30'
                  },
                  {
                      demandOrderNum: 'MO-1212323232',
                      lineNum: 2,
                      demandNum: 188,
                      demandDate: '2015-04-30'
                  },
                  {
                      demandOrderNum: 'MO-1212323232',
                      lineNum: 1,
                      demandNum: 188,
                      demandDate: '2015-04-30'
                  }
              ]
          }
      },
      created() {
          switch(this.$route.params.type){
            case 'ordered':
                this.title = '已下单订单行';
                this.text = '已下单';
                break;
            case 'undone':
                this.title = '未发放订单行';
                this.text = '未发放';
                break;
            case 'producting':
                this.title = '生产中订单行';
                this.text = '生产中'
                break;
          }
          this.getData();
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "orderType";
</style>
