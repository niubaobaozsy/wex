import OrderCycle from './OrderCycle.vue'

export default OrderCycle
