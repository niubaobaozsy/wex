export function back() {
  this.$router.go(-(this.$store.state.backToHomeCount + 1));
}

export function drawBar() {
  let bar = this.$echarts.init(document.getElementById('bar'));
  let option = {
    color: ['#3398DB'],
    tooltip : {
      trigger: 'axis',
      axisPointer : {            // 坐标轴指示器，坐标轴触发有效
        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
      }
    },
    grid: {
      left: '3%',
      right: '5%',
      bottom: '3%',
      top: '10%',
      containLabel: true
    },
    xAxis : [
      {
        type : 'category',
        data : ['武汉工厂', '重庆工厂', '邯郸工厂', '芜湖美智', '顺德工厂', '广州工厂'],
        axisLine: {
          lineStyle: {
            color: '#fff'
          }
        },
        axisTick: {
          alignWithLabel: true
        },
        axisLabel:{
          interval: 0,
          rotate: 20
        }
      }
    ],
    yAxis : [
      {
        type : 'value',
        axisLine: {
          lineStyle: {
            color: '#fff'
          }
        }
      }
    ],
    series : [
      {
        type:'bar',
        barWidth: '60%',
        data:[10, 10, 12, 14, 16, 17],
        label:{
          normal:{
            show: true,
            position: 'top',
            color: '#fff'
          }
        },
        markLine: {
          data: [
            {
              name: '目标值',
              yAxis: 15,
              lineStyle:{
                normal:{
                  color: '#F96A42',
                  width: 2,
                  type: 'solid'
                }
              }
            }
          ]
        }
      }
    ]
  }
  bar.setOption(option);
}

export function showSelect() {
  this.selectShow = !this.selectShow;
}

export function selectOption(item, index) {
  this.timeType = item.text;
  this.currentIndex = index;
  this.selectShow = false;
}

export function showDatePopup() {
  this.dateshow = true;
}

export function formatter(type, value) {
  if (type === 'year') {
    return `${value}年`;
  } else if (type === 'month') {
    return `${value}月`
  } else if (type === 'day') {
    return `${value}日`
  }
  return value;
}

export function closeDatePopup() {
  this.dateshow = false;
}

export function selectDate(value) {
  this.time = this.$common.formatDate(value);
  this.dateshow = false;
}

export function toFactoryOrderCycle(data, index) {
  this.$router.push({ name: 'FactoryOrderCycle', params: data });
}
