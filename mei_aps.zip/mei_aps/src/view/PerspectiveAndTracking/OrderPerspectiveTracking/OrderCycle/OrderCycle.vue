<template>
  <div>
    <van-nav-bar left-arrow fixed left-text="返回" title="订单周期" @click-left="back"></van-nav-bar>
    <div class="due-time">
      <span>交付时间</span>
      <span @click="showSelect">{{timeType}}</span>
      <span>{{date | monthFormat}}</span>
      <ul v-if="selectShow">
        <li v-for="(item, index) in options" :key="index" :class="{'current': currentIndex===index}" @click="selectOption(item, index)">{{item.text}}</li>
      </ul>
    </div>
    <div class="data-date" @click="showDatePopup">{{time | dateFormat}}&nbsp;&nbsp;&nbsp;数据</div>
    <van-popup v-model="dateshow" position="bottom">
      <van-datetime-picker v-model="dataDate" :min-date="minDate" :max-date="maxDate" type="date" :formatter="formatter" @cancel="closeDatePopup" @confirm="selectDate"></van-datetime-picker>
    </van-popup>
    <div id="bar"></div>
    <Table stripe :columns="columns" :data="data" @on-row-click="toFactoryOrderCycle"></Table>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'OrderCycle',
      data() {
          return{
              timeType: '本月',
              date: this.$common.formatDate(''),
              selectShow: false,
              options: [
                  {text: '本月', value: 'month'},
                  {text: '两周', value: 'twoWeeks'},
                  {text: '本周', value: 'week'}
              ],
              time: this.$common.formatDate(''),
              currentIndex: 0,
              dateshow: false,
              dataDate: new Date(),
              maxDate: new Date(this.$common.formatDate('')), //可查数据的最大时间
              minDate: new Date('2019/03/08'), //可查数据的最小时间
              columns: [
                  {
                      title: '排名',
                      type: 'index',
                      align: 'center'
                  },
                  {
                      title: '工厂',
                      key: 'factory',
                      align: 'center'
                  },
                  {
                      title: '目标值',
                      key: 'target',
                      align: 'center'
                  },
                  {
                      title: '实际达成',
                      key: 'completed',
                      align: 'center'
                  }
              ],
              data: [
                  {
                      factory: '武汉工厂',
                      target: 15,
                      completed: 10
                  },
                  {
                      factory: '重庆工厂',
                      target: 15,
                      completed: 10
                  },
                  {
                      factory: '邯郸工厂',
                      target: 15,
                      completed: 12
                  },
                  {
                      factory: '芜湖美智',
                      target: 15,
                      completed: 14
                  },
                  {
                      factory: '顺德工厂',
                      target: 15,
                      completed: 16
                  },
                  {
                      factory: '广州工厂',
                      target: 15,
                      completed: 17
                  }
              ]
          }
      },
      filters: {
          dateFormat: function (value) {
              return `${new Date(value).getFullYear()}年${new Date(value).getMonth() + 1}月${new Date(value).getDate()}日`
          },
          monthFormat: function (value) {
              return `${new Date(value).getFullYear()}年${new Date().getMonth() + 1}月`
          }
      },
      mounted() {
          this.drawBar();
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "orderCycle.scss";
</style>
