export function back() {
  this.$router.go(-1);
}

export function toLineDetail(item, index) {
  this.$router.push({name: 'LineDetail', params: item})
}
