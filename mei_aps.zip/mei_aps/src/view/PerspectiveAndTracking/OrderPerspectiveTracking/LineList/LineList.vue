<template>
  <div style="padding: 45px 0; background-color: #252736; min-height: 100vh">
    <van-nav-bar left-arrow fixed left-text="返回" title="行列表" @click-left="back"></van-nav-bar>
    <Table stripe :columns="columns" :data="data" @on-row-click="toLineDetail"></Table>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'LineList',
      data() {
          return{
              columns: [
                  {
                      title: '需求单号',
                      key: 'demandOrderNum',
                      align: 'center',
                      width: 145,
                      fixed: 'left'
                  },
                  {
                      title: '行号',
                      key: 'lineNum',
                      align: 'center',
                      width: 65
                  },
                  {
                      title: '需求数量',
                      key: 'demandNum',
                      align: 'center',
                      width: 95
                  },
                  {
                      title: '需求日期',
                      key: 'demandDate',
                      align: 'center',
                      width: 110
                  },
                  {
                      title: '状态',
                      key: 'state',
                      align: 'center',
                      width: 80
                  }
              ],
              data: [
                  {
                      demandOrderNum: 'M0-1212323232',
                      lineNum: 1,
                      demandNum: 122,
                      demandDate: '2015/04/30',
                      state: '已完成'
                  },
                  {
                      demandOrderNum: 'MO-1212323232',
                      lineNum: 2,
                      demandNum: 123,
                      demandDate: '2015/03/31',
                      state: '已完成'
                  },
                  {
                      demandOrderNum: 'MO-1212323232',
                      lineNum: 3,
                      demandNum: 57,
                      demandDate: '2015/04/01',
                      state: '未发放'
                  },
                  {
                      demandOrderNum: 'MO-1212323232',
                      lineNum: 4,
                      demandNum: 66,
                      demandDate: '2015/04/02',
                      state: '生产中'
                  },
                  {
                      demandOrderNum: 'MO-1212323232',
                      lineNum: 5,
                      demandNum: 77,
                      demandDate: '2015/04/03',
                      state: '已下单'
                  }
              ]
          }
      },
      created() {
          console.log(this.$route.params);
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "lineList.scss";
</style>
