export function tabBarSwitch(which) {
  if(this.lastTab !== which){
    this.$store.commit('BACK_TO_HOME_COUNT')
    this.lastTab = which;
  }
  let obj = {};
  switch (which){
    case 'job':
      this.jobPath = require('./image/job-perspective-selected-icon.svg');
      this.orderPath = require('./image/order-perspective-icon.svg');
      this.queryPath = require('./image/order-query-icon.svg');
      this.cyclePath = require('./image/order-cycle-icon.svg')
      this.jobCurrent = true;
      this.orderCurrent = false;
      this.queryCurrent = false;
      this.cycleCurrent = false;
      this.$router.push({ name: 'JobPerspective' });
      break;
    case 'order':
      this.jobPath = require('./image/job-perspective-icon.svg');
      this.orderPath = require('./image/order-perspective-selected-icon.svg');
      this.queryPath = require('./image/order-query-icon.svg');
      this.cyclePath = require('./image/order-cycle-icon.svg');
      this.jobCurrent = false;
      this.orderCurrent = true;
      this.queryCurrent = false;
      this.cycleCurrent = false;
      this.$router.push({ name: 'OrderPerspective' });
      break;
    case 'query':
      this.jobPath = require('./image/job-perspective-icon.svg');
      this.orderPath = require('./image/order-perspective-icon.svg');
      this.queryPath = require('./image/order-query-selected-icon.svg');
      this.cyclePath = require('./image/order-cycle-icon.svg');
      this.jobCurrent = false;
      this.orderCurrent = false;
      this.queryCurrent = true;
      this.cycleCurrent = false;
      this.$router.push({ name: 'OrderQuery' });
      break;
    case 'cycle':
      this.jobPath = require('./image/job-perspective-icon.svg');
      this.orderPath = require('./image/order-perspective-icon.svg');
      this.queryPath = require('./image/order-query-icon.svg');
      this.cyclePath = require('./image/order-cycle-selected-icon.svg');
      this.jobCurrent = false;
      this.orderCurrent = false;
      this.queryCurrent = false;
      this.cycleCurrent = true;
      this.$router.push({ name: 'OrderCycle' });
      break;
  }
  obj.jobPath = this.jobPath;
  obj.orderPath = this.orderPath;
  obj.queryPath = this.queryPath;
  obj.cyclePath = this.cyclePath;
  obj.jobCurrent = this.jobCurrent;
  obj.orderCurrent = this.orderCurrent;
  obj.queryCurrent = this.queryCurrent;
  obj.cycleCurrent = this.cycleCurrent;
  this.$store.commit('ORDER_PERSPECTIVE_TRACKING_TAB_RECORD', obj);
}
