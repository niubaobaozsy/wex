<template>
  <div style="padding: 45px 0 0; background-color: #252736; min-height: 100vh">
    <van-nav-bar left-arrow fixed left-text="返回" title="工单详情" @click-left="back"></van-nav-bar>
    <div class="detail-common">
      <span>工单名称</span>
      <span>QNF007343307N01</span>
    </div>
    <div class="detail-common" :class="{'expand-none-border': orderNumExpand}" @click="orderNumExpand=!orderNumExpand">
      <span>工单数量</span>
      <span :class="[orderNumExpand? 'detail-collapse' : 'detail-expand']">10台</span>
    </div>
    <div v-if="orderNumExpand" class="expand-item">
      <div>
        <span>交付时间</span>
        <span>交易数量</span>
      </div>
      <div>
        <span>2015-03-28</span>
        <span>8</span>
      </div>
      <div>
        <span>2015-05-04</span>
        <span>1</span>
      </div>
    </div>
    <div class="detail-common">
      <span>工单创建时间</span>
      <span>2015-03-28 08:56:13</span>
    </div>
    <div class="detail-common">
      <span>工单完工时间</span>
      <span>2015-03-29 08:56:13</span>
    </div>
    <div class="detail-common" :class="{'expand-none-border': purchaseOrderExpand}" @click="purchaseOrderExpand=!purchaseOrderExpand">
      <span>采购单</span>
      <span :class="[purchaseOrderExpand? 'detail-collapse' : 'detail-expand']" style="height: 22px"></span>
    </div>
    <Table v-if="purchaseOrderExpand" stripe :columns="purchaseColumns" :data="purchaseData" @on-row-click="toPurchaseOrderDetail"></Table>
    <div class="detail-common" style="border: none">部装工单列表</div>
    <Table stripe :columns="departmentColumns" :data="departmentData" @on-row-click="toDepartmentOrder"></Table>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'OrderDetail',
      data() {
          return{
              orderNumExpand: false,
              purchaseOrderExpand: false,
              purchaseColumns: [
                  {
                      title: '采购编码',
                      key: 'purchaseCode',
                      align: 'center',
                      width: 180
                  },
                  {
                      title: '行号',
                      key: 'lineNum',
                      align: 'center',
                      width: 70
                  },
                  {
                      title: '物料编码',
                      key: 'materialCode',
                      align: 'center',
                      width: 140
                  },
                  {
                      title: '订单数量',
                      key: 'orderNum',
                      align: 'center',
                      width: 95
                  },
                  {
                      title: '接收数量',
                      key: 'receiveNum',
                      align: 'center',
                      width: 95
                  }
              ],
              purchaseData: [
                  {
                      purchaseCode: 'P4PQNF00734307011',
                      lineNum: 10,
                      materialCode: '1512300000412',
                      orderNum: 10,
                      receiveNum: 10
                  },
                  {
                      purchaseCode: 'P4PQNF00734307011',
                      lineNum: 10,
                      materialCode: '1512300000412',
                      orderNum: 10,
                      receiveNum: 10
                  },
                  {
                      purchaseCode: 'P4PQNF00734307011',
                      lineNum: 10,
                      materialCode: '1512300000412',
                      orderNum: 10,
                      receiveNum: 10
                  },{
                      purchaseCode: 'P4PQNF00734307011',
                      lineNum: 10,
                      materialCode: '1512300000412',
                      orderNum: 10,
                      receiveNum: 10
                  }
              ],
              departmentColumns: [
                  {
                      title: '部装工单名称',
                      key: 'departmentOrderName',
                      align: 'center',
                      width: 120
                  },
                  {
                      title: '状态',
                      key: 'state',
                      align: 'center',
                      width: 90
                  },
                  {
                      title: '装配件',
                      key: 'assembly',
                      align: 'center',
                      width: 140
                  },
                  {
                      title: '数量',
                      key: 'count',
                      align: 'center',
                      width: 90
                  }
              ],
              departmentData: [
                  {
                      departmentOrderName: 'QNF232234',
                      state: '已完成',
                      assembly: '1512300000412',
                      count: 10
                  },
                  {
                      departmentOrderName: 'QNF232234',
                      state: '生产中',
                      assembly: '1512300000412',
                      count: 10
                  }
              ]
          }
      },
      created() {
          console.log(this.$route.params);
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "orderDeatil.scss";
</style>
