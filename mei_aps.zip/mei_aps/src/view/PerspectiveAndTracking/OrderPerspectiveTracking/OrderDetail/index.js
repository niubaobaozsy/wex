import OrderDetail from './OrderDetail.vue'

export default OrderDetail
