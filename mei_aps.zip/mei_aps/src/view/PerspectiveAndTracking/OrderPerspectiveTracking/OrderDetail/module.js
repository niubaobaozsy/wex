export function back() {
 this.$router.go(-1);
}

export function toDepartmentOrder(data) {
  this.$router.push({name: 'DepartmentOrder', params: data})
}

export function toPurchaseOrderDetail(data) {
  this.$router.push({name: 'PurchaseOrderDetail', params: data});
}
