export function back() {
  this.$router.go(-1);
}

export function showSelect() {
  this.selectShow = !this.selectShow;
}

export function selectOption(item, index) {
  this.timeType = item.text;
  this.currentIndex = index;
  this.selectShow = false;
}

export function showDatePopup() {
  this.dateshow = true;
}

export function formatter(type, value) {
  if (type === 'year') {
    return `${value}年`;
  } else if (type === 'month') {
    return `${value}月`
  } else if (type === 'day') {
    return `${value}日`
  }
  return value;
}

export function closeDatePopup() {
  this.dateshow = false;
}

export function selectDate(value) {
  this.time = this.$common.formatDate(value);
  this.dateshow = false;
}

export function draw() {
  let bar = this.$echarts.init(document.getElementById('factory-bar'));
  let option = {
    color: ['#3398DB'],
    tooltip : {
      trigger: 'axis',
      axisPointer : {            // 坐标轴指示器，坐标轴触发有效
        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
      }
    },
    grid: {
      left: '3%',
      right: '5%',
      bottom: '1%',
      top: '9%',
      containLabel: true
    },
    xAxis : [
      {
        type : 'category',
        data : ['3月1日', '3月2日', '3月4日', '3月5日', '3月6日', '3月7日', '3月8日', '3月9日'],
        axisTick: {
          alignWithLabel: true
        },
        axisLine: {
          lineStyle: {
            color: '#fff'
          }
        },
        axisLabel:{
          interval: 0,
          rotate: 20
        }
      }
    ],
    yAxis : [
      {
        type : 'value',
        axisLine: {
          lineStyle: {
            color: '#fff'
          }
        }
      }
    ],
    series : [
      {
        type:'bar',
        barWidth: '60%',
        data:[10, 12, 9, 9, 10, 10, 11, 13],
        label:{
          normal:{
            show: true,
            position: 'top',
            color: '#fff'
          }
        },
        markLine: {
          data: [
            {
              name: '目标值',
              yAxis: 15,
              lineStyle:{
                normal:{
                  color: '#F96A42',
                  width: 2,
                  type: 'solid'
                }
              }
            }
          ]
        }
      }
    ]
  }
  bar.setOption(option);
}
