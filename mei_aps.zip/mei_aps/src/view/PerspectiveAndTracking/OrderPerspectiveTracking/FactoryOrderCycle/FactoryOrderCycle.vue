<template>
  <div style="padding: 47px 0 0">
    <van-nav-bar left-arrow fixed left-text="返回" :title="title" @click-left="back"></van-nav-bar>
    <div class="due-time">
      <span>交付时间</span>
      <span @click="showSelect">{{timeType}}</span>
      <span>{{date | monthFormat}}</span>
      <ul v-if="selectShow">
        <li v-for="(item, index) in options" :key="index" :class="{'current': currentIndex===index}" @click="selectOption(item, index)">{{item.text}}</li>
      </ul>
    </div>
    <div class="data-date" @click="showDatePopup">{{time | dateFormat}}&nbsp;&nbsp;&nbsp;数据</div>
    <van-popup v-model="dateshow" position="bottom">
      <van-datetime-picker v-model="dataDate" :min-date="minDate" :max-date="maxDate" type="date" :formatter="formatter" @cancel="closeDatePopup" @confirm="selectDate"></van-datetime-picker>
    </van-popup>
    <div id="factory-bar"></div>
    <Table stripe :columns="columns" :data="data"></Table>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'FactoryOrderCycle',
      data() {
          return{
              title: '',
              timeType: '本月',
              date: this.$common.formatDate(''),
              selectShow: false,
              options: [
                  {text: '本月', value: 'month'},
                  {text: '两周', value: 'twoWeeks'},
                  {text: '本周', value: 'week'}
              ],
              time: this.$common.formatDate(''),
              currentIndex: 0,
              dateshow: false,
              dataDate: new Date(),
              maxDate: new Date(this.$common.formatDate('')), //可查数据的最大时间
              minDate: new Date('2019/03/08'), //可查数据的最小时间
              columns: [
                  {
                      type: 'expand',
                      width: 40,
                      render: (h, params) => {
                          return h('Table', {
                              props: {
//                                  stripe: true,
                                  columns: [
                                      {
                                          title: '统计日期',
                                          key: 'date',
                                          align: 'center',
                                          width: 95
                                      },
                                      {
                                          title: '订单号',
                                          key: 'orderNum',
                                          align: 'center',
                                          width: 110,
                                          fixed: 'left'
                                      },
                                      {
                                          title: '订单生产周期',
                                          key: 'orderProductionCycle',
                                          align: 'center',
                                          width: 120
                                      },
                                      {
                                          title: '订单导入日期',
                                          key: 'orderImportDate',
                                          align: 'center',
                                          width: 120
                                      },
                                      {
                                          title: '完工日期',
                                          key: 'completedDate',
                                          align: 'center',
                                          width: 100
                                      },
                                      {
                                          title: '订单数量',
                                          key: 'orderCount',
                                          align: 'center',
                                          width: 100
                                      },
                                      {
                                          title: '订单完工数量',
                                          key: 'completedOrderCount',
                                          align: 'center',
                                          width: 120
                                      }
                                  ],
                                  data: [
                                      {
                                          date: '3月1日',
                                          orderNum: '云浮01',
                                          orderProductionCycle: 9,
                                          orderImportDate: '2月19日',
                                          completedDate: '2月28日',
                                          orderCount: 500,
                                          completedOrderCount: 500
                                      },
                                      {
                                          date: '3月1日',
                                          orderNum: '云浮13',
                                          orderProductionCycle: 8,
                                          orderImportDate: '2月20日',
                                          completedDate: '2月28日',
                                          orderCount: 500,
                                          completedOrderCount: 500
                                      },
                                      {
                                          date: '3月1日',
                                          orderNum: '武汉3',
                                          orderProductionCycle: 9,
                                          orderImportDate: '2月18日',
                                          completedDate: '2月27日',
                                          orderCount: 500,
                                          completedOrderCount: 0
                                      },
                                      {
                                          date: '3月1日',
                                          orderNum: '云浮02',
                                          orderProductionCycle: 12,
                                          orderImportDate: '2月15日',
                                          completedDate: '2月27日',
                                          orderCount: 500,
                                          completedOrderCount: 500
                                      },
                                      {
                                          date: '3月1日',
                                          orderNum: '武汉2',
                                          orderProductionCycle: 14,
                                          orderImportDate: '2月13日',
                                          completedDate: '2月27日',
                                          orderCount: 500,
                                          completedOrderCount: 0
                                      },
                                      {
                                          date: '3月1日',
                                          orderNum: 'CTEST4100011',
                                          orderProductionCycle: 10,
                                          orderImportDate: '2月17日',
                                          completedDate: '2月27日',
                                          orderCount: 4460,
                                          completedOrderCount: 0
                                      },
                                      {
                                          date: '3月1日',
                                          orderNum: '云浮06',
                                          orderProductionCycle: 10,
                                          orderImportDate: '2月17日',
                                          completedDate: '2月27日',
                                          orderCount: 500,
                                          completedOrderCount: 0
                                      },
                                      {
                                          date: '3月1日',
                                          orderNum: '云浮11',
                                          orderProductionCycle: 10,
                                          orderImportDate: '2月17日',
                                          completedDate: '2月27日',
                                          orderCount: 500,
                                          completedOrderCount: 0
                                      },
                                      {
                                          date: '3月1日',
                                          orderNum: '云浮16',
                                          orderProductionCycle: 10,
                                          orderImportDate: '2月17日',
                                          completedDate: '2月27日',
                                          orderCount: 500,
                                          completedOrderCount: 0
                                      }
                                  ]
                              }
                          })
                      }
                  },
                  {
                      title: '统计时间',
                      key: 'time',
                      align: 'center'
                  },
                  {
                      title: '工厂',
                      key: 'factory',
                      align: 'center'
                  },
                  {
                      title: '目标值',
                      key: 'target',
                      align: 'center'
                  },
                  {
                      title: '实际达成',
                      key: 'completed',
                      align: 'center'
                  }
              ],
              data: [
                  {
                      time: '3月1日',
                      factory: '武汉工厂',
                      target: 15,
                      completed: 10
                  },
                  {
                      time: '3月2日',
                      factory: '武汉工厂',
                      target: 15,
                      completed: 12
                  },
                  {
                      time: '3月4日',
                      factory: '武汉工厂',
                      target: 15,
                      completed: 9
                  },
                  {
                      time: '3月5日',
                      factory: '武汉工厂',
                      target: 15,
                      completed: 9
                  },
                  {
                      time: '3月6日',
                      factory: '武汉工厂',
                      target: 15,
                      completed: 10
                  },
                  {
                      time: '3月7日',
                      factory: '武汉工厂',
                      target: 15,
                      completed: 10
                  },
                  {
                      time: '3月8日',
                      factory: '武汉工厂',
                      target: 15,
                      completed: 11
                  },
                  {
                      time: '3月9日',
                      factory: '武汉工厂',
                      target: 15,
                      completed: 13
                  }
              ]
          }
      },
      created() {
          this.title = this.$route.params.factory;
      },
      mounted() {
          this.draw();
      },
      filters: {
          dateFormat: function (value) {
              return `${new Date(value).getFullYear()}年${new Date(value).getMonth() + 1}月${new Date(value).getDate()}日`
          },
          monthFormat: function (value) {
              return `${new Date(value).getFullYear()}年${new Date().getMonth() + 1}月`
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "factoryOrderCycle.scss";
</style>
<style lang="scss">
  td.ivu-table-expanded-cell{
    padding: 0 !important;
    overflow: scroll;
  }
</style>
