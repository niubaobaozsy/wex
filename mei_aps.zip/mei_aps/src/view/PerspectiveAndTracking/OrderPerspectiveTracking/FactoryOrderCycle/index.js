import FactoryOrderCycle from './FactoryOrderCycle.vue'

export default FactoryOrderCycle
