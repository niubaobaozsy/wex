<template>
  <div style="padding: 45px 0 1.1rem; background-color: #313244; min-height: 100vh">
    <router-view></router-view>
    <div class="tab-bar">
      <span class="job-perspective" :class="{'current': jobCurrent}" @click="tabBarSwitch('job')"><img :src="jobPath" alt="作业透视">作业透视</span>
      <span class="order-perspective" :class="{'current': orderCurrent}" @click="tabBarSwitch('order')"><img :src="orderPath" alt="订单透视">订单透视</span>
      <span class="order-cycle" :class="{'current': cycleCurrent}" @click="tabBarSwitch('cycle')"><img :src="cyclePath" alt="订单周期">订单周期</span>
      <span class="order-query" :class="{'current': queryCurrent}" @click="tabBarSwitch('query')"><img :src="queryPath" alt="订单查询">订单查询</span>
    </div>
  </div>
</template>

<script>
  import * as methods from'./module'
  export default{
      name: 'Index',
      data() {
          return{
              jobPath: require('./image/job-perspective-selected-icon.svg'),
              orderPath: require('./image/order-perspective-icon.svg'),
              queryPath: require('./image/order-query-icon.svg'),
              cyclePath: require('./image/order-cycle-icon.svg'),
              jobCurrent: true,
              orderCurrent: false,
              queryCurrent: false,
              cycleCurrent: false,
              lastTab: 'job'
          }
      },
      created() {
          if(this.$store.state.orderPerspectiveTrackingTabRecord.jobPath != ''){
              this.jobPath = this.$store.state.orderPerspectiveTrackingTabRecord.jobPath;
              this.orderPath = this.$store.state.orderPerspectiveTrackingTabRecord.orderPath;
              this.queryPath = this.$store.state.orderPerspectiveTrackingTabRecord.queryPath;
              this.cyclePath = this.$store.state.orderPerspectiveTrackingTabRecord.cyclePath;
              this.jobCurrent = this.$store.state.orderPerspectiveTrackingTabRecord.jobCurrent;
              this.orderCurrent = this.$store.state.orderPerspectiveTrackingTabRecord.orderCurrent;
              this.queryCurrent = this.$store.state.orderPerspectiveTrackingTabRecord.queryCurrent;
              this.cycleCurrent = this.$store.state.orderPerspectiveTrackingTabRecord.cycleCurrent;
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "index";
</style>
