import OrderQuery from './OrderQuery.vue'

export default OrderQuery
