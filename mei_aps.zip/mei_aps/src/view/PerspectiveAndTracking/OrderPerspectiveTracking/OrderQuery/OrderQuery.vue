<template>
  <div>
    <van-nav-bar left-arrow fixed left-text="返回" @click-left="back" title="订单跟踪"></van-nav-bar>
    <div class="query-common inventory-organization" @click="showOrgPopup">库存组织*
      <input v-model="inventoryOrganization" type="text" readonly placeholder="请选择">
    </div>
    <van-popup v-model="orgShow" position="bottom">
      <!--<van-picker show-toolbar :columns="lists" @cancel="closeOrgPopup" @confirm="confirmOrgSelect"></van-picker>-->
      <div style="background-color: #313244; height: 60vh">
        <div v-for="(item, index) in lists" :key="index" class="popup-common" :class="{'current': index === current}" @click="confirmOrgSelect(item, index)">{{item.text}}</div>
      </div>
    </van-popup>
    <div class="query-common order-code">订单编码
      <input v-model="orderCode" type="text" placeholder="如：G0000247">
    </div>
    <div class="query-common order-cycle" @click="showOrderCyclePopup">下单周期
      <input v-model="orderCycle" type="text" readonly placeholder="请选择">
    </div>
    <div class="button-confirm"><button @click="queryOrder">确认</button></div>
    <van-popup v-model="orderCycleShow" position="bottom">
      <div style="background-color: #313244; height: 60vh">
        <div class="popup-common" :class="{'current': month}" @click="selectCycle('month')">近一月</div>
        <div class="popup-common" :class="{'current': twoWeeks}" @click="selectCycle('twoWeeks')">近两周</div>
        <div class="popup-common" :class="{'current': week}" @click="selectCycle('week')">近一周</div>
        <div class="popup-common" style="border: none; margin-top: 0.4rem">
          <span>开始时间</span>
          <span class="time" @click="showSTPopup">{{startTime}}</span>
          <span>结束时间</span>
          <span class="time" @click="showETPopup">{{endTime}}</span>
        </div>
        <div class="button-confirm"><button @click="confirmOrderCycle">确认</button></div>
      </div>
    </van-popup>
    <van-popup v-model="STShow" position="bottom">
      <van-datetime-picker v-model="currentST" type="date" :formatter="formatter" @cancel="closeSTPopup" @confirm="confirmST"></van-datetime-picker>
    </van-popup>
    <van-popup v-model="ETShow" position="bottom">
      <van-datetime-picker v-model="currentET" type="date" :formatter="formatter" @cancel="closeETPopup" @confirm="confirmET"></van-datetime-picker>
    </van-popup>
  </div>
</template>

<script>
  import * as methods from './module'

  export default{
      name: 'OrderQuery',
      data() {
          return{
              inventoryOrganization: '',
              orderCode: '',
              orderCycle: '',
              orgShow: false,
              lists: [
                  {
                     text: 'INV_M01_广东美的制冷设备有限公司',
                     value: 1
                  },
                  {
                      text: 'INV_M02_广东美的制冷设备有限公司',
                      value: 2
                  },
                  {
                      text: 'INV_M03_广东美的制冷设备有限公司',
                      value: 3
                  },
              ],
              orderCycleShow: false,
              month: false,
              twoWeeks: false,
              week: false,
              cycle: '', //记录周期选择
              startTime: this.$common.formatDate(''),
              endTime: this.$common.formatDate(''),
              STShow: false,
              currentST: new Date(),
              ETShow: false,
              currentET: new Date(),
              current: -1
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "orderQuery.scss";
</style>
