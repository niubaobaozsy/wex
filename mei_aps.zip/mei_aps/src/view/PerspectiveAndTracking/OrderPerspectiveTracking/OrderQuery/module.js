export function back() {
  this.$router.go(-(this.$store.state.backToHomeCount + 1));
}

export function showOrgPopup() {
  this.orgShow = true;
}


export function confirmOrgSelect(data, index) {
  this.inventoryOrganization = data.text;
  this.current = index;
  this.orgShow = false;
}

export function showOrderCyclePopup() {
  this.orderCycleShow = true;
}

export function selectCycle(type) {
  switch (type) {
    case 'month':
      this.month = true;
      this.twoWeeks = false;
      this.week = false;
      this.cycle = '近一月';
      break;
    case 'twoWeeks':
      this.month = false;
      this.twoWeeks = true;
      this.week = false;
      this.cycle = '近两周';
      break;
    case 'week':
      this.month = false;
      this.twoWeeks = false;
      this.week = true;
      this.cycle = '近一周';
      break;
  }
}

export function formatter(type, value) {
  if (type === 'year') {
    return `${value}年`;
  } else if (type === 'month') {
    return `${value}月`
  } else if (type === 'day') {
    return `${value}日`
  }
  return value;
}

export function showSTPopup() {
  this.STShow = true;
}

export function closeSTPopup() {
  this.STShow = false;
}

export function confirmST(value) {
  if(value > new Date(this.endTime)){
    this.$toast('开始时间不能大于结束时间！');
  }else{
    this.startTime = this.$common.formatDate(value);
    this.STShow = false;
  }
}

export function showETPopup() {
  this.ETShow = true;
}

export function closeETPopup() {
  this.ETShow = false;
}

export function confirmET(value) {
  if(new Date(this.startTime) > value){
    this.$toast('开始时间不能大于结束时间！');
  }else{
    this.endTime = this.$common.formatDate(value);
    this.ETShow = false;
  }
}

export function confirmOrderCycle() {
  this.orderCycle = `${this.cycle}  ${this.startTime} - ${this.endTime}`;
  this.orderCycleShow = false;
}

export function queryOrder() {

}
