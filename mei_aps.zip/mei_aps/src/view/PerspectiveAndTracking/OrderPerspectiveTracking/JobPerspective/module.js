export function back() {
  this.$router.go(-(this.$store.state.backToHomeCount + 1));
}

export function showPopup() {
  this.show = true;
}

export function onCancel() {
  this.show = false;
}

export function onConfirm(data) {
  console.log('data',data);
  this.text = data.text;
  this.show = false;
}

export function jobTabSwitch(tab) {
  switch (tab){
    case 'one':
      this.one = true;
      this.two = false;
      this.three = false;
      break;
    case 'two':
      this.two = true;
      this.one = false;
      this.three = false;
      break;
    case 'three':
      this.three = true;
      this.one = false;
      this.two = false;
      break;
  }
}

export function typeTabSwitch(type) {
  switch (type){
    case 'order':
      this.order = true;
      this.production = false;
      break;
    case 'production':
      this.production = true;
      this.order = false;
      break;
  }
}

export function getData() {
  //获取数据函数，传入当前事业部选择，作业率选择，类型选择，时间选择
}

export function dateBack() {
  if(new Date(this.date) <= this.minDate){
    this.$toast('不能低于最小时间');
    return;
  }
  let tempDate = this.date;
  this.date = this.$common.formatDate(new Date(new Date(tempDate).getTime() - 24*60*60*1000));
  this.getData();
}

export function dateForward() {
  if(new Date(this.date) >= this.maxDate){
    this.$toast('不能超过当前日期！');
    return;
  }
  let tempDate = this.date;
  this.date = this.$common.formatDate(new Date(new Date(tempDate).getTime() + 24*60*60*1000));
  this.getData();
}

export function showDatePopup() {
  this.dateshow = true;
}

export function formatter(type, value) {
  if (type === 'year') {
    return `${value}年`;
  } else if (type === 'month') {
    return `${value}月`
  } else if (type === 'day') {
    return `${value}日`
  }
  return value;
}

export function closeDatePopup() {
  this.dateshow = false;
}

export function selectDate(value) {
  this.date = this.$common.formatDate(value);
  this.dateshow = false;
}

export function drawRingDiagram() {
  var ringDiagram = this.$echarts.init(document.getElementById('ring'));
  var option = {
    title: {
      text: "90%",
      subtext: '目标完成',
      itemGap: 5,
      left: 'center',
      top: 'center',
      textStyle: {
        color: "#fff",
        fontSize: 18,
        fontWeight: 'bold'
      },
      subtextStyle: {
        color: "#AEB0BD",
        fontSize: 14,
        fontWeight: 'normal'
      }
    },
    color:['#08AE9A', '#F96A42'],
    tooltip: {
      trigger: 'item',
      formatter: "{a} <br/>{b}: {c} ({d}%)",
      confine: true //将提示框限制在容器内
    },
    series: [
      {
        name:'数据',
        type:'pie',
        radius: ['70%', '95%'],
        avoidLabelOverlap: false, //是否启用防止标签重叠策略，默认开启，在标签拥挤重叠的情况下会挪动各个标签的位置，防止标签间的重叠。
        hoverAnimation: false, //关闭hover在扇区上的放大效果
        // silent: true, //图形是否不响应和触发鼠标时间，默认false
        label: {
          normal: {
            show: false,
            position: 'outside'
          }
        },
        data:[
          {value:721, name:'已完成'},
          {value:3626, name:'未完成'}
        ]
      }
    ]
  };
  ringDiagram.setOption(option);
}
