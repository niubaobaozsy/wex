<template>
  <div>
    <van-nav-bar left-arrow fixed left-text="返回" @click-left="back">
      <span class="nav-bar-title" slot="title" @click="showPopup">{{text}}</span>
    </van-nav-bar>
    <van-popup v-model="show" position="bottom">
      <van-picker show-toolbar :columns="lists" @cancel="onCancel" @confirm="onConfirm"></van-picker>
    </van-popup>
    <div class="job-tab">
      <span :class="{'current': one}" @click="jobTabSwitch('one')">当天作业完成率</span>
      <span :class="{'current': two}" @click="jobTabSwitch('two')">两天作业完成率</span>
      <span :class="{'current': three}" @click="jobTabSwitch('three')">三天作业完成率</span>
      <span></span>
    </div>
    <div class="type-tab">
      <span :class="{'current': order}" @click="typeTabSwitch('order')">工单统计</span>
      <span :class="{'current': production}" @click="typeTabSwitch('production')">产品数量</span>
    </div>
    <div class="data-date" @click="showDatePopup">{{date | dateFormat}}&nbsp;&nbsp;&nbsp;数据</div>
    <van-popup v-model="dateshow" position="bottom">
      <van-datetime-picker v-model="dataDate" :min-date="minDate" :max-date="maxDate" type="date" :formatter="formatter" @cancel="closeDatePopup" @confirm="selectDate"></van-datetime-picker>
    </van-popup>
    <div class="chart-area">
      <div class="fl back" :class="{'disabled': backDisabled}" @click="dateBack" style="height: 3.6rem"></div>
      <div class="fl ring-diagram" style="width: 42.67vw; height:48vw;" id="ring"></div>
      <div class="fl chart-data" style="height: 3.6rem">
        <div class="completed">
          <div class="completed-num">已完成{{completedNum}}</div>
          <div class="completed-rate">{{completedRate}}%</div>
        </div>
        <div class="undone">
          <div class="undone-num">未完成{{undoneNum}}</div>
          <div class="undone-rate">{{undoneRate}}%</div>
        </div>
      </div>
      <div class="fr forward" :class="{'disabled': forwardDisabled}" @click="dateForward" style="height: 3.6rem"></div>
    </div>
    <div class="plan-completed">当天计划完成&nbsp;&nbsp;<span style="font-size: 16px; font-weight: bold; color: #ffffff">{{planCompleted}}</span></div>
    <Table stripe :columns="columns" :data="data"></Table>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'JobPerspective',
      data (){
          return{
              text: '家用空调事业部',
              show: false,
              lists: [
                  {text: '家用空调事业部', value: '1'},
                  {text: '顺德工厂', value: '2'}
              ],
              businessUnit: '记录事业部的当前选择',
              one: true,
              two: false,
              three: false,
              order: true,
              production: false,
              job: '记录作业率的当前选择',
              type: '记录产品，工单的当前选择',
              date: this.$common.formatDate(''),
              backDisabled: false,
              forwardDisabled: true,
              dateshow: false,
              dataDate: new Date(),
              maxDate: new Date(this.$common.formatDate('')), //可查数据的最大时间
              minDate: new Date('2019/03/08'), //可查数据的最小时间
              completedNum: 721,
              completedRate: 16.59,
              undoneNum: 3626,
              undoneRate: 83.41,
              planCompleted: 4347,
              columns: [
                  {
                      title: '排名',
                      type: 'index',
                      width: 70,
                      align: 'center',
//                      renderHeader: (h, params) => {
//                          return h('div',{
//                              style: {
//                                  backgroundColor: '#363652'
//                              }
//                          }, '排名')
//                      }
                  },
                  {
                      title: '工厂',
                      key: 'factory',
                      width: 100,
                      align: 'center',
                      className: 'factory-column',
                      fixed: 'left'
                  },
                  {
                      title: '当天达成率',
                      key: 'dayCompletionRate',
                      width: 130,
                      align: 'center',
                      className: 'rate-column-warning',
                      sortable: true,
                      sortType: 'desc'
                  },
                  {
                      title: '已完成/未完成',
                      key: 'completedAndUndone',
                      width: 125,
                      align: 'center'
                  },
                  {
                      title: '计划完成',
                      key: 'planComplete',
                      width: 110,
                      align: 'center',
                      sortable: true,
//                      sortType: 'desc'
                  }
              ],
              data: [
                  {
                      factory: '武汉工厂',
                      dayCompletionRate: '68.04%',
                      completedAndUndone: '66/31',
                      planComplete: 97
                  },
                  {
                      factory: '芜湖美智',
                      dayCompletionRate: '65.43%',
                      completedAndUndone: '475/251',
                      planComplete: 726
                  },
                  {
                      factory: '邯郸工厂',
                      dayCompletionRate: '42.37%',
                      completedAndUndone: '50/68',
                      planComplete: 118
                  },
                  {
                      factory: '重庆工厂',
                      dayCompletionRate: '37.04%',
                      completedAndUndone: '10/17',
                      planComplete: 27
                  },
                  {
                      factory: '顺德工厂',
                      dayCompletionRate: '30.66%',
                      completedAndUndone: '84/190',
                      planComplete: 274
                  },
                  {
                      factory: '广州工厂',
                      dayCompletionRate: '1.16%',
                      completedAndUndone: '36/3069',
                      planComplete: 3105
                  }
              ]
          }
      },
      filters: {
          dateFormat: function (value) {
              return `${new Date(value).getFullYear()}年${new Date(value).getMonth() + 1}月${new Date(value).getDate()}日`
          }
      },
      watch: {
          'date': function (newVal, oldVal) {
              if(new Date(newVal) >= this.maxDate){
                  this.forwardDisabled = true;
                  if(this.backDisabled){
                      this.backDisabled = false;
                  }
              }else if(new Date(newVal) <= this.minDate){
                  this.backDisabled = true;
                  if(this.forwardDisabled){
                      this.forwardDisabled = false;
                  }
              }else{
                  this.backDisabled = false;
                  this.forwardDisabled = false;
              }
          }
      },
      mounted() {
          this.drawRingDiagram();
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "jobPerspective.scss";
</style>
