import JobPerspective from './JobPerspective.vue'

export default JobPerspective
