import PurchaseOrderDetail from './PurchaseOrderDetail.vue'

export default PurchaseOrderDetail
