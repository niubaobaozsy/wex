<template>
  <div style="padding: 45px 0 0; background-color: #252736; min-height: 100vh">
    <van-nav-bar left-arrow fixed left-text="返回" title="采购单详细信息" @click-left="back"></van-nav-bar>
    <div class="detail-common">
      <span>采购编码</span>
      <span>QNF007343307N01</span>
    </div>
    <div class="detail-common">
      <span>行号</span>
      <span>10</span>
    </div>
    <div class="detail-common">
      <span>订单创建日期</span>
      <span>2015-03-28</span>
    </div>
    <div class="detail-common">
      <span>物料编码</span>
      <span>12200102012321</span>
    </div>
    <div class="detail-common">
      <span>物料描述</span>
      <span>这里是物料描述文字这里是物料描述文字</span>
    </div>
    <div class="detail-common">
      <span>订单数量</span>
      <span>10件</span>
    </div>
    <div class="detail-common">
      <span>接收数量</span>
      <span>10件</span>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'PurchaseOrderDetail',
      data() {
          return{

          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "purchaseOrderDetail.scss";
</style>
