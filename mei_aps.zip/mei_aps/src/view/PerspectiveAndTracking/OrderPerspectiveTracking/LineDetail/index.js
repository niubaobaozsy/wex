import LineDetail from './LineDetail.vue'

export default LineDetail
