<template>
  <div style="padding: 45px 0 0; background-color: #252736; min-height: 100vh">
    <van-nav-bar left-arrow fixed left-text="返回" title="行号详情" @click-left="back"></van-nav-bar>
    <div class="detail-common">
      <span>行号</span>
      <span>1</span>
    </div>
    <div class="detail-common">
      <span>需求单号</span>
      <span>MO-RW-WER</span>
    </div>
    <div class="detail-common">
      <span>下单时间</span>
      <span>2015-04-30 08:00:00</span>
    </div>
    <div class="detail-common">
      <span>客户代码</span>
      <span>G0000271</span>
    </div>
    <div class="detail-common">
      <span>客户名称</span>
      <span>广州苏宁易购</span>
    </div>
    <div class="detail-common">
      <span>销售码</span>
      <span>655333-3232</span>
    </div>
    <div class="detail-common">
      <span>销售码描述</span>
      <span>MIDEA-CE-KFR129393</span>
    </div>
    <div class="detail-common">
      <span>SEIBAN号</span>
      <span>MO-1212323232.1</span>
    </div>
    <div class="detail-common">
      <span>生产码</span>
      <span>62255-0033322323</span>
    </div>
    <div class="detail-common">
      <span>生产描述</span>
      <span>MIDEA-CE-KFR129393</span>
    </div>
    <div class="detail-common" style="border: none">总装工单列表</div>
    <Table stripe :columns="columns" :data="data" @on-row-click="toOrderDetail"></Table>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'LineDetail',
      data() {
          return{
              columns: [
                  {
                      title: '工单名称',
                      key: 'orderName',
                      align: 'center',
                      width: 145
                  },
                  {
                      title: '状态',
                      key: 'state',
                      align: 'center',
                      width: 100
                  },
                  {
                      title: '产线',
                      key: 'productionLine',
                      align: 'center',
                      width: 100
                  },
                  {
                      title: '需求数量',
                      key: 'demandNum',
                      align: 'center',
                      width: 110
                  }
              ],
              data: [
                  {
                      orderName: 'QNF232234',
                      state: '已完成',
                      productionLine: '内一',
                      demandNum: 60
                  },
                  {
                      orderName: 'QNF232234',
                      state: '已完成',
                      productionLine: '内一',
                      demandNum: 60
                  },
                  {
                      orderName: 'QNF232234',
                      state: '已完成',
                      productionLine: '内一',
                      demandNum: 60
                  },
                  {
                      orderName: 'QNF232234',
                      state: '已完成',
                      productionLine: '内一',
                      demandNum: 60
                  }
              ]
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "lineDetail.scss";
</style>
