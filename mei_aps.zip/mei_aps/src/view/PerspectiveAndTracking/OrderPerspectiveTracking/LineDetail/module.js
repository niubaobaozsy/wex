export function back() {
  this.$router.go(-1);
}

export function toOrderDetail(data, index) {
  this.$router.push({name: 'OrderDetail', params: data});
}
