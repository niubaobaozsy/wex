<template>
  <div>
    <van-nav-bar left-arrow fixed left-text="返回" @click-left="back">
      <span class="nav-bar-title" slot="title" @click="showPopup">{{text}}</span>
    </van-nav-bar>
    <van-popup v-model="show" position="bottom">
      <van-picker show-toolbar :columns="lists" @cancel="onCancel" @confirm="onConfirm"></van-picker>
    </van-popup>
    <div class="type-tab">
      <span :class="{'current': production}" @click="typeSwitch('production')">产品透视</span>
      <span :class="{'current': orderLine}" @click="typeSwitch('orderLine')">订单行透视</span>
    </div>
    <div class="due-time">
      <span>交付时间</span>
      <span @click="showSelect">{{timeType}}</span>
      <span>{{date}}</span>
      <ul v-if="selectShow">
        <li v-for="(item, index) in options" :key="index" :class="{'current': currentIndex===index}" @click="selectOption(item, index)">{{item.text}}</li>
      </ul>
    </div>
    <div class="chart-area">
      <div class="fl back" :class="{'disabled': backDisabled}" @click="dateBack" style="height: 5.4rem"></div>
      <div class="fl pie-chart" style="width: 40vw; height:72vw;" id="pie"></div>
      <div class="fl chart-data" style="height: 5.4rem">
        <div class="completed common-style">
          <div class="completed-num item-common-style">已完成{{completedNum}}</div>
          <div class="completed-rate item-common-style">{{completedRate}}%</div>
        </div>
        <div class="order common-style" @click="toOrderType('ordered')">
          <div class="order-num item-common-style">已下单{{orderNum}}</div>
          <div class="order-rate item-common-style">{{orderRate}}%</div>
        </div>
        <div class="undone common-style" @click="toOrderType('undone')">
          <div class="undone-num item-common-style">未发放{{undoneNum}}</div>
          <div class="undone-rate item-common-style">{{undoneRate}}%</div>
        </div>
        <div class="producting common-style" @click="toOrderType('producting')">
          <div class="producting-num item-common-style">生产中{{productingNum}}</div>
          <div class="producting-rate item-common-style">{{productingRate}}%</div>
        </div>
      </div>
      <div class="fr forward" :class="{'disabled': forwardDisabled}" @click="dateForward" style="height: 5.4rem"></div>
    </div>
    <div style="height: 0.2rem"></div>
    <Table stripe :columns="columns" :data="data" @on-row-click="toLineList"></Table>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'OrderPerspective',
      data() {
          return{
              text: '家用空调事业部',
              show: false,
              lists: [
                  {text: '家用空调事业部', value: '1'},
                  {text: '顺德工厂', value: '2'}
              ],
              businessUnit: '记录事业部的当前选择',
              production: true,
              orderLine: false,
              type: '记录产品透视、订单行透视的当前选择',
              timeType: '本月',
              date: '2015.3月',
              options: [
                  {text: '本月', value: 'month'},
                  {text: '两周', value: 'twoWeeks'},
                  {text: '本周', value: 'week'}
              ],
              currentIndex: 0,
              selectShow: false,
              backDisabled: false,
              forwardDisabled: true,
              completedNum: 1000,
              completedRate: 76.92,
              orderNum: 100,
              orderRate: 7.69,
              undoneNum: 100,
              undoneRate: 7.69,
              productingNum: 100,
              productingRate: 7.69,
              columns: [
                  {
                      title: '组织',
                      key: 'org',
                      align: 'center',
                      width: 95,
                      className: 'factory-column',
                      fixed: 'left',
                      sortable: true
                  },
                  {
                      title: '完成率',
                      key: 'completedRate',
                      align: 'center',
                      width: 100,
                      sortable: true,
                      sortType: 'desc'
                  },
                  {
                      title: '已下单/未发放/生产中',
                      key: 'mix',
                      align: 'center',
                      width: 180
                  },
                  {
                      title: '计划完成',
                      key: 'planCompleted',
                      align: 'center',
                      width: 110,
                      sortable: true
                  }
              ],
              data: [
                  {
                      org: '广州工厂',
                      completedRate: '89%',
                      mix: '18/23/28',
                      planCompleted: 1000
                  },
                  {
                      org: '合肥工厂',
                      completedRate: '90%',
                      mix: '18/23/28',
                      planCompleted: 1000
                  },
                  {
                      org: '芜湖工厂',
                      completedRate: '88%',
                      mix: '18/23/28',
                      planCompleted: 1000
                  },
                  {
                      org: '顺德工厂',
                      completedRate: '86%',
                      mix: '18/23/28',
                      planCompleted: 1000
                  },
                  {
                      org: '武汉工厂',
                      completedRate: '74%',
                      mix: '18/23/28',
                      planCompleted: 1000
                  },
                  {
                      org: '重庆工厂',
                      completedRate: '70%',
                      mix: '18/23/28',
                      planCompleted: 1000
                  },
                  {
                      org: '邯郸工厂',
                      completedRate: '65%',
                      mix: '18/23/28',
                      planCompleted: 1000
                  }
              ]
          }
      },
      mounted() {
          this.drawPie();
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "orderPerspective.scss";
</style>
