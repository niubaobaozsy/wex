import OrderPerspective from './OrderPerspective.vue'

export default OrderPerspective
