export function back() {
  this.$router.go(-(this.$store.state.backToHomeCount + 1));
}

export function showPopup() {
  this.show = true;
}

export function onCancel() {
  this.show = false;
}

export function onConfirm(data) {
  console.log('data',data);
  this.text = data.text;
  this.show = false;
}

export function typeSwitch(type) {
  switch (type) {
    case 'production':
      this.production = true;
      this.orderLine = false;
      break;
    case 'orderLine':
      this.orderLine = true;
      this.production = false;
      break;
  }
}

export function showSelect() {
  this.selectShow = !this.selectShow;
}

export function selectOption(item, index) {
  this.timeType = item.text;
  this.currentIndex = index;
  this.selectShow = false;
}
export function dateBack() {

}

export function dateForward() {

}

export function drawPie() {
  let myChart = this.$echarts.init(document.getElementById('pie'));
  let option = {
    title: {
      text: '计划完成1100',
      textStyle: {
        color: "#fff",
        fontSize: 16,
        fontWeight: 'bold'
      },
      left: '14%',
      top: '5%'
    },
    color:['#0582C2', '#08AE9A', '#F96A42', '#FD9C3E'],
    tooltip: {
      trigger: 'item',
      formatter: "{a} <br/>{b}: {c} ({d}%)",
      confine: true //将提示框限制在容器内
    },
    series : [
      {
        name: '订单',
        type: 'pie',
        radius : '95%',
        center: ['50%', '50%'],
        hoverAnimation: false, //关闭hover在扇区上的放大效果
        label: {
          normal: {
            show: false
          }
        },
        data:[
          {value:1000, name:'已完成'},
          {value:100, name:'已下单'},
          {value:100, name:'未发放'},
          {value:100, name:'生产中'}
        ]
      }
    ]
  }
  myChart.setOption(option)
}

export function toOrderType(type) {
  this.$router.push({path: `/perspectiveandtracking/orderperspectivetracking/orderperspective/${type}`})
}

export function toLineList(item, index) {
  this.$router.push({name: 'LineList', params: item})
}
