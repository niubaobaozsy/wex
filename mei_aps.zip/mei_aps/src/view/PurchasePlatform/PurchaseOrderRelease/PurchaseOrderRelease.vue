<template>
  <div style="padding: 47px 0 45px">
    <van-nav-bar left-arrow fixed left-text="返回" title="采购订单下达" @click-left="back"></van-nav-bar>
    <code-search text="物料编码" require type="material" :url="url" @getCodeData="getMaterialCode"></code-search>
    <date text="下单日期" @showValue="getDateData"></date>
    <picker text="自制采购" :pickValueList="list" @getPickValue="getPickValue"></picker>
    <picker text="来源类型" :pickValueList="values" @getPickValue="getPickValue"></picker>
    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="toPurchaseOrderList">查询</van-button>
    </div>
  </div>
</template>

<script>
  import * as methods from './module'
  import CodeSearch from '../../../components/CodeSearch'
  import Date from '../../../components/Date'
  import Picker from '../../../components/Picker'
  export default{
      name: 'PurchaseOrderRelease',
      components: { CodeSearch, Date, Picker },
      data() {
          return{
              url: '',
              materialCode: '',
              sd: this.$common.formatDate(''),
              ed: this.$common.formatDate(''),
              list: ['否', '是'],
              values: ['全部', '部分']
          }
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "purchaseOrderRelease.scss";
</style>
