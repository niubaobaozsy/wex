import PurchaseOrderReleaseList from './PurchaseOrderReleaseList.vue'

export default PurchaseOrderReleaseList
