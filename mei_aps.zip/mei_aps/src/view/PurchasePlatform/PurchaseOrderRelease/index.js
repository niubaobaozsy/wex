import PurchaseOrderRelease from './PurchaseOrderRelease.vue'

export default PurchaseOrderRelease
