export function back() {
  this.$router.go(-1);
}

export function getMaterialCode(code) {
  this.materialCode = code;
}

export function getDateData(data) {
  if(data.type === 'start'){
    this.sd = data.value;
  }else{
    this.ed = data.value;
  }
}

export function getPickValue(data) {
  console.log(data)
}

export function toPurchaseOrderList() {
  this.$router.push({ name: 'PurchaseOrderReleaseList' })
}
