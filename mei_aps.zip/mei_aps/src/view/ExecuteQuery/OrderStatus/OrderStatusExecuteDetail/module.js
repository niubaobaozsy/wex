export function backToListDetail() {
  this.$router.go(-1);
}
