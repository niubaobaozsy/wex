<template>
  <div style="padding: 47px 0 45px;">
    <van-nav-bar left-arrow fixed title="需求工作台查询" left-text="返回" @click-left="backToHome">
    </van-nav-bar>
    <code-search text="物料编码" type="material" @getCodeData="getMaterialCode"></code-search>
    <div class="order-num common-list-style">
      <span class="common-font-style">订单号</span>
      <span class="code"><input type="text" placeholder="请输入订单号" v-model="orderNum"></span>
    </div>
    <date require @showValue="getDemandDate"></date>
    <code-search require text="订单来源" type="orderFrom"></code-search>

    <div class="material-code common-list-style" @click="showSelectPopup">
      <span class="common-font-style">需求状态</span>
      <span class="code">{{demandStateText}}</span>
      <span><van-icon name="arrow" size="20px"></van-icon></span>
    </div>
    <van-actionsheet v-model="showSelect" :actions="demandStateOptions" cancel-text="取消" @select="selectOption" @cancel="closeSelectPopup"/>

    <div class="query-button">
      <van-button class="self-button-style" type="primary" @click="toOrderStatusList">查询</van-button>
    </div>
  </div>
</template>

<script>
    import * as methods from './module'
    import CodeSearch from '../../../components/CodeSearch'
    import Date from '../../../components/Date'
    export default{
        name: 'Query',
        components: { CodeSearch, Date },
        data(){
            return {
              materialCode: '',
              orderNum: '',
              startDate: this.$common.formatDate(''),
              endDate: this.$common.formatDate(''),
              orderFrom: '',
              showSelect: false,
              visibleItemCount: 3,
              demandStateText: 'NEW 新增',
              demandStateVal: 'new',
              demandStateOptions: [
                { key: 'update', name: 'UPDATED 修改'},
                { key: 'new', name: 'NEW 新增'},
                { key: 'cancelled', name: 'CANCELLED 取消'},
              ]
            }
        },
        methods
    }
</script>

<style>

</style>
<style lang="scss" scoped>
    @import "query.scss";
</style>
