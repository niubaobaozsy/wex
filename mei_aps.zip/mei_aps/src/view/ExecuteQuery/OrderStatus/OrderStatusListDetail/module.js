export function backToListDetail() {
  this.$router.go(-1);
}

export function toExecuteDetail() {
  this.$router.push({ name: 'ExecuteQueryOrderStatusExecuteDetail'})
}
