export function backToHome() {
  this.$router.go(-1);
}

export function getMaterialCode(value) {
  this.materialCode = value;
}

export function getDemandDate(data) {
  if(data.type === 'start'){
    this.startDate = data.value;
  }else{
    this.endDate = data.value
  }
}

export function showSelectPopup() {
  this.showSelect = true;
}

export function closeSelectPopup() {
  this.showSelect = false;
}

export function selectOption(data) {
  if(typeof data === 'object'){
    this.$emit('input', data.value);
  }else{
    this.$emit('input', data);
  }
  this.showSelect = false;
  this.demandStateText = data.name;
  this.demandStateVal = data.key;
}

export function toOrderStatusList() {
  let data = {
    materialCode: this.materialCode,
    orderNum: this.orderNum,
    startDate: this.startDate,
    endDate: this.endDate,
    orderFrom: this.orderFrom,
    demandStateVal: this.demandStateVal,
  };
  // this.$store.commit('DEMAND_WORKBENCH_INFO', data);
  this.$router.push({ name: 'ExecuteQueryOrderStatusList', params: data })
}
