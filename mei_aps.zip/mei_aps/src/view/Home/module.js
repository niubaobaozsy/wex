export function toMessage() {
  this.$router.push({ name: 'Message' })
}
