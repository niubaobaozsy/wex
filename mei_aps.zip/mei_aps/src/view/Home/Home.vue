<template>
  <div style="padding: 47px 0 0; background-color: #2a2a39">
    <van-nav-bar left-text="" left-arrow fixed>
      <span slot="title" class="home-title">排程易APS</span>
      <nav-bar-select v-model="factoryCode" :options="list" slot="right"></nav-bar-select>
    </van-nav-bar>
    <div style="padding: 0.32rem; background-color: #34344A; margin-bottom: 10px">
      <div class="home-cover"></div>
      <van-notice-bar :text="text" left-icon="volume-o" mode="link" class="notice-bar" @click="toMessage"></van-notice-bar>
      <!--<div class="newest-notice-area">-->
        <!--<span class="fl">最新的一条通知</span>-->
        <!--<span class="fr">更多</span>-->
      <!--</div>-->
    </div>
    <van-collapse v-model="activeNames">
      <van-collapse-item title="需求管理" name="1" class="interval">
        <router-link :to="{ path: '/demandmanage/demandinterface' }"><div class="menu-list-item fl demand-interface">需求接口</div></router-link>
        <router-link :to="{ path: '/demandmanage/demandworkbench' }"><div class="menu-list-item fl demand-interface-workbench">需求工作台</div></router-link>
      </van-collapse-item>
      <van-collapse-item title="生产计划" name="2" class="interval">
        <router-link :to="{ path: '/productionplan/documentaryworkbench' }"><div class="menu-list-item fl documentary-workbench">跟单件下达</div></router-link>
        <router-link :to="{ path: '/productionplan/shareworkbench' }"><div class="menu-list-item fl share-workbench">共享件下达</div></router-link>
        <!--<router-link :to="{ path: '/productionplan/manualworkorder' }"><div class="menu-list-item fl">手工工单</div></router-link>-->
      </van-collapse-item>
      <van-collapse-item title="车间排产" name="3" class="interval">
        <!--<div class="menu-list-item fl">工单查询修改</div>-->
        <router-link :to="{ path: '/workshopscheduling/schedulingtable' }"><div class="menu-list-item fl scheduling-table">排产表</div></router-link>
        <router-link :to="{ path: '/workshopscheduling/workshopschedule' }"><div class="menu-list-item fl workshop-schedule">车间排产</div></router-link>
        <router-link :to="{ path: '/workshopscheduling/mantissaprocess'}"><div class="menu-list-item fl mantissa-process">尾数处理</div></router-link>
      </van-collapse-item>
      <van-collapse-item title="KPI绩效" name="4" class="interval">
        <!--<router-link :to="{ path: '/kpiview/kpiperformance' }"><div class="menu-list-item fl">KPI绩效</div></router-link>-->
        <router-link :to="{ path: '/perspectiveandtracking/orderperspectivetracking' }"><div class="menu-list-item fl kpi">业绩KPI</div></router-link>
      </van-collapse-item>
      <van-collapse-item title="采购平台" name="6" class="interval">
        <router-link :to="{ path: '/purchaseplatform/purchaseorderrelease' }"><div class="menu-list-item fl purchase-order-release">采购订单下达</div></router-link>
        <!--<div class="menu-list-item fl">采购订单管理</div>-->
        <!--<div class="menu-list-item fl">采购订单批量下达</div>-->
      </van-collapse-item>
      <van-collapse-item title="备料平台" name="7">
        <router-link :to="{ path: '/preparationplatform/deliverynotice' }"><div class="menu-list-item fl delivery-notice">送货通知下达</div></router-link>
        <!--<div class="menu-list-item fl">一键下达</div>-->
        <!--<div class="menu-list-item fl">送货通知手工下达</div>-->
        <router-link :to="{ path: '/preparationplatform/deliverynoticequery' }"><div class="menu-list-item fl delivery-notice-query">送货通知查询</div></router-link>
        <!--<div class="menu-list-item fl">内仓送货单查询</div>-->
        <!--<div class="menu-list-item fl">外租仓送货单查询</div>-->
        <!--<div class="menu-list-item fl">一键下达</div>-->
        <!--<div class="menu-list-item fl">内仓送货单查询</div>-->
        <!--<div class="menu-list-item fl">外租仓送货单查询</div>-->
      </van-collapse-item>
      <!--<van-collapse-item title="执行查询" name="8">-->
        <!--<router-link :to="{ path: '/executequery/orderstatus'}"><div class="menu-list-item fl">订单状态</div></router-link>-->
        <!--<div class="menu-list-item fl">工单状态</div>-->
        <!--<div class="menu-list-item fl">一键查</div>-->
        <!--<div class="menu-list-item fl">供应需求查询</div>-->
        <!--<div class="menu-list-item fl">现有量查询</div>-->
        <!--<div class="menu-list-item fl">缺料查询</div>-->
        <!--<div class="menu-list-item fl">批准供应商查询</div>-->
      <!--</van-collapse-item>-->
    </van-collapse>
  </div>
</template>

<script>
import * as methods from './module';
import NavBarSelect from '../../components/NavBarSelect'
export default{
    name: 'Home',
    components: { NavBarSelect },
    data(){
        return {
            activeNames: ['1','2','3','4','5','6','7'],
            text: '【2019-3-28 10:20:31】 aps_admin  非洲区域订单（业务员：黄婷）取消了客户订单，数量300套。',
            list: [
                {text: 'M01顺德工厂', value: 'M01'},
                {text: 'M04芜湖工厂', value: 'M04'},
                {text: 'M09南沙工厂', value: 'M09'}
            ],
            factoryCode: 'M01'
        }
    },
    methods
}
</script>

<style>
  .van-collapse-item__title{
    background-color: #34344A !important;
    color: #ffffff !important;
    font-size: 18px !important;
    font-weight: bold !important;
  }
  .van-collapse-item__content{
    overflow: hidden;
    padding: 0 !important;
    background-color: #34344A !important;
    margin-top: 2px;
    padding: 0.3rem 0.3rem !important;
  }
  .van-cell:not(:last-child)::after{
    border: none !important;
  }
  .van-hairline--top-bottom::after{
    border-width: 0 !important;
  }
  .van-hairline--top::after{
    border-top-width: 0 !important;
  }
</style>
<style lang="scss" scoped>
@import "home.scss";
</style>
