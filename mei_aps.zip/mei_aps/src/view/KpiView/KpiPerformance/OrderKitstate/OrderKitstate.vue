<template>
  <div style="padding: 47px 0;">
    <van-nav-bar title="工单齐套率" left-arrow fixed left-text="返回" @click-left="backToKpiPerformance"></van-nav-bar>
    <div id="chart" style="width: 100%; height: 61vw; background-color: #fff"></div>
    <div class="list-title">
      <span>计划组</span>
      <span>工单数</span>
      <span>齐套数</span>
      <span>齐套率</span>
    </div>
    <ul>
      <li class="list-content" v-for="(item, index) in items" :key="index">
        <span>{{item.planGroup}}</span>
        <span>{{item.orderNum}}</span>
        <span>{{item.kitNum}}</span>
        <span :class="{ 'danger': item.kitRate.replace(/%/g,'') <= 80, 'warning': item.kitRate.replace(/%/g,'') > 80 && item.kitRate.replace(/%/g,'') < 100, 'success': item.kitRate.replace(/%/g,'') == 100 }">{{item.kitRate}}</span>
      </li>
    </ul>
  </div>
</template>

<script>
  import * as methods from './module'
  export default{
      name: 'OrderKitstate',
      data() {
          return{
              items: [
                  {
                      planGroup: '精益01',
                      orderNum: 172630,
                      kitNum: 170904,
                      kitRate: '90%'
                  },
                  {
                      planGroup: '日韩01',
                      orderNum: 172630,
                      kitNum: 170904,
                      kitRate: '95%'
                  },
                  {
                      planGroup: '内销01',
                      orderNum: 172630,
                      kitNum: 170904,
                      kitRate: '80%'
                  },
                  {
                      planGroup: '精品01',
                      orderNum: 172630,
                      kitNum: 170904,
                      kitRate: '90%'
                  },
                  {
                      planGroup: '滴胶01',
                      orderNum: 172630,
                      kitNum: 170904,
                      kitRate: '100%'
                  },
                  {
                      planGroup: '零配01',
                      orderNum: 172630,
                      kitNum: 170904,
                      kitRate: '100%'
                  },
                  {
                      planGroup: '注塑01',
                      orderNum: 172630,
                      kitNum: 170904,
                      kitRate: '100%'
                  }
              ]
          }
      },
      mounted() {
          this.drawKitBar();
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "orderKitstate.scss";
</style>
