export function backToKpiPerformance() {
  this.$router.go(-1);
}

export function drawKitBar() {
  let option = {
    color: ['#EE7621'],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
        }
      },
    grid: {
      left: '3%',
      right: '3%',
      top: '10%',
      bottom: '2%',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        data: ['精益01', '日韩01', '内销01', '精品01', '滴胶01', '零配01', '注塑01'],
        axisTick: {
          alignWithLabel: true
        },
        axisLabel:{
          interval: 0
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        min: 0,
        max: 100,
        interval: 20,
        axisLabel: {
          formatter: '{value}%'
        }
      }
    ],
    series: [
      {
        name: '齐套率',
        type: 'bar',
        data: [90, 95, 80, 90, 100, 100, 100],
        barWidth: '30%',
        label: {
          normal: {
            show: true,
            position: 'top',
            formatter: '{c}%',
            color: 'black'
          }
        }
      }
    ]
  }
  let myChart = this.$echarts.init(document.getElementById('chart'));
  myChart.setOption(option);
}
