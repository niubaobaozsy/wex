<template>
  <div style="padding: 47px 0 0;">
    <van-nav-bar left-arrow fixed title="订单达成" left-text="返回" @click-left="backToKpiPerformance">
      <select-options text="全部订单" :options="list" @getSelectedOption="getDataBasedOfOrderType" slot="right"></select-options>
    </van-nav-bar>
    <div class="tab-bar">
      <span @click="getDataBasedOfTime('week')" :class="{ current : isWeek }">周</span>
      <span @click="getDataBasedOfTime('month')" :class="{ current : isMonth }">月</span>
      <span @click="getDataBasedOfTime('year')" :class="{ current : isYear }">年</span>
    </div>
    <div id="bar" style="width: 100%; height: 61vw; background-color: #fff"></div>
    <div class="list-title">
      <span>日期</span>
      <span>计划</span>
      <span>达成</span>
      <span>达成率</span>
  </div>
    <ul>
      <li class="list-content" v-for="(item, index) in items" :key="index">
        <span>{{item.date}}</span>
        <span>{{item.all}}</span>
        <span>{{item.complete}}</span>
        <span :class="{ 'success': item.completeRate.replace(/%/g,'') == 100, 'danger': item.completeRate.replace(/%/g,'') <= 80, 'warning': item.completeRate.replace(/%/g,'') > 80 && item.completeRate.replace(/%/g,'') <= 95 }">{{item.completeRate}}</span>
      </li>
    </ul>
  </div>
</template>

<script>
  import * as methods from './module'
  import SelectOptions from '../../../../components/SelectOptions'
  export default{
      name: 'OrderReach',
      components: { SelectOptions },
      data() {
          return{
              list: ['全部订单', '外销订单', '内销订单'],
              isWeek: true,
              isMonth: false,
              isYear: false,
              items: [
                  {
                      date: '2018-09-20',
                      all: 172630,
                      complete: 170904,
                      completeRate: '99%'
                  },
                  {
                      date: '2018-09-21',
                      all: 323881,
                      complete: 307687,
                      completeRate: '95%'
                  },
                  {
                      date: '2018-09-22',
                      all: 253607,
                      complete: 248535,
                      completeRate: '98%'
                  },
                  {
                      date: '2018-09-23',
                      all: 296672,
                      complete: 296672,
                      completeRate: '100%'
                  },
                  {
                      date: '2018-09-24',
                      all: 319597,
                      complete: 255678,
                      completeRate: '80%'
                  },
                  {
                      date: '2018-09-25',
                      all: 247029,
                      complete: 234678,
                      completeRate: '95%'
                  },{
                      date: '2018-09-26',
                      all: 217211,
                      complete: 215039,
                      completeRate: '99%'
                  }
              ]
          }
      },
      mounted() {
          this.getDataBasedOfTime('week');
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "orderReach";
</style>
