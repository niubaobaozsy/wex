import KpiPerformance from './KpiPerformance.vue'

export default KpiPerformance
