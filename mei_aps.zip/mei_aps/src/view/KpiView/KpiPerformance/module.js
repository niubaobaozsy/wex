export function drawLineAndBarChart() {
  let kpi = this.$echarts.init(document.getElementById("kpi"));
  let option = {
    color: ['	#5CACEE', '#EE7621'],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        crossStyle: {
          color: '#999'
        }
      }
    },
    grid: {
      left: '5%',
      right: '5%',
      top: '15%',
      bottom: '0',
      containLabel: true,
    },
    xAxis: [
        {
          type: 'category',
          data: ['2018/09/20', '2018/09/21', '2018/09/22', '2018/09/23', '2018/09/24', '2018/09/25', '2018/09/26'],
          axisPointer: {
            type: 'shadow'
          },
          axisLabel: {
            rotate: 50
          }
        }
      ],
    yAxis: [
        {
          type: 'value',
          name: '数量',
          min: 0,
          max: 350000,
          interval: 50000,
        },
        {
          type: 'value',
          name: '百分比',
          min: 0,
          max: 140,
          interval: 20,
          axisLabel: {
            formatter: '{value}%'
          }
        }
      ],
    series: [
        {
          name: '数量',
          type: 'bar',
          barWidth: '35%',
          data: [70000, 100000, 50000, 120000, 220000, 130000, 300000]
        },
        {
          name: '百分比',
          type: 'line',
          yAxisIndex: 1,
          data: [5, 7, 3, 11, 27, 35, 56]
        }
      ]
  }
  kpi.setOption(option);
}

export function getFactoryKpiPerformanceData(value) {
  console.log(value)
}
export function backToHome() {
  this.$router.go(-1);
}
