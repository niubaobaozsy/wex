<template>
  <div style="padding: 47px 0 0;">
    <van-nav-bar left-arrow fixed left-text="返回" @click-left="backToHome" title="绩效看板">
      <select-options text="M01" :options="list" @getSelectedOption="getFactoryKpiPerformanceData" slot="right"></select-options>
    </van-nav-bar>
    <div id="kpi" style="width: 100%; height: 61vw; background-color: #fff"></div>
    <router-link tag="div" :to="{ name: 'OrderReach' }"><div class="kpi-item-common">订单达成</div></router-link>
    <div class="kpi-item-common">排产变动</div>
    <router-link tag="div" :to="{ name: 'OrderKitstate' }"><div class="kpi-item-common">工单齐套</div></router-link>
    <div class="kpi-item-common">资源负荷</div>
    <div class="kpi-item-common">备货达成</div>
  </div>
</template>

<script>
  import * as methods from './module'
  import SelectOptions from '../../../components/SelectOptions'
  export default{
      name: 'KpiPerformance',
      components: { SelectOptions },
      data() {
          return{
              list: [
                  {text: 'M01顺德工厂', value: 'M01'},
                  {text: 'M04芜湖工厂', value: 'M04'},
                  {text: 'M09南沙工厂', value: 'M09'}
              ]
          }
      },
      mounted() {
          this.drawLineAndBarChart();
      },
      methods
  }
</script>

<style lang="scss" scoped>
  @import "kpiPerformance";
</style>
