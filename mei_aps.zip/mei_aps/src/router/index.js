import Vue from 'vue'
import Router from 'vue-router'
import Home from '../view/Home'
import Message from '../view/Message/Message.vue'
import DemandInterface from '../view/DemandManage/DemandInterface'
import DemandInterfaceList from '../view/DemandManage/DemandInterface/DmandInterfaceList'
import MantissaProcess from '../view/WorkshopScheduling/MantissaProcess'
import MantissaMakeorder from '../view/WorkshopScheduling/MantissaProcess/MantissaMakeorder'
import CollaborativeList from '../view/WorkshopScheduling/MantissaProcess/CollaborativeList'
import MantissaMakeorderDetail from '../view/WorkshopScheduling/MantissaProcess/MantissaMakeorderDetail'
import InitCollaboration from '../view/WorkshopScheduling/MantissaProcess/InitCollaboration'
import DemandInterfaceDetail from '../view/DemandManage/DemandInterface/DemandInterfaceDetail'
import KpiPerformance from '../view/KpiView/KpiPerformance'
import OrderReach from '../view/KpiView/KpiPerformance/OrderReach'
import OrderKitstate from '../view/KpiView/KpiPerformance/OrderKitstate'
import DemandWorkbench from '../view/DemandManage/DemandWorkbench'
import DemandWorkbenchList from '../view/DemandManage/DemandWorkbench/DemandWorkbenchList'
import DemandWorkbenchDetail from '../view/DemandManage/DemandWorkbench/DemandWorkbenchDetail'
import HistoryRecord from '../view/DemandManage/DemandWorkbench/HistoryRecord'
import DocumentaryWorkbench from '../view/ProductionPlan/DocumentaryWorkbench'
import DocumentaryWorkbenchList from '../view/ProductionPlan/DocumentaryWorkbench/DocumentaryWorkbenchList'
import DocumentaryWorkbenchDetailList from '../view/ProductionPlan/DocumentaryWorkbench/DocumentaryWorkbenchDetailList'
import DocumentaryWorkbenchDetail from '../view/ProductionPlan/DocumentaryWorkbench/DocumentaryWorkbenchDetail'
import WorkshopSchedule from '../view/WorkshopScheduling/WorkshopSchedule'
import WorkshopScheduleList from '../view/WorkshopScheduling/WorkshopSchedule/WorkshopScheduleList'
import WorkshopScheduleDetail from '../view/WorkshopScheduling/WorkshopSchedule/WorkshopScheduleDetail'
import SchedulingTable from '../view/WorkshopScheduling/SchedulingTable'
import ScheduleTableList from '../view/WorkshopScheduling/SchedulingTable/ScheduleTableList'
import ScheduleTableDetail from '../view/WorkshopScheduling/SchedulingTable/ScheduleTableDetail'
import ShareWorkbench from '../view/ProductionPlan/ShareWorkbench'
import ShareWorkbenchList from '../view/ProductionPlan/ShareWorkbench/ShareWorkbenchList'
import ShareWorkbenchDetail from '../view/ProductionPlan/ShareWorkbench/ShareWorkbenchDetail'
import ManualWorkOrder from '../view/ProductionPlan/ManualWorkOrder'
import OrderPerspectiveTracking from '../view/PerspectiveAndTracking/OrderPerspectiveTracking'
import JobPerspective from '../view/PerspectiveAndTracking/OrderPerspectiveTracking/JobPerspective'
import OrderPerspective from '../view/PerspectiveAndTracking/OrderPerspectiveTracking/OrderPerspective'
import OrderQuery from '../view/PerspectiveAndTracking/OrderPerspectiveTracking/OrderQuery'
import OrderType from '../view/PerspectiveAndTracking/OrderPerspectiveTracking/OrderType'
import LineList from '../view/PerspectiveAndTracking/OrderPerspectiveTracking/LineList'
import LineDetail from '../view/PerspectiveAndTracking/OrderPerspectiveTracking/LineDetail'
import OrderDetail from '../view/PerspectiveAndTracking/OrderPerspectiveTracking/OrderDetail'
import DepartmentOrder from '../view/PerspectiveAndTracking/OrderPerspectiveTracking/DepartmentOrder'
import PurchaseOrderDetail from '../view/PerspectiveAndTracking/OrderPerspectiveTracking/PurchaseOrderDetail'
import OrderCycle from '../view/PerspectiveAndTracking/OrderPerspectiveTracking/OrderCycle'
import FactoryOrderCycle from '../view/PerspectiveAndTracking/OrderPerspectiveTracking/FactoryOrderCycle'
import PurchaseOrderRelease from '../view/PurchasePlatform/PurchaseOrderRelease'
import PurchaseOrderReleaseList from '../view/PurchasePlatform/PurchaseOrderRelease/PurchaseOrderReleaseList'
import DeliveryNotice from '../view/PreparationPlatform/DeliveryNotice'
import DeliveryNoticeList from '../view/PreparationPlatform/DeliveryNotice/DeliveryNoticeList'
import DeliveryNoticeDetail from '../view/PreparationPlatform/DeliveryNotice/DeliveryNoticeDetail'
import DeliveryNoticeQuery from '../view/PreparationPlatform/DeliveryNoticeQuery'
import DeliveryNoticeQueryList from '../view/PreparationPlatform/DeliveryNoticeQuery/DeliveryNoticeQueryList'
import DeliveryNoticeQueryDetail from '../view/PreparationPlatform/DeliveryNoticeQuery/DeliveryNoticeQueryDetail'
import Transfer from '../view/PreparationPlatform/DeliveryNoticeQuery/Transfer/Transfer.vue'

import ExecuteQueryOrderStatus from '../view/ExecuteQuery/OrderStatus/Query'
import ExecuteQueryOrderStatusList from '../view/ExecuteQuery/OrderStatus/OrderStatusList/List'
import ExecuteQueryOrderStatusListDetail from '../view/ExecuteQuery/OrderStatus/OrderStatusListDetail/Detail'
import ExecuteQueryOrderStatusExecuteDetail from '../view/ExecuteQuery/OrderStatus/OrderStatusExecuteDetail/Detail'

Vue.use(Router)

export default new Router({
  mode: 'history',
  scrollBehavior (to, from, savePosition) {
    // console.log('from',from) // from：离开的路由对象，哪里来
    // console.log('to',to) // to：要进入的目标路由对象，到哪里去
    // console.log(savePosition) // savePosition：会记录滚动条的坐标，点击前进/后退的时候记录值{x:?,y:?}
    if(from.name === 'DemandInterfaceList' && to.name === 'DemandInterface'){
      console.log(this);
      this.app.$store.commit('LIST', []);
    }
    if(savePosition) {
      return savePosition;
    }else{
      return {x:0,y:0}
    }
  },
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/message',
      name: 'Message',
      component: Message
    },
    {
      path: '/demandmanage/demandinterface',
      name: 'DemandInterface',
      component: DemandInterface
    },
    {
      path: '/demandmanage/demandinterface/demandinterfacelist',
      name: 'DemandInterfaceList',
      component: DemandInterfaceList
    },
    {
      path: '/demandmanage/demandinterface/demandinterfacedetail',
      name: 'DemandInterfaceDetail',
      component: DemandInterfaceDetail
    },
    {
      path: '/workshopscheduling/mantissaprocess',
      name: 'MantissaProcess',
      component: MantissaProcess
    },
    {
      path: '/workshopscheduling/mantissaprocess/mantissamakerorder',
      name: 'MantissaMakeorder',
      component: MantissaMakeorder
    },
    {
      path: '/workshopscheduling/mantissaprocess/collaborativelist',
      name: 'CollaborativeList',
      component: CollaborativeList
    },
    {
      path: '/workshopscheduling/mantissaprocess/mantissamakeorderdetail',
      name: 'MantissaMakeorderDetail',
      component: MantissaMakeorderDetail
    },
    {
      path: '/workshopscheduling/mantissaprocess/initcollaboration',
      name: 'InitCollaboration',
      component: InitCollaboration
    },
    {
      path: '/kpiview/kpiperformance',
      name: 'KpiPerformance',
      component: KpiPerformance
    },
    {
      path: '/kpiview/kpiperformance/orderreach',
      name: 'OrderReach',
      component: OrderReach
    },
    {
      path: '/kpiview/kpiperformance/orderkitstate',
      name: 'OrderKitstate',
      component: OrderKitstate
    },
    {
      path: '/demandmanage/demandworkbench',
      name: 'DemandWorkbench',
      component: DemandWorkbench
    },
    {
      path: '/demandmanage/demandworkbench/demandworkbenchlist',
      name: 'DemandWorkbenchList',
      component: DemandWorkbenchList
    },
    {
      path: '/demandmanage/demandworkbench/demandworkbenchdetail',
      name: 'DemandWorkbenchDetail',
      component: DemandWorkbenchDetail
    },
    {
      path: '/demandmanage/demandworkbench/historyrecord',
      name: 'HistoryRecord',
      component: HistoryRecord
    },
    {
      path: '/productionplan/documentaryworkbench',
      name: 'DocumentaryWorkbench',
      component: DocumentaryWorkbench
    },
    {
      path: '/productionplan/documentaryworkbench/documentaryworkbenchlist',
      name: 'DocumentaryWorkbenchList',
      component: DocumentaryWorkbenchList
    },
    {
      path: '/productionplan/documentaryworkbench/documrntaryworkbenchdetaillist',
      name: 'DocumentaryWorkbenchDetailList',
      component: DocumentaryWorkbenchDetailList
    },
    {
      path: '/productionplan/documentaryworkbench/documentaryworkbwnchdetail',
      name: 'DocumentaryWorkbenchDetail',
      component: DocumentaryWorkbenchDetail
    },
    {
      path: '/workshopscheduling/workshopschedule',
      name: 'WorkshopSchedule',
      component: WorkshopSchedule
    },
    {
      path: '/workshopscheduling/workshopschedule/workshopschedulelist',
      name: 'WorkshopScheduleList',
      component: WorkshopScheduleList
    },
    {
      path: '/workshopscheduling/workshopschedule/workshopscheduledetail',
      name: 'WorkshopScheduleDetail',
      component: WorkshopScheduleDetail
    },
    {
      path: '/workshopscheduling/schedulingtable',
      name: 'SchedulingTable',
      component: SchedulingTable
    },
    {
      path: '/workshopscheduling/schedulingtable/scheduletablelist',
      name: 'ScheduleTableList',
      component: ScheduleTableList
    },
    {
      path: '/workshopscheduling/schedulingtable/scheduletabledetail',
      name: 'ScheduleTableDetail',
      component: ScheduleTableDetail
    },
    {
      path: '/productionplan/shareworkbench',
      name: 'ShareWorkbench',
      component: ShareWorkbench
    },
    {
      path: '/productionplan/shareworkbench/shareworkbenchlist',
      name: 'ShareWorkbenchList',
      component: ShareWorkbenchList
    },
    {
      path: '/productionplan/shareworkbench/shareworkbenchdetail',
      name: 'ShareWorkbenchDetail',
      component: ShareWorkbenchDetail
    },
    {
      path: '/productionplan/manualworkorder',
      name: 'ManualWorkOrder',
      component: ManualWorkOrder
    },
    {
      path: '/perspectiveandtracking/orderperspectivetracking',
      // name: 'OrderPerspectiveTracking',
      component: OrderPerspectiveTracking,
      beforeEnter: (to, from, next) => {
        if(from.name === 'Home'){
          this.a.app.$store.commit('RESET_BACK_TO_HOME_COUNT');
          this.a.app.$store.commit('ORDER_PERSPECTIVE_TRACKING_TAB_RECORD', {jobPath: '', orderPath: '', queryPath: '', jobCurrent: true, orderCurrent: false, queryCurrent: false});
        }
        next();
      },
      children: [
        {
          path: '',
          name: 'JobPerspective',
          component: JobPerspective
        },
        {
          path: '/perspectiveandtracking/orderperspectivetracking/orderperspective',
          name: 'OrderPerspective',
          component: OrderPerspective
        },
        {
          path: '/perspectiveandtracking/orderperspectivetracking/orderquery',
          name: 'OrderQuery',
          component: OrderQuery
        },
        {
          path: '/perspectiveandtracking/orderperspectivetracking/ordercycle',
          name: 'OrderCycle',
          component: OrderCycle
        }
      ]
    },
    {
      path: '/perspectiveandtracking/orderperspectivetracking/linelist',
      name: 'LineList',
      component: LineList
    },
    {
      path: '/perspectiveandtracking/orderperspectivetracking/orderperspective/:type',
      name: 'OrderType',
      component: OrderType
    },
    {
      path: '/perspectiveandtracking/orderperspectivetracking/linedetail',
      name: 'LineDetail',
      component: LineDetail
    },
    {
      path: '/perspectiveandtracking/orderperspectivetracking/orderdetail',
      name: 'OrderDetail',
      component: OrderDetail
    },
    {
      path: '/perspectiveandtracking/orderperspectivetracking/departmentorder',
      name: 'DepartmentOrder',
      component: DepartmentOrder
    },
    {
      path: '/perspectiveandtracking/orderperspectivetracking/purchaseorderdetail',
      name: 'PurchaseOrderDetail',
      component: PurchaseOrderDetail
    },
    {
      path: '/perspectiveandtracking/orderperspectivetracking/factoryordercycle',
      name: 'FactoryOrderCycle',
      component: FactoryOrderCycle
    },
    {
      path: '/purchaseplatform/purchaseorderrelease',
      name: 'PurchaseOrderRelease',
      component: PurchaseOrderRelease
    },
    {
      path: '/purchaseplatform/purchaseorderrelease/purchaseorderreleaselist',
      name: 'PurchaseOrderReleaseList',
      component: PurchaseOrderReleaseList
    },
    {
      path: '/preparationplatform/deliverynotice',
      name: 'DeliveryNotice',
      component: DeliveryNotice
    },
    {
      path: '/preparationplatform/deliverynotice/deliverynoticelist',
      name: 'DeliveryNoticeList',
      component: DeliveryNoticeList
    },
    {
      path: '/preparationplatform/deliverynotice/deliverynoticedetail',
      name: 'DeliveryNoticeDetail',
      component: DeliveryNoticeDetail
    },
    {
      path: '/preparationplatform/deliverynoticequery',
      name: 'DeliveryNoticeQuery',
      component: DeliveryNoticeQuery
    },
    {
      path: '/preparationplatform/deliverynoticequery/deliverynoticequerylist',
      name: 'DeliveryNoticeQueryList',
      component: DeliveryNoticeQueryList
    },
    {
      path: '/preparationplatform/deliverynoticequery/deliverynoticequerydetail',
      name: 'DeliveryNoticeQueryDetail',
      component: DeliveryNoticeQueryDetail
    },
    {
      path: '/preparationplatform/deliverynoticequery/transfer',
      name: 'Transfer',
      component: Transfer
    },
    {
      path: '/executequery/orderstatus',//执行查询/订单状态
      name: 'ExecuteQueryOrderStatus',
      component: ExecuteQueryOrderStatus
    },
    {
      path: '/executequery/orderstatus/list',//执行查询/订单状态/订单状态列表
      name: 'ExecuteQueryOrderStatusList',
      component: ExecuteQueryOrderStatusList
    },
    {
      path: '/executequery/orderstatus/list/detail',//执行查询/订单状态/订单状态列表
      name: 'ExecuteQueryOrderStatusListDetail',
      component: ExecuteQueryOrderStatusListDetail
    },
    {
      path: '/executequery/orderstatus/list/executedetail',//执行查询/订单状态/订单状态列表
      name: 'ExecuteQueryOrderStatusExecuteDetail',
      component: ExecuteQueryOrderStatusExecuteDetail
    }
  ]
})
