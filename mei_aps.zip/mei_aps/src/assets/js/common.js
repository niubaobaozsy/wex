export default {
  /**
   *将时间格式化为YYYY/MM/DD
   * @param time 时间类型，为空表示当前时间
   */
  formatDate: function (time) {
    var date = time == ''? new Date() : time;
    var year = date.getFullYear();
    var month = (date.getMonth() + 1) < 10? `0${date.getMonth() + 1}` : date.getMonth() + 1;
    var day = date.getDate() < 10? `0${date.getDate()}` : date.getDate();
    return `${year}/${month}/${day}`;
  }
}
